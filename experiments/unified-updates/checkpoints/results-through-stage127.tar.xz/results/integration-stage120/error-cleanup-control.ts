import { it } from 'vitest';
import { createRoot, createSignal, createMemo, createErrorBoundary, createRenderEffect, onCleanup, flush } from '../src/index.js';
it('ordinary propagated error cleanup', () => {
  const cleaned: number[] = [];
  const [source, setSource] = createSignal(0);
  let shown = '';
  const dispose = createRoot(dispose => {
    const input = createMemo(() => { const value=source(); if(value===2) throw Error('failed'); return value; });
    const boundary = createErrorBoundary(() => {
      const owned=createMemo(() => { const value=input(); onCleanup(() => {cleaned.push(value);}); return String(value); });
      return owned();
    }, error => (error() as Error).message);
    createRenderEffect(boundary,value=>{shown=value;});
    return dispose;
  });
  flush();
  for (const n of [1,2,3]) {setSource(n); flush(); console.log(n,shown,cleaned.slice());}
  dispose();flush(); console.log('disposed',cleaned);
});
