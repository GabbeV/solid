import { writeFileSync } from 'node:fs';
import { bundle } from '../../../../scripts/size/bundle.mjs';
const result = await bundle({
  name: 'signals: scalar optimism (supplementary)',
  path: '../../packages/signals/dist/prod/index.js',
  import: '{ createSignal, createMemo, createRenderEffect, createRoot, createOptimistic, action, flush, refresh }'
});
writeFileSync(process.argv[2], JSON.stringify({name:result.name, minified:result.min, brotli:result.br}, null, 2));
