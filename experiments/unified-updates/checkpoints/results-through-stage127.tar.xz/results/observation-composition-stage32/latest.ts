/** One lazily created latest output per source, published by ordinary machinery. */
import { context, prepareComputed, read, runWithOwner, setVerdict, verdict } from "../core/core.js";
import {
  $REFRESH,
  CONFIG_HELD,
  NOT_PENDING,
  STATUS_ERROR,
  STATUS_PENDING,
  STATUS_UNINITIALIZED
} from "../core/constants.js";
import { link } from "../core/graph.js";
import type { Computed, Root, Signal } from "../core/types.js";
import { createLayerBoundary, type Layer } from "./layer.js";
import {
  initializeObservation,
  markObservation,
  type Observation,
  type ObservationKind
} from "./observation.js";

const kind: ObservationKind<any> = {
  sample: record => {
    const source = record.input;
    if (source._statusFlags & STATUS_ERROR) return NOT_PENDING;
    if (!(source._config & CONFIG_HELD) && !(source._statusFlags & STATUS_PENDING)) {
      const output = record.output;
      const value = output._pendingValue !== NOT_PENDING ? output._pendingValue : output._value;
      // A held input may have committed after this output read its old
      // value. Finish that publication before returning to ordinary reads.
      return Object.is(value, source._value) ? NOT_PENDING : source._value;
    }
    return source._pendingValue !== NOT_PENDING ? source._pendingValue : source._value;
  },
  active: record =>
    !!(record.input._config & CONFIG_HELD || record.input._statusFlags & STATUS_PENDING)
};

function fallback(layer: Layer<any>): unknown {
  const source = layer.input;
  if (typeof source._fn === "function") prepareComputed(source, false);
  if (
    (layer as Observation<any>).retiring ||
    source._statusFlags & (STATUS_ERROR | STATUS_UNINITIALIZED) ||
    (!(source._config & CONFIG_HELD) && !(source._statusFlags & STATUS_PENDING))
  )
    return read(source);
  const output = context as Computed<any>;
  link(source, output);
  if (source._height >= output._height) output._height = source._height + 1;
  return source._value;
}

const observations = new WeakMap<Signal<any>, Observation<any>>();
function latestOutput(source: Computed<any>): Computed<any> {
  const existing = observations.get(source);
  if (existing) return existing.output;
  const record = runWithOwner(null, () =>
    initializeObservation(createLayerBoundary(source, fallback, markObservation, false, true), kind)
  );
  record.statusInput = source;
  observations.set(source, record);
  return record.output;
}

let windowOwner: Computed<any> | null = null;
let outerWindow: typeof verdict = null;
function windowRead(source: Signal<any>, reader: Computed<any> | null): unknown {
  const previous = verdict;
  setVerdict(reader === windowOwner ? outerWindow : null);
  try {
    return read(reader === windowOwner ? latestOutput(source as Computed<any>) : source);
  } finally {
    setVerdict(previous);
  }
}

export function latest<T>(input: () => T): T {
  const source = (input as any)[$REFRESH] as Computed<any> | undefined;
  if (source) {
    const previous = verdict;
    if (previous === windowRead) setVerdict(outerWindow);
    try {
      return read(latestOutput(source));
    } finally {
      setVerdict(previous);
    }
  }
  const previousOwner = windowOwner,
    previousVerdict = verdict,
    previousOuter = outerWindow;
  if (previousVerdict !== windowRead) outerWindow = previousVerdict;
  windowOwner = (context as Root)?._root
    ? (context as Root)._parentComputed
    : (context as Computed<any> | null);
  setVerdict(windowRead);
  try {
    return input();
  } finally {
    windowOwner = previousOwner;
    outerWindow = previousOuter;
    setVerdict(previousVerdict);
  }
}
