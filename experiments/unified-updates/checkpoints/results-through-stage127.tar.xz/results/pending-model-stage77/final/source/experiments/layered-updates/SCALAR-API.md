# Scalar experiment entry

Current checkpoint: [pending as optimistic state, stage 77](PENDING-MODEL-77.md).
Pending outputs retain input demand like explicit optimistic booleans. Loading's
pending rearm condition retains that demand outside its content; this is an
intentional change relative to next in the working model. The original pending
feedback lifetime remains unresolved.

`packages/signals/src/experimental/scalar.ts` is the explicit experimental API.
`node experiments/layered-updates/build.mjs --scalar` builds it as
`packages/signals/dist/scalar/index.js`. The normal package entry and normal
builds keep their compatibility API. Nothing has been published.

The experimental entry exports:

- `createSignal`, `createMemo`, `createRenderEffect`, `createEffect`;
- `createRoot`, `onCleanup`, `flush`, `action`;
- `createOptimistic`, using the shared layer implementation;
- `isPending` and preliminary `latest`, using shared, source-owned observation outputs;
- scalar `refresh`, including an action's staged-answer promise;
- `createErrorBoundary`, `createLoadingBoundary`.

This is a testable scope, not a claim that every combination or option has been
validated. The acceptance audit lists the evidence and remaining gates.

## Optimistic input and lifetime

```ts
const [source, setSource] = createSignal(0);
const [view, guess] = createOptimistic(source);

const save = action(function* () {
  guess(previous => previous + 1);
  const answer = yield request();
  setSource(answer);
});
```

This entry accepts an input accessor or synchronous callback. A callback receives
its own producer’s previous result (initially undefined), including a staged
result from a preceding run in the same update context. A computation moving
above a pending lower context starts from its committed result instead. An output guess does not become that argument.
Functional guess setters use the selected output instead. An async input
can be expressed with `createMemo` and supplied through its accessor. It does
not implement the full upstream overload/options surface (initial scalar
value, equality/options). Guesses use action lifetime;
standalone ambient guesses are not implemented. Functional guesses evaluate
once and do not rebase. Input answers join the guessing actions but do not
replace the selected override until their shared lifetime ends. Delayed
downstream correction is an accepted consequence. The ordinary publication machinery holds consequences
and publishes a replacement or restoration coherently.

Both direct accessor inputs and callback inputs currently receive a separate
input computation. This preserves the scope of refresh: re-read the
boundary's input without invalidating a clean dependency. Avoiding that extra
allocation for direct accessors remains an optimization to explore once the
refresh implementation is validated further; two full nodes are not a permanent requirement.

## Scalar refresh

`refresh(memo)` invalidates that memo. `refresh(optimistic)` invalidates its own
input callback computation, including when the original argument was a tagged
accessor. Clean dependencies are read without being invalidated. Plain signals
are unchanged. Same-tick calls coalesce, and superseded requests wait for the
replacement answer. A refresh flight is quiet for `isPending`, as in next; it
cannot silence a different pending question already in progress.

The promise receives the refreshed computation's result. A caller in the
holding action can receive its staged answer before publication, permitting
`yield refresh(source)` without deadlocking that action. A caller outside that
update waits for publication. The waiter reuses ordinary computations and the
existing transaction rerun queue; it adds no ordinary-node fields or read hooks.

For an optimistic target, refresh crosses only that boundary. With an upstream
override already published as 1 and a downstream override of 10 over
`createMemo(() => first() * 2)`, refreshing the downstream boundary returns 2.
It retains 10 until its action ends under the previously accepted lifetime.
Pinned next returns 0 from its authoritative view and replaces 10 with 2 before
that action ends. Those are existing accepted model differences, not changes to
refresh's upstream invalidation scope. No authoritative duplicate graph is added.

This export accepts scalar source accessors only; refreshable stores remain
outside this experiment. See [stage 69](REFRESH-69.md) for validation and limits.

The action body returning does not finish that lifetime while an input in the
group is still pending. All overrides in the group stay selected until those
inputs settle. This includes input work derived from another guess in that group,
matching current `next`. Input errors, like input values, remain masked by a
selected override until the shared lifetime ends; current `next` can forward
those errors earlier. These cases have executable production comparisons.

`createLayer` with explicit clearing remains available only through the separate
experimental layer module as a testing scaffold. Its persistent-override
lifetime is not the public `createOptimistic` prototype contract.

## Exclusions

The scalar entry deliberately does not export stores,
`until`, deferred/reveal-order helpers, SSR/hydration, tracked-effect APIs,
or attribution APIs. Their compatibility exports elsewhere are not evidence
that they work with the scalar implementation. The observation APIs remain
preliminary;
`until` and the outside flushed-value read
exception are deferred under the user's explicit direction. Stores are paused.

Avoid combining this entry with a separately bundled normal runtime: they must
not create two reactive module instances. Cross-package renderer integration
and the complete public API replacement are not yet acceptance claims.

## Preliminary latest output

`latest` observes its argument's selected output, as accepted after the stage-30
comparison. An incoming answer hidden by an active optimistic override is not
an output proposal. A repeated guess can be an output proposal; `latest` exposes
it through its own publication, which ordinary async consequences can hold.
Direct accessors and wrapped reads share one lazily created output per source.
The latest output passes through ordinary settled synchronous updates.

`isPending(() => latest(x))` describes that latest output, including unresolved
input work. `latest(() => isPending(x))` observes the pending boolean's proposal.
The user accepted this composition rule in stage 32. With committed x=0 and
an action holding proposed x=1, the two expressions return false and true,
respectively. Upstream returns false for both; wrapping pending in a memo makes
upstream's outer latest return true. The prototype consistently composes outputs
in both forms. Each output still waits for its own ordinary async consequences.

Callback windows use a shared stack only while evaluating the callback. Nested
computations own their ordinary reads; a caller's window does not change those
computations' dependencies. New or revived observation outputs initialize from
their current proposal; existing observed outputs keep their committed value
during a hold. Initialization and revival now have Loading and ownership tests.
Sibling callback order is unspecified, as confirmed by the user and the existing
notification-order ruling. The acceptance audit records duplicate initial work
and deliberately deferred imperative flushed-value exceptions.
`latest` is not feature-complete.

The current validation checkpoint is [stage 77](PENDING-MODEL-77.md). Runtime code
is unchanged from stage 76's size and synchronous measurements against next. Tracked observation
feedback into its own pending cause remains an unresolved semantic question.
Optimistic propagation now honors ordinary memo equality, preserving downstream
owned children and independent refetch work when a memo output is unchanged.

The producer-local previous-value contract was accepted after the explicit
next/prototype comparison in stage 71. Dependency changes and repeated refreshes
are covered in `layered-previous-input.test.ts`.

The stage-74 cross-context contract is accepted for the experiment: preserve
staged history within a coordinated context, including entangled peers, but use
committed history when replacing work with a calculation in another context.
There is no saved stack of abandoned results or replay of lower reducer history.
Published optimistic values can still enter downstream calculation history;
expiration does not undo accumulation. This is not an event-delivery guarantee.
