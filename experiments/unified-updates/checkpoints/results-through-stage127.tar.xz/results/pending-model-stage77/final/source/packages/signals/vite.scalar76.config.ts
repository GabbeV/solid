import { defineConfig, mergeConfig } from 'vitest/config';
import original from './vite.config.js';
export default defineConfig(async env => mergeConfig(await original(env), {
  define: { __LEGACY_LANES__: 'false' },
  test: { include: [
    'layered-pending-observation.test.ts',
    'layered-pending-model.test.ts',
    'layered-forwarded-observation.test.ts',
    'layered-stable-context.test.ts',
    'layered-previous-context.test.ts',
    'layered-latest-errors.test.ts',
    'layered-latest-pair.test.ts'
  ] }
}));
