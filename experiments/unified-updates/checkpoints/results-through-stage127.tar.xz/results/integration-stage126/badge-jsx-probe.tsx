/**
 * @jsxImportSource @solidjs/web
 * @vitest-environment jsdom
 */
import { expect, test } from "vitest";
import { createMemo, createSignal, isPending } from "solid-js";
import { render } from "@solidjs/web";
const turn = () => new Promise<void>(resolve => setTimeout(resolve, 0));
test("ordinary details finish before the optimistic pending badge", async () => {
 const detailsAnswer = Promise.withResolvers<string>();
 const requests: {id:number,pending:boolean,answer:ReturnType<typeof Promise.withResolvers<string>>}[]=[];
 const container=document.createElement('div');
 document.body.append(container);
 function App() {
  const [id,setId]=createSignal(0);
  const details=createMemo(()=>id()===0?'Item 0':detailsAnswer.promise);
  const badge=createMemo(()=>{
   const current=id(), pending=isPending(id);
   const text=`${current}:${pending}`;
   if(current===0&&!pending)return text;
   const answer=Promise.withResolvers<string>();
   requests.push({id:current,pending,answer});
   return answer.promise;
  });
  return <><button onClick={()=>setId(1)}>Navigate</button><main><span>{id()}</span> / <span>{details()}</span> / <span>{String(isPending(id))}</span> / <span>{badge()}</span></main></>;
 }
 const dispose=render(()=><App/>,container);
 const screen=()=>container.querySelector('main')!.textContent;
 const snap=(label:string)=>process.stdout.write(JSON.stringify({label,screen:screen(),requests:requests.map(r=>`${r.id}:${r.pending}`)})+'\n');
 try {
  await turn(); expect(screen()).toBe('0 / Item 0 / false / 0:false');snap('initial');
  container.querySelector('button')!.click();await turn();snap('navigate');
  detailsAnswer.resolve('Item 1');await turn();snap('details');
  const pending=requests.find(r=>r.pending)!;
  pending.answer.resolve(`${pending.id}:${pending.pending}`);await turn();snap('pending badge');
  const correction=requests.filter(r=>r.id===1&&!r.pending).at(-1)!;
  correction.answer.resolve('1:false');await turn();snap('correction');
  expect(screen()).toBe('1 / Item 1 / false / 1:false');
 } finally { dispose(); container.remove(); }
});
