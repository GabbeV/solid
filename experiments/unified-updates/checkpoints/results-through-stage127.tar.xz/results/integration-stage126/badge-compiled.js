import { template as _$template } from "@solidjs/web";
import { insert as _$insert } from "@solidjs/web";
import { createComponent as _$createComponent } from "@solidjs/web";
import { delegateEvents as _$delegateEvents } from "@solidjs/web";
var _tmpl$ = /* @__PURE__ */ _$template(`<button>Navigate`);
var _tmpl$2 = /* @__PURE__ */ _$template(`<main><span></span> / <span></span> / <span></span> / <span>`);
/**
* @jsxImportSource @solidjs/web
* @vitest-environment jsdom
*/
import { expect, test } from "vitest";
import { createMemo, createSignal, isPending } from "solid-js";
import { render } from "../src/index.js";
const turn = () => new Promise<void>((resolve) => setTimeout(resolve, 0));
test("ordinary details finish before the optimistic pending badge", async () => {
	const detailsAnswer = Promise.withResolvers<string>();
	const requests: {
		id: number;
		pending: boolean;
		answer: ReturnType<typeof Promise.withResolvers<string>>;
	}[] = [];
	const container = document.createElement("div");
	document.body.append(container);
	function App() {
		const [id, setId] = createSignal(0);
		const details = createMemo(() => id() === 0 ? "Item 0" : detailsAnswer.promise);
		const badge = createMemo(() => {
			const current = id(), pending = isPending(id);
			const text = `${current}:${pending}`;
			if (current === 0 && !pending) return text;
			const answer = Promise.withResolvers<string>();
			requests.push({
				id: current,
				pending,
				answer
			});
			return answer.promise;
		});
		return [(() => {
			var _el$ = _tmpl$();
			_el$._$$click = () => setId(1);
			return _el$;
		})(), (() => {
			var _el$2 = _tmpl$2();
			var _el$3 = _el$2.firstChild;
			var _el$4 = _el$3.nextSibling;
			var _el$5 = _el$4.nextSibling;
			var _el$6 = _el$5.nextSibling;
			var _el$7 = _el$6.nextSibling;
			var _el$8 = _el$7.nextSibling;
			var _el$9 = _el$8.nextSibling;
			_$insert(_el$3, id, undefined, undefined, {
				name: "span.children",
				loc: "probe.tsx:25:72"
			});
			_$insert(_el$5, details, undefined, undefined, {
				name: "span.children",
				loc: "probe.tsx:25:94"
			});
			_$insert(_el$7, () => {
				return String(isPending(id));
			}, undefined, undefined, {
				name: "span.children",
				loc: "probe.tsx:25:121"
			});
			_$insert(_el$9, badge, undefined, undefined, {
				name: "span.children",
				loc: "probe.tsx:25:160"
			});
			return _el$2;
		})()];
	}
	const dispose = render(() => _$createComponent(App, {}, "App", "probe.tsx:27:27"), container);
	const screen = () => container.querySelector("main")!.textContent;
	const snap = (label: string) => process.stdout.write(JSON.stringify({
		label,
		screen: screen(),
		requests: requests.map((r) => `${r.id}:${r.pending}`)
	}) + "\n");
	try {
		await turn();
		expect(screen()).toBe("0 / Item 0 / false / 0:false");
		snap("initial");
		container.querySelector("button")!.click();
		await turn();
		snap("navigate");
		detailsAnswer.resolve("Item 1");
		await turn();
		snap("details");
		const pending = requests.find((r) => r.pending)!;
		pending.answer.resolve(`${pending.id}:${pending.pending}`);
		await turn();
		snap("pending badge");
		const correction = requests.filter((r) => r.id === 1 && !r.pending).at(-1)!;
		correction.answer.resolve("1:false");
		await turn();
		snap("correction");
		expect(screen()).toBe("1 / Item 1 / false / 1:false");
	} finally {
		dispose();
		container.remove();
	}
});
_$delegateEvents(["click"]);
