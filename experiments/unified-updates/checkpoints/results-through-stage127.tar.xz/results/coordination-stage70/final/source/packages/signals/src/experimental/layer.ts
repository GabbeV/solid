/**
 * Scalar experiment: an input producer and an ordinary output computation.
 * Explicit propose/clear isolates publication; the optional action lifetime
 * retires overrides through the same ordinary derivation and commit paths.
 * This entry does not install or use the optimistic lane engine.
 */
import { releaseFlightTeardown } from "../core/async.js";
import { computed, read } from "../core/core.js";
import { link } from "../core/graph.js";
import { NotReadyError } from "../core/error.js";
import { enqueueSub } from "../core/heap.js";
import { disposeChildren } from "../core/owner.js";
import {
  $REFRESH,
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  CONFIG_REDERIVE,
  CONFIG_STAGED,
  EFFECT_RENDER,
  NOT_PENDING,
  REACTIVE_DISPOSED,
  REACTIVE_FRAME_READ,
  REACTIVE_JOINED,
  REACTIVE_RECOMPUTING_DEPS,
  REACTIVE_ZOMBIE,
  STATUS_UNINITIALIZED,
  STATUS_PENDING,
  STATUS_ERROR
} from "../core/constants.js";
import {
  blocked,
  onScreen,
  setLayerObserved,
  setLayerVisibility,
  flushTransaction,
  globalQueue,
  setLayerCommit,
  setLayerReads,
  setLayerCompute,
  setLayerTransactions,
  holdNode,
  holdQueuedProposals,
  recomputeInUpdate,
  hasHeldNodes,
  hasUnheldProposals,
  insertSubs,
  joinFuture,
  liveTx,
  merge,
  newTransaction,
  resolveTx,
  schedule,
  staleReader,
  txOf,
  type NormalizeCalculation,
  type Transaction
} from "../core/scheduler.js";
import type { Computed, Signal } from "../core/types.js";
import { boundaries } from "./boundary.js";
import { committedDependencies, layerPosition } from "./committed-dependencies.js";

export function inputTime(input: Computed<any>): number {
  return typeof input._fn === "function" ? input._time : input._notifiedAt;
}

export type Layer<T> = {
  input: Computed<any>;
  output: Computed<T>;
  override: T | typeof NOT_PENDING;
  update: Transaction | null;
  scope: Transaction | null;
  inputTime: number;
  inputStatus?: true;
  statusInput?: Computed<any>;
  position?: number;
};

/** Value overrides retain the pending calculation of their relative input.
 * Observation boundaries do not inherit the pending state they describe. */
export function pendingInput(source: Signal<any>): Computed<any> | undefined {
  const boundary = boundaries.get(source);
  return boundary?.statusInput ?? (boundary?.inputStatus ? boundary.input : undefined);
}

const proposals = new Map<Layer<any>, unknown>();
const active = new Set<Layer<any>>();
const scoped = new Set<Layer<any>>();
// Active value boundaries forward demand, not values or notifications. No
// state is added to ordinary nodes; the scheduler consults this only for
// pending work during its existing readiness check.
const inputObservers = new Map<Computed<any>, Set<Layer<any>>>();
function forwardObservation(layer: Layer<any>, active: boolean): void {
  if (!layer.inputStatus) return;
  if (active) {
    let observers = inputObservers.get(layer.input);
    if (!observers) inputObservers.set(layer.input, (observers = new Set()));
    observers.add(layer);
    setLayerObserved(forwardedHold);
  } else {
    const observers = inputObservers.get(layer.input);
    if (observers?.delete(layer) && !observers.size) inputObservers.delete(layer.input);
    if (!inputObservers.size) setLayerObserved();
  }
}

function observed(
  node: Computed<any>,
  update: Transaction | null,
  seen = new Set<Computed<any>>()
): boolean {
  if (seen.has(node) || node._flags & REACTIVE_DISPOSED || !onScreen(node, update)) return false;
  seen.add(node);
  if ((node as any)._type === EFFECT_RENDER) return true;
  for (let edge = node._subs; edge; edge = edge._nextSub) {
    const reader = edge._sub;
    const replaces =
      update &&
      !(reader._statusFlags & (STATUS_PENDING | STATUS_ERROR)) &&
      reader._config & CONFIG_HELD &&
      txOf(reader) === resolveTx(update);
    let reads = edge._gen === reader._depGen;
    // A different pending update has not removed the displayed dependency.
    // The retained frame journal distinguishes old reads from new insertions.
    if (!reads && !replaces)
      for (const dependency of committedDependencies(reader))
        if (dependency === node) {
          reads = true;
          break;
        }
    if (reads && observed(reader, update, seen)) return true;
  }
  for (const boundary of inputObservers.get(node) || [])
    if (observed(boundary.output, update, seen)) return true;
  return false;
}

function forwardedHold(input: Computed<any>, update: Transaction | null): boolean {
  const observers = inputObservers.get(input);
  if (observers)
    for (const boundary of observers) if (observed(boundary.output, update)) return true;
  return false;
}

// CONFIG_REDERIVE absorbs status at the selector. Unlike a display boundary,
// an optimistic selector is not itself an observer once its readers disappear.
setLayerVisibility((output, update) => !boundaries.get(output) || observed(output, update));
// A child update may observe its input update's published frame without
// consuming that update's proposal. Only live child updates have this record.
// Only optimistic transactions carry a context record. Settled ordinary reads
// and ordinary nodes retain the existing storage and fast paths.
function positionOf(update: Transaction | null): number {
  return update ? (resolveTx(update)._level ?? 0) : 0;
}
const candidateUpdates = new Set<Transaction>();
const preparingEffects = new WeakSet<Computed<any>>();
let releasingInput: Transaction | null = null;
let evaluation: Computed<any> | null = null;
let evaluationReads: Map<Signal<any>, Transaction> | null = null;
let retryEvaluation = false;
const RETRY = Symbol("retry layer calculation");
const layerOwn = (node: Signal<any>, update: Transaction) => {
  const layer = boundaries.get(node);
  if (layer === undefined) return;
  // A settled selector propagates normally. If its consequences suspend,
  // ordinary parking supplies the output update and we record only its cut.
  // The selector retires its override before proposing any input answer.
  if (
    layer &&
    layer.update === null &&
    layer.override !== NOT_PENDING &&
    node._pendingValue !== NOT_PENDING &&
    !Object.is(node._value, node._pendingValue)
  )
    ownLayerUpdate(layer, update, inputUpdate(layer));
};

/** Observation boundaries install their lifecycle at these same seams.
 * Their proposals use stageLayer and the ordinary output machinery. */
export const layerHooks: {
  beforeCommit?: () => boolean;
  afterCommit?: () => void;
  active?: () => boolean;
} = {};

export function wakeLayers(): void {
  setLayerCommit(prepareLayers, settleLayers);
  schedule();
}

function enableReads(): void {
  setLayerReads(layerOwn, mergeLayers, frameRead, rederiveStatus, notifyLayer);
}

function stopIfIdle(): void {
  if (
    candidateUpdates.size ||
    active.size ||
    scoped.size ||
    proposals.size ||
    layerHooks.active?.()
  )
    return;
  setLayerCommit();
  setLayerReads();
  setLayerCompute();
}

function watchParent(update: Transaction): void {
  update = resolveTx(update);
  if (candidateUpdates.has(update)) return;
  if (!candidateUpdates.size) {
    enableReads();
    setLayerCompute(computeLayer, rerunLayer, readContext, deferJoin, detachedOutput);
  }
  candidateUpdates.add(update);
}

function isChildUpdate(update: Transaction): boolean {
  return positionOf(update) > 0;
}

function inputUpdate(layer: Layer<any>): Transaction | null {
  if (layer.input._config & CONFIG_HELD) return txOf(layer.input);
  if (layer.scope) return liveTx(layer.scope);
  const boundary = boundaries.get(layer.input);
  return boundary?.inputStatus ? inputUpdate(boundary) : null;
}

/** An input answer or the end of an action retires its override as work of
 * that action. Reading the input below then uses normal derivation joining.
 * Published output and owned children stay in the common committed slots. */
export function resumeInput(layer: Layer<any>, update: Transaction): void {
  forwardObservation(layer, false);
  layer.override = NOT_PENDING;
  // Retiring the cut makes its suspended consequences input work again.
  // Recompute will supersede obsolete flights in that common update.
  if (layer.output._config & CONFIG_HELD) merge(txOf(layer.output), update);
  joinFuture(update);
  enqueueSub(layer.output);
}

function retire(layer: Layer<any>): void {
  // An input hidden by an override can outlive the action transaction. Its
  // eventual answer resumes in live ordinary work, never a completed hold.
  const scope = liveTx(layer.scope!);
  if (!scope) joinFuture(null);
  resumeInput(layer, scope ?? resolveTx(flushTransaction!));
  layer.scope = null;
  scoped.delete(layer);
}

let orderPublication = false;

function prepareLayers(): boolean {
  if (!scoped.size && !candidateUpdates.size) return layerHooks.beforeCommit?.() ?? false;
  // This round can discover a lower flight after a child already re-ran.
  // Include all its proposals before deciding whether that input is ready.
  if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
  let changed = false;
  // Guesses made in the same action hold have one lifetime. An input still
  // in flight keeps every override in that group selected, even after the
  // bodies return. This bookkeeping exists only for active optimistic scopes.
  let waiting: Set<Transaction> | undefined;
  for (const layer of scoped) {
    const scope = resolveTx(layer.scope!);
    if (
      !scope._open &&
      !(layer.output._flags & REACTIVE_DISPOSED) &&
      layer.input._statusFlags & STATUS_PENDING &&
      observed(layer.output, scope)
    )
      (waiting ??= new Set()).add(scope);
  }
  for (const layer of scoped) {
    if (layer.output._flags & REACTIVE_DISPOSED) {
      scoped.delete(layer);
      layer.scope = null;
    } else if (resolveTx(layer.scope!)._open === 0 && !waiting?.has(resolveTx(layer.scope!))) {
      proposals.delete(layer);
      retire(layer);
      changed = true;
    }
  }
  // Retire observations before replaying readers of the now-ready input.
  // A callback probe also reads that input for control flow. Replaying it
  // against a stale true observation would join the ready input to the
  // obsolete async consequence that the false observation must supersede.
  changed = (layerHooks.beforeCommit?.() ?? false) || changed;
  for (const update of candidateUpdates) {
    const parent = liveTx(update);
    if (!parent || blocked(parent)) continue;
    for (const reader of parent._reruns || []) {
      if (
        !(reader as any)._type &&
        reader._flags & REACTIVE_FRAME_READ &&
        !(reader._flags & REACTIVE_DISPOSED)
      ) {
        const frame = unpublishedFrame(reader);
        if (frame && positionOf(frame) < positionOf(parent)) {
          orderPublication = true;
          continue;
        }
        // Derivations of a committed parent frame must discover their next
        // async work before that parent publishes. A post-commit rerun is
        // sufficient for a direct binding, but would let a memo lag behind
        // an already-published input after its boundary dependency changes.
        parent._reruns!.delete(reader);
        reader._flags &= ~REACTIVE_FRAME_READ;
        const previous = releasingInput;
        releasingInput = parent;
        try {
          recomputeInUpdate(reader, parent);
        } finally {
          releasingInput = previous;
        }
        changed = true;
        // This pass can merge its holder into another update. Its remaining
        // readers moved there; reconsider that holder's readiness on the
        // next iteration instead of continuing against the emptied record.
        if (resolveTx(parent) !== parent) break;
      }
    }
  }
  return changed;
}

function mergeLayers(from: Transaction, into: Transaction): void {
  if (from._level || into._level) into._level = Math.min(positionOf(from), positionOf(into));
  if (candidateUpdates.delete(from)) candidateUpdates.add(into);
}

function includesBoundary(reader: Computed<any>, holder: Transaction): boolean {
  return currentPosition(reader) > positionOf(holder);
}

/** A new owned frame belongs to its creator's proposal until that creator
 * publishes. Parked children are the old visible frame and are not excluded. */
function unpublishedFrame(node: Computed<any>): Transaction | null {
  let child = node;
  for (let owner = node._parent; owner; child = owner as Computed<any>, owner = owner._parent) {
    if (child._flags & REACTIVE_ZOMBIE) return null;
    const parent = owner as Computed<any>;
    if (parent._flags & REACTIVE_RECOMPUTING_DEPS && parent._flags & REACTIVE_JOINED)
      return flushTransaction;
    if (parent._config & CONFIG_STAGED && parent._config & CONFIG_HELD) return txOf(parent);
  }
  return null;
}

function frameRead(reader: Computed<any>, source: Signal<any>): boolean {
  const update = flushTransaction;
  const uninitialized = (source as Computed<any>)._statusFlags & STATUS_UNINITIALIZED;
  const holder = txOf(source);
  if (update && holder === resolveTx(update)) return false;
  const ownPosition = positionOf(update),
    heldPosition = positionOf(holder);
  if (heldPosition > ownPosition && unpublishedFrame(reader)) {
    staleReader(reader, holder);
    // This frame can wait for publication without consuming the higher
    // proposal. With no committed value yet, its read simply suspends.
    if (uninitialized) throw new NotReadyError(source);
    return true;
  }
  if (uninitialized) return false;
  if (ownPosition > heldPosition) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  if (ownPosition > 0 && heldPosition > 0) return false;
  // Direct bindings already have the common committed-frame read rule.
  // They do not need a speculative derivation or a provisional transaction.
  if ((reader as any)._type === EFFECT_RENDER) return false;
  if (includesBoundary(reader, holder)) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  return false;
}

/** A lower pending/error notification is an obligation to check, not a read
 * of its proposal. Let the existing higher calculation select its inputs;
 * inheriting status here would merge the contexts before that selection. */
function rederiveStatus(reader: Computed<any>, source: Computed<any>): boolean {
  if (!(reader._config & CONFIG_HELD)) return false;
  const incoming = source._config & CONFIG_HELD ? txOf(source) : flushTransaction;
  const ownPosition = positionOf(txOf(reader)),
    incomingPosition = positionOf(incoming);
  if (
    ownPosition <= incomingPosition &&
    !(ownPosition < incomingPosition && unpublishedFrame(reader))
  )
    return false;
  enqueueSub(reader);
  schedule();
  return true;
}

/** A notification does not consume its update's proposal. A held child's
 * pass first keeps its own context; actual reads can still merge peer work.
 * Ready input releases explicitly run in the input context instead. */
function rerunLayer(node: Computed<any>): boolean {
  const frame = unpublishedFrame(node);
  if (
    frame &&
    flushTransaction &&
    frame !== resolveTx(flushTransaction) &&
    positionOf(frame) < positionOf(flushTransaction)
  ) {
    preparingEffects.delete(node);
    recomputeInUpdate(node, frame, true);
    return true;
  }
  if ((node as any)._type && !preparingEffects.delete(node)) return false;
  const own = txOf(node);
  if (!isChildUpdate(own)) return false;
  if (!flushTransaction && hasUnheldProposals()) joinFuture(null);
  const incoming = flushTransaction && resolveTx(flushTransaction);
  if (incoming === own || (incoming && incoming === releasingInput)) return false;
  if (positionOf(incoming) >= positionOf(own)) return false;
  if (incoming) holdQueuedProposals(incoming);
  recomputeInUpdate(node, own, true);
  return true;
}

function deferJoin(reader: Computed<any>, source: Signal<any>): boolean {
  if (evaluation !== reader || (reader as any)._type === EFFECT_RENDER) return false;
  const holder = txOf(source);
  if (flushTransaction && resolveTx(flushTransaction) === holder) return false;
  (evaluationReads ??= new Map()).set(source, holder);
  // Isolate tentative reads before merging their holders. A fresh frame
  // adopts its accepted input context in computeLayer, after discovery.
  joinFuture(null);
  reader._flags |= REACTIVE_JOINED;
  return true;
}

/** The dependency prefix of this attempt selects its retry context. Existing
 * overrides retain their frozen position; discovering inputs cannot move them. */
function currentPosition(node: Signal<any>, seen = new Set<Signal<any>>()): number {
  if (seen.has(node)) return 0;
  seen.add(node);
  const boundary = boundaries.get(node);
  if (boundary && boundary.override !== NOT_PENDING) return boundary.position ?? 1;
  const computed = node as Computed<any>;
  let position = 0;
  for (let edge = computed._deps; edge; edge = edge._nextDep)
    if (edge._gen === computed._depGen)
      position = Math.max(position, currentPosition(edge._dep, seen));
  return position;
}

function readContext(reader: Computed<any>, _source: Computed<any>): void {
  if (evaluation !== reader || !evaluationReads) return;
  for (const holder of evaluationReads.values()) {
    const parent = resolveTx(holder);
    if (flushTransaction && parent === resolveTx(flushTransaction)) continue;
    const ownPosition = positionOf(flushTransaction),
      heldPosition = positionOf(parent);
    if (ownPosition > 0 && heldPosition >= ownPosition) continue;
    if (!includesBoundary(reader, parent)) continue;
    watchParent(parent);
    staleReader(reader, parent);
    joinFuture(null);
    const update = resolveTx(flushTransaction!);
    update._level = Math.max(positionOf(update), currentPosition(reader));
    retryEvaluation = true;
    throw RETRY;
  }
}

function detachedOutput(node: Computed<any>): boolean {
  const layer = boundaries.get(node);
  return !!layer && !layer.inputStatus;
}

/** Initial observation is already an explicitly selected output, not a lower
 * proposal inherited from whichever computation happened to call it first. */
export function initialObservation<T>(layer: Layer<T>, value: T): T {
  if (inputUpdate(layer)) {
    layer.override = value;
    layer.position = 1 + Math.max(layerPosition(layer.input), positionOf(inputUpdate(layer)));
  }
  return value;
}

function computeLayer(node: Computed<any>, previous: any, normalize?: NormalizeCalculation): any {
  const incoming = flushTransaction;
  const outer = evaluation,
    outerRetry = retryEvaluation;
  let outerReads = evaluationReads;
  evaluation = node;
  evaluationReads = null;
  retryEvaluation = false;
  try {
    for (;;) {
      let result: any,
        error: unknown,
        failed = false;
      try {
        const previousFlight = node._x?._inFlight;
        result = node._fn(previous);
        if (!retryEvaluation && normalize) result = normalize(node, result, previousFlight);
      } catch (e) {
        error = e;
        failed = true;
      }
      if (!retryEvaluation) {
        const reads = evaluationReads as Map<Signal<any>, Transaction> | null;
        if (reads) {
          if (outer && node._parent === outer) {
            for (const [source, holder] of reads) (outerReads ??= new Map()).set(source, holder);
          } else {
            // Accept the calculation before adopting its first consumed
            // context. During discovery a fresh frame must remain free to
            // retry above a deeper proposal encountered later in the body.
            if (incoming === null && flushTransaction && !positionOf(flushTransaction))
              flushTransaction._level = positionOf(reads.values().next().value!);
            for (const holder of reads.values()) joinFuture(resolveTx(holder));
          }
        }
        if (failed) throw error;
        return result;
      }
      if (result && typeof result.then === "function") Promise.resolve(result).catch(() => {});
      if (node._x !== null) node._x._inFlight = null;
      releaseFlightTeardown(node);
      disposeChildren(node);
      node._depsTail = null;
      node._depGen++;
      evaluationReads = null;
      retryEvaluation = false;
    }
  } finally {
    evaluation = outer;
    evaluationReads = outerReads;
    retryEvaluation = outerRetry;
  }
}

// Transactions, rather than ordinary node creation, activate coordination.
function orderUpdates(updates: Transaction[]): void {
  // Only a ready output with unpublished lower readers needs a landing order.
  // Independent ready updates and ordinary visible readers impose no order.
  if (!orderPublication) return;
  orderPublication = false;
  for (let i = 1; i < updates.length; i++) {
    if (positionOf(updates[i - 1]) <= positionOf(updates[i])) continue;
    updates.sort((a, b) => positionOf(a) - positionOf(b));
    return;
  }
}
setLayerTransactions(update => {
  watchParent(update);
  wakeLayers();
}, orderUpdates);

/** Assign notified work to its output update, preserving the committed frame.
 * Active boundaries and unpublished lower owners remain propagation cuts. */
function adoptOutput(node: Computed<any>, update: Transaction, origin = false): void {
  const effect = node as Computed<any> & {
    _modified?: boolean;
    _boundRunEffect?: (type: number) => void;
    _type?: number;
  };
  if (effect._type) preparingEffects.add(node);
  // A lower notification cannot change an already selected upper context.
  // Its normal re-pass will read the lower update's committed value.
  if (!origin && node._config & CONFIG_HELD && positionOf(txOf(node)) > positionOf(update)) return;
  const frame = unpublishedFrame(node);
  if (!origin && frame && positionOf(frame) < positionOf(update)) {
    staleReader(node, update);
    return;
  }
  const boundary = boundaries.get(node);
  if (!origin && boundary && boundary.override !== NOT_PENDING) return;
  const transferredProposal =
    (node._pendingValue !== NOT_PENDING || node._statusFlags & (STATUS_PENDING | STATUS_ERROR)) &&
    (!(node._config & CONFIG_HELD) || txOf(node) !== update);
  if (effect._modified && effect._boundRunEffect) {
    update._queues[effect._type! - 1].push(effect._boundRunEffect);
  }
  holdNode(node, update);
  // A previously computed proposal may compare equal on its next pass, and
  // repeated status propagation may short-circuit. Its consumers must still
  // follow that existing proposal/status into this update.
  if (transferredProposal) insertSubs(node);
}

/** Transfer context along value and status notifications. An unchanged
 * memo is a propagation stop for optimistic updates just as for ordinary ones. */
function notifyLayer(source: Signal<any>, reader: Computed<any>): void {
  if (!(source._config & CONFIG_HELD)) return;
  const update = txOf(source);
  if (isChildUpdate(update)) adoptOutput(reader, update);
}

function ownLayerUpdate(layer: Layer<any>, update: Transaction, input: Transaction | null) {
  layer.update = update;
  resolveTx(update)._level = layer.position ?? 1 + layerPosition(layer.input);
  active.add(layer);
  if (input !== null && input !== update) watchParent(input);
}

export function stageLayer(layer: Layer<any>, proposal: unknown, position?: number): void {
  const inputHolder = inputUpdate(layer);
  // Snapshot the context at the new proposal. A subsequently discovered input
  // dependency cannot promote this existing override or split its peer joins.
  layer.position = position ?? 1 + Math.max(layerPosition(layer.input), positionOf(inputHolder));
  layer.override = proposal;
  forwardObservation(layer, proposal !== NOT_PENDING);
  layer.inputTime = inputTime(layer.input);
  enableReads();
  // Selecting an equal, settled scalar output has no downstream proposal.
  // In particular a newly allocated pending observation must not replay its
  // consumers just to install its initial false selector.
  if (
    inputHolder === null &&
    !(layer.output._config & CONFIG_HELD) &&
    layer.output._pendingValue === NOT_PENDING &&
    proposal !== NOT_PENDING &&
    layer.output._equals &&
    layer.output._equals(layer.output._value, proposal)
  ) {
    enqueueSub(layer.output);
    return;
  }
  const previous = layer.update && liveTx(layer.update);
  // A correction may have merged the old output back into its input. A new
  // guess needs a new cut, rather than reusing that now-lower update.
  const update =
    previous &&
    previous !== inputHolder &&
    isChildUpdate(previous) &&
    positionOf(previous) === layer.position
      ? previous
      : newTransaction(false);
  ownLayerUpdate(layer, update, inputHolder);
  adoptOutput(layer.output, update, true);
  enqueueSub(layer.output);
}

function forgetFinishedUpdate(update: Transaction): void {
  if (!liveTx(update)) candidateUpdates.delete(update);
}

function forgetFinishedLayer(layer: Layer<any>): void {
  if (!liveTx(layer.update!)) {
    layer.update = null;
    active.delete(layer);
  }
}

function selectProposal(proposal: unknown, layer: Layer<any>): void {
  layer.override = proposal;
  layer.position = undefined;
}

function positionProposal(_proposal: unknown, layer: Layer<any>): void {
  layer.position = 1 + Math.max(layerPosition(layer.input), positionOf(inputUpdate(layer)));
}

function applyProposal(proposal: unknown, layer: Layer<any>): void {
  if (!(layer.output._flags & REACTIVE_DISPOSED)) stageLayer(layer, proposal, layer.position);
}

function settleLayers(): void {
  if (!candidateUpdates.size && !active.size && !proposals.size && !scoped.size) {
    layerHooks.afterCommit?.();
    stopIfIdle();
    return;
  }
  candidateUpdates.forEach(forgetFinishedUpdate);
  if (!candidateUpdates.size) {
    if (!active.size) setLayerCompute();
    // A later ordinary write can create a hold beneath an already published
    // override. Enable order-independent discovery once that hold exists.
    if (scoped.size && hasHeldNodes()) {
      for (const layer of scoped) if (layer.scope) watchParent(resolveTx(layer.scope));
    }
  }
  active.forEach(forgetFinishedLayer);
  // First propagate value proposals. Their pending outputs describe the
  // resulting work, just as they do after an ordinary write's pure phase.
  // Staging both at once would merge a status update with the input update
  // it is meant to observe independently.
  if (proposals.size) {
    // Select all boundaries before assigning the new contexts, so simultaneous
    // nested guesses do not depend on setter order. Existing proposals outside
    // this batch keep their context, including across new parent activation.
    proposals.forEach(selectProposal);
    proposals.forEach(positionProposal);
    proposals.forEach(applyProposal);
    proposals.clear();
    return;
  }
  layerHooks.afterCommit?.();
  stopIfIdle();
}

export function createLayer<T>(input: () => T, options?: { lifetime: "action" }) {
  // The producer records each input evaluation. Equality belongs at the
  // output: an answer equal to an earlier input may still replace a guess.
  // Keep this computation even for a source accessor: refreshing the boundary
  // must re-read its input, not invalidate that input's own computation.
  const producer = computed(input, { equals: false });
  const layer = createLayerBoundary<T>(producer);
  layer.inputStatus = true;
  return layerAccessors(layer, options);
}

function selectLayer<T>(
  layer: Layer<T>,
  fallback: ((layer: Layer<T>) => T) | undefined,
  onEvaluate: ((layer: Layer<T>) => void) | undefined
): T {
  const producer = layer.input;
  onEvaluate?.(layer);
  if (
    layer.scope !== null &&
    layer.override !== NOT_PENDING &&
    !(producer._statusFlags & STATUS_PENDING) &&
    inputTime(producer) !== layer.inputTime
  ) {
    // An input answer joins the guessing actions, but the selector stays
    // overridden until their shared lifetime ends. Intermediate answers
    // must not start downstream work beneath the selected guess.
    const scope = liveTx(layer.scope);
    if (scope) {
      if (producer._config & CONFIG_HELD) merge(txOf(producer), scope);
      // A ready input can still be an unparked proposal in this flush.
      // Couple that input frame, not an independently preparing override.
      if (!layer.update || liveTx(layer.update) !== flushTransaction) joinFuture(scope);
    }
    // The pre-commit phase releases the group once all its inputs are ready.
  }
  if (layer.override === NOT_PENDING) return fallback ? fallback(layer) : read(producer);
  // Choosing an override subscribes to the input's changes, but does not
  // consume its proposal. No other read in the graph has this exemption.
  // The subscription keeps input work current; observation forwarding decides
  // whether it holds. Neither operation consumes the input's proposed value.
  link(producer, layer.output);
  return layer.override as T;
}

/** Internal construction shared by guesses and observations. */
export function createLayerBoundary<T>(
  producer: Computed<any>,
  fallback?: (layer: Layer<T>) => T,
  onEvaluate?: (layer: Layer<T>) => void,
  ownInput = true,
  lazy = false
) {
  if (ownInput) producer._config &= ~CONFIG_AUTO_DISPOSE;
  const layer = {
    input: producer,
    override: NOT_PENDING,
    update: null,
    scope: null,
    inputTime: inputTime(producer)
  } as Layer<T>;
  // Bind the shared selector instead of retaining a constructor closure and
  // its captured producer, callbacks and layer. Only boundaries pay this cost.
  const output = computed<T>((selectLayer<T>).bind(null, layer, fallback, onEvaluate), {
    lazy,
    _extraConfig: CONFIG_REDERIVE
  });
  if (!lazy) output._config &= ~CONFIG_AUTO_DISPOSE;
  layer.output = output;
  boundaries.set(output, layer);
  if (!boundaries.has(producer)) boundaries.set(producer, null);
  return layer;
}

function releaseLayer(layer: Layer<any>): void {
  forwardObservation(layer, false);
  scoped.delete(layer);
  active.delete(layer);
  proposals.delete(layer);
  layer.scope = layer.update = null;
  // Disposal can be the last event while an input is permanently pending.
  // Prune finished update references and disable idle hooks without requiring
  // an unrelated future write to visit the disposed boundary.
  wakeLayers();
}

function layerAccessors<T>(layer: Layer<T>, options?: { lifetime: "action" }) {
  const output = layer.output;
  const propose = (value: T | ((previous: T) => T)) => {
    const pending = proposals.get(layer);
    const previous =
      proposals.has(layer) && pending !== NOT_PENDING
        ? pending
        : layer.override !== NOT_PENDING
          ? layer.override
          : output._pendingValue !== NOT_PENDING
            ? output._pendingValue
            : output._value;
    const next = typeof value === "function" ? (value as (v: T) => T)(previous as T) : value;
    if (options?.lifetime === "action") {
      const scope = flushTransaction ?? (layer.scope && liveTx(layer.scope));
      if (!scope || !resolveTx(scope)._acted) {
        throw new Error("The action-lifetime experiment requires a guess inside an action.");
      }
      if (layer.scope) merge(scope, layer.scope);
      layer.scope = resolveTx(scope);
      // A ready input proposal can predate the guess. It has the same lifetime
      // relationship as an answer that arrives afterwards; its evaluation
      // timestamp cannot tell us whether this action has adopted that hold.
      // Only the input joins the action. The output proposal still gets its
      // own publication context when stageLayer selects the override.
      if (layer.input._config & CONFIG_HELD && !(layer.input._statusFlags & STATUS_PENDING))
        merge(txOf(layer.input), layer.scope);
      scoped.add(layer);
    }
    output._cleanup ??= releaseLayer.bind(null, layer);
    proposals.set(layer, next);
    wakeLayers();
    return next;
  };
  const clear = () => {
    proposals.set(layer, NOT_PENDING);
    wakeLayers();
  };
  const accessor = () => read(output);
  (accessor as any)[$REFRESH] = output;
  return [accessor, propose, clear] as const;
}
