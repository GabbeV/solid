// packages/signals/dist/scalar/core/constants.js
var LEGACY_LANES = false;
var REACTIVE_NONE = 0;
var REACTIVE_CHECK = 1 << 0;
var REACTIVE_DIRTY = 1 << 1;
var REACTIVE_RECOMPUTING_DEPS = 1 << 2;
var REACTIVE_IN_HEAP = 1 << 3;
var REACTIVE_IN_HEAP_HEIGHT = 1 << 4;
var REACTIVE_ZOMBIE = 1 << 5;
var REACTIVE_DISPOSED = 1 << 6;
var REACTIVE_JOINED = 1 << 7;
var REACTIVE_SNAPSHOT_STALE = 1 << 8;
var REACTIVE_LAZY = 1 << 9;
var REACTIVE_MANUAL_WRITE = 1 << 10;
var REACTIVE_FRAME_READ = 1 << 11;
var REACTIVE_MISSED_WAKE = 1 << 12;
var REACTIVE_REASK = 1 << 13;
var REACTIVE_STAGED_READ = 1 << 14;
var REACTIVE_LANE_DIRTY = 1 << 16;
var REACTIVE_LANE_READ = 1 << 17;
var REACTIVE_SCREEN_READ = 1 << 18;
var REACTIVE_PROBE_UNANSWERED = 1 << 19;
var CONFIG_OWNED_WRITE = 1 << 0;
var CONFIG_NO_SNAPSHOT = 1 << 1;
var CONFIG_TRANSPARENT = 1 << 2;
var CONFIG_IN_SNAPSHOT_SCOPE = 1 << 3;
var CONFIG_CHILDREN_FORBIDDEN = 1 << 4;
var CONFIG_AUTO_DISPOSE = 1 << 5;
var CONFIG_SYNC = 1 << 6;
var CONFIG_STAGED = 1 << 7;
var CONFIG_HELD = 1 << 8;
var CONFIG_INPUTS_PUBLISHED = 1 << 10;
var CONFIG_OVERRIDE = 1 << 11;
var CONFIG_SLOT_NODE = 1 << 12;
var CONFIG_LOADING = 1 << 19;
var CONFIG_GUESS = 1 << 13;
var CONFIG_VERDICT = 1 << 14;
var CONFIG_REDERIVE = 1 << 15;
var CONFIG_AUTHORITATIVE = 1 << 17;
var CONFIG_HAS_SNAPSHOT = 1 << 9;
var CONFIG_FRESH_READ = 1 << 16;
var CONFIG_PROMOTED = 1 << 22;
var STATUS_PENDING = 1 << 0;
var STATUS_ERROR = 1 << 1;
var STATUS_UNINITIALIZED = 1 << 2;
var EFFECT_RENDER = 1;
var EFFECT_USER = 2;
var EFFECT_TRACKED = 3;
var NOT_PENDING = {};
var defaultContext = {};
var $REFRESH = /* @__PURE__ */ Symbol("refresh");

// packages/signals/dist/scalar/core/error.js
var NotReadyError = class extends Error {
  source;
  constructor(r) {
    const t = Error;
    const o = t.stackTraceLimit;
    if (o !== void 0) t.stackTraceLimit = 0;
    super();
    if (o !== void 0) t.stackTraceLimit = o;
    this.source = r;
  }
};
var StatusError = class extends Error {
  source;
  constructor(r, t) {
    super(t instanceof Error ? t.message : String(t), {
      cause: t
    });
    this.source = r;
  }
};
function unwrapStatusError(r) {
  return r instanceof StatusError ? r.cause : r;
}

// packages/signals/dist/scalar/core/scheduler.js
var layerSeam;
var layerBeforeCommit;
var layerMerge;
var layerCompute;
var layerRead;
var layerJoin;
var layerDetached;
var layerTransaction;
var layerOrder;
function setLayerTransactions(e, n) {
  layerTransaction = e;
  layerOrder = n;
}
var layerRecompute;
var layerOwn;
var layerFrameRead;
var preparingUpdate = null;
var layerStatus;
var layerObserved;
function setLayerObserved(e) {
  layerObserved = e;
}
var layerVisibility;
function setLayerVisibility(e) {
  layerVisibility = e;
}
function setLayerCommit(e, n) {
  layerBeforeCommit = e;
  layerSeam = n;
}
function setLayerReads(e, n, t, l) {
  layerOwn = e;
  layerMerge = n;
  layerFrameRead = t;
  layerStatus = l;
}
function setLayerCompute(e, n, t, l, r) {
  layerCompute = e;
  layerRecompute = n;
  layerRead = t;
  layerJoin = l;
  layerDetached = r;
}
var transactions = [];
function hasHeldNodes() {
  for (const e of transactions) if (e.fn.length) return true;
  return false;
}
var rerunHolders = /* @__PURE__ */ new Set();
var cleanupReruns;
function newTransaction(e, n = null) {
  const t = {
    fn: [],
    De: false,
    et: [[], []],
    pn: null,
    hn: null,
    tt: 0,
    nt: false,
    je: null,
    ...{}
  };
  {
    transactions.push(t);
    layerTransaction?.(t);
  }
  return t;
}
var passLane = null;
var flushTransaction = null;
var passTx = null;
function joinPassTx(e, n) {
  if (globalQueue.j && !n || flushTransaction !== null) return joinFuture(e);
  if (passTx === null) passTx = resolveTx(e);
  else merge(resolveTx(e), passTx);
  schedule();
}
function txOf(e) {
  return e.R.Te = resolveTx(e.R.Te);
}
function liveTx(e) {
  e = resolveTx(e);
  return transactions.indexOf(e) !== -1 ? e : null;
}
function resolveTx(e) {
  while (e.hn !== null) e = e.hn;
  return e;
}
function joinFuture(e) {
  const n = flushTransaction;
  if (n === null) {
    flushTransaction = e === null ? newTransaction() : resolveTx(e);
  } else if (e !== null) merge(resolveTx(e), n);
  if (!globalQueue.j) schedule();
}
function merge(e, n) {
  e = resolveTx(e);
  n = resolveTx(n);
  if (e === n || LEGACY_LANES) return;
  layerMerge?.(e, n);
  e.hn = n;
  n.tt += e.tt;
  n.nt ||= e.nt;
  n.De ||= e.De;
  append(n.fn, e.fn);
  append(n.et[0], e.et[0]);
  append(n.et[1], e.et[1]);
  if (globalQueue.et === e.et) globalQueue.et = n.et;
  if (e.pn) {
    if (n.pn) for (const t of e.pn) n.pn.add(t);
    else n.pn = e.pn;
    e.pn = null;
    rerunHolders.delete(e);
    rerunHolders.add(n);
  }
  if (e.je !== null) append(n.je ??= [], e.je);
  transactions.splice(transactions.indexOf(e), 1);
}
function blocked(e) {
  const n = judge;
  judge ??= e;
  const t = e.tt !== 0 || e.De && blockedBy(e.fn, e) || LEGACY_LANES;
  judge = n;
  return t;
}
var judge = null;
function ownSource(e, n) {
  const t = e.R?.oe;
  if (t === void 0) return true;
  for (const e2 of t) {
    const t2 = e2.R?.Te;
    if (t2 == null || resolveTx(t2) === n) return true;
  }
  return false;
}
function blockedBy(e, n, t = false) {
  for (let l = 0; l < e.length; l++) {
    const r = e[l];
    if (!(r.h & STATUS_PENDING) || r.m & REACTIVE_DISPOSED || r.U & CONFIG_GUESS || r.R.Te !== null && txOf(r) !== n || t && !ownSource(r, n)) continue;
    if (r.l === EFFECT_RENDER) {
      if (onScreen(r, judge ?? n)) return true;
      continue;
    }
    if (layerObserved?.(r, judge ?? n)) return true;
    for (let e2 = r.ie; e2 !== null; e2 = e2.se) {
      const t2 = e2.le;
      if ((t2.l === EFFECT_RENDER && t2.h & STATUS_PENDING || t2.m & REACTIVE_FRAME_READ || t2.U & CONFIG_REDERIVE && t2.h === STATUS_PENDING && (!layerVisibility || layerVisibility(t2, judge ?? n))) && (e2.Oe === t2._e || t2.R?.i != null) && !(t2.m & REACTIVE_DISPOSED) && onScreen(t2, judge ?? n)) return true;
    }
  }
  return false;
}
function onScreen(e, n) {
  return !(n && e.m & REACTIVE_ZOMBIE && removalStagedBy(e, n)) && !(GlobalQueue.ne && GlobalQueue.ne(e));
}
function removalStagedBy(e, n) {
  let t = e;
  while (t !== null && t.m & REACTIVE_ZOMBIE) t = t._parent;
  return t !== null && (t.U & CONFIG_HELD) !== 0 && t.R?.Te != null && txOf(t) === resolveTx(n);
}
var heldTrims = [];
function heldTrim(e) {
  heldTrims.push(e);
}
var deferredZombies = [];
function deferZombie(e) {
  deleteFromHeap(e, dirtyQueue);
  e.m &= -4;
  deferredZombies.push(e);
}
function holdNode(e, n) {
  e.U |= CONFIG_HELD;
  dependencyFrame?.(e, "park");
  list(e, n);
}
function list(e, n) {
  if (e.h & STATUS_PENDING) n.De = true;
  const t = ext(e);
  if (t.Te === n) return;
  layerOwn?.(e, n);
  t.Te = n;
  n.fn.push(e);
}
function holdFrame(e, n) {
  for (let t = e.pe; t !== null; t = t.He) {
    if (t.M !== void 0 && !(t.U & CONFIG_HELD)) holdNode(t, n);
    holdFrame(t, n);
  }
}
var dirtyQueue = {
  Xe: new Array(2e3).fill(void 0),
  Et: false,
  Je: 0,
  $e: 0
};
var clock = 0;
var scheduled = false;
var halted = false;
var haltNotified = false;
var syncDepth = 0;
var actionDepth = 0;
function enterAction() {
  actionDepth++;
}
function exitAction() {
  actionDepth--;
}
var question = 0;
var questions = 0;
function setQuestion(e) {
  question = e;
}
function nextQuestion() {
  return ++questions;
}
var MAINLINE_QUESTION = 2147483647;
function schedule() {
  if (halted) {
    notifyHalted();
    return;
  }
  if (scheduled) return;
  scheduled = true;
  if (!syncDepth && !globalQueue.j) {
    queueMicrotask(flush);
  }
}
function haltReactivity(e) {
  if (halted) return;
  halted = true;
  let n = "[REACTIVITY_HALTED]";
  const t = e !== void 0 && globalThis.reportError;
  t || e === void 0 ? console.error(n) : console.error(n, e);
  t && t(e);
}
function notifyHalted() {
  if (haltNotified) return;
  haltNotified = true;
  console.error("[REACTIVITY_HALTED]");
}
var GlobalQueue = class _GlobalQueue {
  et = [[], []];
  j = false;
  flush() {
    if (this.j) return;
    this.j = true;
    resyncUnflushedCompanions();
    passLane = null;
    passTx = null;
    try {
      sweepDormant();
      runHeap(dirtyQueue, _GlobalQueue.Ae);
      this.settle();
      clock++;
      scheduled = dirtyQueue.$e >= dirtyQueue.Je || pendingNodes.length !== 0;
      this.run(EFFECT_RENDER);
      this.run(EFFECT_USER);
      if (false) ;
      if (false) ;
      if (false) ;
    } finally {
      this.j = false;
      passTx = null;
    }
  }
  /** L2 — the seam: end of the pure phase. Commit this flush's staged nodes,
   * or park them with the transaction the flush joined; then land every
   * transaction no frame is waiting on. The landing flush is an ordinary
   * flush: the settle walk (async.ts) re-ran the parked readers in its pure
   * phase, and here no flight the transaction holds has a frame deriving
   * from it (`blocked`). */
  settle() {
    while (layerBeforeCommit?.()) runHeap(dirtyQueue, _GlobalQueue.Ae);
    const e = flushTransaction;
    flushTransaction = null;
    const n = e !== null && true ? resolveTx(e) : null;
    if (n !== null) {
      holdQueuedProposals(n);
      if (dependencyFrame) {
        for (const e3 of heldTrims) if (!(e3.U & (CONFIG_HELD | CONFIG_OVERRIDE)) && dependencyFrame(e3, "park")) holdNode(e3, n);
      }
      pendingNodes.length = 0;
      _GlobalQueue.yn?.(n);
      const e2 = deferredZombies.splice(0).sort((e3, n2) => e3.Fe - n2.Fe);
      for (let n2 = 0; n2 < e2.length; n2++) if ((e2[n2].m & (REACTIVE_DISPOSED | REACTIVE_ZOMBIE)) === REACTIVE_ZOMBIE && e2[n2].U & CONFIG_VERDICT) recompute(e2[n2]);
    } else {
      commitPendingNodes();
      for (let e2 = 0; e2 < heldTrims.length; e2++) {
        const n2 = heldTrims[e2];
        if (!(n2.U & CONFIG_HELD) && n2.R?.i == null && !n2.Ce) trimStaleDeps(n2);
      }
    }
    if (heldTrims.length) heldTrims.length = 0;
    const t = this.et;
    this.et = [[], []];
    layerOrder?.(transactions);
    for (let e2 = transactions.length - 1; e2 >= 0; e2--) {
      const n2 = transactions[e2];
      if (blocked(n2) || queuedWork(n2)) continue;
      transactions.splice(e2, 1);
      land(n2);
      e2 = transactions.length;
    }
    _GlobalQueue.mn?.();
    const l = n && liveTx(n);
    _GlobalQueue.Fn?.(l);
    const r = l !== null;
    for (let e2 = 0; e2 < 2; e2++) {
      if (r) append(l.et[e2], t[e2]);
      if (!r) {
        this.et[e2] = this.et[e2].length ? t[e2].concat(this.et[e2]) : t[e2];
      }
    }
    if (deferredZombies.length !== 0) {
      const e2 = deferredZombies.splice(0).sort((e3, n2) => e3.Fe - n2.Fe);
      for (let n2 = 0; n2 < e2.length; n2++) {
        if (!(e2[n2].m & REACTIVE_DISPOSED)) recompute(e2[n2]);
      }
    }
    _GlobalQueue.re?.();
    layerSeam?.();
  }
  run(e) {
    const n = this.et[e - 1];
    if (n.length) {
      this.et[e - 1] = [];
      runQueue(n, e);
    }
  }
  enqueue(e, n, t = passLane) {
    if (e) (t !== null ? t : this).et[e - 1].push(n);
    schedule();
  }
  /** Status reaching the root: pending is absorbed (the root mount defers —
   * dev records it for the ASYNC_OUTSIDE_LOADING_BOUNDARY FYI); an error is
   * unhandled (`false` → the caller halts).
   *
   * L2: this is where a transaction is registered. Pending that reaches an
   * observer (a render effect: the frame) is a frame that cannot show — the
   * flush parks, and the transaction waits on the flight while a frame
   * derives from it (`blocked`). Pending nobody observes holds nothing: a
   * memo in flight that no frame reads is not a frame waiting. (Base: the
   * queue's `_asyncReporters`, INV-3's one registration site.)
   *
   * A boundary between the observer and the root (boundaries.ts) is asked
   * first: a fallback catches what is not ready under it, and the root
   * never hears of it. */
  notify(e, n, t, l) {
    if (_GlobalQueue.$ && _GlobalQueue.$(e, t & n, l)) return true;
    if (n & STATUS_PENDING) {
      if (t & STATUS_PENDING) {
        if (passLane === null) joinFuture(null);
      }
      return true;
    }
    return false;
  }
};
function reruns(e) {
  const n = e.pn;
  if (!n) return;
  e.pn = null;
  rerunHolders.delete(e);
  if (!rerunHolders.size) cleanupReruns = void 0;
  for (const e2 of n) {
    if (e2.m & REACTIVE_DISPOSED || e2.h & STATUS_ERROR) continue;
    if (e2.m & REACTIVE_FRAME_READ || e2.U & CONFIG_VERDICT) {
      e2.m &= ~REACTIVE_FRAME_READ;
      e2.Ce = false;
      for (let n2 = e2.pe; n2 !== null; n2 = n2.He) if (n2.l) n2.Ce = false;
      enqueueSub(e2);
    }
  }
}
function queuedWork(e) {
  for (let n = 0; n < e.fn.length; n++) {
    const t = e.fn[n];
    if (t.m & REACTIVE_IN_HEAP && !(t.m & REACTIVE_DISPOSED) && t.U & CONFIG_HELD && txOf(t) === e) return true;
  }
  return false;
}
function land(e) {
  reruns(e);
  if (e.je !== null) GlobalQueue.gn(e.je);
  for (let n = 0; n < e.fn.length; n++) {
    const t = e.fn[n];
    if (t.R.Te === null || txOf(t) !== e) continue;
    t.R.Te = null;
    commitPendingNode(t);
  }
  releaseQueues(e);
}
function releaseQueues(e) {
  for (let n = 0; n < 2; n++) {
    append(globalQueue.et[n], e.et[n]);
    e.et[n] = [];
  }
}
function append(e, n) {
  for (let t = 0; t < n.length; t++) e.push(n[t]);
}
var pendingNodes = [];
function holdQueuedProposals(e, n = 0) {
  const t = pendingNodes.length;
  for (let l = n; l < t; l++) {
    const n2 = pendingNodes[l];
    if (n2.m & REACTIVE_DISPOSED) continue;
    if (!(n2.U & (CONFIG_HELD | 0)) && !LEGACY_LANES) {
      if (n2.Ee === NOT_PENDING && n2.h & STATUS_UNINITIALIZED && n2.l !== EFFECT_RENDER) continue;
      if (n2.Ee !== NOT_PENDING && !(n2.h & (STATUS_PENDING | STATUS_UNINITIALIZED)) && n2.Pe && n2.Pe(n2.Ne, n2.Ee) && n2.R?.he == null && n2.R?.Ve == null) {
        n2.Ee = NOT_PENDING;
        n2.U &= ~CONFIG_STAGED;
        continue;
      }
      holdNode(n2, e);
    }
    if (n2.U & CONFIG_STAGED) holdFrame(n2, txOf(n2));
  }
}
function hasUnheldProposals() {
  for (let e = 0; e < pendingNodes.length; e++) if (!(pendingNodes[e].U & CONFIG_HELD)) return true;
  for (let e = 0; e < heldTrims.length; e++) if (!(heldTrims[e].U & CONFIG_HELD)) return true;
  return false;
}
function recomputeInUpdate(e, n, t = false) {
  const l = flushTransaction;
  const r = pendingNodes.length;
  const o = preparingUpdate;
  const u = globalQueue.et;
  const s = l !== null && u === l.et;
  flushTransaction = n;
  preparingUpdate = t && !blocked(n) ? n : null;
  globalQueue.et = n.et;
  try {
    recompute(e, false, true);
  } finally {
    if (flushTransaction) {
      n = resolveTx(flushTransaction);
      holdQueuedProposals(n, r);
    }
    globalQueue.et = s ? resolveTx(l).et : u;
    preparingUpdate = o;
    flushTransaction = l && resolveTx(l);
  }
}
function staleReader(e, n) {
  e.m |= REACTIVE_FRAME_READ;
  queueRerun(n, e);
}
function queueRerun(e, n) {
  if (!e.pn) {
    e.pn = /* @__PURE__ */ new Set();
    rerunHolders.add(e);
    cleanupReruns = forgetReruns;
  }
  e.pn.add(n);
}
function forgetReruns(e) {
  for (const n of rerunHolders) {
    const t = n.pn;
    t.delete(e);
    if (!t.size) {
      n.pn = null;
      rerunHolders.delete(n);
    }
  }
  if (!rerunHolders.size) cleanupReruns = void 0;
}
function queuePendingNode(e) {
  pendingNodes.push(e);
  if (!globalQueue.j) markUnflushedStaged();
}
var notifyEpoch = 0;
function bumpNotifyEpoch() {
  notifyEpoch++;
}
function insertSubs(e) {
  e.be = notifyEpoch;
  const n = e.U;
  const t = (n & CONFIG_HAS_SNAPSHOT) !== 0 && e.R?.Ze !== void 0;
  for (let n2 = e.ie; n2 !== null; n2 = n2.se) {
    const e2 = n2.le;
    if (e2.m & REACTIVE_RECOMPUTING_DEPS && n2.Oe === e2._e && n2 !== e2.Ge) e2.m |= REACTIVE_MISSED_WAKE;
    if (t && e2.U & CONFIG_IN_SNAPSHOT_SCOPE) {
      e2.m |= REACTIVE_SNAPSHOT_STALE;
      continue;
    }
    enqueueSub(e2);
  }
}
function commitPendingNode(e) {
  const n = e;
  if (!n.M) {
    e.U &= -385;
    if (e.Ee !== NOT_PENDING) {
      e.Ne = e.Ee;
      e.Ee = NOT_PENDING;
    }
    return;
  }
  const t = e.Ee === NOT_PENDING && (n.h & STATUS_PENDING) !== 0;
  e.U = t ? e.U & -524545 | CONFIG_INPUTS_PUBLISHED : e.U & -525697;
  if (e.Ee !== NOT_PENDING) {
    e.Ne = e.Ee;
    e.Ee = NOT_PENDING;
    n.h &= ~STATUS_UNINITIALIZED;
    if (n.R != null) n.R.ue = false, n.R.Me = NOT_PENDING;
    if (e.l && e.l !== EFFECT_TRACKED) {
      e.Ce = true;
      globalQueue.enqueue(e.l, e.L ??= GlobalQueue.k.bind(null, n));
    }
  }
  n.m &= ~REACTIVE_MANUAL_WRITE;
  if (n.R?.i == null) trimStaleDeps(n);
  else if (!t) dependencyFrame?.(n, "commit");
  if (!(n.h & STATUS_PENDING)) n.h &= ~STATUS_UNINITIALIZED;
  if (!t && n.R != null && (n.R.he !== null || n.R.Ve !== null)) GlobalQueue.Re(n, false, true);
}
function commitPendingNodes() {
  for (let e = 0; e < pendingNodes.length; e++) {
    const n = pendingNodes[e];
    if (!(n.U & (CONFIG_OVERRIDE | CONFIG_HELD))) commitPendingNode(n);
  }
  pendingNodes.length = 0;
}
var globalQueue = new GlobalQueue();
function flush(e) {
  if (actionDepth > 0) {
    return e ? e() : void 0;
  }
  if (e) {
    syncDepth++;
    try {
      return e();
    } finally {
      try {
        flush();
      } finally {
        syncDepth--;
      }
    }
  }
  if (globalQueue.j) {
    return;
  }
  if (halted) return;
  while (scheduled) {
    globalQueue.flush();
  }
}
function runQueue(e, n) {
  for (let t = 0; t < e.length; t++) e[t](n);
}

// packages/signals/dist/scalar/core/heap.js
function enqueueSub(e) {
  if (dirtyQueue.Je > e.Fe) dirtyQueue.Je = e.Fe;
  insertIntoHeap(e, dirtyQueue);
}
function actualInsertIntoHeap(e, t) {
  const E = (e._parent?.Be ? e._parent.G?.Fe : e._parent?.Fe) ?? -1;
  if (E >= e.Fe) e.Fe = E + 1;
  const n = e.Fe;
  const I = t.Xe[n];
  if (I === void 0) t.Xe[n] = e;
  else {
    const t2 = I.Le;
    t2.ye = e;
    e.Le = t2;
    I.Le = e;
  }
  if (n > t.$e) t.$e = n;
}
function insertIntoHeap(e, t) {
  let E = e.m;
  if (E & (REACTIVE_IN_HEAP | REACTIVE_RECOMPUTING_DEPS)) return;
  if (E & REACTIVE_CHECK) {
    e.m = E & -4 | REACTIVE_DIRTY | REACTIVE_IN_HEAP;
  } else {
    e.m = E | REACTIVE_IN_HEAP;
    if (t.Et) markNode(e);
  }
  if (!(E & REACTIVE_IN_HEAP_HEIGHT)) actualInsertIntoHeap(e, t);
}
function insertIntoHeapHeight(e, t) {
  let E = e.m;
  if (E & (REACTIVE_IN_HEAP | REACTIVE_RECOMPUTING_DEPS | REACTIVE_IN_HEAP_HEIGHT)) return;
  e.m = E | REACTIVE_IN_HEAP_HEIGHT;
  actualInsertIntoHeap(e, t);
}
function deleteFromHeap(e, t) {
  const E = e.m;
  if (!(E & (REACTIVE_IN_HEAP | REACTIVE_IN_HEAP_HEIGHT))) return;
  e.m = E & -25;
  const n = e.Fe;
  if (e.Le === e) t.Xe[n] = void 0;
  else {
    const E2 = e.ye;
    const I = t.Xe[n];
    const i = E2 ?? I;
    if (e === I) t.Xe[n] = E2;
    else e.Le.ye = E2;
    i.Le = e.Le;
  }
  e.Le = e;
  e.ye = void 0;
}
function markHeap(e) {
  if (e.Et) return;
  e.Et = true;
  for (let t = 0; t <= e.$e; t++) {
    for (let E = e.Xe[t]; E !== void 0; E = E.ye) {
      if (E.m & REACTIVE_IN_HEAP) markNode(E);
    }
  }
}
function markNode(e, t = REACTIVE_DIRTY) {
  const E = e.m;
  if ((E & (REACTIVE_CHECK | REACTIVE_DIRTY)) >= t) return;
  e.m = E & -4 | t;
  for (let t2 = e.ie; t2 !== null; t2 = t2.se) {
    markNode(t2.le, REACTIVE_CHECK);
  }
}
function runHeap(e, t) {
  e.Et = false;
  for (e.Je = 0; e.Je <= e.$e; e.Je++) {
    let E = e.Xe[e.Je];
    while (E !== void 0) {
      if (E.m & REACTIVE_IN_HEAP) t(E);
      else adjustHeight(E, e);
      E = e.Xe[e.Je];
    }
  }
  e.$e = 0;
}
function adjustHeight(e, t) {
  deleteFromHeap(e, t);
  let E = e.Fe;
  for (let t2 = e.v; t2; t2 = t2.B) {
    const e2 = t2.H;
    if (e2.M && e2.Fe >= E) E = e2.Fe + 1;
  }
  if (e.Fe !== E) {
    e.Fe = E;
    for (let E2 = e.ie; E2 !== null; E2 = E2.se) insertIntoHeapHeight(E2.le, t);
  }
}

// packages/signals/dist/scalar/core/owner.js
function markDisposal(e) {
  let n = e.pe;
  while (n) {
    n.m |= REACTIVE_ZOMBIE;
    markDisposal(n);
    n = n.He;
  }
}
function disposeChildren(e, n = false, t) {
  const l = e.m;
  if (l & REACTIVE_DISPOSED) return;
  if (n && !t && e.R !== null && (e.R.he !== null || e.R.Ve !== null)) disposeChildren(e, false, true);
  if (n) {
    e.m = l | REACTIVE_DISPOSED;
  }
  if (n && e.M) {
    cleanupReruns?.(e);
    if (e.R !== null) e.R.ce = null;
    if (e.h & STATUS_PENDING && e.R?.Te != null || l & REACTIVE_FRAME_READ || layerObserved && e.l === EFFECT_RENDER) schedule();
  }
  let r = t ? e.R.he : e.pe;
  if (t) e.R.he = null;
  else e.pe = null;
  while (r) {
    const e2 = r;
    e2.U &= ~CONFIG_AUTO_DISPOSE;
    deleteFromHeap(e2, dirtyQueue);
    clearDeps(e2);
    r.xe = r;
    disposeChildren(r, true);
    r = r.He;
  }
  if (!t) e.Ue = 0;
  if (n && !t && !(l & REACTIVE_ZOMBIE) && e._parent !== null && !(e._parent.m & REACTIVE_DISPOSED)) {
    const n2 = e.xe;
    const t2 = e.He;
    if (n2 !== null) n2.He = t2;
    else e._parent.pe = t2;
    if (t2 !== null) t2.xe = n2;
    e.xe = null;
  }
  runDisposal(e, t);
  if (n && e.Ke) {
    const n2 = e.Ke;
    e.Ke = void 0;
    n2();
  }
}
function linkChild(e, n) {
  const t = e.pe;
  n.xe = null;
  n.He = t;
  if (t !== null) t.xe = n;
  e.pe = n;
}
function runDisposal(e, n) {
  const t = n ? e.R.Ve : e.Ie;
  if (!t) return;
  if (n) e.R.Ve = null;
  else e.Ie = null;
  if (Array.isArray(t)) {
    for (let e2 = t.length - 1; e2 >= 0; e2--) {
      const n2 = t[e2];
      n2.call(n2);
    }
  } else {
    t.call(t);
  }
}
function childId(e, n) {
  let t = e;
  while (t.U & CONFIG_TRANSPARENT && t._parent) t = t._parent;
  if (t.id != null) return formatId(t.id, t.Ue++);
  throw new Error("");
}
function getNextChildId(e) {
  return childId(e);
}
function inheritId(e, n, t) {
  return e?.id ?? (n ? t?.id : t?.id != null ? getNextChildId(t) : void 0);
}
function formatId(e, n) {
  const t = n.toString(36), l = t.length - 1;
  return e + (l ? String.fromCharCode(64 + l) : "") + t;
}
function cleanup(e) {
  if (!context) return e;
  if (!context.Ie) context.Ie = e;
  else if (Array.isArray(context.Ie)) context.Ie.push(e);
  else context.Ie = [context.Ie, e];
  return e;
}
function disposeRootSelf(e = true) {
  disposeChildren(this, e);
}
function createOwner(e) {
  const n = context;
  const t = e?.transparent ?? false;
  const l = {
    id: inheritId(e, t, n),
    U: t ? CONFIG_TRANSPARENT : 0,
    Be: true,
    G: n?.Be ? n.G : n,
    pe: null,
    He: null,
    xe: null,
    Ie: null,
    t: n?.t || defaultContext,
    Ue: 0,
    R: null,
    _parent: n,
    dispose: disposeRootSelf
  };
  if (n) linkChild(n, l);
  return l;
}
function createRoot(e, n) {
  const t = createOwner(n);
  return runWithOwner(t, () => e(() => t.dispose()));
}

// packages/signals/dist/scalar/core/graph.js
var dependencyFrame;
function setDependencyFrameHook(e) {
  dependencyFrame = e;
}
var slotUnobservedHook;
function unlinkSubs(e) {
  const n = e.H;
  const o = e.B;
  const l = e.se;
  const t = e.ze;
  if (l !== null) l.ze = t;
  else n.ke = t;
  if (t !== null) t.se = l;
  else {
    n.ie = l;
    if (l === null) {
      if (n.U & CONFIG_SLOT_NODE) slotUnobservedHook(n);
      else n.R?.We?.();
      const e2 = n;
      e2.M && e2.U & CONFIG_AUTO_DISPOSE && !(e2.m & REACTIVE_ZOMBIE) && !(e2.h & STATUS_PENDING) && unobserved(e2);
    }
  }
  return o;
}
function trimStaleDeps(e) {
  const n = e.Ge;
  let o = n !== null ? n.B : e.v;
  if (o !== null) {
    do {
      o = unlinkSubs(o);
    } while (o !== null);
    if (n !== null) n.B = null;
    else e.v = null;
  }
  dependencyFrame?.(e, "commit");
}
function clearDeps(e) {
  dependencyFrame?.(e, "clear");
  let n = e.v;
  if (!n) return;
  do {
    n = unlinkSubs(n);
  } while (n !== null);
  e.v = null;
  e.Ge = null;
}
function unobserved(e) {
  deleteFromHeap(e, dirtyQueue);
  clearDeps(e);
  disposeChildren(e, true);
}
var dormantNodes = /* @__PURE__ */ new Set();
function sweepDormant() {
  if (dormantNodes.size === 0) return;
  for (const e of dormantNodes) {
    if (!e.ie && e.U & CONFIG_AUTO_DISPOSE && !(e.h & STATUS_PENDING) && !(e.m & (REACTIVE_DISPOSED | REACTIVE_ZOMBIE))) {
      unobserved(e);
    }
  }
  dormantNodes.clear();
}
function link(e, n) {
  const o = n.Ge;
  if (o !== null && o.H === e) return;
  let l = null;
  const t = n.m & REACTIVE_RECOMPUTING_DEPS;
  if (t) {
    l = o !== null ? o.B : n.v;
    if (l !== null && l.H === e) {
      l.Oe = n._e;
      n.Ge = l;
      return;
    }
  }
  const r = e.ke;
  if (r !== null && r.le === n && (!t || r.Oe === n._e)) return;
  const s = n.Ge = e.ke = {
    H: e,
    le: n,
    B: l,
    ze: r,
    se: null,
    Oe: n._e
  };
  if (o !== null) o.B = s;
  else n.v = s;
  if (r !== null) r.se = s;
  else e.ie = s;
  if (dependencyFrame && !(n.h & STATUS_UNINITIALIZED)) dependencyFrame(n, "insert");
  bumpNotifyEpoch();
}

// packages/signals/dist/scalar/core/core.js
GlobalQueue.Ae = (e) => {
  if (e.l === EFFECT_TRACKED) {
    deleteFromHeap(e, dirtyQueue);
    e.Ce = true;
    globalQueue.enqueue(EFFECT_USER, e.V);
  } else if (e.m & REACTIVE_ZOMBIE && !(e.m & REACTIVE_LANE_DIRTY)) deferZombie(e);
  else recompute(e);
};
GlobalQueue.Re = disposeChildren;
var tracking = false;
var context = null;
function normalizeCalculation(e, t, n) {
  const l = typeof t === "object" && t !== null;
  const E = e.R?.ce !== n;
  const u = E || !l ? t : handleAsync(e, t);
  if (!E && !l) {
    if (e.R !== null) e.R.ce = null;
    e.U &= ~CONFIG_LOADING;
  }
  return u;
}
function recompute(e, t = false, n = false) {
  if (!t && layerRecompute && e.U & CONFIG_HELD && !n && layerRecompute(e)) return;
  bumpNotifyEpoch();
  const l = e.l;
  const E = null;
  if (!t) {
    deleteFromHeap(e, dirtyQueue);
    if (e.R !== null) {
      e.R.ce = null;
      releaseFlightTeardown(e);
    }
    if (e.U & CONFIG_HELD) {
      const t2 = txOf(e);
      if (l !== EFFECT_RENDER && true) joinPassTx(t2);
      else if (t2 !== flushTransaction && !(e.h & STATUS_UNINITIALIZED)) {
        e.Ee = NOT_PENDING;
        if (l === EFFECT_RENDER) e.U &= ~CONFIG_HELD;
      }
    }
    if (l === EFFECT_TRACKED || e.U & CONFIG_STAGED) disposeChildren(e);
    else if (e.pe !== null || e.Ie !== null) parkChildren(e);
  }
  const u = !!(e.h & STATUS_UNINITIALIZED);
  const i = e.h & STATUS_ERROR ? e.R?.i : void 0;
  const r = (e.h & STATUS_PENDING) !== 0;
  const o = r ? e.R?.oe : void 0;
  const _ = e.R?.oe?.has(e);
  const s = (e.m & REACTIVE_REASK) !== 0 && !(e.h & STATUS_PENDING && e.R !== null && !e.R.ue);
  const I = context;
  context = e;
  e.Ge = null;
  e._e++;
  e.m = REACTIVE_RECOMPUTING_DEPS | e.m & REACTIVE_ZOMBIE;
  e.ae = clock;
  let a = e.Ee !== NOT_PENDING ? e.Ee : e.Ne;
  let f = e.Fe;
  let N = false;
  let T = false;
  let c = tracking;
  tracking = true;
  try {
    if (e.U & CONFIG_SYNC) {
      a = layerCompute ? layerCompute(e, a) : e.M(a);
      if (e.R !== null) e.R.ce = null;
      e.U &= ~CONFIG_LOADING;
    } else {
      const t2 = e.R?.ce;
      a = layerCompute ? layerCompute(e, a, normalizeCalculation) : normalizeCalculation(e, e.M(a), t2);
    }
    if (e.h !== 0 || e.R !== null) clearStatus(e, t);
  } catch (t2) {
    const n2 = t2 instanceof NotReadyError;
    if (n2 && e.U & CONFIG_LOADING) {
      parkLoadingWindow(e, t2);
    } else {
      if (n2) ext(e).fe = true;
      notifyStatus(e, n2 ? STATUS_PENDING : STATUS_ERROR, t2);
      if (n2 && _ && !e.R?.ce) settlePendingSource(e);
      if (n2 && o) {
        for (const t3 of o) if (t3 !== e && !e.R?.oe?.has(t3)) settlePendingSource(e, t3);
      }
    }
  } finally {
    tracking = c;
    N = (e.m & REACTIVE_MISSED_WAKE) !== 0;
    T = (e.m & REACTIVE_JOINED) !== 0;
    e.m = e.m & (REACTIVE_ZOMBIE | REACTIVE_DISPOSED | REACTIVE_FRAME_READ | REACTIVE_STAGED_READ | REACTIVE_LANE_READ | REACTIVE_SCREEN_READ | REACTIVE_PROBE_UNANSWERED) | (t ? e.m & REACTIVE_SNAPSHOT_STALE : 0);
    context = I;
    if (e.R !== null) e.R.ue = s && (e.h & STATUS_PENDING) !== 0;
  }
  if (e.m & REACTIVE_DISPOSED) {
    clearDeps(e);
    if (e.R !== null) e.R.ce = null;
    return;
  }
  let d = null;
  const A = !!e.R?.i;
  if (!e.R?.i) {
    const n2 = e.Ee !== NOT_PENDING ? e.Ee : e.Ne;
    let r2 = false;
    try {
      r2 = !l && u || !e.Pe || !e.Pe(n2, a);
    } catch (t2) {
      notifyStatus(e, STATUS_ERROR, t2);
    }
    if (l && r2 && // A stale reader of a lane (REACTIVE_SCREEN_READ) that computed what it
    // last applied owes no run (lanes.ts).
    !(e.m & REACTIVE_SCREEN_READ && !e.Ce && Object.is(e.me, a)) && // A re-staging pass owes no run: the commit replays the effect (#3802).
    e.Ee === NOT_PENDING) {
      e.Ce = !e.R?.i;
      if (!t || d !== null) globalQueue.enqueue(l, e.L ??= GlobalQueue.k.bind(null, e), d);
    }
    if (A) ;
    else if (r2) {
      if (t ? !((flushTransaction !== null || passTx !== null) && (T || E || !layerDetached?.(e) && (creatorPass(I)?.m ?? 0) & REACTIVE_JOINED)) : l && e.Ee === NOT_PENDING) {
        e.Ne = a;
      } else {
        e.Ee = a;
        if (t) {
          holdNode(e, flushTransaction ?? passTx);
          e.h |= STATUS_UNINITIALIZED;
          GlobalQueue.ee?.(e);
        }
      }
      if (e.ie !== null) {
        insertSubs(e);
      }
    } else if (e.Fe != f) {
      for (let t2 = e.ie; t2 !== null; t2 = t2.se) insertIntoHeapHeight(t2.le, dirtyQueue);
    }
    if (!r2 && !e.R?.i) {
      if (i !== void 0) settleErroredDependents(e, i);
      if (o) {
        for (const t2 of o) if (t2 !== e) settlePendingSource(e, t2);
      }
    }
    if (_ && !(e.h & (STATUS_PENDING | STATUS_UNINITIALIZED))) settlePendingSource(e);
  }
  if (t && d === null && (T || E) && e.h & STATUS_PENDING) {
    const t2 = flushTransaction ?? passTx;
    if (t2 !== null && true && !GlobalQueue.ee?.(e)) holdNode(e, t2);
  }
  if (!e.R?.i && e.Ee === NOT_PENDING && !(l && e.Ce)) {
    if (t || l === EFFECT_TRACKED) trimStaleDeps(e);
    else heldTrim(e);
  }
  if (e.Ee !== NOT_PENDING || dependencyFrame && e.h & STATUS_ERROR || e.R !== null && (e.R.he !== null || e.R.Ve !== null) || (e.h & (STATUS_PENDING | STATUS_UNINITIALIZED)) !== 0 && (!t || (e.h & STATUS_PENDING) !== 0)) {
    e.U |= CONFIG_STAGED;
    queuePendingNode(e);
  }
  if (N) {
    enqueueSub(e);
    schedule();
  }
}
function updateIfNecessary(e) {
  if (e.m & (REACTIVE_RECOMPUTING_DEPS | REACTIVE_DISPOSED)) return;
  if (e.m & REACTIVE_CHECK) {
    for (let t = e.v; t; t = t.B) {
      const n = t.H;
      if (n.M) {
        updateIfNecessary(n);
      }
      if (e.m & REACTIVE_DIRTY) {
        break;
      }
    }
  }
  if (e.m & REACTIVE_DIRTY || e.R?.i && e.ae < clock && !e.R?.ce) {
    recompute(e);
  }
  e.m = e.m & (REACTIVE_SNAPSHOT_STALE | REACTIVE_IN_HEAP | REACTIVE_IN_HEAP_HEIGHT | REACTIVE_ZOMBIE | REACTIVE_DISPOSED | REACTIVE_MANUAL_WRITE | REACTIVE_FRAME_READ | REACTIVE_STAGED_READ | REACTIVE_LANE_READ | REACTIVE_SCREEN_READ | REACTIVE_PROBE_UNANSWERED);
}
function computed(e, t) {
  const n = t?.transparent ?? false;
  const l = t !== null && typeof t === "object" && "loadingValue" in t;
  const E = {
    id: inheritId(t, n, context),
    U: (l ? CONFIG_LOADING : 0) | (n ? CONFIG_TRANSPARENT : 0) | (t?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (!context || t?.lazy ? CONFIG_AUTO_DISPOSE : 0) | (t?.sync ? CONFIG_SYNC : 0) | (t?.X ? CONFIG_NO_SNAPSHOT : 0) | (t?.ge ?? 0) | 0,
    Pe: t?.equals ?? isEqual,
    Ie: null,
    t: context?.t ?? defaultContext,
    Ue: 0,
    M: e,
    Ne: l ? t.loadingValue : void 0,
    Fe: 0,
    ye: void 0,
    Le: null,
    v: null,
    Ge: null,
    _e: 0,
    ie: null,
    ke: null,
    _parent: context,
    He: null,
    xe: null,
    pe: null,
    m: t?.lazy ? REACTIVE_LAZY : REACTIVE_NONE,
    // A loadingValue node is born committed: commit #0 is already in _value.
    h: l ? 0 : STATUS_UNINITIALIZED,
    ae: clock,
    Ee: NOT_PENDING,
    be: -1,
    // Cold machinery (async slots) lives one hop away in the lazily-allocated extension — the core literal MUST
    // stay under V8's in-object boundary (§12: past ~39 fields every
    // allocation spills to a backing store and creation cost ~4x's).
    R: null
  };
  if (t?.unobserved) ext(E).We = t.unobserved;
  setupComputedNode(E, t);
  return E;
}
function ext(e) {
  return e.R ??= {
    ce: null,
    Se: null,
    i: void 0,
    fe: void 0,
    oe: void 0,
    We: void 0,
    Ze: void 0,
    he: null,
    Ve: null,
    Te: null,
    ue: false,
    Me: NOT_PENDING,
    Qe: -1,
    de: 0,
    D: NOT_PENDING,
    je: 0
  };
}
function joinPass(e, t) {
  if (layerJoin?.(e, t)) return;
  if (preparingUpdate === null || preparingUpdate !== txOf(t)) e.m |= REACTIVE_JOINED;
  if (t.h & STATUS_UNINITIALIZED || e.l !== EFFECT_RENDER) joinPassTx(txOf(t), !e.l && e.h & STATUS_UNINITIALIZED || GlobalQueue.ee?.(e));
}
function frameRead(e, t) {
  if (layerFrameRead?.(e, t)) return true;
  if (t.h & STATUS_UNINITIALIZED) return false;
  if (e.l !== EFFECT_RENDER || t.U & CONFIG_INPUTS_PUBLISHED) return false;
  const n = txOf(t);
  if (n === flushTransaction && true && true || e.h & STATUS_UNINITIALIZED && e.U & CONFIG_HELD && txOf(e) === n) return false;
  staleReader(e, n);
  return true;
}
function creatorPass(e) {
  return e !== null && e.Be ? e.G : e;
}
function parkChildren(e) {
  markDisposal(e);
  const t = ext(e);
  t.Ve = e.Ie;
  t.he = e.pe;
  e.Ie = null;
  e.pe = null;
  e.Ue = 0;
}
function createEffectNode(e, t, n, l, E) {
  const u = E?.transparent ?? false;
  const i = {
    id: inheritId(E, u, context),
    U: (u ? CONFIG_TRANSPARENT : 0) | (E?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (E?.sync ? CONFIG_SYNC : 0) | (E?.ge ?? 0) | 0,
    Pe: false,
    Ie: null,
    t: context?.t ?? defaultContext,
    Ue: 0,
    M: e,
    Ne: void 0,
    Fe: 0,
    ye: void 0,
    Le: null,
    v: null,
    Ge: null,
    _e: 0,
    ie: null,
    ke: null,
    _parent: context,
    He: null,
    xe: null,
    pe: null,
    m: REACTIVE_LAZY,
    h: STATUS_UNINITIALIZED,
    ae: clock,
    Ee: NOT_PENDING,
    be: -1,
    Ce: false,
    me: void 0,
    ve: t,
    Ye: n,
    Ke: void 0,
    l,
    R: null
  };
  if (E?.unobserved) ext(i).We = E.unobserved;
  setupComputedNode(i, lazyOptions);
  return i;
}
var effectStatusNotify = null;
function setEffectStatusNotify(e) {
  effectStatusNotify = e;
}
function statusNotifierOf(e) {
  return e.l ? effectStatusNotify ?? void 0 : void 0;
}
var lazyOptions = {
  lazy: true
};
function setupComputedNode(e, t) {
  e.Le = e;
  const n = context?.Be ? context.G : context;
  if (context) linkChild(context, e);
  if (n) e.Fe = n.Fe + 1;
  GlobalQueue.qe?.(e);
  !t?.lazy && recompute(e, true);
}
function signal(e, t) {
  const n = {
    Pe: t?.equals ?? isEqual,
    U: (t?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (t?.X ? CONFIG_NO_SNAPSHOT : 0),
    Ne: e,
    ie: null,
    ke: null,
    Ee: NOT_PENDING,
    // Signal-literal diet (§12e): NO _time/_fn/_statusFlags slots. Stores
    // materialize one signal per touched leaf, so signal bytes are store
    // bytes. Computations use _time for retries and async provenance;
    // signal writes use _notifiedAt. _fn/_statusFlags read falsy-identically as
    // missing properties on the shared paths (undefined masks to 0).
    be: -1,
    R: null
  };
  if (t?.unobserved) ext(n).We = t.unobserved;
  return n;
}
function isEqual(e, t) {
  return e === t;
}
var verdict = null;
function untrack(e, t) {
  if (GlobalQueue.we === null && !tracking && true) return e();
  const n = tracking;
  tracking = false;
  try {
    if (GlobalQueue.we) return GlobalQueue.we(e);
    return e();
  } finally {
    tracking = n;
  }
}
var spectating = false;
function prepareComputed(e, t) {
  if (e.m & REACTIVE_LAZY) {
    e.m &= ~REACTIVE_LAZY;
    recompute(e, true);
  } else if (e.m & REACTIVE_DISPOSED) {
    if (e.U & CONFIG_AUTO_DISPOSE) {
      const t2 = e._parent;
      if (t2 !== null) {
        if (t2.m & REACTIVE_DISPOSED) {
          e.U &= ~CONFIG_AUTO_DISPOSE;
          return;
        }
        if (!(e.m & REACTIVE_ZOMBIE)) linkChild(t2, e);
      }
      recompute(e, true);
    }
  } else ;
}
function readerSeesCommitted(e, t) {
  return !!(!t || e.Ee === NOT_PENDING || t.U & CONFIG_CHILDREN_FORBIDDEN);
}
var unflushedStaged = false;
function markUnflushedStaged() {
  unflushedStaged = true;
}
function unflushedValue(e) {
  if (globalQueue.j || e.Ee === NOT_PENDING || e.U & CONFIG_PROMOTED) return NOT_PENDING;
  if (e.U & CONFIG_HELD) return e.R.Qe === clock ? e.R.Me : NOT_PENDING;
  return e.Ne;
}
function stashFlushed(e) {
  const t = e.R;
  if (t.Qe !== clock) {
    t.Me = e.Ee;
    t.Qe = clock;
    unflushedStaged = true;
  }
}
var promotedWrites = [];
function markLateLinker(e) {
  e.m |= REACTIVE_MISSED_WAKE;
  return true;
}
function resyncUnflushedCompanions() {
  unflushedStaged = false;
  if (promotedWrites.length !== 0) {
    for (const e of promotedWrites) e.U &= ~CONFIG_PROMOTED;
    promotedWrites.length = 0;
  }
}
function pullComputed(e, t) {
  if (e.Fe >= dirtyQueue.Je) {
    markNode(t);
    markHeap(dirtyQueue);
    updateIfNecessary(e);
  } else if (t.U & CONFIG_FRESH_READ) updateIfNecessary(e);
  const n = e.Fe;
  if (n >= t.Fe && e._parent !== t) t.Fe = n + 1;
}
function read(e) {
  let t = context;
  if (t?.Be) t = t.G;
  const n = e;
  const l = e;
  const E = typeof n.M === "function";
  if (E) prepareComputed(e);
  if (verdict !== null) return verdict(e, t);
  if (!E && e.R?.Ze === void 0 && true && (!unflushedStaged || e.Ee === NOT_PENDING) && // A28, see readNodeFast
  true && // lanes: the slow path's one arm
  true) {
    if (t) {
      if (tracking) link(e, t);
      if (e.U & CONFIG_HELD && !(t.U & CONFIG_CHILDREN_FORBIDDEN)) {
        if (frameRead(t, e)) return e.Ne;
        joinPass(t, e);
      }
    }
    if (!t || e.Ee === NOT_PENDING || t.U & CONFIG_CHILDREN_FORBIDDEN) return e.Ne;
    stagedRead(t, e);
    return e.Ee;
  }
  let u = false;
  if (t) {
    if (tracking) {
      link(e, t);
      if (E) pullComputed(l, t);
    }
    if (E) layerRead?.(t, l);
    if (e.U & CONFIG_HELD && true && !(t.U & CONFIG_CHILDREN_FORBIDDEN)) {
      if (!frameRead(t, e)) joinPass(t, e);
      else u = true;
    }
  }
  if (l.h & STATUS_PENDING && !u) {
    if (t) {
      if (!(t.U & CONFIG_CHILDREN_FORBIDDEN) || l.h & STATUS_UNINITIALIZED) {
        if (!tracking && !spectating && e !== t) link(e, t);
        throw l.R?.i;
      }
    } else if (l.h & STATUS_UNINITIALIZED) {
      throw l.R?.i;
    }
  }
  if (E && l.h & STATUS_ERROR) {
    if (tracking && l.ae < clock) {
      recompute(l);
      return read(e);
    } else throw l.R?.i;
  }
  if (u) return e.Ne;
  const i = serve(e, t);
  if (!t && E && e.U & CONFIG_AUTO_DISPOSE && !(l.h & STATUS_PENDING) && !e.ie) {
    dormantNodes.add(e);
    schedule();
  }
  return i;
}
function serve(e, t) {
  if (e.Ee !== NOT_PENDING && e.h & STATUS_UNINITIALIZED && (!t || spectating || t.U & CONFIG_CHILDREN_FORBIDDEN)) throw new NotReadyError(null);
  const n = t && unflushedStaged ? unflushedValue(e) : NOT_PENDING;
  if (n !== NOT_PENDING) {
    markLateLinker(t);
    return n;
  }
  if (readerSeesCommitted(e, t)) return e.Ne;
  stagedRead(t, e);
  return e.Ee;
}
function stagedRead(e, t) {
  if (!(t?.h & STATUS_UNINITIALIZED)) {
    e.m |= REACTIVE_STAGED_READ;
    if (t && flushTransaction !== null && preparingUpdate === null && true && true) e.m |= REACTIVE_JOINED;
  }
}
function notePromotedWrite(e) {
  if (globalQueue.j || e.U & CONFIG_PROMOTED) return;
  e.U |= CONFIG_PROMOTED;
  promotedWrites.push(e);
}
function setSignal(e, t) {
  const n = e.Ee === NOT_PENDING ? e.Ne : e.Ee;
  if (typeof t === "function") t = t(n);
  if (e.U & CONFIG_HELD) joinFuture(txOf(e));
  const l = !!(e.h & STATUS_UNINITIALIZED) || !e.Pe || !e.Pe(n, t);
  if (!l) return t;
  const E = e.Ee !== NOT_PENDING;
  if (!E) queuePendingNode(e);
  else if (e.U & CONFIG_HELD && !globalQueue.j) stashFlushed(e);
  e.Ee = t;
  if (context !== null) notePromotedWrite(e);
  if (e.M !== void 0) e.ae = clock;
  if (E && e.be === notifyEpoch) return t;
  insertSubs(e);
  schedule();
  return t;
}
function setMemo(e, t) {
  const n = e.U & CONFIG_HELD && !(e.m & REACTIVE_MANUAL_WRITE) && txOf(e) !== flushTransaction;
  if (n && typeof t === "function") t = t(e.Ne);
  const l = setSignal(e, t);
  if (n) {
    e.m = e.m & ~REACTIVE_CHECK | REACTIVE_DIRTY;
    insertIntoHeap(e, dirtyQueue);
    schedule();
  } else if (e.Ee !== NOT_PENDING) e.m |= REACTIVE_MANUAL_WRITE;
  return l;
}
function runWithOwner(e, t) {
  const n = context;
  const l = tracking;
  context = e;
  tracking = false;
  try {
    return t();
  } finally {
    context = n;
    tracking = l;
  }
}

// packages/signals/dist/scalar/core/async.js
function addPendingSource(e, t) {
  if (e.R?.oe?.has(t)) return false;
  (ext(e).oe ??= /* @__PURE__ */ new Set()).add(t);
  return true;
}
function removePendingSource(e, t) {
  const n = e.R?.oe;
  if (!n?.delete(t)) return false;
  if (!n.size) e.R.oe = void 0;
  return true;
}
function clearPendingSources(e) {
  if (e.R !== null) e.R.oe = void 0;
}
function retryReaches(e, t) {
  for (let n = e.v; n; n = n.B) {
    const e2 = n.H;
    if (e2 === t || e2.R?.oe?.has(t)) return true;
  }
  return false;
}
function parkLoadingWindow(e, t) {
  ext(e).fe = true;
  if (t.source) addPendingSource(e, t.source);
  if (!(e.h & STATUS_ERROR)) setPendingError(e, t.source, t);
}
function setPendingError(e, t, n) {
  if (!t) {
    if (e.R !== null) e.R.i = null;
    return;
  }
  if (n instanceof NotReadyError && n.source === t) {
    ext(e).i = n;
    return;
  }
  const r = e.R?.i;
  if (!(r instanceof NotReadyError) || r.source !== t) {
    ext(e).i = new NotReadyError(t);
  }
}
function forEachDependent(e, t) {
  for (let n = e.ie; n !== null; n = n.se) t(n.le, n);
}
function releaseIfSettledUnobserved(e) {
  e.M && e.U & CONFIG_AUTO_DISPOSE && !e.ie && !(e.m & REACTIVE_ZOMBIE) && !(e.h & STATUS_PENDING) && unobserved(e);
}
function releaseSettledDependents(e) {
  let t;
  const n = /* @__PURE__ */ new Set();
  const visit = (e2) => {
    if (n.has(e2)) return;
    n.add(e2);
    if (!e2.ie && e2.U & CONFIG_AUTO_DISPOSE) (t ??= []).push(e2);
    forEachDependent(e2, visit);
  };
  forEachDependent(e, visit);
  if (t) for (const e2 of t) releaseIfSettledUnobserved(e2);
}
function settleErroredDependents(e, t) {
  let n = false;
  const r = /* @__PURE__ */ new Set();
  const visit = (e2) => {
    if (r.has(e2)) return;
    r.add(e2);
    if (e2.R?.i === t) {
      enqueueSub(e2);
      n = true;
    }
    forEachDependent(e2, visit);
  };
  forEachDependent(e, visit);
  if (n) schedule();
}
function settlePendingSource(e, t = e) {
  removePendingSource(e, t);
  let n = false;
  let r;
  const o = /* @__PURE__ */ new Set();
  const settle = (u) => {
    if (o.has(u) || // A conditional dropped this source, but another dependency can still
    // carry it. Only retire pending state inherited through the recovered
    // branch. Deliberately NOT marked visited on this early return: the
    // carrying dependency may itself be a later branch of this same walk
    // (two unchanged memos converging), and its visit must be free to
    // re-examine this node once that branch has retired the source.
    t !== e && retryReaches(u, t) || !removePendingSource(u, t))
      return u.U & CONFIG_VERDICT && enqueueSub(u);
    o.add(u);
    u.ae = clock;
    const f = u.R?.oe?.values().next().value;
    const i = u.h & STATUS_ERROR;
    if (f) {
      if (!i) setPendingError(u, f);
    } else {
      u.h &= ~STATUS_PENDING;
      if (!i) setPendingError(u);
      if (u.U & CONFIG_HELD && !layerStatus?.(u, e)) joinFuture(txOf(u));
      if (u.R?.fe) {
        enqueueSub(u);
        n = true;
      }
      if (u.R !== null) u.R.fe = false;
      if (!u.ie && u.U & CONFIG_AUTO_DISPOSE) (r ??= []).push(u);
    }
    forEachDependent(u, settle);
  };
  forEachDependent(e, settle);
  if (r) for (const e2 of r) releaseIfSettledUnobserved(e2);
  if (n) schedule();
}
function isThenable(e) {
  return e != null && typeof e === "object" && typeof e.then === "function";
}
function releaseFlightTeardown(e) {
  const t = e.R?.Se;
  if (t != null) {
    e.R.Se = null;
    t();
  }
}
function handleAsync(e, t, n, r) {
  let o = false;
  let u = false;
  if (typeof t === "object" && t !== null) {
    untrack(() => {
      o = t[Symbol.asyncIterator];
      u = !o && isThenable(t);
    });
  }
  if (!u && !o) {
    if (e.R !== null) e.R.ce = null;
    e.U &= ~CONFIG_LOADING;
    return t;
  }
  ext(e).ce = t;
  e.R.de = question || MAINLINE_QUESTION;
  e.R.oe = void 0;
  let f;
  const handleError = (n2) => {
    if (e.R?.ce !== t) return;
    let r2 = n2 instanceof NotReadyError;
    if (r2 && e.U & CONFIG_LOADING) {
      if (e.R !== null) e.R.ce = null;
      parkLoadingWindow(e, n2);
      e.ae = clock;
      return;
    }
    notifyStatus(e, r2 ? STATUS_PENDING : STATUS_ERROR, n2);
    if (r2) settlePendingSource(e);
    e.ae = clock;
    if (!r2) releaseSettledDependents(e);
  };
  const asyncWrite = (n2, r2) => {
    if (e.R?.ce !== t) return;
    if (e.m & REACTIVE_DIRTY) return;
    !!(e.h & STATUS_UNINITIALIZED);
    landStatus(e);
    {
      try {
        setSignal(e, () => n2);
      } catch (t2) {
        notifyStatus(e, STATUS_ERROR, t2);
      }
    }
    if (e.Ee === NOT_PENDING) {
      e.U &= ~CONFIG_LOADING;
      trimStaleDeps(e);
    }
    settlePendingSource(e);
    schedule();
    flush();
    r2?.();
  };
  const settleAutodispose = () => {
    if (e.U & CONFIG_AUTO_DISPOSE && !e.ie && !(e.h & STATUS_PENDING)) {
      unobserved(e);
      return true;
    }
    return false;
  };
  const consumeIterator = (n2, r2) => {
    const o2 = n2[Symbol.asyncIterator]();
    let u2 = false;
    let i2 = false;
    let s = !r2;
    const close = () => {
      if (i2) return;
      i2 = true;
      try {
        const e2 = o2.return?.();
        if (isThenable(e2)) e2.then(void 0, () => {
        });
      } catch {
      }
    };
    r2 ? r2(close) : cleanup(close);
    ext(e).Se = close;
    const iterateOrRelease = () => {
      if (!i2 && !settleAutodispose()) iterate();
    };
    const iterate = () => {
      let n3, r3, l2 = false, a = false, S = true;
      const c = o2.next();
      const d = isThenable(c) ? c : {
        then: (e2) => void e2(c)
      };
      d.then((r4) => {
        if (i2) return;
        if (S && s) {
          n3 = r4;
          l2 = true;
          if (r4.done) i2 = true;
        } else if (e.R?.ce !== t) {
          return;
        } else if (!r4.done) {
          u2 = true;
          asyncWrite(r4.value, iterateOrRelease);
        } else {
          i2 = true;
          if (u2) {
            schedule();
            flush();
          } else {
            asyncWrite(void 0);
          }
          settleAutodispose();
        }
      }, (n4) => {
        if (i2) return;
        if (S && s) {
          r3 = n4;
          a = true;
        } else if (e.R?.ce === t) {
          i2 = true;
          handleError(n4);
          settleAutodispose();
        }
      });
      S = false;
      if (a) {
        i2 = true;
        handleError(r3);
        if (s) throw r3;
        return true;
      }
      if (l2 && !n3.done) {
        f = n3.value;
        u2 = true;
        return iterate();
      }
      return l2 && n3.done;
    };
    const l = iterate();
    s = false;
    return u2 || l;
  };
  let i = null;
  const flattenIfIterable = (e2, t2) => {
    let n2 = false;
    if (typeof e2 === "object" && e2 !== null) {
      untrack(() => {
        n2 = e2[Symbol.asyncIterator];
      });
    }
    if (!n2) return false;
    const r2 = consumeIterator(e2, t2);
    if (!t2) i = r2;
    return true;
  };
  if (u) {
    let n2 = false, r2 = false, o2, u2 = true;
    const registerDeferredClose = (t2) => {
      if (!e.Ie) e.Ie = t2;
      else if (Array.isArray(e.Ie)) e.Ie.push(t2);
      else e.Ie = [e.Ie, t2];
    };
    t.then((r3) => {
      if (u2) {
        f = r3;
        n2 = true;
      } else if (e.R?.ce === t && !(e.m & REACTIVE_DISPOSED) && flattenIfIterable(r3, registerDeferredClose)) ;
      else {
        asyncWrite(r3);
        settleAutodispose();
      }
    }, (e2) => {
      if (u2) {
        o2 = e2;
        r2 = true;
      } else {
        handleError(e2);
        settleAutodispose();
      }
    });
    u2 = false;
    if (r2) {
      handleError(o2);
      throw o2;
    } else if (!n2) {
      if (e.U & CONFIG_LOADING) return e.Ne;
      throw new NotReadyError(context);
    } else if (!flattenIfIterable(f)) {
      e.U &= ~CONFIG_LOADING;
    }
  }
  if (o) flattenIfIterable(t);
  if (i !== null) {
    if (!i) {
      if (e.U & CONFIG_LOADING) return e.Ne;
      throw new NotReadyError(context);
    }
    e.U &= ~CONFIG_LOADING;
  }
  return f;
}
function clearStatus(e, t = false) {
  if (e.R?.oe) clearPendingSources(e);
  if (e.R?.fe) {
    if (e.R !== null) e.R.fe = false;
  }
  e.h = t ? 0 : e.h & STATUS_UNINITIALIZED;
  if (e.R?.i) setPendingError(e);
  const n = statusNotifierOf(e);
  if (n) n.call(e);
}
function landStatus(e, t = false) {
  const n = e.R?.oe;
  if (n && (n.delete(e), n.size)) {
    e.R.fe = false;
    if (t) e.h = STATUS_PENDING;
    setPendingError(e, n.values().next().value);
  } else clearStatus(e, t);
}
function notifyStatus(e, t, n, r) {
  if (t === STATUS_ERROR && !(n instanceof StatusError) && !(n instanceof NotReadyError)) n = new StatusError(e, n);
  const o = t === STATUS_PENDING && n instanceof NotReadyError ? n.source : void 0;
  {
    if (t === STATUS_PENDING && o) {
      addPendingSource(e, o);
      e.h = STATUS_PENDING | e.h & STATUS_UNINITIALIZED;
      setPendingError(e, o, n);
    } else {
      clearPendingSources(e);
      e.h = t | (t !== STATUS_ERROR ? e.h & STATUS_UNINITIALIZED : 0);
      ext(e).i = n;
    }
  }
  if (t === STATUS_PENDING && e.R?.Te) resolveTx(e.R.Te).De = true;
  if (t === STATUS_PENDING && layerObserved?.(e, flushTransaction)) joinFuture(null);
  if (t === STATUS_PENDING && e.U & CONFIG_GUESS) {
    if (passLane === null) joinFuture(null);
    return;
  }
  const u = statusNotifierOf(e);
  if (u) {
    {
      u.call(e);
    }
    return;
  }
  propagateStatus(e, t, n);
}
function propagateStatus(e, t, n, r) {
  const o = t === STATUS_PENDING && n instanceof NotReadyError ? n.source : void 0;
  forEachDependent(e, (r2, u) => {
    if (layerStatus?.(r2, e)) return;
    r2.ae = clock;
    if (r2.U & (CONFIG_REDERIVE | CONFIG_VERDICT) || t === STATUS_PENDING && u.Oe !== r2._e) {
      enqueueSub(r2);
      schedule();
      return;
    }
    if (t === STATUS_PENDING && o && r2.R?.oe?.has(o)) {
      if (passLane === null && (r2.U & (CONFIG_HELD | CONFIG_OVERRIDE)) === CONFIG_HELD && globalQueue.j) joinFuture(txOf(r2));
      return;
    }
    if (t === STATUS_PENDING && o || t !== STATUS_PENDING && (r2.R?.i !== n || r2.R?.oe)) {
      {
        {
          queuePendingNode(r2);
          if (t === STATUS_PENDING && (r2.U & (CONFIG_HELD | CONFIG_OVERRIDE)) === CONFIG_HELD && !r2.l) joinFuture(txOf(r2));
        }
      }
      notifyStatus(r2, t, n);
    }
  });
}

// packages/signals/dist/scalar/core/action.js
function inTransaction(t, n, e) {
  const i = question;
  setQuestion(n);
  joinFuture(t);
  const o = e();
  if (actionDepth === 0) flush();
  setQuestion(i);
  return o;
}
function action(t) {
  return (...n) => new Promise((e, i) => {
    const o = t(...n);
    const r = newTransaction();
    r.tt = 1;
    r.nt = true;
    const s = nextQuestion();
    const done = (t2, n2, o2 = false) => {
      resolveTx(r).tt--;
      schedule();
      o2 ? i(n2) : e(t2);
    };
    const step = (t2, n2) => {
      let e2;
      enterAction();
      try {
        e2 = n2 ? o.throw(t2) : o.next(t2);
      } catch (t3) {
        exitAction();
        return done(void 0, t3, true);
      }
      exitAction();
      if (isThenable(e2)) return void e2.then(run, (t3) => done(void 0, t3, true));
      run(e2);
    };
    const run = (t2) => {
      if (t2.done) return done(t2.value);
      let n2 = false;
      try {
        if (isThenable(t2.value)) return void t2.value.then((t3) => {
          if (n2) return;
          n2 = true;
          inTransaction(r, s, () => step(t3));
        }, (t3) => {
          if (n2) return;
          n2 = true;
          inTransaction(r, s, () => step(t3, true));
        });
      } catch (t3) {
        if (n2) return;
        n2 = true;
        return void inTransaction(r, s, () => step(t3, true));
      }
      inTransaction(r, s, () => step(t2.value));
    };
    joinFuture(r);
    const u = question;
    setQuestion(s);
    step();
    setQuestion(u);
  });
}

// packages/signals/dist/scalar/core/effect.js
function effect(t, e, E, u) {
  const f = !!u?.user;
  const r = createEffectNode(t, e, E, f ? EFFECT_USER : EFFECT_RENDER, u);
  recompute(r, true);
  !u?.defer && r.Ee === NOT_PENDING && true && (r.l === EFFECT_USER || u?.schedule ? globalQueue.enqueue(r.l, runEffect.bind(null, r)) : runEffect(r, r.l));
}
function notifyEffectStatus(t, e) {
  const E = t !== void 0 ? t : this.h;
  const u = e !== void 0 ? e : this.R?.i;
  if (E & STATUS_ERROR) {
    globalQueue.notify(this, STATUS_PENDING, 0);
    if (this.l === EFFECT_USER) {
      if (this.h & STATUS_ERROR) {
        this.Ce = true;
        globalQueue.enqueue(this.l, this.L ??= runEffect.bind(null, this));
      }
      return;
    }
    if (!globalQueue.notify(this, STATUS_ERROR, STATUS_ERROR)) {
      haltReactivity(unwrapStatusError(u));
      throw u;
    }
  } else if (this.l === EFFECT_RENDER) {
    globalQueue.notify(this, STATUS_PENDING | STATUS_ERROR, E, u);
  }
}
function runEffect(t, e) {
  if (!t.Ce || t.m & REACTIVE_DISPOSED) return;
  if (GlobalQueue.te && GlobalQueue.te(t)) return;
  if (t.h & STATUS_ERROR && t.l === EFFECT_USER) {
    const e2 = unwrapStatusError(t.R?.i);
    t.me = t.Ne;
    t.Ce = false;
    try {
      t.Ye ? t.Ye(e2, () => {
        const e3 = t.Ke;
        t.Ke = void 0;
        e3?.();
      }) : console.error(e2);
    } catch (e3) {
      if (!globalQueue.notify(t, STATUS_ERROR, STATUS_ERROR)) {
        haltReactivity(e3);
        throw e3;
      }
    }
    return;
  }
  const E = t.R?.i == null;
  if (t.U & CONFIG_HELD && true) {
    txOf(t).et[e - 1].push(t.L ??= runEffect.bind(null, t));
    return;
  }
  const u = t.Ke;
  t.Ke = void 0;
  try {
    u?.();
    const e2 = t.ve(t.Ne, t.me);
    if (false) ;
    t.Ke = e2;
  } catch (e2) {
    ext(t).i = new StatusError(t, e2);
    t.h |= STATUS_ERROR;
    if (!globalQueue.notify(t, STATUS_ERROR, STATUS_ERROR)) {
      haltReactivity(e2);
      throw e2;
    }
  } finally {
    t.me = t.Ne;
    t.Ce = false;
    if (E) trimStaleDeps(t);
  }
}
GlobalQueue.k = runEffect;
setEffectStatusNotify(notifyEffectStatus);

// packages/signals/dist/scalar/signals.js
function accessor(e) {
  const c = read.bind(null, e);
  c[$REFRESH] = e;
  return c;
}
function createSignal(e, c) {
  if (typeof e === "function") {
    const r2 = computed(e, c);
    r2.U &= ~CONFIG_AUTO_DISPOSE;
    return [accessor(r2), setMemo.bind(null, r2)];
  }
  const r = signal(e, c);
  return [accessor(r), setSignal.bind(null, r)];
}
function createMemo(e, c) {
  return accessor(computed(e, c));
}
function createRenderEffect(e, c, r) {
  effect(e, c, void 0, r);
}

// packages/signals/dist/scalar/experimental/boundary.js
var boundaries = /* @__PURE__ */ new WeakMap();

// packages/signals/dist/scalar/experimental/committed-dependencies.js
var saved = /* @__PURE__ */ new WeakMap();
var inserted = [];
var count = 0;
var boundaries2 = /* @__PURE__ */ new WeakMap();
function registerBoundary(e) {
  boundaries2.set(e.output, e);
}
function isInserted(e) {
  for (let n = 0; n < count; n++) if (inserted[n] === e) return true;
  return false;
}
function forgetInserted(e) {
  let n = false;
  for (let t = count - 1; t >= 0; t--) {
    if (inserted[t].le !== e) continue;
    inserted[t] = inserted[--count];
    inserted[count] = null;
    n = true;
  }
  return n;
}
function dependencies(e, n = false) {
  const t = [];
  if (n && e.Ge === null) return t;
  for (let r = e.v; r; r = r.B) {
    if (n || !isInserted(r)) t.push(r.H);
    if (n && r === e.Ge) break;
  }
  return t;
}
setDependencyFrameHook((e, n) => {
  if (n === "park") {
    if (!saved.has(e) && !(e.h & STATUS_UNINITIALIZED)) {
      for (let n3 = 0; n3 < count; n3++) {
        if (inserted[n3].le !== e) continue;
        saved.set(e, dependencies(e));
        break;
      }
    }
    const n2 = forgetInserted(e);
    return n2 || saved.has(e) || !!(e.Ge ? e.Ge.B : e.v);
  } else if (n === "insert") {
    inserted[count++] = e.Ge;
  } else {
    if (!count && !e.R) return;
    forgetInserted(e);
    if (n === "commit" && e.h & STATUS_ERROR) {
      saved.set(e, dependencies(e, true));
    } else saved.delete(e);
  }
});
function* committedDependencies(e) {
  if (e.h & STATUS_UNINITIALIZED) return;
  const n = saved.get(e);
  if (n) yield* n;
  else for (let n2 = e.v; n2; n2 = n2.B) if (!isInserted(n2)) yield n2.H;
}
function layerPosition(e, n) {
  if (typeof e.M !== "function") return 0;
  n ??= /* @__PURE__ */ new Set();
  if (n.has(e)) return 0;
  n.add(e);
  try {
    const t = boundaries2.get(e);
    if (t) return t.override === NOT_PENDING ? layerPosition(t.input, n) : t.position ?? 1 + layerPosition(t.input, n);
    let r = 0;
    for (const t2 of committedDependencies(e)) r = Math.max(r, layerPosition(t2, n));
    return r;
  } finally {
    n.delete(e);
  }
}

// packages/signals/dist/scalar/experimental/layer.js
function inputTime(e) {
  return typeof e.M === "function" ? e.ae : e.be;
}
var proposals = /* @__PURE__ */ new Map();
var active = /* @__PURE__ */ new Set();
var scoped = /* @__PURE__ */ new Set();
var inputObservers = /* @__PURE__ */ new Map();
function forwardObservation(e, t) {
  if (!e.inputStatus) return;
  if (t) {
    let t2 = inputObservers.get(e.input);
    if (!t2) inputObservers.set(e.input, t2 = /* @__PURE__ */ new Set());
    t2.add(e);
    setLayerObserved(forwardedHold);
  } else {
    const t2 = inputObservers.get(e.input);
    if (t2?.delete(e) && !t2.size) inputObservers.delete(e.input);
    if (!inputObservers.size) setLayerObserved();
  }
}
function observed(e, t, n = /* @__PURE__ */ new Set()) {
  if (n.has(e) || e.m & REACTIVE_DISPOSED || !onScreen(e, t)) return false;
  n.add(e);
  if (e.l === EFFECT_RENDER) return true;
  for (let r = e.ie; r; r = r.se) {
    const o = r.le;
    const s = t && !(o.h & (STATUS_PENDING | STATUS_ERROR)) && o.U & CONFIG_HELD && txOf(o) === resolveTx(t);
    let i = r.Oe === o._e;
    if (!i && !s) {
      for (const t2 of committedDependencies(o)) if (t2 === e) {
        i = true;
        break;
      }
    }
    if (i && observed(o, t, n)) return true;
  }
  for (const r of inputObservers.get(e) || []) if (observed(r.output, t, n)) return true;
  return false;
}
function forwardedHold(e, t) {
  const n = inputObservers.get(e);
  if (n) {
    for (const e2 of n) if (observed(e2.output, t)) return true;
  }
  return false;
}
setLayerVisibility((e, t) => !boundaries.get(e) || observed(e, t));
function positionOf(e) {
  return e ? resolveTx(e).rt ?? 0 : 0;
}
var candidateUpdates = /* @__PURE__ */ new Set();
var preparingEffects = /* @__PURE__ */ new WeakSet();
var releasingInput = null;
var evaluation = null;
var evaluationReads = null;
var retryEvaluation = false;
var RETRY = /* @__PURE__ */ Symbol("retry layer calculation");
var layerOwn2 = (e, t) => {
  const n = boundaries.get(e);
  if (n === void 0) return;
  if (n && n.update === null && n.override !== NOT_PENDING && e.Ee !== NOT_PENDING && !Object.is(e.Ne, e.Ee)) ownLayerUpdate(n, t, inputUpdate(n));
};
var layerHooks = {};
function wakeLayers() {
  setLayerCommit(prepareLayers, settleLayers);
  schedule();
}
function enableReads() {
  setLayerReads(layerOwn2, mergeLayers, frameRead2, rederiveStatus);
}
function stopIfIdle() {
  if (candidateUpdates.size || active.size || scoped.size || proposals.size || layerHooks.active?.()) return;
  setLayerCommit();
  setLayerReads();
  setLayerCompute();
}
function watchParent(e) {
  e = resolveTx(e);
  if (candidateUpdates.has(e)) return;
  if (!candidateUpdates.size) {
    enableReads();
    setLayerCompute(computeLayer, rerunLayer, readContext, deferJoin, detachedOutput);
  }
  candidateUpdates.add(e);
}
function isChildUpdate(e) {
  return positionOf(e) > 0;
}
function inputUpdate(e) {
  if (e.input.U & CONFIG_HELD) return txOf(e.input);
  if (e.scope) return liveTx(e.scope);
  const t = boundaries.get(e.input);
  return t?.inputStatus ? inputUpdate(t) : null;
}
function resumeInput(e, t) {
  forwardObservation(e, false);
  e.override = NOT_PENDING;
  if (e.output.U & CONFIG_HELD) merge(txOf(e.output), t);
  joinFuture(t);
  enqueueSub(e.output);
}
function retire(e) {
  const t = liveTx(e.scope);
  if (!t) joinFuture(null);
  resumeInput(e, t ?? resolveTx(flushTransaction));
  e.scope = null;
  scoped.delete(e);
}
var orderPublication = false;
function prepareLayers() {
  if (!scoped.size && !candidateUpdates.size) return layerHooks.beforeCommit?.() ?? false;
  if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
  let e = false;
  let t;
  for (const e2 of scoped) {
    const n = resolveTx(e2.scope);
    if (!n.tt && !(e2.output.m & REACTIVE_DISPOSED) && e2.input.h & STATUS_PENDING && observed(e2.output, n)) (t ??= /* @__PURE__ */ new Set()).add(n);
  }
  for (const n of scoped) {
    if (n.output.m & REACTIVE_DISPOSED) {
      scoped.delete(n);
      n.scope = null;
    } else if (resolveTx(n.scope).tt === 0 && !t?.has(resolveTx(n.scope))) {
      proposals.delete(n);
      retire(n);
      e = true;
    }
  }
  e = (layerHooks.beforeCommit?.() ?? false) || e;
  for (const t2 of candidateUpdates) {
    const n = liveTx(t2);
    if (!n || blocked(n)) continue;
    for (const t3 of n.pn || []) {
      if (!t3.l && t3.m & REACTIVE_FRAME_READ && !(t3.m & REACTIVE_DISPOSED)) {
        const r = unpublishedFrame(t3);
        if (r && positionOf(r) < positionOf(n)) {
          orderPublication = true;
          continue;
        }
        n.pn.delete(t3);
        t3.m &= ~REACTIVE_FRAME_READ;
        const o = releasingInput;
        releasingInput = n;
        try {
          recomputeInUpdate(t3, n);
        } finally {
          releasingInput = o;
        }
        e = true;
        if (resolveTx(n) !== n) break;
      }
    }
  }
  return e;
}
function mergeLayers(e, t) {
  if (e.rt || t.rt) t.rt = Math.min(positionOf(e), positionOf(t));
  if (candidateUpdates.delete(e)) candidateUpdates.add(t);
}
function includesBoundary(e, t) {
  return currentPosition(e) > positionOf(t);
}
function unpublishedFrame(e) {
  let t = e;
  for (let n = e._parent; n; t = n, n = n._parent) {
    if (t.m & REACTIVE_ZOMBIE) return null;
    const e2 = n;
    if (e2.m & REACTIVE_RECOMPUTING_DEPS && e2.m & REACTIVE_JOINED) return flushTransaction;
    if (e2.U & CONFIG_STAGED && e2.U & CONFIG_HELD) return txOf(e2);
  }
  return null;
}
function frameRead2(e, t) {
  const n = flushTransaction;
  const r = t.h & STATUS_UNINITIALIZED;
  const o = txOf(t);
  if (n && o === resolveTx(n)) return false;
  const s = positionOf(n), i = positionOf(o);
  if (i > s && unpublishedFrame(e)) {
    staleReader(e, o);
    if (r) throw new NotReadyError(t);
    return true;
  }
  if (r) return false;
  if (s > i) {
    watchParent(o);
    staleReader(e, o);
    return true;
  }
  if (s > 0 && i > 0) return false;
  if (e.l === EFFECT_RENDER) return false;
  if (includesBoundary(e, o)) {
    watchParent(o);
    staleReader(e, o);
    return true;
  }
  return false;
}
function rederiveStatus(e, t) {
  if (!(e.U & CONFIG_HELD)) return false;
  const n = t.U & CONFIG_HELD ? txOf(t) : flushTransaction;
  const r = positionOf(txOf(e)), o = positionOf(n);
  if (r <= o && !(r < o && unpublishedFrame(e))) return false;
  enqueueSub(e);
  schedule();
  return true;
}
function rerunLayer(e) {
  const t = unpublishedFrame(e);
  if (t && flushTransaction && t !== resolveTx(flushTransaction) && positionOf(t) < positionOf(flushTransaction)) {
    preparingEffects.delete(e);
    recomputeInUpdate(e, t, true);
    return true;
  }
  if (e.l && !preparingEffects.delete(e)) return false;
  const n = txOf(e);
  if (!isChildUpdate(n)) return false;
  if (!flushTransaction && hasUnheldProposals()) joinFuture(null);
  const r = flushTransaction && resolveTx(flushTransaction);
  if (r === n || r && r === releasingInput) return false;
  if (positionOf(r) >= positionOf(n)) return false;
  if (r) holdQueuedProposals(r);
  recomputeInUpdate(e, n, true);
  return true;
}
function deferJoin(e, t) {
  if (evaluation !== e || e.l === EFFECT_RENDER) return false;
  const n = txOf(t);
  if (flushTransaction && resolveTx(flushTransaction) === n) return false;
  (evaluationReads ??= /* @__PURE__ */ new Map()).set(t, n);
  joinFuture(null);
  e.m |= REACTIVE_JOINED;
  return true;
}
function currentPosition(e, t = /* @__PURE__ */ new Set()) {
  if (t.has(e)) return 0;
  t.add(e);
  const n = boundaries.get(e);
  if (n && n.override !== NOT_PENDING) return n.position ?? 1;
  const r = e;
  let o = 0;
  for (let e2 = r.v; e2; e2 = e2.B) if (e2.Oe === r._e) o = Math.max(o, currentPosition(e2.H, t));
  return o;
}
function readContext(e, t) {
  if (evaluation !== e || !evaluationReads) return;
  for (const t2 of evaluationReads.values()) {
    const n = resolveTx(t2);
    if (flushTransaction && n === resolveTx(flushTransaction)) continue;
    const r = positionOf(flushTransaction), o = positionOf(n);
    if (r > 0 && o >= r) continue;
    if (!includesBoundary(e, n)) continue;
    watchParent(n);
    staleReader(e, n);
    joinFuture(null);
    const s = resolveTx(flushTransaction);
    s.rt = Math.max(positionOf(s), currentPosition(e));
    retryEvaluation = true;
    throw RETRY;
  }
}
function detachedOutput(e) {
  const t = boundaries.get(e);
  return !!t && !t.inputStatus;
}
function computeLayer(e, t, n) {
  const r = flushTransaction;
  const o = evaluation, s = retryEvaluation;
  let i = evaluationReads;
  evaluation = e;
  evaluationReads = null;
  retryEvaluation = false;
  try {
    for (; ; ) {
      let s2, a, u = false;
      try {
        const r2 = e.R?.ce;
        s2 = e.M(t);
        if (!retryEvaluation && n) s2 = n(e, s2, r2);
      } catch (e2) {
        a = e2;
        u = true;
      }
      if (!retryEvaluation) {
        const t2 = evaluationReads;
        if (t2) {
          if (o && e._parent === o) {
            for (const [e2, n2] of t2) (i ??= /* @__PURE__ */ new Map()).set(e2, n2);
          } else {
            if (r === null && flushTransaction && !positionOf(flushTransaction)) flushTransaction.rt = positionOf(t2.values().next().value);
            for (const e2 of t2.values()) joinFuture(resolveTx(e2));
          }
        }
        if (u) throw a;
        return s2;
      }
      if (s2 && typeof s2.then === "function") Promise.resolve(s2).catch(() => {
      });
      if (e.R !== null) e.R.ce = null;
      releaseFlightTeardown(e);
      disposeChildren(e);
      e.Ge = null;
      e._e++;
      evaluationReads = null;
      retryEvaluation = false;
    }
  } finally {
    evaluation = o;
    evaluationReads = i;
    retryEvaluation = s;
  }
}
function orderUpdates(e) {
  if (!orderPublication) return;
  orderPublication = false;
  for (let t = 1; t < e.length; t++) {
    if (positionOf(e[t - 1]) <= positionOf(e[t])) continue;
    e.sort((e2, t2) => positionOf(e2) - positionOf(t2));
    return;
  }
}
setLayerTransactions((e) => {
  watchParent(e);
  wakeLayers();
}, orderUpdates);
function takeOutput(e, t) {
  const n = /* @__PURE__ */ new Set();
  const visit = (r) => {
    if (n.has(r)) return;
    n.add(r);
    const o = unpublishedFrame(r);
    if (r !== e.output && o && positionOf(o) < positionOf(t)) {
      staleReader(r, t);
      return;
    }
    const s = boundaries.get(r);
    if (r !== e.output && s && s.override !== NOT_PENDING) return;
    enqueueSub(r);
    const i = r;
    if (i.l) preparingEffects.add(r);
    if (i.Ce && i.L) {
      t.et[i.l - 1].push(i.L);
    }
    holdNode(r, t);
    for (let e2 = r.ie; e2; e2 = e2.se) visit(e2.le);
  };
  visit(e.output);
}
function ownLayerUpdate(e, t, n) {
  e.update = t;
  resolveTx(t).rt = e.position ?? 1 + layerPosition(e.input);
  active.add(e);
  if (n !== null && n !== t) watchParent(n);
}
function stageLayer(e, t, n) {
  const r = inputUpdate(e);
  e.position = n ?? 1 + Math.max(layerPosition(e.input), positionOf(r));
  e.override = t;
  forwardObservation(e, t !== NOT_PENDING);
  e.inputTime = inputTime(e.input);
  enableReads();
  if (r === null && !(e.output.U & CONFIG_HELD) && e.output.Ee === NOT_PENDING && t !== NOT_PENDING && e.output.Pe && e.output.Pe(e.output.Ne, t)) {
    enqueueSub(e.output);
    return;
  }
  const o = e.update && liveTx(e.update);
  const s = o && o !== r && isChildUpdate(o) && positionOf(o) === e.position ? o : newTransaction();
  ownLayerUpdate(e, s, r);
  takeOutput(e, s);
  enqueueSub(e.output);
}
function forgetFinishedUpdate(e) {
  if (!liveTx(e)) candidateUpdates.delete(e);
}
function forgetFinishedLayer(e) {
  if (!liveTx(e.update)) {
    e.update = null;
    active.delete(e);
  }
}
function selectProposal(e, t) {
  t.override = e;
  t.position = void 0;
}
function positionProposal(e, t) {
  t.position = 1 + Math.max(layerPosition(t.input), positionOf(inputUpdate(t)));
}
function applyProposal(e, t) {
  if (!(t.output.m & REACTIVE_DISPOSED)) stageLayer(t, e, t.position);
}
function settleLayers() {
  if (!candidateUpdates.size && !active.size && !proposals.size && !scoped.size) {
    layerHooks.afterCommit?.();
    stopIfIdle();
    return;
  }
  candidateUpdates.forEach(forgetFinishedUpdate);
  if (!candidateUpdates.size) {
    if (!active.size) setLayerCompute();
    if (scoped.size && hasHeldNodes()) {
      for (const e of scoped) if (e.scope) watchParent(resolveTx(e.scope));
    }
  }
  active.forEach(forgetFinishedLayer);
  if (proposals.size) {
    proposals.forEach(selectProposal);
    proposals.forEach(positionProposal);
    proposals.forEach(applyProposal);
    proposals.clear();
    return;
  }
  layerHooks.afterCommit?.();
  stopIfIdle();
}
function createLayer(e, t) {
  const n = computed(e, {
    equals: false
  });
  const r = createLayerBoundary(n);
  r.inputStatus = true;
  return layerAccessors(r, t);
}
function selectLayer(e, t, n) {
  const r = e.input;
  n?.(e);
  if (e.scope !== null && e.override !== NOT_PENDING && !(r.h & STATUS_PENDING) && inputTime(r) !== e.inputTime) {
    const t2 = liveTx(e.scope);
    if (t2) {
      if (r.U & CONFIG_HELD) merge(txOf(r), t2);
      if (!e.update || liveTx(e.update) !== flushTransaction) joinFuture(t2);
    }
  }
  if (e.override === NOT_PENDING) return t ? t(e) : read(r);
  link(r, e.output);
  return e.override;
}
function createLayerBoundary(e, t, n, r = true, o = false) {
  if (r) e.U &= ~CONFIG_AUTO_DISPOSE;
  const s = {
    input: e,
    override: NOT_PENDING,
    update: null,
    scope: null,
    inputTime: inputTime(e)
  };
  const i = computed(selectLayer.bind(null, s, t, n), {
    lazy: o,
    ge: CONFIG_REDERIVE
  });
  if (!o) i.U &= ~CONFIG_AUTO_DISPOSE;
  s.output = i;
  registerBoundary(s);
  boundaries.set(i, s);
  if (!boundaries.has(e)) boundaries.set(e, null);
  return s;
}
function releaseLayer(e) {
  forwardObservation(e, false);
  scoped.delete(e);
  active.delete(e);
  proposals.delete(e);
  e.scope = e.update = null;
  wakeLayers();
}
function layerAccessors(e, t) {
  const n = e.output;
  const propose = (r) => {
    const o = proposals.get(e);
    const s = proposals.has(e) && o !== NOT_PENDING ? o : e.override !== NOT_PENDING ? e.override : n.Ee !== NOT_PENDING ? n.Ee : n.Ne;
    const i = typeof r === "function" ? r(s) : r;
    if (t?.lifetime === "action") {
      const t2 = flushTransaction ?? (e.scope && liveTx(e.scope));
      if (!t2 || !resolveTx(t2).nt) {
        throw new Error("The action-lifetime experiment requires a guess inside an action.");
      }
      if (e.scope) merge(t2, e.scope);
      e.scope = resolveTx(t2);
      if (e.input.U & CONFIG_HELD && !(e.input.h & STATUS_PENDING)) merge(txOf(e.input), e.scope);
      scoped.add(e);
    }
    n.Ke ??= releaseLayer.bind(null, e);
    proposals.set(e, i);
    wakeLayers();
    return i;
  };
  const clear = () => {
    proposals.set(e, NOT_PENDING);
    wakeLayers();
  };
  const accessor2 = () => read(n);
  accessor2[$REFRESH] = n;
  return [accessor2, propose, clear];
}

// packages/signals/dist/scalar/index.js
function createOptimistic(e) {
  if (typeof e !== "function") {
    throw new TypeError("The scalar experiment requires an optimistic input accessor.");
  }
  const [r, t] = createLayer(e, {
    lifetime: "action"
  });
  return [r, t];
}
export {
  action,
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  createOptimistic as optimistic
};
