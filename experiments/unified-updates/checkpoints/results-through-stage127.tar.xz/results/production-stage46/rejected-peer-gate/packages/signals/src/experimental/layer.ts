/**
 * Scalar experiment: an input producer and an ordinary output computation.
 * Explicit propose/clear isolates publication; the optional action lifetime
 * retires overrides through the same ordinary derivation and commit paths.
 * This entry does not install or use the optimistic lane engine.
 */
import { computed, read } from "../core/core.js";
import {
  changedDependencies,
  clearDeps,
  dependencyEpoch,
  link,
  trackDependencies
} from "../core/graph.js";
import { enqueueSub } from "../core/heap.js";
import { disposeChildren } from "../core/owner.js";
import {
  $REFRESH,
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  CONFIG_REDERIVE,
  EFFECT_RENDER,
  NOT_PENDING,
  REACTIVE_DISPOSED,
  REACTIVE_FRAME_READ,
  REACTIVE_JOINED,
  STATUS_UNINITIALIZED,
  STATUS_PENDING
} from "../core/constants.js";
import {
  blocked,
  flushTransaction,
  globalQueue,
  setLayerCommit,
  setLayerReads,
  setLayerCompute,
  holdNode,
  holdQueuedProposals,
  recomputeInUpdate,
  hasHeldNodes,
  joinFuture,
  liveTx,
  merge,
  newTransaction,
  resolveTx,
  schedule,
  staleReader,
  txOf,
  type Transaction
} from "../core/scheduler.js";
import type { Computed, Link, Signal } from "../core/types.js";
import { registerBoundary } from "./committed-dependencies.js";
import { changedUpdateGroups, coupleUpdates, registerUpdate, settleUpdateGroups, updatePosition } from "./update-groups.js";

export function inputTime(input: Computed<any>): number {
  return typeof input._fn === "function" ? input._time : input._notifiedAt;
}

export type Layer<T> = {
  input: Computed<any>;
  output: Computed<T>;
  override: T | typeof NOT_PENDING;
  update: Transaction | null;
  scope: Transaction | null;
  inputTime: number;
  inputStatus?: true;
  statusInput?: Computed<any>;
};

const boundaries = new WeakMap<Signal<any>, Layer<any> | null>();
/** Value overrides retain the pending calculation of their relative input.
 * Observation boundaries do not inherit the pending state they describe. */
export function pendingInput(source: Signal<any>): Computed<any> | undefined {
  const boundary = boundaries.get(source);
  return boundary?.statusInput ?? (boundary?.inputStatus ? boundary.input : undefined);
}

const proposals = new Map<Layer<any>, unknown>();
const active = new Set<Layer<any>>();
const scoped = new Set<Layer<any>>();
// A child update may observe its input update's published frame without
// consuming that update's proposal. Only live child updates have this record.
const parents = new WeakMap<Transaction, Set<Transaction>>();
const candidateUpdates = new Set<Transaction>();
let releasingInput: Transaction | null = null;
let evaluation: Computed<any> | null = null;
let evaluationReads: Map<Signal<any>, Transaction> | null = null;
// Positive reachability only, scoped to a parent update and unchanged
// dependencies. Weak keys do not retain disposed nodes or completed updates.
type Reach = { epoch: number; dependencies: number; tail: Link | null; visit: number };
let visit = 0;
const reachability = new WeakMap<Transaction, WeakMap<Signal<any>, Reach>>();
let graphEpoch = 0;
let cacheReads = true;
const layerOwn = (node: Signal<any>, update: Transaction) => {
  const layer = boundaries.get(node);
  if (layer === undefined) return;
  graphEpoch++;
  // A settled selector propagates normally. If its consequences suspend,
  // ordinary parking supplies the output update and we record only its cut.
  // The selector retires its override before proposing any input answer.
  if (
    layer &&
    layer.update === null &&
    layer.override !== NOT_PENDING &&
    node._pendingValue !== NOT_PENDING &&
    !Object.is(node._value, node._pendingValue)
  )
    ownLayerUpdate(layer, update, inputUpdate(layer));
};

/** Observation boundaries install their lifecycle at these same seams.
 * Their proposals use stageLayer and the ordinary output machinery. */
export const layerHooks: {
  beforeCommit?: () => boolean;
  afterCommit?: () => void;
  active?: () => boolean;
} = {};

export function wakeLayers(): void {
  setLayerCommit(prepareLayers, settleLayers);
  schedule();
}

function enableReads(): void {
  trackDependencies(true);
  setLayerReads(layerOwn, mergeLayers, frameRead);
}

function stopIfIdle(): void {
  if (
    candidateUpdates.size ||
    active.size ||
    scoped.size ||
    proposals.size ||
    layerHooks.active?.()
  )
    return;
  setLayerCommit();
  setLayerReads();
  setLayerCompute();
  trackDependencies(false);
}

function parentSet(update: Transaction): Set<Transaction> | undefined {
  return parents.get(resolveTx(update));
}

function watchParent(update: Transaction): void {
  enableReads();
  candidateUpdates.add(update);
  setLayerCompute(computeLayer, rerunLayer);
}

function isChildUpdate(update: Transaction): boolean {
  const resolved = resolveTx(update);
  const excluded = parents.get(resolved);
  // An explicit-clear override can start above a settled input. An empty
  // exclusion set still identifies its output update; no parent is pending.
  if (excluded?.size === 0) return true;
  for (const parent of excluded || []) {
    if (resolveTx(parent) !== resolved) return true;
  }
  return false;
}

function inputUpdate(layer: Layer<any>): Transaction | null {
  if (layer.input._config & CONFIG_HELD) return txOf(layer.input);
  if (layer.scope) return liveTx(layer.scope);
  const boundary = boundaries.get(layer.input);
  return boundary?.inputStatus ? inputUpdate(boundary) : null;
}

/** An input answer or the end of an action retires its override as work of
 * that action. Reading the input below then uses normal derivation joining.
 * Published output and owned children stay in the common committed slots. */
export function resumeInput(layer: Layer<any>, update: Transaction): void {
  graphEpoch++;
  layer.override = NOT_PENDING;
  // Retiring the cut makes its suspended consequences input work again.
  // Recompute will supersede obsolete flights in that common update.
  if (layer.output._config & CONFIG_HELD) merge(txOf(layer.output), update);
  joinFuture(update);
  enqueueSub(layer.output);
}

function retire(layer: Layer<any>): void {
  // An input hidden by an override can outlive the action transaction. Its
  // eventual answer resumes in live ordinary work, never a completed hold.
  const scope = liveTx(layer.scope!);
  if (!scope) joinFuture(null);
  resumeInput(layer, scope ?? resolveTx(flushTransaction!));
  layer.scope = null;
  scoped.delete(layer);
}

function prepareLayers(): boolean {
  const changedGroups = changedUpdateGroups();
  if (changedGroups.length) {
    if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
    for (const [update, layer] of changedGroups) takeOutput(layer, update);
    return true;
  }
  if (!scoped.size && !candidateUpdates.size) return layerHooks.beforeCommit?.() ?? false;
  // This round can discover a lower flight after a child already re-ran.
  // Include all its proposals before deciding whether that input is ready.
  if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
  // Park/commit can change ownership without a computation running. Keep
  // those phases uncached; pure rounds reuse only structurally valid entries.
  cacheReads = false;
  let changed = false;
  // Guesses made in the same action hold have one lifetime. An input still
  // in flight keeps every override in that group selected, even after the
  // bodies return. This bookkeeping exists only for active optimistic scopes.
  let waiting: Set<Transaction> | undefined;
  for (const layer of scoped) {
    const scope = resolveTx(layer.scope!);
    if (
      !scope._open &&
      !(layer.output._flags & REACTIVE_DISPOSED) &&
      layer.input._statusFlags & STATUS_PENDING
    )
      (waiting ??= new Set()).add(scope);
  }
  for (const layer of scoped) {
    if (layer.output._flags & REACTIVE_DISPOSED) {
      scoped.delete(layer);
      layer.scope = null;
    } else if (resolveTx(layer.scope!)._open === 0 && !waiting?.has(resolveTx(layer.scope!))) {
      proposals.delete(layer);
      retire(layer);
      changed = true;
    }
  }
  // Retire observations before replaying readers of the now-ready input.
  // A callback probe also reads that input for control flow. Replaying it
  // against a stale true observation would join the ready input to the
  // obsolete async consequence that the false observation must supersede.
  changed = (layerHooks.beforeCommit?.() ?? false) || changed;
  for (const update of candidateUpdates) {
    const parent = liveTx(update);
    if (!parent || blocked(parent)) continue;
    for (const reader of parent._reruns || []) {
      if (
        !(reader as any)._type &&
        reader._flags & REACTIVE_FRAME_READ &&
        !(reader._flags & REACTIVE_DISPOSED)
      ) {
        // Derivations of a committed parent frame must discover their next
        // async work before that parent publishes. A post-commit rerun is
        // sufficient for a direct binding, but would let a memo lag behind
        // an already-published input after its boundary dependency changes.
        parent._reruns!.delete(reader);
        reader._flags &= ~REACTIVE_FRAME_READ;
        const previous = releasingInput;
        releasingInput = parent;
        try {
          recomputeInUpdate(reader, parent);
        } finally {
          releasingInput = previous;
        }
        changed = true;
        // This pass can merge its holder into another update. Its remaining
        // readers moved there; reconsider that holder's readiness on the
        // next iteration instead of continuing against the emptied record.
        if (resolveTx(parent) !== parent) break;
      }
    }
  }
  return changed;
}

function mergeLayers(from: Transaction, into: Transaction): void {
  coupleUpdates(from, into);
  graphEpoch++;
  if (candidateUpdates.delete(from)) candidateUpdates.add(into);
  const source = parents.get(from);
  if (!source) return;
  const target = parents.get(into);
  if (target) for (const parent of source) target.add(parent);
  else parents.set(into, source);
  parents.delete(from);
}

function reachesBoundary(
  node: Signal<any>,
  holder: Transaction,
  cache: WeakMap<Signal<any>, Reach>,
  epoch: number,
  visit: number
): boolean {
  const computed = node as Computed<any>;
  const cached = cache.get(node);
  if (
    cached &&
    epoch >= 0 &&
    cached.epoch === epoch &&
    cached.dependencies === dependencyEpoch &&
    cached.tail === computed._depsTail
  )
    return true;
  if (cached?.visit === visit) return false;
  const entry = cached || { epoch: -1, dependencies: -1, tail: null, visit };
  if (cached) entry.visit = visit;
  else cache.set(node, entry);
  const boundary = boundaries.get(node);
  let found = false;
  if (boundary && boundary.override !== NOT_PENDING) {
    const input = inputUpdate(boundary);
    found =
      (input === null ||
        !(boundary.output._config & CONFIG_HELD) ||
        txOf(boundary.output) !== input) &&
      (input === holder || !isChildUpdate(holder));
  } else {
    for (let edge = computed._deps; edge; edge = edge._nextDep) {
      // A staged memo retains old links for its committed children's frame.
      // They do not describe the proposal consumed by an ordinary derivation.
      if (edge._gen !== computed._depGen) continue;
      if (reachesBoundary(edge._dep, holder, cache, epoch, visit)) {
        found = true;
        break;
      }
    }
  }
  if (found && epoch >= 0) {
    entry.epoch = epoch;
    entry.dependencies = dependencyEpoch;
    entry.tail = computed._depsTail;
  }
  return found;
}

function includesBoundary(reader: Computed<any>, holder: Transaction): boolean {
  // Only current dependencies authorize a published-parent read. Cache
  // positive answers while dependencies are unchanged; the visit stamp bounds
  // cycles without allocating a Set and recursive closure for every read.
  let cache = reachability.get(holder);
  if (!cache) reachability.set(holder, (cache = new WeakMap()));
  return reachesBoundary(
    reader,
    holder,
    cache,
    cacheReads && globalQueue._running ? graphEpoch : -1,
    ++visit
  );
}

function frameRead(reader: Computed<any>, source: Signal<any>): boolean {
  const update = flushTransaction;
  if ((source as Computed<any>)._statusFlags & STATUS_UNINITIALIZED) return false;
  const excluded = update && parentSet(update);
  const holder = txOf(source);
  if (update && holder === resolveTx(update)) return false;
  if (update && updatePosition(update) > updatePosition(holder)) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  if (excluded)
    for (const parent of excluded) {
      if (resolveTx(parent) === holder) {
        staleReader(reader, holder);
        return true;
      }
    }
  // Direct bindings already have the common committed-frame read rule.
  // They do not need a speculative derivation or a provisional transaction.
  if ((reader as any)._type === EFFECT_RENDER) return false;
  if (includesBoundary(reader, holder)) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  // An ordinary input may be read before the boundary that justifies using
  // its committed value. Validate that relationship after the complete body.
  if (evaluation === reader && (candidateUpdates.has(holder) || !isChildUpdate(holder))) {
    (evaluationReads ??= new Map()).set(source, holder);
    // Children created before the final boundary read must remain proposals
    // too. A provisional ordinary update gives them the common owned-frame
    // lifetime; the end-of-body decision either keeps it independent or
    // merges it into the input update and recalculates.
    joinFuture(null);
    const provisional = resolveTx(flushTransaction!);
    const allowed = parentSet(provisional) || new Set<Transaction>();
    allowed.add(holder);
    parents.set(provisional, allowed);
    reader._flags |= REACTIVE_JOINED;
    return true;
  }
  return false;
}

/** A notification does not consume its update's proposal. A held child's
 * pass first keeps its own context; actual reads can still merge peer work.
 * Ready input releases explicitly run in the input context instead. */
function rerunLayer(node: Computed<any>): boolean {
  if ((node as any)._type) return false;
  const own = txOf(node);
  if (!isChildUpdate(own)) return false;
  if (!flushTransaction) joinFuture(null);
  const incoming = resolveTx(flushTransaction!);
  if (incoming === own || incoming === releasingInput) return false;
  if (updatePosition(incoming) >= updatePosition(own)) return false;
  holdQueuedProposals(incoming);
  recomputeInUpdate(node, own);
  return true;
}

function computeLayer(node: Computed<any>, previous: any, previousTail: Link | null): any {
  const outer = evaluation;
  let outerReads = evaluationReads;
  evaluation = node;
  evaluationReads = null;
  try {
    for (;;) {
      let result: any,
        error: unknown,
        failed = false;
      try {
        result = node._fn(previous);
      } catch (e) {
        error = e;
        failed = true;
      }
      if (node._depsTail !== previousTail) changedDependencies?.();
      let retry = false;
      const reads = evaluationReads as Map<Signal<any>, Transaction> | null;
      if (reads) {
        for (const holder of reads.values()) {
          const parent = resolveTx(holder);
          if (includesBoundary(node, parent)) {
            watchParent(parent);
            staleReader(node, parent);
          } else if (outer && node._parent === outer) {
            // An owned child's context is not complete before its owner
            // finishes. Keep its proposal in the provisional update and
            // let the owner validate the remaining reads as one frame.
            for (const [source, sourceHolder] of reads) {
              (outerReads ??= new Map()).set(source, sourceHolder);
            }
            break;
          } else {
            joinFuture(parent);
            retry = true;
          }
        }
      }
      if (!retry) {
        if (failed) throw error;
        return result;
      }
      // This provisional body never owned a published frame or registered
      // its returned flight. Retire its children and ignore late rejection.
      if (result && typeof result.then === "function") Promise.resolve(result).catch(() => {});
      disposeChildren(node);
      node._depsTail = null;
      node._depGen++;
      evaluationReads = null;
    }
  } finally {
    evaluation = outer;
    evaluationReads = outerReads;
  }
}

/** Move proposals downstream of the cut to the new update, preserving every
 * published value and parked child frame. Old queued effects cannot publish
 * the proposals after ownership has moved. Nested active cuts stop the walk. */
function takeOutput(layer: Layer<any>, update: Transaction): void {
  const seen = new Set<Signal<any>>();
  const visit = (node: Signal<any>) => {
    if (seen.has(node)) return;
    seen.add(node);
    const boundary = boundaries.get(node);
    if (node !== layer.output && boundary && boundary.override !== NOT_PENDING) return;
    // A stale reader may not itself be held. An equal pending proposal
    // becoming this update's proposal still changes that reader's context.
    enqueueSub(node as Computed<any>);
    // Effects store their computed value privately and may owe a callback
    // without being held themselves. Requeue owed work under its new owner;
    // an older queue's copy is harmless once the callback has published.
    const effect = node as Computed<any> & {
      _modified?: boolean;
      _boundRunEffect?: (type: number) => void;
      _type?: number;
    };
    if (effect._modified && effect._boundRunEffect) {
      update._queues[effect._type! - 1].push(effect._boundRunEffect);
    }
    holdNode(node, update);
    for (let edge = node._subs; edge; edge = edge._nextSub) visit(edge._sub);
  };
  visit(layer.output);
}

function ownLayerUpdate(layer: Layer<any>, update: Transaction, input: Transaction | null) {
  layer.update = update;
  registerUpdate(update, layer);
  active.add(layer);
  setLayerCompute(computeLayer, rerunLayer);
  const excluded = parentSet(update) || new Set<Transaction>();
  if (input !== null && input !== update) {
    watchParent(input);
    excluded.add(input);
    for (const ancestor of parentSet(input) || []) excluded.add(ancestor);
  }
  parents.set(update, excluded);
  return excluded;
}

export function stageLayer(layer: Layer<any>, proposal: unknown): void {
  graphEpoch++;
  const inputHolder = inputUpdate(layer);
  layer.override = proposal;
  layer.inputTime = inputTime(layer.input);
  enableReads();
  const previous = layer.update && liveTx(layer.update);
  // A correction may have merged the old output back into its input. A new
  // guess needs a new cut, rather than reusing that now-lower update.
  const update =
    previous && previous !== inputHolder && isChildUpdate(previous)
      ? previous
      : newTransaction(false);
  const excluded = ownLayerUpdate(layer, update, inputHolder);
  if (proposal === NOT_PENDING && inputHolder !== null) {
    for (const parent of excluded) if (resolveTx(parent) === inputHolder) excluded.delete(parent);
  }
  takeOutput(layer, update);
  joinFuture(update);
  enqueueSub(layer.output);
}

function settleLayers(): void {
  settleUpdateGroups();
  cacheReads = true;
  if (!candidateUpdates.size && !active.size && !proposals.size && !scoped.size) {
    layerHooks.afterCommit?.();
    stopIfIdle();
    return;
  }
  for (const update of candidateUpdates) if (!liveTx(update)) candidateUpdates.delete(update);
  if (!candidateUpdates.size) {
    if (!active.size) setLayerCompute();
    // A later ordinary write can create a hold beneath an already published
    // override. Enable order-independent discovery once that hold exists.
    if (scoped.size && hasHeldNodes()) {
      for (const layer of scoped) if (layer.scope) watchParent(resolveTx(layer.scope));
    }
  }
  for (const layer of active) {
    if (!liveTx(layer.update!)) {
      layer.update = null;
      active.delete(layer);
    }
  }
  // First propagate value proposals. Their pending outputs describe the
  // resulting work, just as they do after an ordinary write's pure phase.
  // Staging both at once would merge a status update with the input update
  // it is meant to observe independently.
  if (proposals.size) {
    for (const [layer, proposal] of proposals) {
      if (layer.output._flags & REACTIVE_DISPOSED) continue;
      stageLayer(layer, proposal);
    }
    proposals.clear();
    return;
  }
  layerHooks.afterCommit?.();
  stopIfIdle();
}

export function createLayer<T>(input: () => T, options?: { lifetime: "action" }) {
  const source = (input as any)[$REFRESH] as Computed<T> | undefined;
  // The producer records each input evaluation. Equality belongs at the
  // output: an answer equal to an earlier input may still replace a guess.
  const producer = source || computed(input, { equals: false });
  const layer = createLayerBoundary<T>(producer, undefined, undefined, !source);
  layer.inputStatus = true;
  return layerAccessors(layer, options);
}

function selectLayer<T>(
  layer: Layer<T>,
  fallback: ((layer: Layer<T>) => T) | undefined,
  onEvaluate: ((layer: Layer<T>) => void) | undefined
): T {
  const producer = layer.input;
  onEvaluate?.(layer);
  if (
    layer.scope !== null &&
    layer.override !== NOT_PENDING &&
    !(producer._statusFlags & STATUS_PENDING) &&
    inputTime(producer) !== layer.inputTime
  ) {
    // An input answer joins the guessing actions, but the selector stays
    // overridden until their shared lifetime ends. Intermediate answers
    // must not start downstream work beneath the selected guess.
    const scope = liveTx(layer.scope);
    if (scope) {
      if (producer._config & CONFIG_HELD) merge(txOf(producer), scope);
      joinFuture(scope);
    }
    // The pre-commit phase releases the group once all its inputs are ready.
  }
  if (layer.override === NOT_PENDING) return fallback ? fallback(layer) : read(producer);
  // Choosing an override subscribes to the input's changes, but does not
  // consume its proposal. No other read in the graph has this exemption.
  // Persistent test overrides only resume their input on explicit clear.
  // Action overrides and observation outputs must still notice input work.
  if (layer.scope !== null || !layer.inputStatus) link(producer, layer.output);
  return layer.override as T;
}

/** Internal construction shared by guesses and observations. */
export function createLayerBoundary<T>(
  producer: Computed<any>,
  fallback?: (layer: Layer<T>) => T,
  onEvaluate?: (layer: Layer<T>) => void,
  ownInput = true,
  lazy = false
) {
  if (ownInput) producer._config &= ~CONFIG_AUTO_DISPOSE;
  const layer = {
    input: producer,
    override: NOT_PENDING,
    update: null,
    scope: null,
    inputTime: inputTime(producer)
  } as Layer<T>;
  // Bind the shared selector instead of retaining a constructor closure and
  // its captured producer, callbacks and layer. Only boundaries pay this cost.
  const output = computed<T>((selectLayer<T>).bind(null, layer, fallback, onEvaluate), {
    lazy,
    _extraConfig: CONFIG_REDERIVE
  });
  if (!lazy) output._config &= ~CONFIG_AUTO_DISPOSE;
  layer.output = output;
  registerBoundary(layer);
  boundaries.set(output, layer);
  if (!boundaries.has(producer)) boundaries.set(producer, null);
  return layer;
}

function releaseLayer(layer: Layer<any>): void {
  scoped.delete(layer);
  active.delete(layer);
  proposals.delete(layer);
  layer.scope = layer.update = null;
  // Disposal can be the last event while an input is permanently pending.
  // Prune finished update references and disable idle hooks without requiring
  // an unrelated future write to visit the disposed boundary.
  wakeLayers();
}

function layerAccessors<T>(layer: Layer<T>, options?: { lifetime: "action" }) {
  const output = layer.output;
  const propose = (value: T | ((previous: T) => T)) => {
    const pending = proposals.get(layer);
    const previous =
      proposals.has(layer) && pending !== NOT_PENDING
        ? pending
        : layer.override !== NOT_PENDING
          ? layer.override
          : output._pendingValue !== NOT_PENDING
            ? output._pendingValue
            : output._value;
    const next = typeof value === "function" ? (value as (v: T) => T)(previous as T) : value;
    if (options?.lifetime === "action") {
      const scope = flushTransaction ?? (layer.scope && liveTx(layer.scope));
      if (!scope || !resolveTx(scope)._acted) {
        throw new Error("The action-lifetime experiment requires a guess inside an action.");
      }
      if (layer.scope) merge(scope, layer.scope);
      layer.scope = resolveTx(scope);
      scoped.add(layer);
    }
    output._cleanup ??= releaseLayer.bind(null, layer);
    proposals.set(layer, next);
    wakeLayers();
    return next;
  };
  const clear = () => {
    proposals.set(layer, NOT_PENDING);
    wakeLayers();
  };
  const accessor = () => read(output);
  (accessor as any)[$REFRESH] = output;
  return [accessor, propose, clear] as const;
}
