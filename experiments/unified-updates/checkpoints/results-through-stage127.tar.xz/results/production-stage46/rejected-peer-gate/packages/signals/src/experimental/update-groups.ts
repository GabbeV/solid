/** Pending optimistic origins keep their ordinary transaction records.
 * Equal-position peers share a publication gate instead of destroying their
 * identities through _into. Ordinary updates and explicit lifecycle coupling
 * continue to use the existing permanent merge.
 */
import {
  blocked, liveTx, resolveTx, setLayerCoordination, type Transaction
} from "../core/scheduler.js";
import type { Layer } from "./layer.js";
import { layerPosition } from "./committed-dependencies.js";
import { NOT_PENDING } from "../core/constants.js";

const origins = new Map<Transaction, Layer<any>>();
const positions = new WeakMap<Transaction, number>();
const peers = new Map<Transaction, Set<Transaction>>();
let judging = false;

export function updatePosition(update: Transaction): number {
  const origin = origins.get(resolveTx(update));
  return origin ? layerPosition(origin.input) + (origin.override === NOT_PENDING ? 0 : 1) : 0;
}

export function registerUpdate(update: Transaction, origin: Layer<any>): void {
  origins.set(resolveTx(update), origin);
  positions.set(resolveTx(update), updatePosition(update));
  setLayerCoordination(entangle, peerBlocked);
}

export function changedUpdateGroups(): [Transaction, Layer<any>][] {
  const changed: [Transaction, Layer<any>][] = [];
  for (const [update, origin] of origins) {
    if (!liveTx(update)) continue;
    const position = updatePosition(update);
    if (position === positions.get(update)) continue;
    positions.set(update, position);
    changed.push([update, origin]);
  }
  return changed.sort((a, b) => updatePosition(a[0]) - updatePosition(b[0]));
}

function entangle(a: Transaction, b: Transaction): boolean {
  const level = updatePosition(a);
  if (!level || level !== updatePosition(b)) return false;
  let adjacent = peers.get(a);
  if (!adjacent) peers.set(a, (adjacent = new Set()));
  adjacent.add(b);
  adjacent = peers.get(b);
  if (!adjacent) peers.set(b, (adjacent = new Set()));
  adjacent.add(a);
  return true;
}

function peerBlocked(update: Transaction): boolean {
  if (judging || !peers.size) return false;
  const level = updatePosition(update), seen = new Set([update]), pending = [update];
  judging = true;
  try {
    for (let i = 0; i < pending.length; i++) {
      for (const neighbor of peers.get(pending[i]) || []) {
        const peer = liveTx(neighbor);
        if (!peer || seen.has(peer) || updatePosition(peer) !== level) continue;
        seen.add(peer);
        if (blocked(peer)) return true;
        pending.push(peer);
      }
    }
    return false;
  } finally {
    judging = false;
  }
}

/** A deliberate lifecycle merge cannot later separate. Its output now belongs
 * to the lower context; peer edges follow the surviving record. */
export function coupleUpdates(from: Transaction, into: Transaction): void {
  const a = origins.get(from), b = origins.get(into);
  if (a && b) {
    if (layerPosition(a.input) < layerPosition(b.input)) origins.set(into, a);
  } else origins.delete(into);
  origins.delete(from);
  const adjacent = peers.get(from);
  if (adjacent) {
    peers.delete(from);
    let target = peers.get(into);
    if (!target) peers.set(into, (target = new Set()));
    for (const neighbor of adjacent) {
      peers.get(neighbor)?.delete(from);
      if (neighbor !== into) {
        target.add(neighbor);
        peers.get(neighbor)?.add(into);
      }
    }
    target.delete(from);
  }
}

export function settleUpdateGroups(): void {
  for (const update of origins.keys()) if (!liveTx(update)) origins.delete(update);
  for (const [update, adjacent] of peers) {
    if (liveTx(update)) continue;
    peers.delete(update);
    for (const neighbor of adjacent) peers.get(neighbor)?.delete(update);
  }
  if (!origins.size && !peers.size) setLayerCoordination();
}
