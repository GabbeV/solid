import { afterEach, expect, it } from "vitest";
import { createMemo, createRenderEffect, createRoot, createSignal, flush } from "../src/index.js";
import { $REFRESH } from "../src/core/constants.js";
import { txOf } from "../src/core/scheduler.js";
import { createLayer } from "../src/experimental/layer.js";

const turn = () => new Promise<void>(resolve => setTimeout(resolve, 0));
const disposals: (() => void)[] = [];
afterEach(() => { for (const dispose of disposals.splice(0)) dispose(); flush(); });
function requests() {
  const calls: { value: number; resolve: (value: number) => void }[] = [];
  return {
    calls,
    run(value: number) {
      if (value === 0) return 0;
      const gate = Promise.withResolvers<number>();
      calls.push({ value, resolve: gate.resolve });
      return gate.promise;
    },
    async answer(value: number) {
      const call = calls.findLast(call => call.value === value);
      expect(call, `requests: ${calls.map(c => c.value)}`).toBeDefined();
      call!.resolve(value); await turn(); flush();
    }
  };
}

for (const reverse of [false, true]) {
  it(`keeps peer identities while holding their common publication (reverse=${reverse})`, async () => {
    const work = requests(), holdB = requests(), shown = { b: 0, c: 0, q: 0 };
    let b!: () => number, c!: () => number, guessB!: (v: number) => number, guessC!: (v: number) => number;
    createRoot(dispose => {
      disposals.push(dispose);
      [b, guessB] = createLayer(() => 0);
      [c, guessC] = createLayer(() => 0);
      const held = createMemo(() => holdB.run(b()));
      const q = createMemo(() => work.run(reverse ? b() + c() : c() + b()));
      createRenderEffect(held, () => {});
      for (const [key, read] of Object.entries({ b, c, q }))
        createRenderEffect(read, value => { shown[key as keyof typeof shown] = value; });
    });
    guessB(2); flush(); guessC(10); flush();
    expect(txOf((b as any)[$REFRESH])).not.toBe(txOf((c as any)[$REFRESH]));
    await work.answer(12);
    expect(shown).toEqual({ b: 0, c: 0, q: 0 });
    await holdB.answer(2);
    expect(shown).toEqual({ b: 2, c: 10, q: 12 });
  });

  it(`reclassifies a held child when its parent becomes active (reverse=${reverse})`, async () => {
    const work = requests(), holdB = requests(), shown = { a: 0, b: 0, c: 0, q: 0 };
    let guessA!: (v: number) => number, guessB!: (v: number) => number, guessC!: (v: number) => number;
    createRoot(dispose => {
      disposals.push(dispose);
      const [source] = createSignal(0);
      const [a, setA] = createLayer(source), [b, setB] = createLayer(source), [c, setC] = createLayer(a);
      [guessA, guessB, guessC] = [setA, setB, setC];
      const held = createMemo(() => holdB.run(b()));
      const q = createMemo(() => work.run(reverse ? b() + c() : c() + b()));
      createRenderEffect(held, () => {});
      for (const [key, read] of Object.entries({ a, b, c, q }))
        createRenderEffect(read, value => { shown[key as keyof typeof shown] = value; });
    });
    guessB(2); flush(); guessC(10); flush(); guessA(1); flush();
    await work.answer(12);
    expect(shown.c).toBe(0);
    await work.answer(10);
    const childFrame = { ...shown };
    await holdB.answer(2); await work.answer(12);
    expect(shown).toEqual({ a: 1, b: 2, c: 10, q: 12 });
    expect(childFrame).toEqual({ a: 0, b: 0, c: 10, q: 10 });
  });
}
