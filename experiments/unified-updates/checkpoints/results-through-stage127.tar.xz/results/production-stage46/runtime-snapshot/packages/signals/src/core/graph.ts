import {
  CONFIG_AUTO_DISPOSE,
  CONFIG_SLOT_NODE,
  REACTIVE_DISPOSED,
  REACTIVE_RECOMPUTING_DEPS,
  REACTIVE_ZOMBIE,
  STATUS_PENDING,
  STATUS_UNINITIALIZED
} from "./constants.js";
import { deleteFromHeap } from "./heap.js";
import { disposeChildren } from "./owner.js";
import { bumpNotifyEpoch, dirtyQueue } from "./scheduler.js";
import type { Computed, Link, Signal } from "./types.js";

// Optional coordination metadata. Reusing an existing edge pays nothing;
// only structural insertion, publication and disposal visit this seam.
export let dependencyFrame:
  | ((node: Computed<any>, phase: "insert" | "commit" | "clear" | "park") => boolean | void)
  | undefined;
export function setDependencyFrameHook(hook: typeof dependencyFrame): void {
  dependencyFrame = hook;
}

/** Layer reachability caching only needs epochs while coordination is active. */
export let dependencyEpoch = 0;
export let changedDependencies: (() => void) | undefined;
function advanceDependencies(): void {
  dependencyEpoch++;
}
export function trackDependencies(enabled: boolean): void {
  if (enabled === !!changedDependencies) return;
  dependencyEpoch++;
  changedDependencies = enabled ? advanceDependencies : undefined;
}

/** The store's shared slot-node release handler (store/store.ts installs it
 * once) — a live binding read directly by the sweep site: no wrapper frame,
 * no null check (a CONFIG_SLOT_NODE node existing implies the store module
 * loaded and registered it). */
export let slotUnobservedHook: (node: Signal<any>) => void;
export function setSlotUnobserved(fn: (node: Signal<any>) => void): void {
  slotUnobservedHook = fn;
}

// https://github.com/stackblitz/alien-signals/blob/v2.0.3/src/system.ts#L100
export function unlinkSubs(link: Link): Link | null {
  changedDependencies?.();
  const dep = link._dep;
  const nextDep = link._nextDep;
  const nextSub = link._nextSub;
  const prevSub = link._prevSub;
  if (nextSub !== null) nextSub._prevSub = prevSub;
  else dep._subsTail = prevSub;

  if (prevSub !== null) prevSub._nextSub = nextSub;
  else {
    dep._subs = nextSub;
    if (nextSub === null) {
      // Store slot nodes dispatch to the ONE shared hook — no per-node
      // unobserved closure, no NodeExtension to hold it.
      if (dep._config & CONFIG_SLOT_NODE) slotUnobservedHook(dep as Signal<any>);
      else dep._x?._unobserved?.();
      // No more subscribers; only tear down if CONFIG_AUTO_DISPOSE is set.
      // A pending node is exempt: its in-flight async work is an observer —
      // tearing down would orphan the work and re-execute it on the next
      // read. The settle path runs this same last-one-out check when that
      // observer releases (the untracked-read dormancy sweep guards on
      // pending identically).
      const c = dep as Computed<any>;
      (c as any)._fn &&
        c._config & CONFIG_AUTO_DISPOSE &&
        !(c._flags & REACTIVE_ZOMBIE) &&
        !(c._statusFlags & STATUS_PENDING) &&
        unobserved(c);
    }
  }
  return nextDep;
}

export function trimStaleDeps(el: Computed<any>): void {
  const depsTail = el._depsTail;
  let toRemove = depsTail !== null ? depsTail._nextDep : el._deps;
  if (toRemove !== null) {
    do {
      toRemove = unlinkSubs(toRemove);
    } while (toRemove !== null);
    if (depsTail !== null) depsTail._nextDep = null;
    else el._deps = null;
  }
  dependencyFrame?.(el, "commit");
}

// Shared by unobserved() and the disposeChildren child loop. The truthy guard
// (not `!== null`) matters: plain Owners in a child chain have no _deps field,
// and skipping early also avoids adding one (hidden-class churn) via the
// null-out below.
export function clearDeps(el: Computed<unknown>): void {
  dependencyFrame?.(el, "clear");
  let dep = el._deps;
  if (!dep) return;
  do {
    dep = unlinkSubs(dep);
  } while (dep !== null);
  el._deps = null;
  el._depsTail = null;
}

export function unobserved(el: Computed<unknown>) {
  deleteFromHeap(el, dirtyQueue);
  clearDeps(el);
  disposeChildren(el, true);
}

/**
 * Deferred dormancy for never-observed auto-dispose computeds (#3078).
 *
 * An untracked top-level read of a subscriber-less observation-lifecycle memo
 * used to call unobserved() inline at the end of read(). That kept the leak
 * closed (the compute links the memo into its deps' sub lists — without a
 * teardown point a never-observed memo is retained by its sources forever;
 * upstream alien-signals has exactly this retention), but it made reads
 * destructive: each read disposed the node, the next read revived it with a
 * full recompute in whatever ambient transition/lane context happened to be
 * current, so consecutive reads could return different answers with no write
 * in between.
 *
 * Instead, reads queue the node here and the scheduler sweeps at the top of
 * the next flush (before runHeap, so a same-tick dirtying is reclaimed
 * instead of recomputed). Reads become idempotent within a tick (the node
 * stays alive and serves its cache, uniform with observed memos) while
 * reclamation still happens within one microtask — the enqueue site arms
 * schedule(), so a flush is guaranteed even when no other work is queued.
 */
export const dormantNodes = new Set<Computed<unknown>>();

export function sweepDormant(): void {
  if (dormantNodes.size === 0) return;
  for (const el of dormantNodes) {
    // Re-validate at sweep time: the node may have gained a subscriber (its
    // lifecycle is the unlinkSubs cascade now), gone pending (in-flight async
    // is an observer; the settle path re-runs last-one-out), lost its
    // AUTO_DISPOSE bit (owner teardown strips it, #3024), or already been
    // torn down.
    if (
      !el._subs &&
      el._config & CONFIG_AUTO_DISPOSE &&
      !(el._statusFlags & STATUS_PENDING) &&
      !(el._flags & (REACTIVE_DISPOSED | REACTIVE_ZOMBIE))
    ) {
      unobserved(el);
    }
  }
  dormantNodes.clear();
}

// https://github.com/stackblitz/alien-signals/blob/v2.0.3/src/system.ts#L52
export function link(dep: Signal<any> | Computed<any>, sub: Computed<any>) {
  const prevDep = sub._depsTail;
  if (prevDep !== null && prevDep._dep === dep) return;

  let nextDep: Link | null = null;
  const isRecomputing = sub._flags & REACTIVE_RECOMPUTING_DEPS;
  if (isRecomputing) {
    nextDep = prevDep !== null ? prevDep._nextDep : sub._deps;
    if (nextDep !== null && nextDep._dep === dep) {
      nextDep._gen = sub._depGen;
      sub._depsTail = nextDep;
      return;
    }
  }

  // A link stamped with the current pass generation was created or reused
  // in-order during this recompute, i.e. it already sits in the validated
  // [deps.._depsTail] prefix — the O(1) equivalent of scanning the dep list
  // (the old alien-signals `isValidLink` walk, O(n²) when a computation
  // re-reads earlier deps non-consecutively, e.g. store leaf reads).
  const prevSub = dep._subsTail;
  if (prevSub !== null && prevSub._sub === sub && (!isRecomputing || prevSub._gen === sub._depGen))
    return;

  const newLink =
    (sub._depsTail =
    dep._subsTail =
      {
        _dep: dep,
        _sub: sub,
        _nextDep: nextDep,
        _prevSub: prevSub,
        _nextSub: null,
        _gen: sub._depGen
      });
  if (prevDep !== null) prevDep._nextDep = newLink;
  else sub._deps = newLink;

  if (prevSub !== null) prevSub._nextSub = newLink;
  else dep._subs = newLink;
  if (dependencyFrame && !(sub._statusFlags & STATUS_UNINITIALIZED)) dependencyFrame(sub, "insert");

  // New subscriber edge: staged-rewrite skips (§12d) must not miss it.
  changedDependencies?.();
  bumpNotifyEpoch();
}
