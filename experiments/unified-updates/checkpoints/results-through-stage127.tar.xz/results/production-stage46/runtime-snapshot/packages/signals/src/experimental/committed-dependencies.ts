/** Dependency structure for the next layer coordinator, independent of values.
 *
 * The ordinary graph retains old links until publication. A pass only reuses
 * them in order or inserts new links; it never moves an old link. Consequently
 * a dropping/reusing pass already retains its exact committed dependencies.
 * Insertions enter a reusable link journal. Only a park materializes a retained
 * snapshot, which repeated proposals keep until publication. No fields are
 * added to ordinary nodes or links.
 */
import { NOT_PENDING, STATUS_ERROR, STATUS_UNINITIALIZED } from "../core/constants.js";
import { setDependencyFrameHook } from "../core/graph.js";
import type { Computed, Link, Signal } from "../core/types.js";

const saved = new WeakMap<Computed<any>, readonly Signal<any>[]>();
// Reuse the journal's storage across synchronous flushes. Entries are existing
// graph links, not fresh records; removing an entry clears its strong reference.
const inserted: (Link | null)[] = [];
let count = 0;
type Boundary = { input: Computed<any>; output: Computed<any>; override: unknown };
const boundaries = new WeakMap<Signal<any>, Boundary>();

export function registerBoundary(boundary: Boundary): void {
  boundaries.set(boundary.output, boundary);
}

function isInserted(edge: Link): boolean {
  for (let i = 0; i < count; i++) if (inserted[i] === edge) return true;
  return false;
}

function forgetInserted(node: Computed<any>): boolean {
  let found = false;
  for (let i = count - 1; i >= 0; i--) {
    if (inserted[i]!._sub !== node) continue;
    inserted[i] = inserted[--count];
    inserted[count] = null;
    found = true;
  }
  return found;
}

function dependencies(node: Computed<any>, prefix = false): Signal<any>[] {
  const result: Signal<any>[] = [];
  if (prefix && node._depsTail === null) return result;
  for (let edge = node._deps; edge; edge = edge._nextDep) {
    if (prefix || !isInserted(edge)) result.push(edge._dep);
    if (prefix && edge === node._depsTail) break;
  }
  return result;
}

// Installed by the optional feature module, before application computations
// run. Installing only on the first guess would miss earlier held branch
// changes. Ordinary-only imports can discard this entire module.
setDependencyFrameHook((node, phase) => {
  if (phase === "park") {
    if (!saved.has(node) && !(node._statusFlags & STATUS_UNINITIALIZED)) {
      for (let i = 0; i < count; i++) {
        if (inserted[i]!._sub !== node) continue;
        saved.set(node, dependencies(node));
        break;
      }
    }
    const changed = forgetInserted(node);
    return changed || saved.has(node) || !!(node._depsTail ? node._depsTail._nextDep : node._deps);
  } else if (phase === "insert") {
    inserted[count++] = node._depsTail;
  } else {
    // A new synchronous node cannot have a retained frame snapshot. Avoid
    // WeakMap work on its initial commit and disposal when no journal exists.
    if (!count && !node._x) return;
    forgetInserted(node);
    if (phase === "commit" && node._statusFlags & STATUS_ERROR) {
      // Recovery subscriptions are not reads of the published error frame.
      saved.set(node, dependencies(node, true));
    } else saved.delete(node);
  }
});

/** Values and dependencies advance at the same publication boundary. The
 * caller handles never-published computations separately (there is no frame).
 * No copy of a settled dependency list is retained. */
export function* committedDependencies(node: Computed<any>): Iterable<Signal<any>> {
  if (node._statusFlags & STATUS_UNINITIALIZED) return;
  const snapshot = saved.get(node);
  if (snapshot) yield* snapshot;
  else
    for (let edge = node._deps; edge; edge = edge._nextDep) if (!isInserted(edge)) yield edge._dep;
}

/** Cold-path context calculation for pending optimistic origins. Inactive
 * boundaries are transparent; speculative branch reads cannot choose their
 * own context. The recursion stack is per path, so a shared ancestor reached
 * by a longer path still contributes its complete depth. */
export function layerPosition(source: Signal<any>, path = new Set<Signal<any>>()): number {
  if (path.has(source)) return 0;
  path.add(source);
  try {
    const boundary = boundaries.get(source);
    if (boundary)
      return layerPosition(boundary.input, path) + (boundary.override === NOT_PENDING ? 0 : 1);
    let position = 0;
    for (const dependency of committedDependencies(source as Computed<any>))
      position = Math.max(position, layerPosition(dependency, path));
    return position;
  } finally {
    path.delete(source);
  }
}
