/** Dependency structure for the next layer coordinator, independent of values.
 *
 * The ordinary graph retains old links until publication. A pass only reuses
 * them in order or inserts new links; it never moves an old link. Consequently
 * a dropping/reusing pass already retains its exact committed dependencies.
 * Only the first insertion needs a snapshot. Repeated proposals keep it until
 * publication. No fields are added to ordinary nodes or links.
 */
import { NOT_PENDING, STATUS_ERROR, STATUS_UNINITIALIZED } from "../core/constants.js";
import { setDependencyFrameHook } from "../core/graph.js";
import type { Computed, Signal } from "../core/types.js";

const saved = new WeakMap<Computed<any>, readonly Signal<any>[]>();
type Boundary = { input: Computed<any>; output: Computed<any>; override: unknown };
const boundaries = new WeakMap<Signal<any>, Boundary>();

export function registerBoundary(boundary: Boundary): void {
  boundaries.set(boundary.output, boundary);
}

function dependencies(node: Computed<any>, prefix = false): Signal<any>[] {
  const result: Signal<any>[] = [];
  if (prefix && node._depsTail === null) return result;
  for (let edge = node._deps; edge; edge = edge._nextDep) {
    result.push(edge._dep);
    if (prefix && edge === node._depsTail) break;
  }
  return result;
}

// Installed by the optional feature module, before application computations
// run. Installing only on the first guess would miss earlier held branch
// changes. Ordinary-only imports can discard this entire module.
setDependencyFrameHook((node, phase) => {
  if (phase === "park") {
    return saved.has(node) || !!(node._depsTail ? node._depsTail._nextDep : node._deps);
  } else if (phase === "insert") {
    if (!(node._statusFlags & STATUS_UNINITIALIZED) && !saved.has(node))
      saved.set(node, dependencies(node));
  } else if (phase === "commit" && node._statusFlags & STATUS_ERROR) {
    // Error recovery keeps subscriptions to unread old dependencies. They are
    // recovery obligations, not reads of the newly published error frame.
    saved.set(node, dependencies(node, true));
  } else saved.delete(node);
});

/** Values and dependencies advance at the same publication boundary. The
 * caller handles never-published computations separately (there is no frame).
 * No copy of a settled dependency list is retained. */
export function* committedDependencies(node: Computed<any>): Iterable<Signal<any>> {
  if (node._statusFlags & STATUS_UNINITIALIZED) return;
  const snapshot = saved.get(node);
  if (snapshot) yield* snapshot;
  else for (let edge = node._deps; edge; edge = edge._nextDep) yield edge._dep;
}

/** Cold-path context calculation for pending optimistic origins. Inactive
 * boundaries are transparent; speculative branch reads cannot choose their
 * own context. The recursion stack is per path, so a shared ancestor reached
 * by a longer path still contributes its complete depth. */
export function layerPosition(source: Signal<any>, path = new Set<Signal<any>>()): number {
  if (path.has(source)) return 0;
  path.add(source);
  try {
    const boundary = boundaries.get(source);
    if (boundary)
      return layerPosition(boundary.input, path) + (boundary.override === NOT_PENDING ? 0 : 1);
    let position = 0;
    for (const dependency of committedDependencies(source as Computed<any>))
      position = Math.max(position, layerPosition(dependency, path));
    return position;
  } finally {
    path.delete(source);
  }
}
