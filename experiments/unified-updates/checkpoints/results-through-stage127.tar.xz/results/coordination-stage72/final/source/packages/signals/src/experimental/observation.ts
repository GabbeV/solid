/** Publication lifecycle shared by source-owned observation outputs. */
import {
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  NOT_PENDING,
  REACTIVE_DISPOSED,
  STATUS_UNINITIALIZED
} from "../core/constants.js";
import { blocked, liveTx, txOf, type Transaction } from "../core/scheduler.js";
import {
  inputTime,
  setObservationHooks,
  resumeInput,
  stageLayer,
  wakeLayers,
  type Layer
} from "./layer.js";

export type Observation<T> = Layer<T> & {
  parent: Transaction | null;
  retiring: boolean;
  time: number;
  observation: ObservationKind<T>;
};
export type ObservationKind<T> = {
  sample: (record: Observation<T>) => T;
  active: (record: Observation<T>, value: T) => boolean;
  observe?: (record: Observation<T>) => void;
};
const dirty = new Set<Observation<any>>();
const watching = new Set<Observation<any>>();
function prepareObservations(): boolean {
  let changed = false;
  for (const record of watching) {
    if (record.output._flags & REACTIVE_DISPOSED) {
      watching.delete(record);
      dirty.delete(record);
      continue;
    }
    const parent = record.parent && liveTx(record.parent);
    if (!parent || record.retiring || blocked(parent)) continue;
    // Rejoin before publication so new ordinary consequences can hold the
    // input and the observation's restoration together.
    record.retiring = true;
    record.time = inputTime(record.input);
    resumeInput(record, parent);
    changed = true;
  }
  return changed;
}

function settleObservations(): void {
  for (const record of watching) dirty.add(record);
  for (const record of dirty) {
    if (
      record.output._flags & REACTIVE_DISPOSED ||
      record.input._statusFlags & STATUS_UNINITIALIZED
    ) {
      watching.delete(record);
      continue;
    }
    if (record.retiring) {
      const live = record.parent && liveTx(record.parent);
      if (live && record.time === inputTime(record.input)) continue;
      record.retiring = false;
    }
    record.parent = record.input._config & CONFIG_HELD ? txOf(record.input) : null;
    const next = record.observation.sample(record);
    if (record.observation.active(record, next)) watching.add(record);
    else watching.delete(record);
    if (!Object.is(record.override, next)) stageLayer(record, next);
  }
  dirty.clear();
}

setObservationHooks(prepareObservations, settleObservations, () => !!(dirty.size || watching.size));

export function initializeObservation<T>(
  layer: Layer<T>,
  kind: ObservationKind<T>
): Observation<T> {
  const record = layer as Observation<T>;
  record.parent = null;
  record.retiring = false;
  record.time = inputTime(record.input);
  record.observation = kind;
  return record;
}

export function releaseObservation(record: Observation<any>): void {
  dirty.delete(record);
  watching.delete(record);
  record.parent = null;
  record.retiring = false;
  record.override = NOT_PENDING;
  // Dormant observation outputs have no remaining published consumers.
  // Their next use initializes a fresh frame from the current input state,
  // rather than manufacturing a stale frame before starting current work.
  if (record.output._config & CONFIG_AUTO_DISPOSE)
    record.output._statusFlags |= STATUS_UNINITIALIZED;
}

export function markObservation(layer: Layer<any>): void {
  const record = layer as Observation<any>;
  record.observation.observe?.(record);
  dirty.add(record);
  record.output._cleanup ??= releaseObservation.bind(null, record);
  wakeLayers();
}
