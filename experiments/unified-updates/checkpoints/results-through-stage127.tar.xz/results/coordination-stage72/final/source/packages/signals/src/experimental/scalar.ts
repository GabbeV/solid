/**
 * Deliberately limited entry for the scalar publication experiment.
 * This is not a replacement for the complete @solidjs/signals API.
 * See experiments/layered-updates/SCALAR-API.md for exclusions.
 */
export { action } from "../core/action.js";
export { flush } from "../core/scheduler.js";
export { createRoot } from "../core/owner.js";
export {
  createSignal,
  createMemo,
  createRenderEffect,
  createEffect,
  onCleanup
} from "../signals.js";
export { createErrorBoundary, createLoadingBoundary } from "../boundaries.js";
export { isPending } from "./pending.js";
export { latest } from "./latest.js";
export { refresh } from "./refresh.js";
import { createLayer } from "./layer.js";

/** Callback/accessor input and action-owned guesses only in this prototype.
 * The callback receives its input producer's previous result, including a
 * staged result. Output overrides do not become the producer's previous value.
 * An async input can be supplied through a createMemo accessor.
 */
export function createOptimistic<T>(input: (previous: NoInfer<T> | undefined) => T) {
  if (typeof input !== "function") {
    throw new TypeError("The scalar experiment requires an optimistic input accessor.");
  }
  const [read, guess] = createLayer<T>(input, { lifetime: "action" });
  return [read, guess] as const;
}
