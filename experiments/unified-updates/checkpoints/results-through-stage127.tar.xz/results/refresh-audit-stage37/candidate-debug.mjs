// packages/signals/src/core/constants.ts
var LEGACY_LANES = false;
var REACTIVE_NONE = 0;
var REACTIVE_CHECK = 1 << 0;
var REACTIVE_DIRTY = 1 << 1;
var REACTIVE_RECOMPUTING_DEPS = 1 << 2;
var REACTIVE_IN_HEAP = 1 << 3;
var REACTIVE_IN_HEAP_HEIGHT = 1 << 4;
var REACTIVE_ZOMBIE = 1 << 5;
var REACTIVE_DISPOSED = 1 << 6;
var REACTIVE_JOINED = 1 << 7;
var REACTIVE_SNAPSHOT_STALE = 1 << 8;
var REACTIVE_LAZY = 1 << 9;
var REACTIVE_MANUAL_WRITE = 1 << 10;
var REACTIVE_FRAME_READ = 1 << 11;
var REACTIVE_MISSED_WAKE = 1 << 12;
var REACTIVE_REASK = 1 << 13;
var REACTIVE_STAGED_READ = 1 << 14;
var REACTIVE_PROBED = 1 << 15;
var REACTIVE_LANE_DIRTY = 1 << 16;
var REACTIVE_LANE_READ = 1 << 17;
var REACTIVE_SCREEN_READ = 1 << 18;
var REACTIVE_PROBE_UNANSWERED = 1 << 19;
var CONFIG_OWNED_WRITE = 1 << 0;
var CONFIG_NO_SNAPSHOT = 1 << 1;
var CONFIG_TRANSPARENT = 1 << 2;
var CONFIG_IN_SNAPSHOT_SCOPE = 1 << 3;
var CONFIG_CHILDREN_FORBIDDEN = 1 << 4;
var CONFIG_AUTO_DISPOSE = 1 << 5;
var CONFIG_SYNC = 1 << 6;
var CONFIG_STAGED = 1 << 7;
var CONFIG_HELD = 1 << 8;
var CONFIG_INPUTS_PUBLISHED = 1 << 10;
var CONFIG_OVERRIDE = 1 << 11;
var CONFIG_SLOT_NODE = 1 << 12;
var CONFIG_MANUAL_WRITE = 1 << 18;
var CONFIG_LOADING = 1 << 19;
var CONFIG_GUESS = 1 << 13;
var CONFIG_VERDICT = 1 << 14;
var CONFIG_REDERIVE = 1 << 15;
var CONFIG_AUTHORITATIVE = 1 << 17;
var CONFIG_HAS_SNAPSHOT = 1 << 9;
var CONFIG_FRESH_READ = 1 << 16;
var CONFIG_PROMOTED = 1 << 22;
var CONFIG_PLUMBING = 1 << 25;
var CONFIG_WIDE = 1 << 26;
var CONFIG_SUPERSEDES = 1 << 27;
var STATUS_PENDING = 1 << 0;
var STATUS_ERROR = 1 << 1;
var STATUS_UNINITIALIZED = 1 << 2;
var EFFECT_RENDER = 1;
var EFFECT_USER = 2;
var EFFECT_TRACKED = 3;
var NOT_PENDING = {};
var NO_SNAPSHOT = {};
var defaultContext = {};
var $REFRESH = /* @__PURE__ */ Symbol("refresh");

// packages/signals/src/core/error.ts
var NotReadyError = class extends Error {
  source;
  constructor(source) {
    const ErrorCtor = Error;
    const limit = true ? ErrorCtor.stackTraceLimit : void 0;
    if (limit !== void 0) ErrorCtor.stackTraceLimit = 0;
    super();
    if (limit !== void 0) ErrorCtor.stackTraceLimit = limit;
    this.source = source;
  }
};
var StatusError = class extends Error {
  constructor(source, original) {
    super(original instanceof Error ? original.message : String(original), {
      cause: original
    });
    this.source = source;
  }
  source;
};
function unwrapStatusError(error) {
  return error instanceof StatusError ? error.cause : error;
}

// packages/signals/src/core/scheduler.ts
var layerSeam;
var layerBeforeCommit;
var layerMerge;
var layerCompute;
var layerRecompute;
var layerOwn;
var layerFrameRead;
function setLayerCommit(before, seam) {
  layerBeforeCommit = before;
  layerSeam = seam;
}
function setLayerReads(own, mergeHook, frame) {
  layerOwn = own;
  layerMerge = mergeHook;
  layerFrameRead = frame;
}
function setLayerCompute(compute, rerun) {
  layerCompute = compute;
  layerRecompute = rerun;
}
var transactions = [];
function hasHeldNodes() {
  for (const update of transactions) if (update._nodes.length) return true;
  return false;
}
var rerunHolders = /* @__PURE__ */ new Set();
var cleanupReruns;
function newTransaction(lane, parent = null) {
  const t = {
    _nodes: [],
    _queues: [[], []],
    _reruns: null,
    _into: null,
    _open: 0,
    _acted: false,
    _marks: null,
    ...LEGACY_LANES ? {
      _parent: parent,
      _lane: lane,
      _verdict: null,
      _links: null,
      _shown: false,
      _held: false
    } : {}
  };
  if (!LEGACY_LANES || !lane) transactions.push(t);
  return t;
}
var passLane = null;
function setPassLane(l) {
  passLane = l;
}
var flushTransaction = null;
var passTx = null;
function joinPassTx(t, own) {
  if (globalQueue._running && !own || flushTransaction !== null) return joinFuture(t);
  if (passTx === null) passTx = resolveTx(t);
  else merge(resolveTx(t), passTx);
  schedule();
}
function txOf(n) {
  return n._x._transaction = resolveTx(n._x._transaction);
}
function liveTx(t) {
  t = resolveTx(t);
  return transactions.indexOf(t) !== -1 ? t : null;
}
function resolveTx(t) {
  while (t._into !== null) t = t._into;
  return t;
}
function joinFuture(t) {
  const f = flushTransaction;
  if (f === null) {
    flushTransaction = t === null ? newTransaction(false) : resolveTx(t);
  } else if (t !== null) merge(resolveTx(t), f);
  if (!globalQueue._running) schedule();
}
function merge(t, f) {
  t = resolveTx(t);
  f = resolveTx(f);
  if (t === f || LEGACY_LANES && (t._lane || f._lane)) return;
  layerMerge?.(t, f);
  if (false) attrHooks.transitionMerged(f, t);
  t._into = f;
  f._open += t._open;
  f._acted ||= t._acted;
  append(f._nodes, t._nodes);
  append(f._queues[0], t._queues[0]);
  append(f._queues[1], t._queues[1]);
  if (t._reruns) {
    if (f._reruns) for (const reader of t._reruns) f._reruns.add(reader);
    else f._reruns = t._reruns;
    t._reruns = null;
    rerunHolders.delete(t);
    rerunHolders.add(f);
  }
  if (t._marks !== null) append(f._marks ??= [], t._marks);
  transactions.splice(transactions.indexOf(t), 1);
}
function blocked(t) {
  const prev = judge;
  judge ??= t;
  const r = t._open !== 0 || blockedBy(t._nodes, t) || LEGACY_LANES && !!GlobalQueue._lanesBlocked && GlobalQueue._lanesBlocked(t);
  judge = prev;
  return r;
}
var judge = null;
function ownFlights(t) {
  return blockedBy(t._nodes, t, true);
}
function ownSource(n, t) {
  const sources = n._x?._pendingSources;
  if (sources === void 0) return true;
  for (const s of sources) {
    const u = s._x?._transaction;
    if (u == null || resolveTx(u) === t) return true;
  }
  return false;
}
function blockedBy(nodes, owner, own = false) {
  for (let i = 0; i < nodes.length; i++) {
    const n = nodes[i];
    if (!(n._statusFlags & STATUS_PENDING) || n._flags & REACTIVE_DISPOSED || n._config & CONFIG_GUESS || n._x._transaction !== null && txOf(n) !== owner || own && !ownSource(n, owner))
      continue;
    if (n._type === EFFECT_RENDER) {
      if (onScreen(n, judge ?? owner)) return true;
      continue;
    }
    for (let s = n._subs; s !== null; s = s._nextSub) {
      const r = s._sub;
      if ((r._type === EFFECT_RENDER && r._statusFlags & STATUS_PENDING || r._flags & REACTIVE_FRAME_READ || r._config & CONFIG_REDERIVE && r._statusFlags === STATUS_PENDING) && (s._gen === r._depGen || r._x?._error != null) && !(r._flags & REACTIVE_DISPOSED) && onScreen(r, judge ?? owner))
        return true;
    }
  }
  return false;
}
function onScreen(r, t) {
  return !(r._flags & REACTIVE_ZOMBIE && removalStagedBy(r, t)) && !(GlobalQueue._hidden && GlobalQueue._hidden(r));
}
function removalStagedBy(r, t) {
  let o = r;
  while (o !== null && o._flags & REACTIVE_ZOMBIE) o = o._parent;
  return o !== null && (o._config & CONFIG_HELD) !== 0 && o._x?._transaction != null && txOf(o) === resolveTx(t);
}
var heldTrims = [];
function heldTrim(el) {
  heldTrims.push(el);
}
var deferredZombies = [];
function deferZombie(el) {
  deleteFromHeap(el, dirtyQueue);
  el._flags &= ~(REACTIVE_DIRTY | REACTIVE_CHECK);
  deferredZombies.push(el);
}
function holdNode(n, t) {
  n._config |= CONFIG_HELD;
  list(n, t);
}
function list(n, t) {
  const x = ext(n);
  if (x._transaction === t) return;
  layerOwn?.(n, t);
  x._transaction = t;
  t._nodes.push(n);
}
function holdFrame(owner, t) {
  for (let c = owner._firstChild; c !== null; c = c._nextSibling) {
    if (LEGACY_LANES && c._x?._transaction?._lane) continue;
    if (c._fn !== void 0 && !(c._config & CONFIG_HELD))
      holdNode(c, t);
    holdFrame(c, t);
  }
}
var dirtyQueue = {
  _heap: new Array(2e3).fill(void 0),
  _marked: false,
  _min: 0,
  _max: 0
};
var clock = 0;
var scheduled = false;
var halted = false;
var haltNotified = false;
var syncDepth = 0;
var actionDepth = 0;
function enterAction() {
  actionDepth++;
}
function exitAction() {
  actionDepth--;
}
var question = 0;
var questions = 0;
function setQuestion(q) {
  question = q;
}
function nextQuestion() {
  return ++questions;
}
var MAINLINE_QUESTION = 2147483647;
function schedule() {
  if (halted) {
    notifyHalted();
    return;
  }
  if (scheduled) return;
  scheduled = true;
  if (!syncDepth && !globalQueue._running) {
    queueMicrotask(flush);
  }
}
var ROOT_ERROR_HOOK = /* @__PURE__ */ Symbol.for("solid-js/root-error-hook");
function haltReactivity(cause) {
  if (halted) return;
  halted = true;
  let message = "[REACTIVITY_HALTED]";
  if (false) {
    message += " An uncaught error halted the reactive system. No further updates will be processed. Handle errors with <Errored> or treat this as a crash.";
    emitDiagnostic({
      code: "REACTIVITY_HALTED",
      kind: "error",
      severity: "error",
      message
    });
  }
  const report = cause !== void 0 && globalThis.reportError;
  report || cause === void 0 ? console.error(message) : console.error(message, cause);
  report && report(cause);
}
function notifyHalted() {
  if (haltNotified) return;
  haltNotified = true;
  console.error(
    false ? "[REACTIVITY_HALTED] Update ignored: the reactive system was halted by an earlier uncaught error." : "[REACTIVITY_HALTED]"
  );
}
var GlobalQueue = class _GlobalQueue {
  _queues = [[], []];
  _running = false;
  flush() {
    if (this._running) return;
    this._running = true;
    resyncUnflushedCompanions();
    passLane = null;
    passTx = null;
    try {
      sweepDormant();
      runHeap(dirtyQueue, _GlobalQueue._update);
      this.settle();
      clock++;
      scheduled = dirtyQueue._max >= dirtyQueue._min || pendingNodes.length !== 0;
      this.run(EFFECT_RENDER);
      this.run(EFFECT_USER);
      if (false) {
        holding = false;
        attrHooks.holdEnd();
      }
      if (false) {
        devCheckQuiescent(
          (n) => pendingNodes.includes(n) || (n._config & (CONFIG_HELD | CONFIG_OVERRIDE)) !== 0
        );
      }
      if (false) DEV.hooks.onUpdate?.();
    } finally {
      this._running = false;
      passTx = null;
    }
  }
  /** L2 — the seam: end of the pure phase. Commit this flush's staged nodes,
   * or park them with the transaction the flush joined; then land every
   * transaction no frame is waiting on. The landing flush is an ordinary
   * flush: the settle walk (async.ts) re-ran the parked readers in its pure
   * phase, and here no flight the transaction holds has a frame deriving
   * from it (`blocked`). */
  settle() {
    while (layerBeforeCommit?.()) runHeap(dirtyQueue, _GlobalQueue._update);
    if (LEGACY_LANES && _GlobalQueue._laneCorrections?.()) runHeap(dirtyQueue, _GlobalQueue._update);
    const joined = flushTransaction;
    flushTransaction = null;
    if (LEGACY_LANES) _GlobalQueue._applyGuesses?.(joined);
    const t = joined !== null && !(LEGACY_LANES && joined._lane) ? resolveTx(joined) : null;
    if (t !== null) {
      holdQueuedProposals(t);
      pendingNodes.length = 0;
      _GlobalQueue._storePark?.(t);
      const zombies = deferredZombies.splice(0).sort((a, b) => a._height - b._height);
      for (let i = 0; i < zombies.length; i++)
        if ((zombies[i]._flags & (REACTIVE_DISPOSED | REACTIVE_ZOMBIE)) === REACTIVE_ZOMBIE && zombies[i]._config & CONFIG_VERDICT)
          recompute(zombies[i]);
    } else {
      commitPendingNodes();
      for (let i = 0; i < heldTrims.length; i++) {
        const t2 = heldTrims[i];
        if (t2._x?._error == null && !t2._modified) trimStaleDeps(t2);
      }
    }
    if (heldTrims.length) heldTrims.length = 0;
    const own = this._queues;
    const lanes2 = LEGACY_LANES ? this._queues = [[], []] : null;
    if (LEGACY_LANES) _GlobalQueue._laneSeams?.(t !== null ? stagedReaders : null);
    if (stagedReaders.length) stagedReaders.length = 0;
    this._queues = [[], []];
    for (let k = transactions.length - 1; k >= 0; k--) {
      const u = transactions[k];
      if (blocked(u)) continue;
      transactions.splice(k, 1);
      if (LEGACY_LANES) _GlobalQueue._endLanes?.(u);
      land(u);
      k = transactions.length;
    }
    _GlobalQueue._storeCommit?.();
    const live = t && liveTx(t);
    _GlobalQueue._releaseAmbientMarks?.(live);
    const parked = live !== null;
    if (false) {
      attrHooks.holdStart(live);
      holding = true;
    }
    for (let i = 0; i < 2; i++) {
      if (parked) append(live._queues[i], own[i]);
      if (LEGACY_LANES) {
        this._queues[i] = parked || lanes2[i].length || this._queues[i].length ? lanes2[i].concat(parked ? [] : own[i], this._queues[i]) : own[i];
      } else if (!parked) {
        this._queues[i] = this._queues[i].length ? own[i].concat(this._queues[i]) : own[i];
      }
    }
    if (deferredZombies.length !== 0) {
      const zombies = deferredZombies.splice(0).sort((a, b) => a._height - b._height);
      for (let i = 0; i < zombies.length; i++) {
        if (!(zombies[i]._flags & REACTIVE_DISPOSED)) recompute(zombies[i]);
      }
    }
    _GlobalQueue._boundarySeam?.();
    layerSeam?.();
  }
  run(type) {
    const effects = this._queues[type - 1];
    if (effects.length) {
      this._queues[type - 1] = [];
      runQueue(effects, type);
    }
  }
  enqueue(type, fn, lane = passLane) {
    if (type) (lane !== null ? lane : this)._queues[type - 1].push(fn);
    schedule();
  }
  /** Status reaching the root: pending is absorbed (the root mount defers —
   * dev records it for the ASYNC_OUTSIDE_LOADING_BOUNDARY FYI); an error is
   * unhandled (`false` → the caller halts).
   *
   * L2: this is where a transaction is registered. Pending that reaches an
   * observer (a render effect: the frame) is a frame that cannot show — the
   * flush parks, and the transaction waits on the flight while a frame
   * derives from it (`blocked`). Pending nobody observes holds nothing: a
   * memo in flight that no frame reads is not a frame waiting. (Base: the
   * queue's `_asyncReporters`, INV-3's one registration site.)
   *
   * A boundary between the observer and the root (boundaries.ts) is asked
   * first: a fallback catches what is not ready under it, and the root
   * never hears of it. */
  notify(node, mask, flags, error) {
    if (_GlobalQueue._catch && _GlobalQueue._catch(node, flags & mask, error)) return true;
    if (mask & STATUS_PENDING) {
      if (flags & STATUS_PENDING) {
        if (false) _hitUnhandledAsync = true;
        if (passLane === null) joinFuture(null);
      }
      return true;
    }
    return false;
  }
};
function reruns(u) {
  const readers = u._reruns;
  if (!readers) return;
  u._reruns = null;
  rerunHolders.delete(u);
  if (!rerunHolders.size) cleanupReruns = void 0;
  for (const r of readers) {
    if (r._flags & REACTIVE_DISPOSED || r._statusFlags & STATUS_ERROR) continue;
    if (r._flags & REACTIVE_FRAME_READ || r._config & CONFIG_VERDICT) {
      r._flags &= ~REACTIVE_FRAME_READ;
      r._modified = false;
      for (let c = r._firstChild; c !== null; c = c._nextSibling)
        if (c._type) c._modified = false;
      enqueueSub(r);
    }
  }
}
function land(u) {
  if (false) attrHooks.transitionSettled(u);
  reruns(u);
  if (u._marks !== null) GlobalQueue._releaseMarks(u._marks);
  for (let i = 0; i < u._nodes.length; i++) {
    const n = u._nodes[i];
    if (n._x._transaction === null || txOf(n) !== u) continue;
    n._x._transaction = null;
    commitPendingNode(n);
  }
  releaseQueues(u);
}
function releaseQueues(u) {
  for (let i = 0; i < 2; i++) {
    append(globalQueue._queues[i], u._queues[i]);
    u._queues[i] = [];
  }
}
function append(a, b) {
  for (let i = 0; i < b.length; i++) a.push(b[i]);
}
var pendingNodes = [];
function holdQueuedProposals(update, start = 0) {
  const count = pendingNodes.length;
  for (let i = start; i < count; i++) {
    const n = pendingNodes[i];
    if (n._flags & REACTIVE_DISPOSED) continue;
    if (!(n._config & (CONFIG_HELD | (LEGACY_LANES ? CONFIG_OVERRIDE : 0))) && (!LEGACY_LANES || n._x === null || n._x._transaction === null || !n._x._transaction._lane)) {
      if (n._pendingValue === NOT_PENDING && n._statusFlags & STATUS_UNINITIALIZED && n._type !== EFFECT_RENDER)
        continue;
      if (n._pendingValue !== NOT_PENDING && !(n._statusFlags & (STATUS_PENDING | STATUS_UNINITIALIZED)) && n._equals && n._equals(n._value, n._pendingValue) && n._x?._pendingFirstChild == null && n._x?._pendingDisposal == null) {
        n._pendingValue = NOT_PENDING;
        n._config &= ~CONFIG_STAGED;
        continue;
      }
      holdNode(n, update);
    }
    if (n._config & CONFIG_STAGED) holdFrame(n, txOf(n));
  }
}
function recomputeInUpdate(node, update) {
  const incoming = flushTransaction;
  const start = pendingNodes.length;
  flushTransaction = update;
  try {
    recompute(node);
  } finally {
    if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction), start);
    flushTransaction = incoming && resolveTx(incoming);
  }
}
var stagedReaders = [];
function staleReader(c, t) {
  c._flags |= REACTIVE_FRAME_READ;
  queueRerun(t, c);
}
function queueRerun(t, c) {
  if (!t._reruns) {
    t._reruns = /* @__PURE__ */ new Set();
    rerunHolders.add(t);
    cleanupReruns = forgetReruns;
  }
  t._reruns.add(c);
}
function forgetReruns(c) {
  for (const holder of rerunHolders) {
    const readers = holder._reruns;
    readers.delete(c);
    if (!readers.size) {
      holder._reruns = null;
      rerunHolders.delete(holder);
    }
  }
  if (!rerunHolders.size) cleanupReruns = void 0;
}
function queuePendingNode(node) {
  if (false) lastStagedNodeName = node._name ?? null;
  pendingNodes.push(node);
  if (!globalQueue._running) markUnflushedStaged();
}
var notifyEpoch = 0;
function bumpNotifyEpoch() {
  notifyEpoch++;
}
function insertSubs(node) {
  node._notifiedAt = notifyEpoch;
  const cfg = node._config;
  const hasSnapshot = (cfg & CONFIG_HAS_SNAPSHOT) !== 0 && node._x?._snapshotValue !== void 0;
  let fanOut = 0;
  for (let s = node._subs; s !== null; s = s._nextSub) {
    const sub = s._sub;
    if (false) fanOut++;
    if (sub._flags & REACTIVE_RECOMPUTING_DEPS && s._gen === sub._depGen && s !== sub._depsTail)
      sub._flags |= REACTIVE_MISSED_WAKE;
    if (hasSnapshot && sub._config & CONFIG_IN_SNAPSHOT_SCOPE) {
      sub._flags |= REACTIVE_SNAPSHOT_STALE;
      continue;
    }
    enqueueSub(sub);
  }
  if (false) noteFanOut(node, fanOut);
}
function laneDirty(node, l) {
  for (let s = node._subs; s !== null; s = s._nextSub) {
    const t = s._sub._x?._transaction;
    if (t?._lane ? sameLane(t, l) : s._sub._type) s._sub._flags |= REACTIVE_LANE_DIRTY;
  }
}
function sameLane(a, b) {
  return a === b || a._links !== null && a._links === b._links;
}
function commitPendingNode(n) {
  const c = n;
  if (!c._fn) {
    n._config &= ~(CONFIG_STAGED | CONFIG_HELD);
    if (n._pendingValue !== NOT_PENDING) {
      n._value = n._pendingValue;
      n._pendingValue = NOT_PENDING;
    }
    return;
  }
  const inFlight2 = n._pendingValue === NOT_PENDING && (c._statusFlags & STATUS_PENDING) !== 0;
  n._config = inFlight2 ? n._config & ~(CONFIG_HELD | CONFIG_LOADING) | CONFIG_INPUTS_PUBLISHED : n._config & ~(CONFIG_HELD | CONFIG_STAGED | CONFIG_INPUTS_PUBLISHED | CONFIG_LOADING);
  if (n._pendingValue !== NOT_PENDING) {
    n._value = n._pendingValue;
    n._pendingValue = NOT_PENDING;
    c._statusFlags &= ~STATUS_UNINITIALIZED;
    if (c._x != null) c._x._reask = false, c._x._flushed = NOT_PENDING;
    if (n._type && n._type !== EFFECT_TRACKED) {
      n._modified = true;
      globalQueue.enqueue(
        n._type,
        n._boundRunEffect ??= GlobalQueue._runEffect.bind(null, c)
      );
    }
  }
  c._flags &= ~REACTIVE_MANUAL_WRITE;
  if (c._x?._error == null) trimStaleDeps(c);
  if (!(c._statusFlags & STATUS_PENDING)) c._statusFlags &= ~STATUS_UNINITIALIZED;
  if (!inFlight2 && c._x != null && (c._x._pendingFirstChild !== null || c._x._pendingDisposal !== null))
    GlobalQueue._dispose(c, false, true);
}
function commitPendingNodes() {
  for (let i = 0; i < pendingNodes.length; i++) {
    const n = pendingNodes[i];
    if (!(n._config & (CONFIG_OVERRIDE | CONFIG_HELD))) commitPendingNode(n);
  }
  pendingNodes.length = 0;
}
var globalQueue = new GlobalQueue();
function flush(fn) {
  if (actionDepth > 0) {
    if (false) {
      throw new Error(
        "[FLUSH_IN_ACTION] flush() inside an action body is not allowed. An action's writes are held in its transaction and commit when the action settles: flush() cannot reveal them, and draining here would detach the writes that follow from the transaction. Remove the flush(); to observe the result, read after the action resolves."
      );
    }
    return fn ? fn() : void 0;
  }
  if (fn) {
    syncDepth++;
    try {
      return fn();
    } finally {
      try {
        flush();
      } finally {
        syncDepth--;
      }
    }
  }
  if (globalQueue._running) {
    if (false) {
      throw new Error(
        "Cannot call flush() from inside onSettled or createTrackedEffect. flush() is not reentrant there. Writes made here are processed in the same flush's continuation; to force a drain afterwards, defer it: queueMicrotask(() => flush())."
      );
    }
    if (false) {
      const message = "[FLUSH_IN_EFFECT_CALLBACK] flush() called from inside an effect callback is a no-op: the flush that runs effects is already in progress. Writes made here are processed in the same flush's continuation; to force a drain afterwards, defer it: queueMicrotask(() => flush()).";
      reportDiagnostic(
        emitDiagnostic({
          code: "FLUSH_IN_EFFECT_CALLBACK",
          kind: "lifecycle",
          severity: "warn",
          message
        })
      );
    }
    return;
  }
  if (halted) return;
  let count = 0;
  let drained = false;
  if (false) attrHooks.flushStart();
  while (scheduled) {
    if (false) {
      throw new Error(
        `Potential Infinite Loop Detected. Kept alive by scheduled work${lastStagedNodeName ? `; last staged node: ${lastStagedNodeName}` : ""}`
      );
    }
    globalQueue.flush();
    if (false) drained = true;
  }
  if (false) attrHooks.flushEnd();
}
function runQueue(queue, type) {
  for (let i = 0; i < queue.length; i++) queue[i](type);
}

// packages/signals/src/core/heap.ts
function enqueueSub(node) {
  if (dirtyQueue._min > node._height) dirtyQueue._min = node._height;
  insertIntoHeap(node, dirtyQueue);
}
function actualInsertIntoHeap(n, heap) {
  const parentHeight = (n._parent?._root ? n._parent._parentComputed?._height : n._parent?._height) ?? -1;
  if (parentHeight >= n._height) n._height = parentHeight + 1;
  const height = n._height;
  const heapAtHeight = heap._heap[height];
  if (heapAtHeight === void 0) heap._heap[height] = n;
  else {
    const tail = heapAtHeight._prevHeap;
    tail._nextHeap = n;
    n._prevHeap = tail;
    heapAtHeight._prevHeap = n;
  }
  if (height > heap._max) heap._max = height;
}
function insertIntoHeap(n, heap) {
  let flags = n._flags;
  if (flags & (REACTIVE_IN_HEAP | REACTIVE_RECOMPUTING_DEPS)) return;
  if (flags & REACTIVE_CHECK) {
    n._flags = flags & ~(REACTIVE_CHECK | REACTIVE_DIRTY) | REACTIVE_DIRTY | REACTIVE_IN_HEAP;
  } else {
    n._flags = flags | REACTIVE_IN_HEAP;
    if (heap._marked) markNode(n);
  }
  if (!(flags & REACTIVE_IN_HEAP_HEIGHT)) actualInsertIntoHeap(n, heap);
}
function insertIntoHeapHeight(n, heap) {
  let flags = n._flags;
  if (flags & (REACTIVE_IN_HEAP | REACTIVE_RECOMPUTING_DEPS | REACTIVE_IN_HEAP_HEIGHT)) return;
  n._flags = flags | REACTIVE_IN_HEAP_HEIGHT;
  actualInsertIntoHeap(n, heap);
}
function deleteFromHeap(n, heap) {
  const flags = n._flags;
  if (!(flags & (REACTIVE_IN_HEAP | REACTIVE_IN_HEAP_HEIGHT))) return;
  n._flags = flags & ~(REACTIVE_IN_HEAP | REACTIVE_IN_HEAP_HEIGHT);
  const height = n._height;
  if (n._prevHeap === n) heap._heap[height] = void 0;
  else {
    const next = n._nextHeap;
    const dhh = heap._heap[height];
    const end = next ?? dhh;
    if (n === dhh) heap._heap[height] = next;
    else n._prevHeap._nextHeap = next;
    end._prevHeap = n._prevHeap;
  }
  n._prevHeap = n;
  n._nextHeap = void 0;
}
function markHeap(heap) {
  if (heap._marked) return;
  heap._marked = true;
  for (let i = 0; i <= heap._max; i++) {
    for (let el = heap._heap[i]; el !== void 0; el = el._nextHeap) {
      if (el._flags & REACTIVE_IN_HEAP) markNode(el);
    }
  }
}
function markNode(el, newState = REACTIVE_DIRTY) {
  const flags = el._flags;
  if ((flags & (REACTIVE_CHECK | REACTIVE_DIRTY)) >= newState) return;
  el._flags = flags & ~(REACTIVE_CHECK | REACTIVE_DIRTY) | newState;
  for (let link2 = el._subs; link2 !== null; link2 = link2._nextSub) {
    markNode(link2._sub, REACTIVE_CHECK);
  }
}
function runHeap(heap, recompute2) {
  heap._marked = false;
  for (heap._min = 0; heap._min <= heap._max; heap._min++) {
    let el = heap._heap[heap._min];
    while (el !== void 0) {
      if (el._flags & REACTIVE_IN_HEAP) recompute2(el);
      else adjustHeight(el, heap);
      el = heap._heap[heap._min];
    }
  }
  heap._max = 0;
}
function adjustHeight(el, heap) {
  deleteFromHeap(el, heap);
  let newHeight = el._height;
  for (let d = el._deps; d; d = d._nextDep) {
    const dep = d._dep;
    if (dep._fn && dep._height >= newHeight)
      newHeight = dep._height + 1;
  }
  if (el._height !== newHeight) {
    el._height = newHeight;
    for (let s = el._subs; s !== null; s = s._nextSub) insertIntoHeapHeight(s._sub, heap);
  }
}

// packages/signals/src/core/owner.ts
function markDisposal(el) {
  let child = el._firstChild;
  while (child) {
    child._flags |= REACTIVE_ZOMBIE;
    markDisposal(child);
    child = child._nextSibling;
  }
}
function dispose(node) {
  node._config &= ~CONFIG_AUTO_DISPOSE;
  unobserved(node);
}
function disposeChildren(node, self = false, zombie) {
  const flags = node._flags;
  if (flags & REACTIVE_DISPOSED) return;
  if (self && !zombie && node._x !== null && (node._x._pendingFirstChild !== null || node._x._pendingDisposal !== null))
    disposeChildren(node, false, true);
  if (self) {
    node._flags = flags | REACTIVE_DISPOSED;
    if (false) unregisterRoot(node);
  }
  if (self && false) clearSignals(node);
  if (self && node._fn) {
    cleanupReruns?.(node);
    if (node._x !== null) node._x._inFlight = null;
    if (node._statusFlags & STATUS_PENDING && node._x?._transaction != null || flags & REACTIVE_FRAME_READ)
      schedule();
  }
  let child = zombie ? node._x._pendingFirstChild : node._firstChild;
  if (zombie) node._x._pendingFirstChild = null;
  else node._firstChild = null;
  while (child) {
    const n = child;
    n._config &= ~CONFIG_AUTO_DISPOSE;
    deleteFromHeap(n, dirtyQueue);
    clearDeps(n);
    child._prevSibling = child;
    disposeChildren(child, true);
    child = child._nextSibling;
  }
  if (!zombie) node._childCount = 0;
  if (self && !zombie && !(flags & REACTIVE_ZOMBIE) && node._parent !== null && !(node._parent._flags & REACTIVE_DISPOSED)) {
    const prev = node._prevSibling;
    const next = node._nextSibling;
    if (false)
      assertInvariant(
        prev !== null || node._parent._firstChild === node,
        "owner-chain-head",
        "head node is not parent._firstChild \u2014 a node was spliced while flagged live but not in the chain (see #3543)"
      );
    if (prev !== null) prev._nextSibling = next;
    else node._parent._firstChild = next;
    if (next !== null) next._prevSibling = prev;
    node._prevSibling = null;
  }
  runDisposal(node, zombie);
  if (self && node._cleanup) {
    const effectCleanup = node._cleanup;
    node._cleanup = void 0;
    if (false) enterDisposal();
    effectCleanup();
    if (false) exitDisposal();
  }
}
function linkChild(parent, node) {
  const head = parent._firstChild;
  node._prevSibling = null;
  node._nextSibling = head;
  if (head !== null) head._prevSibling = node;
  parent._firstChild = node;
}
function runDisposal(node, zombie) {
  const disposal = zombie ? node._x._pendingDisposal : node._disposal;
  if (!disposal) return;
  if (zombie) node._x._pendingDisposal = null;
  else node._disposal = null;
  if (false) enterDisposal();
  if (Array.isArray(disposal)) {
    for (let i = disposal.length - 1; i >= 0; i--) {
      const callable = disposal[i];
      callable.call(callable);
    }
  } else {
    disposal.call(disposal);
  }
  if (false) exitDisposal();
}
function childId(owner, consume) {
  let counter = owner;
  while (counter._config & CONFIG_TRANSPARENT && counter._parent) counter = counter._parent;
  if (counter.id != null)
    return formatId(counter.id, consume ? counter._childCount++ : counter._childCount);
  throw new Error(false ? "Cannot get child id from owner without an id" : "");
}
function getNextChildId(owner) {
  return childId(owner, true);
}
function inheritId(options, transparent, parent) {
  return options?.id ?? (transparent ? parent?.id : parent?.id != null ? getNextChildId(parent) : void 0);
}
function formatId(prefix, id) {
  const num = id.toString(36), len = num.length - 1;
  return prefix + (len ? String.fromCharCode(64 + len) : "") + num;
}
function getOwner() {
  return context;
}
function cleanup(fn) {
  if (!context) return fn;
  if (!context._disposal) context._disposal = fn;
  else if (Array.isArray(context._disposal)) context._disposal.push(fn);
  else context._disposal = [context._disposal, fn];
  return fn;
}
function disposeRootSelf(self = true) {
  disposeChildren(this, self);
}
function createOwner(options) {
  const parent = context;
  const transparent = options?.transparent ?? false;
  const owner = false ? {
    id: inheritId(options, transparent, parent),
    _config: transparent ? CONFIG_TRANSPARENT : 0,
    _root: true,
    _parentComputed: parent?._root ? parent._parentComputed : parent,
    _firstChild: null,
    _nextSibling: null,
    _prevSibling: null,
    _disposal: null,
    _context: parent?._context || defaultContext,
    _childCount: 0,
    _x: null,
    _parent: parent,
    dispose: disposeRootSelf,
    _name: void 0
  } : {
    id: inheritId(options, transparent, parent),
    _config: transparent ? CONFIG_TRANSPARENT : 0,
    _root: true,
    _parentComputed: parent?._root ? parent._parentComputed : parent,
    _firstChild: null,
    _nextSibling: null,
    _prevSibling: null,
    _disposal: null,
    _context: parent?._context || defaultContext,
    _childCount: 0,
    _x: null,
    _parent: parent,
    dispose: disposeRootSelf
  };
  if (false) {
    emitDiagnostic({
      code: "PRIMITIVE_IN_FORBIDDEN_SCOPE",
      kind: "lifecycle",
      severity: "error",
      message: PRIMITIVE_IN_FORBIDDEN_SCOPE_MESSAGE,
      ownerId: parent.id,
      ownerName: parent._name
    });
    throw new Error(PRIMITIVE_IN_FORBIDDEN_SCOPE_MESSAGE);
  }
  if (false) assertNotInEffectCallback();
  if (parent) linkChild(parent, owner);
  else if (false) registerRoot(owner);
  if (false) DEV.hooks.onOwner?.(owner);
  return owner;
}
function createRoot(init, options) {
  const owner = createOwner(options);
  return runWithOwner(owner, () => init(() => owner.dispose()));
}

// packages/signals/src/core/graph.ts
var dependencyEpoch = 0;
var changedDependencies;
function advanceDependencies() {
  dependencyEpoch++;
}
function trackDependencies(enabled) {
  if (enabled === !!changedDependencies) return;
  dependencyEpoch++;
  changedDependencies = enabled ? advanceDependencies : void 0;
}
var slotUnobservedHook;
function unlinkSubs(link2) {
  changedDependencies?.();
  const dep = link2._dep;
  const nextDep = link2._nextDep;
  const nextSub = link2._nextSub;
  const prevSub = link2._prevSub;
  if (nextSub !== null) nextSub._prevSub = prevSub;
  else dep._subsTail = prevSub;
  if (prevSub !== null) prevSub._nextSub = nextSub;
  else {
    dep._subs = nextSub;
    if (nextSub === null) {
      if (dep._config & CONFIG_SLOT_NODE) slotUnobservedHook(dep);
      else dep._x?._unobserved?.();
      const c = dep;
      c._fn && c._config & CONFIG_AUTO_DISPOSE && !(c._flags & REACTIVE_ZOMBIE) && !(c._statusFlags & STATUS_PENDING) && unobserved(c);
    }
  }
  return nextDep;
}
function trimStaleDeps(el) {
  const depsTail = el._depsTail;
  let toRemove = depsTail !== null ? depsTail._nextDep : el._deps;
  if (toRemove !== null) {
    do {
      toRemove = unlinkSubs(toRemove);
    } while (toRemove !== null);
    if (depsTail !== null) depsTail._nextDep = null;
    else el._deps = null;
  }
}
function clearDeps(el) {
  let dep = el._deps;
  if (!dep) return;
  do {
    dep = unlinkSubs(dep);
  } while (dep !== null);
  el._deps = null;
  el._depsTail = null;
}
function unobserved(el) {
  deleteFromHeap(el, dirtyQueue);
  clearDeps(el);
  disposeChildren(el, true);
}
var dormantNodes = /* @__PURE__ */ new Set();
function sweepDormant() {
  if (dormantNodes.size === 0) return;
  for (const el of dormantNodes) {
    if (!el._subs && el._config & CONFIG_AUTO_DISPOSE && !(el._statusFlags & STATUS_PENDING) && !(el._flags & (REACTIVE_DISPOSED | REACTIVE_ZOMBIE))) {
      unobserved(el);
    }
  }
  dormantNodes.clear();
}
function link(dep, sub) {
  const prevDep = sub._depsTail;
  if (prevDep !== null && prevDep._dep === dep) return;
  let nextDep = null;
  const isRecomputing = sub._flags & REACTIVE_RECOMPUTING_DEPS;
  if (isRecomputing) {
    nextDep = prevDep !== null ? prevDep._nextDep : sub._deps;
    if (nextDep !== null && nextDep._dep === dep) {
      nextDep._gen = sub._depGen;
      sub._depsTail = nextDep;
      return;
    }
  }
  const prevSub = dep._subsTail;
  if (prevSub !== null && prevSub._sub === sub && (!isRecomputing || prevSub._gen === sub._depGen))
    return;
  const newLink = sub._depsTail = dep._subsTail = {
    _dep: dep,
    _sub: sub,
    _nextDep: nextDep,
    _prevSub: prevSub,
    _nextSub: null,
    _gen: sub._depGen
  };
  if (prevDep !== null) prevDep._nextDep = newLink;
  else sub._deps = newLink;
  if (prevSub !== null) prevSub._nextSub = newLink;
  else dep._subs = newLink;
  changedDependencies?.();
  bumpNotifyEpoch();
}

// packages/signals/src/core/core.ts
GlobalQueue._update = (el) => {
  if (el._type === EFFECT_TRACKED) {
    deleteFromHeap(el, dirtyQueue);
    el._modified = true;
    globalQueue.enqueue(EFFECT_USER, el._run);
  } else if (el._flags & REACTIVE_ZOMBIE && !(el._flags & REACTIVE_LANE_DIRTY)) deferZombie(el);
  else recompute(el);
};
GlobalQueue._dispose = disposeChildren;
var tracking = false;
var stale = false;
var context = null;
var snapshotCaptureActive = false;
var snapshotSources = null;
function ownerInSnapshotScope(owner) {
  while (owner) {
    if (owner._snapshotScope) return true;
    owner = owner._parent;
  }
  return false;
}
function recompute(el, create = false) {
  if (!create && layerRecompute && el._config & CONFIG_HELD && layerRecompute(el)) return;
  bumpNotifyEpoch();
  const isEffect = el._type;
  const prevLane = LEGACY_LANES ? passLane : null;
  if (LEGACY_LANES) GlobalQueue._enterLane?.(el, create, creatorPass(context));
  let devChanged = false;
  if (false) {
    el._devWindows = 0;
    if (attrHooks !== null) attrHooks.recomputeStart(el, create);
  }
  if (!create) {
    deleteFromHeap(el, dirtyQueue);
    if (el._x !== null) {
      el._x._inFlight = null;
      releaseFlightTeardown(el);
    }
    if (LEGACY_LANES && el._statusFlags & STATUS_PENDING) el._config &= ~CONFIG_VERDICT;
    if (el._config & CONFIG_HELD) {
      const tx = txOf(el);
      if (LEGACY_LANES && tx._lane) {
      } else if (isEffect !== EFFECT_RENDER && !(LEGACY_LANES && el._config & CONFIG_VERDICT))
        joinPassTx(tx);
      else if (tx !== flushTransaction && !(el._statusFlags & STATUS_UNINITIALIZED)) {
        el._pendingValue = NOT_PENDING;
        if (isEffect === EFFECT_RENDER) el._config &= ~CONFIG_HELD;
      }
    }
    if (isEffect === EFFECT_TRACKED || el._config & CONFIG_STAGED) disposeChildren(el);
    else if (el._firstChild !== null || el._disposal !== null) parkChildren(el);
    if (false) clearSignals(el);
  }
  const wasUninitialized = !!(el._statusFlags & STATUS_UNINITIALIZED);
  const outgoingError = el._statusFlags & STATUS_ERROR ? el._x?._error : void 0;
  const wasPending = (el._statusFlags & STATUS_PENDING) !== 0;
  const outgoingPendingSources = wasPending ? el._x?._pendingSources : void 0;
  const wasPendingSource = el._x?._pendingSources?.has(el);
  const reask = (el._flags & REACTIVE_REASK) !== 0 && !(el._statusFlags & STATUS_PENDING && el._x !== null && !el._x._reask);
  const oldcontext = context;
  const oldDepsTail = el._depsTail;
  context = el;
  el._depsTail = null;
  el._depGen++;
  el._flags = REACTIVE_RECOMPUTING_DEPS | el._flags & REACTIVE_ZOMBIE;
  el._time = clock;
  let value = el._pendingValue !== NOT_PENDING ? el._pendingValue : LEGACY_LANES && el._config & CONFIG_OVERRIDE && el._x._lane !== NOT_PENDING ? el._x._lane : el._value;
  let oldHeight = el._height;
  let missedWake = false;
  let joined = false;
  let prevTracking = tracking;
  let prevStrictRead = false;
  if (false) {
    prevStrictRead = strictRead;
    strictRead = false;
  }
  tracking = true;
  const isStaleEffect = isEffect && isEffect !== EFFECT_USER;
  const prevStale = stale;
  if (isStaleEffect) stale = true;
  try {
    if (el._config & CONFIG_SYNC) {
      value = layerCompute ? layerCompute(el, value, oldDepsTail) : el._fn(value);
      if (el._x !== null) el._x._inFlight = null;
      el._config &= ~CONFIG_LOADING;
    } else {
      const prevInFlight = el._x?._inFlight;
      const fnResult = layerCompute ? layerCompute(el, value, oldDepsTail) : el._fn(value);
      const isAsyncResult = typeof fnResult === "object" && fnResult !== null;
      const selfRegistered = el._x?._inFlight !== prevInFlight;
      value = selfRegistered || !isAsyncResult ? fnResult : handleAsync(el, fnResult);
      if (!selfRegistered && !isAsyncResult) {
        if (el._x !== null) el._x._inFlight = null;
        el._config &= ~CONFIG_LOADING;
      }
    }
    if (el._statusFlags !== 0 || el._x !== null) clearStatus(el, create);
  } catch (e) {
    const notReady = e instanceof NotReadyError;
    if (notReady && el._config & CONFIG_LOADING) {
      parkLoadingWindow(el, e);
    } else {
      if (notReady) ext(el)._blocked = true;
      notifyStatus(el, notReady ? STATUS_PENDING : STATUS_ERROR, e);
      if (notReady && wasPendingSource && !el._x?._inFlight) settlePendingSource(el);
      if (notReady && outgoingPendingSources) {
        for (const source of outgoingPendingSources)
          if (source !== el && !el._x?._pendingSources?.has(source))
            settlePendingSource(el, source);
      }
    }
  } finally {
    tracking = prevTracking;
    if (false) strictRead = prevStrictRead;
    if (isStaleEffect) stale = prevStale;
    missedWake = (el._flags & REACTIVE_MISSED_WAKE) !== 0;
    joined = (el._flags & REACTIVE_JOINED) !== 0;
    if (LEGACY_LANES && !(el._flags & REACTIVE_PROBED)) el._config &= ~CONFIG_VERDICT;
    el._flags = el._flags & (REACTIVE_ZOMBIE | REACTIVE_DISPOSED | REACTIVE_FRAME_READ | REACTIVE_STAGED_READ | REACTIVE_LANE_READ | REACTIVE_SCREEN_READ | REACTIVE_PROBE_UNANSWERED) | (create ? el._flags & REACTIVE_SNAPSHOT_STALE : 0);
    context = oldcontext;
    if (el._x !== null) el._x._reask = reask && (el._statusFlags & STATUS_PENDING) !== 0;
  }
  if (el._flags & REACTIVE_DISPOSED) {
    clearDeps(el);
    if (el._x !== null) el._x._inFlight = null;
    if (false)
      attrHooks.recomputeEnd(el, create, false, false, false, false);
    if (LEGACY_LANES) setPassLane(prevLane);
    return;
  }
  let lane = LEGACY_LANES ? passLane : null;
  const errored = !!el._x?._error;
  if (lane !== null) {
    if (GlobalQueue._laneStage(el, lane, create, errored)) setPassLane(lane);
    else lane = null;
  }
  if (!el._x?._error) {
    if (false) {
      let fanIn = 0;
      for (let d = el._deps; d !== null; d = d._nextDep) {
        fanIn++;
        if (d === el._depsTail) break;
      }
      if (fanIn >= GRAPH_SIZE_WARN_AT) noteFanIn(el, fanIn);
    }
    const compareValue = el._pendingValue !== NOT_PENDING ? el._pendingValue : LEGACY_LANES && el._config & CONFIG_OVERRIDE && el._x._lane !== NOT_PENDING ? el._x._lane : el._value;
    let valueChanged = false;
    try {
      valueChanged = !isEffect && wasUninitialized || !el._equals || !el._equals(compareValue, value);
    } catch (e) {
      notifyStatus(el, STATUS_ERROR, e);
    }
    if (false) {
      devChanged = valueChanged && !el._x?._error;
      if (devChanged && !isEffect && !create) attrHooks.derivedChanged(el);
    }
    if (isEffect && valueChanged && // A stale reader of a lane (REACTIVE_SCREEN_READ) that computed what it
    // last applied owes no run (lanes.ts).
    !(el._flags & REACTIVE_SCREEN_READ && !el._modified && Object.is(el._prevValue, value)) && // A re-staging pass owes no run: the commit replays the effect (#3802).
    el._pendingValue === NOT_PENDING) {
      el._modified = !el._x?._error;
      if (!create || lane !== null)
        globalQueue.enqueue(
          isEffect,
          el._boundRunEffect ??= GlobalQueue._runEffect.bind(null, el),
          lane
        );
    }
    if (!create && lane === null && LEGACY_LANES && el._config & CONFIG_GUESS && GlobalQueue._laneOutcome(el, value, errored)) {
    } else if (errored) {
    } else if (valueChanged) {
      if (lane !== null) {
        GlobalQueue._writeLane(el, value, lane);
      } else if (create ? !((flushTransaction !== null || passTx !== null) && (joined || prevLane && el._flags & REACTIVE_STAGED_READ || (creatorPass(oldcontext)?._flags ?? 0) & REACTIVE_JOINED)) : isEffect && el._pendingValue === NOT_PENDING) {
        el._value = value;
      } else {
        el._pendingValue = value;
        if (create) {
          holdNode(el, flushTransaction ?? passTx);
          el._statusFlags |= STATUS_UNINITIALIZED;
          GlobalQueue._fresh?.(el);
        }
        if (false) devTrackHeldPending(el);
      }
      if (el._subs !== null) {
        insertSubs(el);
        if (lane !== null) laneDirty(el, lane);
      }
    } else if (el._height != oldHeight) {
      for (let s = el._subs; s !== null; s = s._nextSub) insertIntoHeapHeight(s._sub, dirtyQueue);
    }
    if (!valueChanged && !el._x?._error) {
      if (outgoingError !== void 0) settleErroredDependents(el, outgoingError);
      if (outgoingPendingSources) {
        for (const source of outgoingPendingSources)
          if (source !== el) settlePendingSource(el, source);
      }
    }
    if (wasPendingSource && !(el._statusFlags & (STATUS_PENDING | STATUS_UNINITIALIZED)))
      settlePendingSource(el);
  }
  if (create && lane === null && (joined || prevLane && el._flags & REACTIVE_STAGED_READ) && el._statusFlags & STATUS_PENDING) {
    const t = flushTransaction ?? passTx;
    if (t !== null && !(LEGACY_LANES && t._lane) && !GlobalQueue._fresh?.(el)) holdNode(el, t);
  }
  if (!el._x?._error && el._pendingValue === NOT_PENDING && !(isEffect && el._modified)) {
    if (create || isEffect === EFFECT_TRACKED) trimStaleDeps(el);
    else heldTrim(el);
  }
  if (false)
    attrHooks.recomputeEnd(
      el,
      create,
      devChanged,
      lane !== null,
      flushTransaction !== null || passTx !== null || (el._config & CONFIG_HELD) !== 0,
      el._pendingValue !== NOT_PENDING
    );
  if (el._pendingValue !== NOT_PENDING || el._x !== null && (el._x._pendingFirstChild !== null || el._x._pendingDisposal !== null) || (el._statusFlags & (STATUS_PENDING | STATUS_UNINITIALIZED)) !== 0 && (!create || (el._statusFlags & STATUS_PENDING) !== 0)) {
    el._config |= CONFIG_STAGED;
    if (lane === null) queuePendingNode(el);
  }
  if (LEGACY_LANES) setPassLane(prevLane);
  if (missedWake) {
    enqueueSub(el);
    schedule();
  }
}
function updateIfNecessary(el) {
  if (el._flags & (REACTIVE_RECOMPUTING_DEPS | REACTIVE_DISPOSED)) return;
  if (el._flags & REACTIVE_CHECK) {
    for (let d = el._deps; d; d = d._nextDep) {
      const dep = d._dep;
      if (dep._fn) {
        updateIfNecessary(dep);
      }
      if (el._flags & REACTIVE_DIRTY) {
        break;
      }
    }
  }
  if (el._flags & REACTIVE_DIRTY || el._x?._error && el._time < clock && !el._x?._inFlight) {
    recompute(el);
  }
  el._flags = el._flags & (REACTIVE_SNAPSHOT_STALE | REACTIVE_IN_HEAP | REACTIVE_IN_HEAP_HEIGHT | REACTIVE_ZOMBIE | REACTIVE_DISPOSED | REACTIVE_MANUAL_WRITE | REACTIVE_FRAME_READ | REACTIVE_STAGED_READ | REACTIVE_LANE_READ | REACTIVE_SCREEN_READ | REACTIVE_PROBE_UNANSWERED);
}
function computed(fn, options) {
  const transparent = options?.transparent ?? false;
  const loading = options !== null && typeof options === "object" && "loadingValue" in options;
  const self = false ? {
    id: inheritId(options, transparent, context),
    _config: (loading ? CONFIG_LOADING : 0) | (transparent ? CONFIG_TRANSPARENT : 0) | (options?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (!context || options?.lazy ? CONFIG_AUTO_DISPOSE : 0) | (options?.sync ? CONFIG_SYNC : 0) | (options?._noSnapshot ? CONFIG_NO_SNAPSHOT : 0) | // Plumbing is an observe-tier notion (a name and records to
    // withhold); the prod literal never carries the bit.
    (options?._plumbing ? CONFIG_PLUMBING2 : 0) | (options?._extraConfig ?? 0) | (snapshotCaptureActive && ownerInSnapshotScope(context) ? CONFIG_IN_SNAPSHOT_SCOPE : 0),
    _equals: options?.equals ?? isEqual,
    _disposal: null,
    _context: context?._context ?? defaultContext,
    _childCount: 0,
    _fn: fn,
    _value: loading ? options.loadingValue : void 0,
    _height: 0,
    _nextHeap: void 0,
    _prevHeap: null,
    _deps: null,
    _depsTail: null,
    _depGen: 0,
    _subs: null,
    _subsTail: null,
    _parent: context,
    _nextSibling: null,
    _prevSibling: null,
    _firstChild: null,
    _flags: options?.lazy ? REACTIVE_LAZY : REACTIVE_NONE,
    _statusFlags: loading ? 0 : STATUS_UNINITIALIZED,
    _time: clock,
    _pendingValue: NOT_PENDING,
    _notifiedAt: -1,
    _x: null,
    // The slot is always present (hidden class); plumbing leaves it
    // unset, which `ownerPath` skips.
    _name: options?._plumbing ? void 0 : options?.name ?? "computed",
    // Observe: the verdict windows this pass entered (verdict.ts) — a
    // slot, so the stamp is never a write after construction.
    _devWindows: 0
  } : {
    id: inheritId(options, transparent, context),
    _config: (loading ? CONFIG_LOADING : 0) | (transparent ? CONFIG_TRANSPARENT : 0) | (options?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (!context || options?.lazy ? CONFIG_AUTO_DISPOSE : 0) | (options?.sync ? CONFIG_SYNC : 0) | (options?._noSnapshot ? CONFIG_NO_SNAPSHOT : 0) | (options?._extraConfig ?? 0) | (snapshotCaptureActive && ownerInSnapshotScope(context) ? CONFIG_IN_SNAPSHOT_SCOPE : 0),
    _equals: options?.equals ?? isEqual,
    _disposal: null,
    _context: context?._context ?? defaultContext,
    _childCount: 0,
    _fn: fn,
    _value: loading ? options.loadingValue : void 0,
    _height: 0,
    _nextHeap: void 0,
    _prevHeap: null,
    _deps: null,
    _depsTail: null,
    _depGen: 0,
    _subs: null,
    _subsTail: null,
    _parent: context,
    _nextSibling: null,
    _prevSibling: null,
    _firstChild: null,
    _flags: options?.lazy ? REACTIVE_LAZY : REACTIVE_NONE,
    // A loadingValue node is born committed: commit #0 is already in _value.
    _statusFlags: loading ? 0 : STATUS_UNINITIALIZED,
    _time: clock,
    _pendingValue: NOT_PENDING,
    _notifiedAt: -1,
    // Cold machinery (async slots) lives one hop away in the lazily-allocated extension — the core literal MUST
    // stay under V8's in-object boundary (§12: past ~39 fields every
    // allocation spills to a backing store and creation cost ~4x's).
    _x: null
  };
  if (options?.unobserved) ext(self)._unobserved = options.unobserved;
  if (false) self._config |= CONFIG_SUPERSEDES2;
  setupComputedNode(self, options);
  return self;
}
function ext(el) {
  return el._x ??= {
    _inFlight: null,
    _flightTeardown: null,
    _error: void 0,
    _blocked: void 0,
    _pendingSources: void 0,
    _unobserved: void 0,
    _snapshotValue: void 0,
    _pendingFirstChild: null,
    _pendingDisposal: null,
    _transaction: null,
    _reask: false,
    _flushed: NOT_PENDING,
    _flushedAt: -1,
    _q: 0,
    _lane: NOT_PENDING,
    _marks: 0
  };
}
function joinPass(c, el) {
  c._flags |= REACTIVE_JOINED;
  if (el._statusFlags & STATUS_UNINITIALIZED || c._type !== EFFECT_RENDER)
    joinPassTx(
      txOf(el),
      !c._type && c._statusFlags & STATUS_UNINITIALIZED || GlobalQueue._fresh?.(c)
    );
}
function frameRead(c, el) {
  if (layerFrameRead?.(c, el)) return true;
  const verdict2 = LEGACY_LANES && c._config & CONFIG_VERDICT;
  if (((LEGACY_LANES ? passLane : null) === null || c._statusFlags & STATUS_UNINITIALIZED && el._statusFlags & STATUS_PENDING) && !verdict2 && (c._type !== EFFECT_RENDER || el._config & CONFIG_INPUTS_PUBLISHED))
    return false;
  const t = txOf(el);
  if (t === flushTransaction && (LEGACY_LANES ? passLane : null) === null && !verdict2 || c._statusFlags & STATUS_UNINITIALIZED && c._config & CONFIG_HELD && txOf(c) === t)
    return false;
  staleReader(c, t);
  return true;
}
function creatorPass(owner) {
  return owner !== null && owner._root ? owner._parentComputed : owner;
}
function parkChildren(el) {
  markDisposal(el);
  const x = ext(el);
  x._pendingDisposal = el._disposal;
  x._pendingFirstChild = el._firstChild;
  el._disposal = null;
  el._firstChild = null;
  el._childCount = 0;
}
function createEffectNode(fn, effectFn, errorFn, type, options) {
  const transparent = options?.transparent ?? false;
  const self = false ? {
    id: inheritId(options, transparent, context),
    _config: (transparent ? CONFIG_TRANSPARENT : 0) | (options?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (options?.sync ? CONFIG_SYNC : 0) | (options?._extraConfig ?? 0) | (snapshotCaptureActive && ownerInSnapshotScope(context) ? CONFIG_IN_SNAPSHOT_SCOPE : 0),
    _equals: false,
    _disposal: null,
    _context: context?._context ?? defaultContext,
    _childCount: 0,
    _fn: fn,
    _value: void 0,
    _height: 0,
    _nextHeap: void 0,
    _prevHeap: null,
    _deps: null,
    _depsTail: null,
    _depGen: 0,
    _subs: null,
    _subsTail: null,
    _parent: context,
    _nextSibling: null,
    _prevSibling: null,
    _firstChild: null,
    _flags: REACTIVE_LAZY,
    _statusFlags: STATUS_UNINITIALIZED,
    _time: clock,
    _pendingValue: NOT_PENDING,
    _notifiedAt: -1,
    _modified: false,
    _prevValue: void 0,
    _effectFn: effectFn,
    _errorFn: errorFn,
    _cleanup: void 0,
    _type: type,
    _x: null,
    _name: options?.name ?? "effect",
    _devWindows: 0
  } : {
    id: inheritId(options, transparent, context),
    _config: (transparent ? CONFIG_TRANSPARENT : 0) | (options?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (options?.sync ? CONFIG_SYNC : 0) | (options?._extraConfig ?? 0) | (snapshotCaptureActive && ownerInSnapshotScope(context) ? CONFIG_IN_SNAPSHOT_SCOPE : 0),
    _equals: false,
    _disposal: null,
    _context: context?._context ?? defaultContext,
    _childCount: 0,
    _fn: fn,
    _value: void 0,
    _height: 0,
    _nextHeap: void 0,
    _prevHeap: null,
    _deps: null,
    _depsTail: null,
    _depGen: 0,
    _subs: null,
    _subsTail: null,
    _parent: context,
    _nextSibling: null,
    _prevSibling: null,
    _firstChild: null,
    _flags: REACTIVE_LAZY,
    _statusFlags: STATUS_UNINITIALIZED,
    _time: clock,
    _pendingValue: NOT_PENDING,
    _notifiedAt: -1,
    _modified: false,
    _prevValue: void 0,
    _effectFn: effectFn,
    _errorFn: errorFn,
    _cleanup: void 0,
    _type: type,
    _x: null
  };
  if (options?.unobserved) ext(self)._unobserved = options.unobserved;
  if (false) self._config |= CONFIG_WIDE2;
  setupComputedNode(self, lazyOptions);
  return self;
}
var effectStatusNotify = null;
function setEffectStatusNotify(fn) {
  effectStatusNotify = fn;
}
function statusNotifierOf(el) {
  return el._type ? effectStatusNotify ?? void 0 : void 0;
}
var lazyOptions = { lazy: true };
function setupComputedNode(self, options) {
  self._prevHeap = self;
  const parent = context?._root ? context._parentComputed : context;
  if (false) {
    emitDiagnostic({
      code: "PRIMITIVE_IN_FORBIDDEN_SCOPE",
      kind: "lifecycle",
      severity: "error",
      message: PRIMITIVE_IN_FORBIDDEN_SCOPE_MESSAGE,
      ownerId: context.id,
      ownerName: context._name
    });
    throw new Error(PRIMITIVE_IN_FORBIDDEN_SCOPE_MESSAGE);
  }
  if (false) assertNotInEffectCallback();
  if (context) linkChild(context, self);
  if (false) DEV.hooks.onOwner?.(self);
  if (parent) self._height = parent._height + 1;
  GlobalQueue._wireExternalSource?.(self);
  !options?.lazy && recompute(self, true);
  if (snapshotCaptureActive && !options?.lazy) {
    if (!(self._statusFlags & STATUS_PENDING) && !(self._config & CONFIG_NO_SNAPSHOT)) {
      ext(self)._snapshotValue = self._value === void 0 ? NO_SNAPSHOT : self._value;
      self._config |= CONFIG_HAS_SNAPSHOT;
      snapshotSources.add(self);
    }
  }
}
function signal(v, options) {
  const s = false ? {
    _equals: options?.equals ?? isEqual,
    _config: (options?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (options?._noSnapshot ? CONFIG_NO_SNAPSHOT : 0),
    _value: v,
    _subs: null,
    _subsTail: null,
    _pendingValue: NOT_PENDING,
    _notifiedAt: -1,
    _x: null,
    _name: options?.name ?? "signal",
    _owner: null
  } : {
    _equals: options?.equals ?? isEqual,
    _config: (options?.ownedWrite ? CONFIG_OWNED_WRITE : 0) | (options?._noSnapshot ? CONFIG_NO_SNAPSHOT : 0),
    _value: v,
    _subs: null,
    _subsTail: null,
    _pendingValue: NOT_PENDING,
    // Signal-literal diet (§12e): NO _time/_fn/_statusFlags slots. Stores
    // materialize one signal per touched leaf, so signal bytes are store
    // bytes. Computations use _time for retries and async provenance;
    // signal writes use _notifiedAt. _fn/_statusFlags read falsy-identically as
    // missing properties on the shared paths (undefined masks to 0).
    _notifiedAt: -1,
    _x: null
  };
  if (false) s._internal = false;
  if (options?.unobserved) ext(s)._unobserved = options.unobserved;
  if (snapshotCaptureActive && !(s._config & CONFIG_NO_SNAPSHOT)) {
    ext(s)._snapshotValue = v === void 0 ? NO_SNAPSHOT : v;
    s._config |= CONFIG_HAS_SNAPSHOT;
    snapshotSources.add(s);
  }
  return s;
}
function isEqual(a, b) {
  return a === b;
}
var verdict = null;
function setVerdict(fn) {
  verdict = fn;
}
var strictRead = false;
function untrack(fn, strictReadLabel) {
  if (GlobalQueue._externalUntrack === null && !tracking && true)
    return fn();
  const prevTracking = tracking;
  const prevStrictRead = strictRead;
  tracking = false;
  if (false) {
    strictRead = strictReadLabel || false;
    untrackDepth++;
  }
  try {
    if (GlobalQueue._externalUntrack) return GlobalQueue._externalUntrack(fn);
    return fn();
  } finally {
    tracking = prevTracking;
    if (false) {
      strictRead = prevStrictRead;
      untrackDepth--;
    }
  }
}
var spectating = false;
function prepareComputed(comp, refresh2) {
  if (comp._flags & REACTIVE_LAZY) {
    comp._flags &= ~REACTIVE_LAZY;
    recompute(comp, true);
  } else if (comp._flags & REACTIVE_DISPOSED) {
    if (comp._config & CONFIG_AUTO_DISPOSE) {
      const parent = comp._parent;
      if (parent !== null) {
        if (parent._flags & REACTIVE_DISPOSED) {
          comp._config &= ~CONFIG_AUTO_DISPOSE;
          return;
        }
        if (!(comp._flags & REACTIVE_ZOMBIE)) linkChild(parent, comp);
      }
      recompute(comp, true);
    }
  } else if (refresh2) {
    updateIfNecessary(comp);
  }
}
function readerSeesCommitted(el, c) {
  return !!(!c || el._pendingValue === NOT_PENDING || c._config & CONFIG_CHILDREN_FORBIDDEN);
}
var unflushedStaged = false;
function markUnflushedStaged() {
  unflushedStaged = true;
}
function unflushedValue(el) {
  if (globalQueue._running || el._pendingValue === NOT_PENDING || el._config & CONFIG_PROMOTED)
    return NOT_PENDING;
  if (el._config & CONFIG_HELD) return el._x._flushedAt === clock ? el._x._flushed : NOT_PENDING;
  return el._value;
}
function stashFlushed(el) {
  const x = el._x;
  if (x._flushedAt !== clock) {
    x._flushed = el._pendingValue;
    x._flushedAt = clock;
    unflushedStaged = true;
  }
}
var promotedWrites = [];
function markLateLinker(c) {
  c._flags |= REACTIVE_MISSED_WAKE;
  return true;
}
function resyncUnflushedCompanions() {
  unflushedStaged = false;
  if (promotedWrites.length !== 0) {
    for (const el of promotedWrites) el._config &= ~CONFIG_PROMOTED;
    promotedWrites.length = 0;
  }
}
function pullComputed(owner, c) {
  if (owner._height >= dirtyQueue._min) {
    markNode(c);
    markHeap(dirtyQueue);
    updateIfNecessary(owner);
  } else if (c._config & CONFIG_FRESH_READ) updateIfNecessary(owner);
  const height = owner._height;
  if (height >= c._height && owner._parent !== c) c._height = height + 1;
}
function read(el) {
  if (false)
    checkPostAwaitRead(
      el,
      el,
      void 0,
      el._name,
      (el._statusFlags & (STATUS_PENDING | STATUS_UNINITIALIZED)) === (STATUS_PENDING | STATUS_UNINITIALIZED)
    );
  let c = context;
  if (c?._root) c = c._parentComputed;
  const computed2 = el;
  const owner = el;
  const isComputed = typeof computed2._fn === "function";
  if (isComputed) prepareComputed(el, false);
  if (verdict !== null) return verdict(el, c);
  if (!isComputed && el._x?._snapshotValue === void 0 && !snapshotCaptureActive && (!unflushedStaged || el._pendingValue === NOT_PENDING) && // A28, see readNodeFast
  !(LEGACY_LANES && el._config & CONFIG_OVERRIDE) && // lanes: the slow path's one arm
  true) {
    if (c) {
      if (tracking) link(el, c);
      if (el._config & CONFIG_HELD && !(c._config & CONFIG_CHILDREN_FORBIDDEN)) {
        if (frameRead(c, el)) return el._value;
        joinPass(c, el);
      }
    }
    if (!c || el._pendingValue === NOT_PENDING || c._config & CONFIG_CHILDREN_FORBIDDEN)
      return el._value;
    if (LEGACY_LANES && c._config & CONFIG_VERDICT && stagedScreen(c))
      return el._value;
    stagedRead(c, el);
    return el._pendingValue;
  }
  if (false)
    throwPendingUntrackedRead(strictRead, {
      ownerId: c?.id,
      ownerName: c?._name,
      nodeName: owner?._name
    });
  let committed = false;
  if (c) {
    if (tracking) {
      link(el, c);
      if (isComputed) pullComputed(owner, c);
    }
    if (el._config & CONFIG_HELD && !(LEGACY_LANES && el._config & CONFIG_OVERRIDE) && !(c._config & CONFIG_CHILDREN_FORBIDDEN)) {
      if (owner._statusFlags & STATUS_UNINITIALIZED || !frameRead(c, el))
        joinPass(c, el);
      else committed = true;
    }
  }
  if (LEGACY_LANES && el._config & CONFIG_OVERRIDE) {
    const v = GlobalQueue._laneRead(c, el);
    if (v !== NOT_PENDING) return v;
  }
  if (LEGACY_LANES && owner._statusFlags & STATUS_PENDING && !committed && !(el._config & CONFIG_OVERRIDE) && !(owner._statusFlags & STATUS_UNINITIALIZED)) {
    committed = GlobalQueue._pendingFrame?.(c, owner) ?? false;
  }
  if (owner._statusFlags & STATUS_PENDING && !committed) {
    if (c) {
      if (false) {
        const message = "[PENDING_ASYNC_FORBIDDEN_SCOPE] Reading a pending async value inside createTrackedEffect or onSettled serves the committed value (and throws while uninitialized). Use createEffect instead which supports async-aware reactivity.";
        reportDiagnostic(
          emitDiagnostic(
            {
              code: "PENDING_ASYNC_FORBIDDEN_SCOPE",
              kind: "async",
              severity: "warn",
              message,
              ownerId: c.id,
              ownerName: c._name,
              nodeName: owner?._name
            },
            c
          )
        );
      }
      if (!(c._config & CONFIG_CHILDREN_FORBIDDEN) || owner._statusFlags & STATUS_UNINITIALIZED) {
        if (!tracking && !spectating && el !== c) link(el, c);
        throw owner._x?._error;
      }
    } else if (owner._statusFlags & STATUS_UNINITIALIZED) {
      throw owner._x?._error;
    }
  }
  if (isComputed && owner._statusFlags & STATUS_ERROR) {
    if (tracking && owner._time < clock) {
      recompute(owner);
      return read(el);
    } else throw owner._x?._error;
  }
  if (false)
    warnStrictReadUntracked(strictRead, {
      ownerId: c?.id,
      ownerName: c?._name,
      nodeName: owner?._name
    });
  if (snapshotCaptureActive && c && c._config & CONFIG_IN_SNAPSHOT_SCOPE) {
    const sv = el._x?._snapshotValue;
    if (sv !== void 0) {
      const snapshot = sv === NO_SNAPSHOT ? void 0 : sv;
      const current2 = el._pendingValue !== NOT_PENDING ? el._pendingValue : el._value;
      if (current2 !== snapshot) c._flags |= REACTIVE_SNAPSHOT_STALE;
      return snapshot;
    }
  }
  if (committed) return el._value;
  const value = serve(el, c);
  if (!c && isComputed && el._config & CONFIG_AUTO_DISPOSE && !(owner._statusFlags & STATUS_PENDING) && !el._subs) {
    dormantNodes.add(el);
    schedule();
  }
  return value;
}
function serve(el, c) {
  if (el._pendingValue !== NOT_PENDING && el._statusFlags & STATUS_UNINITIALIZED && (!c || spectating || c._config & CONFIG_CHILDREN_FORBIDDEN))
    throw new NotReadyError(null);
  const u = c && unflushedStaged ? unflushedValue(el) : NOT_PENDING;
  if (u !== NOT_PENDING) {
    markLateLinker(c);
    return u;
  }
  if (readerSeesCommitted(el, c)) return el._value;
  if (LEGACY_LANES && c._config & CONFIG_VERDICT && !(el._statusFlags & STATUS_UNINITIALIZED) && stagedScreen(c))
    return el._value;
  stagedRead(c, el);
  return el._pendingValue;
}
function stagedRead(c, el) {
  if (!(el?._statusFlags & STATUS_UNINITIALIZED)) {
    c._flags |= REACTIVE_STAGED_READ;
    if (el && flushTransaction !== null && (LEGACY_LANES ? passLane : null) === null && !(LEGACY_LANES && c._config & CONFIG_VERDICT))
      c._flags |= REACTIVE_JOINED;
    if ((LEGACY_LANES ? passLane : null) !== null) stagedReaders.push(c);
  }
}
function stagedScreen(c) {
  if (flushTransaction === null) return false;
  staleReader(c, flushTransaction);
  return true;
}
function notePromotedWrite(el) {
  if (globalQueue._running || el._config & CONFIG_PROMOTED) return;
  el._config |= CONFIG_PROMOTED;
  promotedWrites.push(el);
}
function captureWriteSnapshot(el, current2) {
  if (el._config & CONFIG_NO_SNAPSHOT || el._fn !== void 0 || el._x?._snapshotValue !== void 0)
    return;
  ext(el)._snapshotValue = current2 === void 0 ? NO_SNAPSHOT : current2;
  el._config |= CONFIG_HAS_SNAPSHOT;
  snapshotSources.add(el);
}
function setSignal(el, v) {
  if (false) {
    emitDiagnostic({
      code: "REACTIVE_WRITE_IN_OWNED_SCOPE",
      kind: "write",
      severity: "error",
      message: REACTIVE_WRITE_IN_OWNED_SCOPE_SIGNAL_MESSAGE,
      ownerId: context.id,
      ownerName: context._name,
      nodeName: el._name,
      data: { operation: "setSignal" }
    });
    throw new Error(ownedScopeWriteMessage(context));
  }
  const currentValue = el._pendingValue === NOT_PENDING ? el._value : el._pendingValue;
  if (typeof v === "function") v = v(currentValue);
  if (LEGACY_LANES && el._config & CONFIG_OVERRIDE) return GlobalQueue._laneWrite(el, v);
  if (el._config & CONFIG_HELD) joinFuture(txOf(el));
  const valueChanged = !!(el._statusFlags & STATUS_UNINITIALIZED) || !el._equals || !el._equals(currentValue, v);
  if (!valueChanged) return v;
  if (false) attrHooks.write(el, currentValue, v);
  if (snapshotCaptureActive) captureWriteSnapshot(el, currentValue);
  const wasStaged = el._pendingValue !== NOT_PENDING;
  if (!wasStaged) queuePendingNode(el);
  else if (el._config & CONFIG_HELD && !globalQueue._running) stashFlushed(el);
  el._pendingValue = v;
  if (false) devTrackHeldPending(el);
  if (context !== null) notePromotedWrite(el);
  if (el._fn !== void 0) el._time = clock;
  if (wasStaged && el._notifiedAt === notifyEpoch) return v;
  insertSubs(el);
  schedule();
  return v;
}
function setMemo(el, v) {
  const held = el._config & CONFIG_HELD && !(el._flags & REACTIVE_MANUAL_WRITE) && txOf(el) !== flushTransaction;
  if (held && typeof v === "function") v = v(el._value);
  const result = setSignal(el, v);
  if (held) {
    el._flags = el._flags & ~REACTIVE_CHECK | REACTIVE_DIRTY;
    insertIntoHeap(el, dirtyQueue);
    schedule();
  } else if (el._pendingValue !== NOT_PENDING) el._flags |= REACTIVE_MANUAL_WRITE;
  return result;
}
function runWithOwner(owner, fn) {
  if (false) {
    const message = "[RUN_WITH_DISPOSED_OWNER] runWithOwner called with a disposed owner. Children created inside will never be disposed.";
    reportDiagnostic(
      emitDiagnostic(
        {
          code: "RUN_WITH_DISPOSED_OWNER",
          kind: "owner",
          severity: "warn",
          message,
          ownerId: owner.id,
          ownerName: owner._name
        },
        owner
      )
    );
  }
  const oldContext = context;
  const prevTracking = tracking;
  context = owner;
  tracking = false;
  try {
    return fn();
  } finally {
    context = oldContext;
    tracking = prevTracking;
  }
}
function markRefresh(node) {
  if (false) {
    emitDiagnostic({
      code: "REACTIVE_WRITE_IN_OWNED_SCOPE",
      kind: "write",
      severity: "error",
      message: REACTIVE_WRITE_IN_OWNED_SCOPE_REFRESH_MESSAGE,
      ownerId: context.id,
      ownerName: context._name,
      nodeName: node._name,
      data: { operation: "refresh" }
    });
    throw new Error(REACTIVE_WRITE_IN_OWNED_SCOPE_REFRESH_MESSAGE);
  }
  if (typeof node._fn === "function" && !(node._flags & REACTIVE_DISPOSED)) {
    node._flags = node._flags & ~REACTIVE_CHECK | REACTIVE_DIRTY | (node._flags & (REACTIVE_DIRTY | REACTIVE_CHECK | REACTIVE_IN_HEAP) ? 0 : REACTIVE_REASK);
    if (false) attrHooks.refreshed(node);
    insertIntoHeap(node, dirtyQueue);
    schedule();
  }
}

// packages/signals/src/core/async.ts
function addPendingSource(el, source) {
  if (el._x?._pendingSources?.has(source)) return false;
  (ext(el)._pendingSources ??= /* @__PURE__ */ new Set()).add(source);
  return true;
}
function removePendingSource(el, source) {
  const sources = el._x?._pendingSources;
  if (!sources?.delete(source)) return false;
  if (!sources.size) el._x._pendingSources = void 0;
  return true;
}
function clearPendingSources(el) {
  if (el._x !== null) el._x._pendingSources = void 0;
}
function retryReaches(el, source) {
  for (let d = el._deps; d; d = d._nextDep) {
    const dep = d._dep;
    if (dep === source || dep._x?._pendingSources?.has(source)) return true;
  }
  return false;
}
function parkLoadingWindow(el, e) {
  ext(el)._blocked = true;
  if (e.source) addPendingSource(el, e.source);
  if (!(el._statusFlags & STATUS_ERROR)) setPendingError(el, e.source, e);
}
function setPendingError(el, source, error) {
  if (!source) {
    if (el._x !== null) el._x._error = null;
    return;
  }
  if (error instanceof NotReadyError && error.source === source) {
    ext(el)._error = error;
    return;
  }
  const current2 = el._x?._error;
  if (!(current2 instanceof NotReadyError) || current2.source !== source) {
    ext(el)._error = new NotReadyError(source);
  }
}
function forEachDependent(el, fn) {
  for (let s = el._subs; s !== null; s = s._nextSub) fn(s._sub, s);
}
function releaseIfSettledUnobserved(node) {
  node._fn && node._config & CONFIG_AUTO_DISPOSE && !node._subs && !(node._flags & REACTIVE_ZOMBIE) && !(node._statusFlags & STATUS_PENDING) && unobserved(node);
}
function releaseSettledDependents(el) {
  let candidates;
  const visited = /* @__PURE__ */ new Set();
  const visit2 = (node) => {
    if (visited.has(node)) return;
    visited.add(node);
    if (!node._subs && node._config & CONFIG_AUTO_DISPOSE) (candidates ??= []).push(node);
    forEachDependent(node, visit2);
  };
  forEachDependent(el, visit2);
  if (candidates) for (const node of candidates) releaseIfSettledUnobserved(node);
}
function settleErroredDependents(el, error) {
  let scheduled2 = false;
  const visited = /* @__PURE__ */ new Set();
  const visit2 = (node) => {
    if (visited.has(node)) return;
    visited.add(node);
    if (node._x?._error === error) {
      enqueueSub(node);
      scheduled2 = true;
    }
    forEachDependent(node, visit2);
  };
  forEachDependent(el, visit2);
  if (scheduled2) schedule();
}
function settlePendingSource(el, source = el) {
  if (false) {
    const sources = el._x?._pendingSources;
    if (el._statusFlags & STATUS_UNINITIALIZED && el._pendingValue === NOT_PENDING && !el._x?._error && !((el._config & (CONFIG_OVERRIDE | CONFIG_GUESS)) === CONFIG_OVERRIDE && el._x._lane !== NOT_PENDING) && // A replacement source makes this a cleanup-only transfer: removing
    // self leaves the source and every propagated dependent parked. No
    // sources (or self alone) would release readers without truth.
    !(sources?.size && (sources.size > 1 || !sources.has(el)))) {
      reportDiagnostic(
        emitDiagnostic(
          {
            code: "SETTLE_WALK_UNINITIALIZED_SOURCE",
            kind: "lifecycle",
            severity: "error",
            message: "[SETTLE_WALK_UNINITIALIZED_SOURCE] settlePendingSource was called on a source that never produced a value. Settling parked readers requires truth to reveal \u2014 an uninitialized source waking its dependents serves them its initial face instead of settled data.",
            ownerId: el.id,
            ownerName: el._name
          },
          el
        )
      );
    }
  }
  removePendingSource(el, source);
  let scheduled2 = false;
  let released;
  const visited = /* @__PURE__ */ new Set();
  const settle = (node) => {
    if (visited.has(node) || // A conditional dropped this source, but another dependency can still
    // carry it. Only retire pending state inherited through the recovered
    // branch. Deliberately NOT marked visited on this early return: the
    // carrying dependency may itself be a later branch of this same walk
    // (two unchanged memos converging), and its visit must be free to
    // re-examine this node once that branch has retired the source.
    source !== el && retryReaches(node, source) || !removePendingSource(node, source))
      return node._config & CONFIG_VERDICT && enqueueSub(node);
    visited.add(node);
    node._time = clock;
    const remaining = node._x?._pendingSources?.values().next().value;
    const errored = node._statusFlags & STATUS_ERROR;
    if (remaining) {
      if (!errored) setPendingError(node, remaining);
    } else {
      node._statusFlags &= ~STATUS_PENDING;
      if (!errored) setPendingError(node);
      if (node._config & CONFIG_HELD) joinFuture(txOf(node));
      if (node._x?._blocked) {
        enqueueSub(node);
        scheduled2 = true;
      }
      if (node._x !== null) node._x._blocked = false;
      if (!node._subs && node._config & CONFIG_AUTO_DISPOSE) (released ??= []).push(node);
    }
    forEachDependent(node, settle);
  };
  forEachDependent(el, settle);
  if (released) for (const node of released) releaseIfSettledUnobserved(node);
  if (scheduled2) schedule();
}
function isThenable(value) {
  return value != null && typeof value === "object" && typeof value.then === "function";
}
function releaseFlightTeardown(el) {
  const teardown = el._x?._flightTeardown;
  if (teardown != null) {
    el._x._flightTeardown = null;
    teardown();
  }
}
function handleAsync(el, result, setter, onError) {
  let iterator = false;
  let thenable = false;
  if (typeof result === "object" && result !== null) {
    untrack(() => {
      iterator = result[Symbol.asyncIterator];
      thenable = !iterator && isThenable(result);
    });
  }
  if (!thenable && !iterator) {
    if (el._x !== null) el._x._inFlight = null;
    el._config &= ~CONFIG_LOADING;
    return result;
  }
  if (false) {
    const message = `[SYNC_NODE_RECEIVED_ASYNC] A computed/effect created with \`sync: true\` returned ${thenable ? "a Promise" : "an AsyncIterable"}. The value would be stored as-is and never awaited in production; remove \`sync: true\` to use async-aware behavior, or unwrap the value before returning.`;
    emitDiagnostic({
      code: "SYNC_NODE_RECEIVED_ASYNC",
      kind: "lifecycle",
      severity: "error",
      message,
      ownerId: el.id,
      ownerName: el._name
    });
    throw new Error(message);
  }
  ext(el)._inFlight = result;
  el._x._q = question || MAINLINE_QUESTION;
  el._x._pendingSources = void 0;
  if (false) attrHooks.flightStart(el, result);
  let syncValue;
  const handleError = (error) => {
    if (el._x?._inFlight !== result) return;
    let stillPending = error instanceof NotReadyError;
    if (false) {
      stillPending = false;
      error = new Error(
        "Read of an unresolved async source after an `await`. Reads inside async computations only register as dependencies before the first `await`; a source first read after it cannot retry when it settles. Read it before the first `await` (or restructure so the value is an input)."
      );
    }
    if (stillPending && el._config & CONFIG_LOADING) {
      if (el._x !== null) el._x._inFlight = null;
      parkLoadingWindow(el, error);
      el._time = clock;
      return;
    }
    notifyStatus(el, stillPending ? STATUS_PENDING : STATUS_ERROR, error);
    if (stillPending) settlePendingSource(el);
    el._time = clock;
    if (!stillPending) releaseSettledDependents(el);
    onError?.(error, stillPending);
  };
  const asyncWrite = (value, then) => {
    if (el._x?._inFlight !== result) return;
    if (el._flags & REACTIVE_DIRTY) return;
    const wasUninitialized = !!(el._statusFlags & STATUS_UNINITIALIZED);
    landStatus(el);
    if (false) attrHooks.asyncStart(el);
    if (setter) {
      try {
        setter(value);
      } catch (error) {
        handleError(error);
        return;
      }
      if (wasUninitialized) landStatus(el, true);
      if (false) attrHooks.asyncEnd(el, void 0, value, true);
    } else {
      try {
        setSignal(el, () => value);
      } catch (e) {
        notifyStatus(el, STATUS_ERROR, e);
      }
      if (false) attrHooks.asyncEnd(el, void 0, value, false);
    }
    if (el._pendingValue === NOT_PENDING) {
      el._config &= ~CONFIG_LOADING;
      trimStaleDeps(el);
    }
    settlePendingSource(el);
    schedule();
    flush();
    then?.();
  };
  const settleAutodispose = () => {
    if (el._config & CONFIG_AUTO_DISPOSE && !el._subs && !(el._statusFlags & STATUS_PENDING)) {
      unobserved(el);
      return true;
    }
    return false;
  };
  const consumeIterator = (source, registerClose) => {
    const it = source[Symbol.asyncIterator]();
    let hadValue = false;
    let completed = false;
    let initialRead = !registerClose;
    const close = () => {
      if (completed) return;
      completed = true;
      try {
        const returned = it.return?.();
        if (isThenable(returned)) returned.then(void 0, () => {
        });
      } catch {
      }
    };
    registerClose ? registerClose(close) : cleanup(close);
    ext(el)._flightTeardown = close;
    const iterateOrRelease = () => {
      if (!completed && !settleAutodispose()) iterate();
    };
    const iterate = () => {
      let syncResult, syncError, resolved = false, rejected = false, isSync = true;
      const step = it.next();
      const settled = isThenable(step) ? step : { then: (onSettle) => void onSettle(step) };
      settled.then(
        (r) => {
          if (completed) return;
          if (isSync && initialRead) {
            syncResult = r;
            resolved = true;
            if (r.done) completed = true;
          } else if (el._x?._inFlight !== result) {
            return;
          } else if (!r.done) {
            hadValue = true;
            asyncWrite(r.value, iterateOrRelease);
          } else {
            completed = true;
            if (hadValue) {
              schedule();
              flush();
            } else {
              asyncWrite(void 0);
            }
            settleAutodispose();
          }
        },
        (e) => {
          if (completed) return;
          if (isSync && initialRead) {
            syncError = e;
            rejected = true;
          } else if (el._x?._inFlight === result) {
            completed = true;
            handleError(e);
            settleAutodispose();
          }
        }
      );
      isSync = false;
      if (rejected) {
        completed = true;
        handleError(syncError);
        if (initialRead) throw syncError;
        return true;
      }
      if (resolved && !syncResult.done) {
        syncValue = syncResult.value;
        hadValue = true;
        return iterate();
      }
      return resolved && syncResult.done;
    };
    const immediatelyDone = iterate();
    initialRead = false;
    return hadValue || immediatelyDone;
  };
  let liveLanded = null;
  const flattenIfIterable = (value, registerClose) => {
    let innerIterator = false;
    if (typeof value === "object" && value !== null) {
      untrack(() => {
        innerIterator = value[Symbol.asyncIterator];
      });
    }
    if (!innerIterator) return false;
    const landed = consumeIterator(value, registerClose);
    if (!registerClose) liveLanded = landed;
    return true;
  };
  if (thenable) {
    let resolved = false, rejected = false, syncError, isSync = true;
    const registerDeferredClose = (fn) => {
      if (!el._disposal) el._disposal = fn;
      else if (Array.isArray(el._disposal)) el._disposal.push(fn);
      else el._disposal = [el._disposal, fn];
    };
    (false ? watchAsyncTail(el, result) : result).then(
      (v) => {
        if (isSync) {
          syncValue = v;
          resolved = true;
        } else if (el._x?._inFlight === result && !(el._flags & REACTIVE_DISPOSED) && flattenIfIterable(v, registerDeferredClose)) {
        } else {
          asyncWrite(v);
          settleAutodispose();
        }
      },
      (e) => {
        if (isSync) {
          syncError = e;
          rejected = true;
        } else {
          handleError(e);
          settleAutodispose();
        }
      }
    );
    isSync = false;
    if (rejected) {
      handleError(syncError);
      throw syncError;
    } else if (!resolved) {
      if (el._config & CONFIG_LOADING) return el._value;
      throw new NotReadyError(context);
    } else if (!flattenIfIterable(syncValue)) {
      el._config &= ~CONFIG_LOADING;
    }
  }
  if (iterator) flattenIfIterable(result);
  if (liveLanded !== null) {
    if (!liveLanded) {
      if (el._config & CONFIG_LOADING) return el._value;
      throw new NotReadyError(context);
    }
    el._config &= ~CONFIG_LOADING;
  }
  return syncValue;
}
function clearStatus(el, clearUninitialized = false) {
  if (el._x?._pendingSources) clearPendingSources(el);
  if (el._x?._blocked) {
    if (el._x !== null) el._x._blocked = false;
  }
  el._statusFlags = clearUninitialized ? 0 : el._statusFlags & STATUS_UNINITIALIZED;
  if (el._x?._error) setPendingError(el);
  const notify = statusNotifierOf(el);
  if (notify) notify.call(el);
}
function landStatus(el, clearUninitialized = false) {
  const sources = el._x?._pendingSources;
  if (sources && (sources.delete(el), sources.size)) {
    el._x._blocked = false;
    if (clearUninitialized) el._statusFlags = STATUS_PENDING;
    setPendingError(el, sources.values().next().value);
  } else clearStatus(el, clearUninitialized);
}
function notifyStatus(el, status, error, blockStatus) {
  if (status === STATUS_ERROR && !(error instanceof StatusError) && !(error instanceof NotReadyError))
    error = new StatusError(el, error);
  const pendingSource = status === STATUS_PENDING && error instanceof NotReadyError ? error.source : void 0;
  if (!blockStatus) {
    if (status === STATUS_PENDING && pendingSource) {
      addPendingSource(el, pendingSource);
      el._statusFlags = STATUS_PENDING | el._statusFlags & STATUS_UNINITIALIZED;
      setPendingError(el, pendingSource, error);
    } else {
      clearPendingSources(el);
      el._statusFlags = status | (status !== STATUS_ERROR ? el._statusFlags & STATUS_UNINITIALIZED : 0);
      ext(el)._error = error;
    }
  }
  const downstreamBlockStatus = blockStatus;
  if (status === STATUS_PENDING && el._config & CONFIG_GUESS) {
    if (passLane === null) joinFuture(null);
    return;
  }
  const elNotify = statusNotifierOf(el);
  if (elNotify) {
    if (blockStatus && status === STATUS_PENDING) {
      return;
    }
    if (downstreamBlockStatus) {
      elNotify.call(el, status, error);
    } else {
      elNotify.call(el);
    }
    return;
  }
  propagateStatus(el, status, error, downstreamBlockStatus);
}
function propagateStatus(el, status, error, downstreamBlockStatus) {
  const pendingSource = status === STATUS_PENDING && error instanceof NotReadyError ? error.source : void 0;
  forEachDependent(el, (sub, link2) => {
    sub._time = clock;
    if (sub._config & (CONFIG_REDERIVE | CONFIG_VERDICT) || status === STATUS_PENDING && link2._gen !== sub._depGen) {
      enqueueSub(sub);
      schedule();
      return;
    }
    if (status === STATUS_PENDING && pendingSource && sub._x?._pendingSources?.has(pendingSource)) {
      if (passLane === null && (sub._config & (CONFIG_HELD | CONFIG_OVERRIDE)) === CONFIG_HELD && globalQueue._running)
        joinFuture(txOf(sub));
      return;
    }
    if (status === STATUS_PENDING && pendingSource || status !== STATUS_PENDING && (sub._x?._error !== error || sub._x?._pendingSources)) {
      if (!downstreamBlockStatus) {
        if (LEGACY_LANES && passLane !== null) GlobalQueue._laneStage(sub, passLane, true, el);
        else {
          queuePendingNode(sub);
          if (status === STATUS_PENDING && (sub._config & (CONFIG_HELD | CONFIG_OVERRIDE)) === CONFIG_HELD && !sub._type)
            joinFuture(txOf(sub));
        }
      }
      notifyStatus(sub, status, error, downstreamBlockStatus);
    }
  });
}

// packages/signals/src/core/action.ts
function inTransaction(t, q, fn) {
  const prevQ = question;
  setQuestion(q);
  joinFuture(t);
  const result = fn();
  if (actionDepth === 0) flush();
  setQuestion(prevQ);
  return result;
}
function action(genFn) {
  return (...args) => {
    if (false) {
      const owner = getOwner();
      if (owner && !(owner._config & CONFIG_CHILDREN_FORBIDDEN)) {
        emitDiagnostic({
          code: "ACTION_CALLED_IN_OWNED_SCOPE",
          kind: "write",
          severity: "error",
          message: ACTION_CALLED_IN_OWNED_SCOPE_MESSAGE,
          ownerId: owner.id,
          ownerName: owner._name
        });
        throw new Error(ACTION_CALLED_IN_OWNED_SCOPE_MESSAGE);
      }
    }
    return new Promise((resolve, reject) => {
      const it = genFn(...args);
      const t = newTransaction(false);
      t._open = 1;
      t._acted = true;
      const q = nextQuestion();
      const done = (v, e, failed = false) => {
        resolveTx(t)._open--;
        schedule();
        failed ? reject(e) : resolve(v);
      };
      const step = (v, err) => {
        let r;
        if (false)
          attrHooks.actionStepStart(it, genFn.name || void 0);
        enterAction();
        let effectCallback = false;
        if (false) {
          enterCallback();
          effectCallback = inEffectCallback2;
          setEffectCallback(false);
        }
        try {
          r = err ? it.throw(v) : it.next(v);
        } catch (e) {
          exitAction();
          if (false) exitCallback(), setEffectCallback(effectCallback);
          if (false) attrHooks.actionStepEnd(it);
          return done(void 0, e, true);
        }
        exitAction();
        if (false) exitCallback(), setEffectCallback(effectCallback);
        if (false) attrHooks.actionStepEnd(it);
        if (isThenable(r)) return void r.then(run, (e) => done(void 0, e, true));
        run(r);
      };
      const run = (r) => {
        if (r.done) return done(r.value);
        let settled = false;
        try {
          if (isThenable(r.value))
            return void r.value.then(
              (v) => {
                if (settled) return;
                settled = true;
                inTransaction(t, q, () => step(v));
              },
              (e) => {
                if (settled) return;
                settled = true;
                inTransaction(t, q, () => step(e, true));
              }
            );
        } catch (e) {
          if (settled) return;
          settled = true;
          return void inTransaction(t, q, () => step(e, true));
        }
        inTransaction(t, q, () => step(r.value));
      };
      joinFuture(t);
      const prevQ = question;
      setQuestion(q);
      step();
      setQuestion(prevQ);
    });
  };
}

// packages/signals/src/core/lanes.ts
GlobalQueue._enterLane = (el, create, creator) => {
  const prevLane = passLane;
  setPassLane(
    (el._flags & REACTIVE_LANE_DIRTY || (el._config & (CONFIG_OVERRIDE | CONFIG_GUESS)) === CONFIG_OVERRIDE) && el._x?._transaction?._lane ? el._x._transaction : (
      // Loose `!=`: false with no creator lane (undefined == null).
      create && prevLane?._parent._verdict != prevLane && (creator?._flags ?? 0) & REACTIVE_RECOMPUTING_DEPS ? prevLane : null
    )
  );
};
GlobalQueue._writeLane = (el, value, lane) => {
  const isEffect = el._type;
  if (isEffect && el._pendingValue === NOT_PENDING) el._value = value;
  else if (isEffect || lane._shown) el._pendingValue = value;
  else el._x._lane = value;
};
GlobalQueue._pendingFrame = (c, owner) => {
  if (passLane !== null && !(c?._statusFlags & STATUS_UNINITIALIZED)) return true;
  return !!(c && c._config & CONFIG_VERDICT && GlobalQueue._observeFlight(c, owner));
};
var lanes = [];
var LEFT_SHOWN = 1 << 20;
function newLane(parent) {
  const l = newTransaction(true, parent);
  lanes.push(l);
  return l;
}
function laneValueOf(el) {
  if (!(el._config & CONFIG_GUESS) && el._pendingValue !== NOT_PENDING) return el._pendingValue;
  const v = el._x._lane;
  return v !== NOT_PENDING ? v : el._value;
}
function display(el) {
  const v = el._x._lane;
  return el._x._transaction._shown && v !== NOT_PENDING ? v : el._value;
}
var pendingGuesses = [];
function inFlight(n) {
  return (n._statusFlags & STATUS_PENDING) !== 0 || (n._config & CONFIG_SLOT_NODE) !== 0 && GlobalQueue._slotFlight?.(n) === true;
}
function applyGuesses(parent) {
  let lane = null;
  for (let i = 0; i < pendingGuesses.length; i += 3) {
    const n = pendingGuesses[i];
    const v = pendingGuesses[i + 1];
    let changed = true;
    if (n._config & CONFIG_OVERRIDE) {
      changed = !n._equals || !n._equals(laneValueOf(n), v);
      if (!(n._config & CONFIG_GUESS)) {
        n._pendingValue = NOT_PENDING;
        n._config |= CONFIG_GUESS;
      }
      n._x._lane = v;
      const holder = txOf(n)._parent;
      if (parent !== null && holder !== null) merge(parent, holder);
    } else {
      let l;
      if (n._config & CONFIG_HELD) l = newLane(txOf(n));
      else {
        if (parent === null && inFlight(n)) parent = newTransaction(false);
        if (parent === null) continue;
        l = lane ??= newLane(parent);
      }
      ext(n)._lane = v;
      n._config |= CONFIG_OVERRIDE | CONFIG_GUESS;
      list(n, l);
    }
    ext(n)._q = pendingGuesses[i + 2];
    if (changed) {
      insertSubs(n);
      laneDirty(n, txOf(n));
    }
  }
  pendingGuesses.length = 0;
}
function enterLane(l, c) {
  c._flags |= REACTIVE_LANE_READ;
  const p = passLane;
  if (p === null) {
    setPassLane(l);
    if (c._flags & REACTIVE_JOINED && c._flags & REACTIVE_STAGED_READ) stagedRead(c);
    return;
  }
  if (sameLane(p, l)) return setPassLane(l);
  if (under(p, l)) return;
  if (under(l, p)) return setPassLane(l);
  linkLanes(p, l);
  setPassLane(l);
}
function under(l, a) {
  for (let t = l._parent; t !== null && t._lane; t = t._parent) if (t === a) return true;
  return false;
}
function linkLanes(a, b) {
  const ga = a._links ?? (a._links = [a]);
  const gb = b._links;
  if (gb === ga) return;
  if (gb === null) {
    ga.push(b);
    b._links = ga;
  } else
    for (let i = 0; i < gb.length; i++) {
      ga.push(gb[i]);
      gb[i]._links = ga;
    }
}
function linkBlocked(l) {
  const g = l._links;
  if (g !== null)
    for (let i = 0; i < g.length; i++) {
      const k = g[i];
      if (k !== l && (k._open !== 0 || ownFlights(k) || nestedBlocked(k))) return true;
    }
  return false;
}
function unlink(l) {
  const g = l._links;
  if (g === null) return;
  const k = g.indexOf(l);
  if (k !== -1) g.splice(k, 1);
  l._links = null;
}
function verdictLane(t) {
  return t._verdict ??= newLane(t);
}
function laneStage(el, l, create, errored) {
  if (!(create || errored || el._flags & REACTIVE_LANE_READ || el._config & CONFIG_GUESS)) {
    const x = el._x;
    if (x !== null) {
      const tx = x._transaction;
      if (tx?._shown && !blocked(resolveTx(tx._parent))) el._flags |= LEFT_SHOWN;
      if (tx?._lane) x._transaction = null;
      x._lane = NOT_PENDING;
    }
    el._config &= ~(CONFIG_OVERRIDE | CONFIG_HELD);
    return false;
  }
  if (!el._type) {
    if (!(el._config & CONFIG_OVERRIDE)) {
      el._pendingValue = NOT_PENDING;
      el._config = el._config & ~CONFIG_HELD | CONFIG_OVERRIDE;
      ext(el);
    }
    if (!errored) el._config &= ~CONFIG_GUESS;
  } else if (errored) {
    if (errored !== true && !(errored._statusFlags & STATUS_UNINITIALIZED) && (el._config & CONFIG_HELD || el._flags & REACTIVE_RECOMPUTING_DEPS) && !el._x?._transaction?._lane) {
      queuePendingNode(el);
      return false;
    }
    el._flags |= REACTIVE_LANE_DIRTY;
  }
  list(el, l);
  return true;
}
function supersede(n, value, changed) {
  const l = txOf(n);
  const parent = resolveTx(l._parent ?? l);
  if (changed && n._config & CONFIG_SLOT_NODE && GlobalQueue._echoes?.(n._x._lane, value))
    changed = false;
  if (changed) {
    if (false)
      attrHooks.optimisticReverted(n, n._x._lane, value, reverting ? "reverted" : "superseded");
    dissolveLane(l, parent, n);
    if (l._shown) n._value = n._x._lane;
    n._config &= ~(CONFIG_OVERRIDE | CONFIG_GUESS);
    n._x._lane = NOT_PENDING;
    holdNode(n, parent);
    if (n._subs !== null) insertSubs(n);
  } else {
    n._config |= CONFIG_HELD;
    GlobalQueue._confirmed?.(l);
  }
  n._pendingValue = value;
  joinFuture(parent);
}
function truthRead(el) {
  return truth(el) ? laneValueOf(el) : el._config & CONFIG_GUESS && el._pendingValue !== NOT_PENDING ? el._pendingValue : el._value;
}
function truthConfirmed(l) {
  for (let i = 0; i < l._nodes.length; i++)
    for (let s = l._nodes[i]._subs; s !== null; s = s._nextSub)
      if (s._sub._config & CONFIG_AUTHORITATIVE) enqueueSub(s._sub);
}
function truth(n) {
  if (n._config & CONFIG_GUESS)
    return n._pendingValue !== NOT_PENDING && n._equals && n._equals(n._x._lane, n._pendingValue);
  if (n._pendingValue !== NOT_PENDING) return;
  if (n._config & CONFIG_OVERRIDE) {
    for (let d = n._deps; d; d = d._nextDep) if (!truth(d._dep)) return;
  }
  return 1;
}
function dissolveLane(l, into, except) {
  const k = lanes.indexOf(l);
  if (k !== -1) lanes.splice(k, 1);
  unlink(l);
  const v = l._verdict;
  if (v !== null) {
    l._verdict = null;
    if (lanes.indexOf(v) !== -1) dissolveLane(v, null);
  }
  for (let i = 0; i < l._nodes.length; i++) {
    const n = l._nodes[i];
    const x = n._x;
    if (n === except || x._transaction !== l) continue;
    const effect2 = n._type;
    const guess = n._config & CONFIG_GUESS;
    const slot = x._lane;
    const shown = l._shown && !effect2 ? slot : n._value;
    const latest2 = laneValueOf(n);
    x._lane = NOT_PENDING;
    n._config &= ~(CONFIG_OVERRIDE | CONFIG_GUESS);
    if (into === null) {
      if (false) {
        const truth2 = n._pendingValue !== NOT_PENDING ? n._pendingValue : n._value;
        if (truth2 !== slot)
          attrHooks.optimisticReverted(
            n,
            slot,
            truth2,
            n._pendingValue !== NOT_PENDING ? "superseded" : "reverted"
          );
      }
      x._transaction = null;
      if (!effect2 && !guess) n._pendingValue = latest2;
      commitPendingNode(n);
      if (!effect2) {
        if (n._flags & (REACTIVE_IN_HEAP | REACTIVE_DIRTY | REACTIVE_CHECK) || n._statusFlags & STATUS_PENDING)
          n._config |= CONFIG_INPUTS_PUBLISHED;
        if (shown !== NOT_PENDING && (!n._equals || !n._equals(shown, n._value))) insertSubs(n);
      }
    } else if (guess) {
      if (n._pendingValue === NOT_PENDING) n._pendingValue = covered(n);
      if (l._shown) n._value = slot;
      holdNode(n, into);
      insertSubs(n);
    } else {
      x._transaction = null;
      if (!effect2) {
        if (shown !== NOT_PENDING && l._shown) n._pendingValue = shown;
        if (n._statusFlags & STATUS_PENDING) {
          x._inFlight = null;
          enqueueSub(n);
        }
      }
      if (l._shown) {
        commitPendingNode(n);
        if (!effect2) n._config |= CONFIG_INPUTS_PUBLISHED;
      } else {
        if (x._pendingFirstChild !== null || x._pendingDisposal !== null)
          GlobalQueue._dispose(n, false, true);
        n._config &= ~(CONFIG_STAGED | CONFIG_HELD);
      }
    }
  }
  if (into === null || l._shown && !l._held) releaseQueues(l);
  else l._queues[0].length = l._queues[1].length = 0;
}
function laneRead(c, el) {
  const guess = el._config & CONFIG_GUESS;
  if (c !== null && c._config & CONFIG_AUTHORITATIVE) return GlobalQueue._truth(el);
  if (c === null) return laneValueOf(el);
  const l = txOf(el);
  const status = el._statusFlags;
  if (!tracking || c._config & CONFIG_CHILDREN_FORBIDDEN) {
    if (passLane === null || c._config & CONFIG_CHILDREN_FORBIDDEN) return display(el);
    enterLane(l, c);
    if (!guess && status & STATUS_PENDING) return NOT_PENDING;
    return laneValueOf(el);
  }
  if (c._type === EFFECT_RENDER && (passLane === null || !sameLane(passLane, l))) {
    if (!guess) {
      if (status & STATUS_PENDING && el._x._lane === NOT_PENDING) return NOT_PENDING;
      if (el._pendingValue !== NOT_PENDING && c._config & CONFIG_HELD && flushTransaction !== null && resolveTx(flushTransaction) === txOf(c))
        return el._pendingValue;
    }
    if (l._held || !guess && status & STATUS_PENDING) {
      if (!guess && !l._shown && status & STATUS_UNINITIALIZED) throw new NotReadyError(null);
      c._flags |= REACTIVE_FRAME_READ | REACTIVE_SCREEN_READ;
      queueRerun(l, c);
      return display(el);
    }
  }
  enterLane(l, c);
  if (!guess && status & STATUS_PENDING) return NOT_PENDING;
  return laneValueOf(el);
}
function covered(n) {
  return n._config & CONFIG_SLOT_NODE && GlobalQueue._slotCovered !== void 0 ? GlobalQueue._slotCovered(n) : n._value;
}
function guessFlights(l) {
  for (let i = 0; i < l._nodes.length; i++) {
    const n = l._nodes[i];
    if (n._config & CONFIG_GUESS && n._x._transaction === l && inFlight(n)) return true;
  }
  return false;
}
function laneCorrections() {
  let judged2 = false;
  const live = lanes.slice();
  for (let k = 0; k < live.length; k++) {
    const l = live[k];
    if (lanes.indexOf(l) === -1) continue;
    const p = resolveTx(l._parent);
    if (!p._acted || p._open !== 0 || p._lane || ownFlights(p) || guessFlights(l)) continue;
    judged2 = true;
    for (let i = 0; i < l._nodes.length && lanes.indexOf(l) !== -1; i++) {
      const n = l._nodes[i];
      if (n._config & CONFIG_GUESS && n._x._transaction === l) {
        const truth2 = n._pendingValue !== NOT_PENDING ? n._pendingValue : covered(n);
        if (false) reverting = n._pendingValue === NOT_PENDING;
        supersede(n, truth2, !n._equals || !n._equals(n._x._lane, truth2));
        if (false) reverting = false;
      }
    }
  }
  return judged2;
}
function laneSeam(l, leaked) {
  if (leaked || blocked(l)) {
    l._held = true;
    return;
  }
  l._held = false;
  l._shown = true;
  reruns(l);
  for (let i = 0; i < l._nodes.length; i++) {
    const n = l._nodes[i];
    if (n._flags & LEFT_SHOWN) {
      n._flags ^= LEFT_SHOWN;
      insertSubs(n);
    }
    const x = n._x;
    if (x._transaction !== l) continue;
    if (!(n._config & CONFIG_GUESS) && !n._type && n._pendingValue !== NOT_PENDING) {
      x._lane = n._pendingValue;
      n._pendingValue = NOT_PENDING;
    }
    if (x._pendingFirstChild !== null || x._pendingDisposal !== null)
      GlobalQueue._dispose(n, false, true);
    n._config &= ~CONFIG_STAGED;
  }
  releaseQueues(l);
}
function endLanes(u) {
  for (let k = lanes.length - 1; k >= 0; k--) {
    const l = lanes[k];
    if (resolveTx(l._parent) !== u) continue;
    endLanes(l);
    dissolveLane(l, null);
  }
}
function lanesBlocked(t) {
  return t._lane && linkBlocked(t) || nestedBlocked(t);
}
function nestedBlocked(t) {
  for (let i = 0; i < lanes.length; i++) {
    const l = lanes[i];
    if (resolveTx(l._parent) !== t) continue;
    if (blocked(l) || guessFlights(l)) return true;
  }
  return false;
}
function laneWrite(el, v) {
  if (el._config & CONFIG_GUESS) {
    if (stale2(el, question)) {
      el._pendingValue = v;
      el._config |= CONFIG_HELD;
      GlobalQueue._laneRebase?.(el, v);
      schedule();
      return v;
    }
    supersede(el, v, !el._equals || !el._equals(el._x._lane, v));
  } else {
    const l = txOf(el);
    if (el._equals && el._equals(laneValueOf(el), v)) return v;
    if (l._shown) el._pendingValue = v;
    else el._x._lane = v;
    if (el._fn !== void 0) el._time = clock;
    insertSubs(el);
    laneDirty(el, l);
  }
  schedule();
  return v;
}
function laneOutcome(el, value, errored) {
  if (errored) return true;
  if (stale2(el, answered(el))) {
    el._pendingValue = value;
    el._config |= CONFIG_HELD;
    return true;
  }
  supersede(el, value, !el._equals || !el._equals(el._x._lane, value));
  return true;
}
function stale2(el, q) {
  return q !== 0 && q < el._x._q;
}
function answered(el) {
  let q = 0;
  for (let l = el._deps; l !== null; l = l._nextDep) {
    const d = l._dep;
    if (d._x !== null && d._x._q > q && d._time === clock) q = d._x._q;
  }
  return q;
}
GlobalQueue._laneRead = laneRead;
GlobalQueue._laneStage = laneStage;
GlobalQueue._laneOutcome = laneOutcome;
GlobalQueue._laneWrite = laneWrite;
var judged = 0;
GlobalQueue._applyGuesses = (parent) => {
  judged = lanes.length;
  if (pendingGuesses.length !== 0) applyGuesses(parent);
};
GlobalQueue._laneSeams = (leaks) => {
  const leaked = [];
  if (leaks !== null)
    for (let i = 0; i < leaks.length; i++) {
      const r = leaks[i];
      const l = r._x?._transaction;
      if (r._flags & REACTIVE_DISPOSED || l != null && l._parent?._verdict === l && (r._config & CONFIG_VERDICT ? !(r._flags & REACTIVE_PROBE_UNANSWERED) : !blocked(l._parent)))
        continue;
      enqueueSub(r);
      if (l != null && l._lane && leaked.indexOf(l) === -1) leaked.push(l);
    }
  for (let k = Math.min(judged, lanes.length) - 1; k >= 0; k--)
    laneSeam(lanes[k], leaked.indexOf(lanes[k]) !== -1);
};
GlobalQueue._laneCorrections = () => lanes.length !== 0 && laneCorrections();
GlobalQueue._endLanes = endLanes;
if (false)
  GlobalQueue._laneGuesses = (t) => {
    const out = [];
    for (let i = 0; i < lanes.length; i++) {
      const l = lanes[i];
      if (resolveTx(l._parent) !== t) continue;
      for (let j = 0; j < l._nodes.length; j++)
        if (l._nodes[j]._config & CONFIG_GUESS && l._nodes[j]._x._transaction === l)
          out.push(l._nodes[j]);
    }
    return out;
  };
GlobalQueue._lanesBlocked = lanesBlocked;
GlobalQueue._verdictLane = verdictLane;

// packages/signals/src/core/effect.ts
function effect(compute, effect2, error, options) {
  const isUser = !!options?.user;
  const node = createEffectNode(
    compute,
    effect2,
    error,
    isUser ? EFFECT_USER : EFFECT_RENDER,
    options
  );
  recompute(node, true);
  !options?.defer && node._pendingValue === NOT_PENDING && !(LEGACY_LANES && node._x?._transaction?._lane) && (node._type === EFFECT_USER || options?.schedule ? globalQueue.enqueue(node._type, runEffect.bind(null, node)) : runEffect(node, node._type));
  if (false) {
    const message = "[NO_OWNER_EFFECT] Effects created outside a reactive context will never be disposed";
    reportDiagnostic(
      emitDiagnostic(
        {
          code: "NO_OWNER_EFFECT",
          kind: "lifecycle",
          severity: "warn",
          message,
          ownerId: node.id,
          ownerName: node._name,
          data: { effectType: "effect" }
        },
        node
      )
    );
  }
}
function notifyEffectStatus(status, error) {
  const actualStatus = status !== void 0 ? status : this._statusFlags;
  const actualError = error !== void 0 ? error : this._x?._error;
  if (actualStatus & STATUS_ERROR) {
    globalQueue.notify(this, STATUS_PENDING, 0);
    if (this._type === EFFECT_USER) {
      if (this._statusFlags & STATUS_ERROR) {
        this._modified = true;
        globalQueue.enqueue(this._type, this._boundRunEffect ??= runEffect.bind(null, this));
      }
      return;
    }
    if (!globalQueue.notify(this, STATUS_ERROR, STATUS_ERROR)) {
      haltReactivity(unwrapStatusError(actualError));
      throw actualError;
    }
  } else if (this._type === EFFECT_RENDER) {
    globalQueue.notify(this, STATUS_PENDING | STATUS_ERROR, actualStatus, actualError);
    if (false) {
      const message = "[ASYNC_OUTSIDE_LOADING_BOUNDARY] An async value was read outside a Loading boundary. The root mount will be deferred until all pending async settles.";
      reportDiagnostic(
        emitDiagnostic(
          {
            code: "ASYNC_OUTSIDE_LOADING_BOUNDARY",
            kind: "async",
            severity: "warn",
            message,
            ownerId: this.id,
            ownerName: this._name
          },
          this
        )
      );
    }
  }
}
function runEffect(node, type) {
  if (!node._modified || node._flags & REACTIVE_DISPOSED) return;
  if (GlobalQueue._heldRun && GlobalQueue._heldRun(node)) return;
  if (node._statusFlags & STATUS_ERROR && node._type === EFFECT_USER) {
    const err = unwrapStatusError(node._x?._error);
    node._prevValue = node._value;
    node._modified = false;
    try {
      node._errorFn ? node._errorFn(err, () => {
        const prevCleanup2 = node._cleanup;
        node._cleanup = void 0;
        prevCleanup2?.();
      }) : console.error(err);
    } catch (error) {
      if (!globalQueue.notify(node, STATUS_ERROR, STATUS_ERROR)) {
        haltReactivity(error);
        throw error;
      }
    }
    return;
  }
  const cleanPass = node._x?._error == null;
  if (node._config & CONFIG_HELD && !(LEGACY_LANES && node._x._transaction._lane)) {
    txOf(node)._queues[type - 1].push(node._boundRunEffect ??= runEffect.bind(null, node));
    return;
  }
  let prevStrictRead = false;
  if (false) {
    prevStrictRead = setStrictRead("an effect callback");
    setEffectCallback2(true);
    enterCallback();
  }
  if (false) attrHooks.effectRunStart(node);
  const prevCleanup = node._cleanup;
  node._cleanup = void 0;
  try {
    prevCleanup?.();
    const nextCleanup = node._effectFn(node._value, node._prevValue);
    if (false) {
      throw new Error(
        `${node._name || "effect"} callback returned an invalid cleanup value. Return a cleanup function or undefined.`
      );
    }
    node._cleanup = nextCleanup;
  } catch (error) {
    ext(node)._error = new StatusError(node, error);
    node._statusFlags |= STATUS_ERROR;
    if (!globalQueue.notify(node, STATUS_ERROR, STATUS_ERROR)) {
      haltReactivity(error);
      throw error;
    }
  } finally {
    if (false) {
      setStrictRead(prevStrictRead);
      setEffectCallback2(false);
      exitCallback();
    }
    node._prevValue = node._value;
    node._modified = false;
    if (cleanPass) trimStaleDeps(node);
  }
  if (false) attrHooks.effectRunEnd(node);
}
GlobalQueue._runEffect = runEffect;
setEffectStatusNotify(notifyEffectStatus);

// packages/signals/src/core/error-hooks.ts
var ambientHook;
var reported = /* @__PURE__ */ new WeakSet();
function hookFor(owner) {
  for (let o = owner; o; o = o._parent) {
    const hook = o[ROOT_ERROR_HOOK];
    if (hook !== void 0) return hook;
  }
  return ambientHook;
}
function labels(owner) {
  const path = [];
  for (let o = owner; o; o = o._parent) {
    const name = o._name;
    if (typeof name === "string" && name.length) path.push(name);
  }
  return path.length ? path.reverse() : void 0;
}
function reportClientError(error, owner, thrower) {
  const isObject = error !== null && (typeof error === "object" || typeof error === "function");
  if (isObject) {
    if (reported.has(error)) return;
    reported.add(error);
  }
  const hook = hookFor(owner);
  if (hook === void 0) return;
  const context2 = {};
  const boundary = labels(owner);
  const path = labels(thrower) ?? boundary;
  if (path !== void 0) context2.ownerPath = path;
  if (boundary !== void 0) context2.boundaryPath = boundary;
  try {
    hook(error, context2);
  } catch (hookError) {
    console.error(hookError);
  }
}

// packages/signals/src/signals.ts
function onCleanup(fn) {
  if (false) {
    const owner = getOwner();
    if (!owner) {
      const message = "[NO_OWNER_CLEANUP] onCleanup called outside a reactive context will never be run";
      reportDiagnostic(
        emitDiagnostic({
          code: "NO_OWNER_CLEANUP",
          kind: "lifecycle",
          severity: "warn",
          message
        })
      );
    } else if (owner._config & CONFIG_CHILDREN_FORBIDDEN) {
      const message = "[CLEANUP_IN_FORBIDDEN_SCOPE] Cannot use onCleanup inside createTrackedEffect or onSettled; return a cleanup function instead";
      emitDiagnostic({
        code: "CLEANUP_IN_FORBIDDEN_SCOPE",
        kind: "lifecycle",
        severity: "error",
        message,
        ownerId: owner.id,
        ownerName: owner._name
      });
      throw new Error(message);
    }
  }
  return cleanup(fn);
}
function accessor(node) {
  const fn = read.bind(null, node);
  fn[$REFRESH] = node;
  return fn;
}
function createSignal(first, second) {
  if (typeof first === "function") {
    const node2 = computed(first, second);
    node2._config &= ~CONFIG_AUTO_DISPOSE;
    return [
      accessor(node2),
      setMemo.bind(null, node2)
    ];
  }
  const node = signal(first, second);
  if (false) registerGraph(node, getOwner());
  return [accessor(node), setSignal.bind(null, node)];
}
function createMemo(compute, options) {
  return accessor(computed(compute, options));
}
function createEffect(compute, effectFn, options) {
  if (false) {
    const message = "[MISSING_EFFECT_FN] createEffect requires both a compute function and an effect function. Use `createEffect(() => signal(), value => doWork(value))`. If you want a derived value, use `createMemo`. If you want a one-shot side effect, just call the function directly.";
    emitDiagnostic({
      code: "MISSING_EFFECT_FN",
      kind: "lifecycle",
      severity: "error",
      message
    });
    throw new Error(message);
  }
  effect(compute, effectFn.effect || effectFn, effectFn.error, {
    user: true,
    ...options
  });
}
function createRenderEffect(compute, effectFn, options) {
  effect(compute, effectFn, void 0, options);
}
function watch(fn, onValue, onError, config = 0, inPass, own = flushTransaction) {
  if (config & CONFIG_AUTHORITATIVE) {
    GlobalQueue._truth = truthRead;
    GlobalQueue._confirmed = truthConfirmed;
  }
  computed(
    () => {
      let v;
      try {
        v = fn();
      } catch (e) {
        if (e instanceof NotReadyError) throw e;
        queueMicrotask(() => onError(unwrapStatusError(e)));
        return;
      }
      const c = getOwner();
      const joined = flushTransaction ?? passTx;
      if (c._flags & REACTIVE_JOINED && joined !== null && (own === null || resolveTx(own) !== resolveTx(joined))) {
        staleReader(c, resolveTx(joined));
        return;
      }
      inPass?.(v);
      queueMicrotask(() => onValue(v));
    },
    { _extraConfig: config }
  )._config |= CONFIG_REDERIVE;
}
function refresh(target) {
  const node = target?.[$REFRESH];
  if (!node) {
    if (false) {
      const message = "[INVALID_REFRESH_TARGET] refresh() expects a Solid source accessor or refreshable store. Pass the original source target, not a wrapper function or derived property read.";
      emitDiagnostic({
        code: "INVALID_REFRESH_TARGET",
        kind: "write",
        severity: "error",
        message
      });
      throw new Error(message);
    }
    return Promise.resolve(void 0);
  }
  markRefresh(node);
  const own = flushTransaction;
  const promise = new Promise((res, rej) => {
    queueMicrotask(() => {
      let waiter = null;
      const make = () => watch(
        () => {
          if (waiter === null) waiter = getOwner();
          const v = read(node);
          if (node._config & CONFIG_GUESS && node._statusFlags & (STATUS_PENDING | STATUS_ERROR))
            throw node._x?._error;
          return v;
        },
        (value) => {
          res(typeof target === "function" ? value : target);
          dispose(waiter);
        },
        (err) => {
          rej(err);
          dispose(waiter);
        },
        CONFIG_FRESH_READ | CONFIG_AUTHORITATIVE,
        void 0,
        own
      );
      createRoot(make);
    });
  });
  promise.catch(() => {
  });
  return promise;
}

// packages/signals/src/flatten.ts
function flatten(children, options) {
  if (typeof children === "function" && !children.length) {
    if (options?.doNotUnwrap) return children;
    do {
      children = children();
    } while (typeof children === "function" && !children.length);
  }
  if (options?.skipNonRendered && (children == null || children === true || children === false || children === ""))
    return;
  if (Array.isArray(children)) {
    let results = [];
    if (flattenArray(children, results, options)) {
      return () => {
        let nested = [];
        flattenArray(results, nested, { ...options, doNotUnwrap: false });
        return nested;
      };
    }
    return results;
  }
  return children;
}
function flattenArray(children, results = [], options) {
  let notReady = null;
  let needsUnwrap = false;
  for (let i = 0; i < children.length; i++) {
    try {
      let child = children[i];
      if (typeof child === "function" && !child.length) {
        if (options?.doNotUnwrap) {
          results.push(child);
          needsUnwrap = true;
          continue;
        }
        do {
          child = child();
        } while (typeof child === "function" && !child.length);
      }
      if (Array.isArray(child)) {
        needsUnwrap = flattenArray(child, results, options) || needsUnwrap;
      } else if (options?.skipNonRendered && (child == null || child === true || child === false || child === "")) {
      } else results.push(child);
    } catch (e) {
      if (!(e instanceof NotReadyError)) throw e;
      notReady = e;
    }
  }
  if (notReady) throw notReady;
  return needsUnwrap;
}

// packages/signals/src/boundaries.ts
var BOUNDARY = /* @__PURE__ */ Symbol(false ? "boundary" : "");
var REVEAL = /* @__PURE__ */ Symbol(false ? "reveal" : "");
var revealHooks = null;
var collecting = /* @__PURE__ */ new Set();
var boundaryOf = (node) => node._context[BOUNDARY];
var isCollecting = (b) => b._type === STATUS_ERROR || !b._initialized || b._armed;
function caught(b, node, error) {
  if (b._type === STATUS_ERROR) {
    error ??= node._x?._error;
    node = error?.source ?? node;
    const caught2 = unwrapStatusError(error);
    setSignal(b._error, caught2);
    reportClientError(caught2, b._owner, node);
  }
  b._readers.add(node);
  collecting.add(b);
  if (b._armed) flip(b);
  if (!b._fallback) redraw(b);
  if (b._reveal !== null) revealHooks._changed(b._reveal);
}
function flip(b) {
  b._initialized = false;
  b._lane = b._armLane;
  if (b._lane !== null && b._output !== null)
    GlobalQueue._laneStage(b._output, b._lane, true, false);
}
function redraw(b) {
  if (b._output !== null && !(b._output._flags & (REACTIVE_DISPOSED | REACTIVE_ZOMBIE))) {
    enqueueSub(b._output);
    schedule();
  }
}
function catchStatus(node, flags, error, fresh = false) {
  if (flags === 0) {
    if (collecting.size !== 0) {
      for (let b = boundaryOf(node); b !== void 0; b = b._parent ?? void 0)
        if (!(node._statusFlags & unsettled(b)) && b._readers.delete(node) && b._readers.size === 0) {
          if (b._fallback) redraw(b);
          if (b._reveal !== null) revealHooks._changed(b._reveal);
        }
    }
    return false;
  }
  for (let b = boundaryOf(node); b !== void 0; b = b._parent ?? void 0) {
    if (!(b._type & flags)) continue;
    if (isCollecting(b)) {
      const creator = b._owner._parentComputed;
      if (fresh && !b._initialized && creator && (creator._config & CONFIG_HELD || creator._flags & REACTIVE_RECOMPUTING_DEPS && creator._flags & REACTIVE_JOINED))
        continue;
      caught(b, node, error);
      return true;
    }
    b._readers.add(node);
    collecting.add(b);
  }
  return false;
}
function hiddenBy(r) {
  for (let b = boundaryOf(r); b !== void 0; b = b._parent ?? void 0)
    if (b._fallback) return b;
  return void 0;
}
function hidden(r) {
  return hiddenBy(r) !== void 0;
}
function heldRun(node) {
  const b = hiddenBy(node);
  if (b === void 0) return false;
  (b._runs ??= /* @__PURE__ */ new Set()).add(node);
  return true;
}
function release(b) {
  if (b._runs === null) return;
  for (const n of b._runs) {
    const type = n._type;
    globalQueue.enqueue(
      type === EFFECT_TRACKED ? EFFECT_USER : type,
      type === EFFECT_TRACKED ? n._run : n._boundRunEffect ??= GlobalQueue._runEffect.bind(null, n)
    );
  }
  b._runs = null;
}
var unsettled = (b) => b._type === STATUS_ERROR ? STATUS_ERROR | STATUS_PENDING : STATUS_PENDING;
function prune(b, pass) {
  const mask = unsettled(b);
  for (const r of b._readers) {
    if (r._flags & REACTIVE_DISPOSED) b._readers.delete(r);
    else if (!(r._statusFlags & mask)) {
      if (r !== b._tree && (r._config & (CONFIG_HELD | CONFIG_OVERRIDE)) === CONFIG_HELD) {
        if (!pass || !b._initialized) continue;
        joinFuture(txOf(r));
      }
      b._readers.delete(r);
    }
  }
  return b._readers.size;
}
function boundarySeam() {
  for (const b of collecting) {
    const flags = b._output._flags;
    if (flags & REACTIVE_DISPOSED) {
      collecting.delete(b);
      continue;
    }
    if (flags & REACTIVE_ZOMBIE) continue;
    prune(b, false);
    if (false) reportOutsideHold(b);
    b._armed = false;
    if (b._readers.size === 0) {
      collecting.delete(b);
      if (b._fallback) redraw(b);
      if (b._reveal !== null) revealHooks._changed(b._reveal);
    }
  }
}
function verdictDerived(c) {
  if (c._config & CONFIG_VERDICT) return true;
  for (let d = c._deps; d !== null; d = d._nextDep)
    if (d._dep._config & CONFIG_VERDICT) return true;
  return false;
}
function arm(b) {
  if (!b._initialized) {
    if (b._fallback && b._lane === null && b._armLane === null && passLane !== null) {
      b._armLane = passLane;
      if (false) b._ahead = true;
      flip(b);
      redraw(b);
    }
    return;
  }
  b._armed = true;
  let lane = passLane;
  if (lane === null && globalQueue._running && verdictDerived(getOwner())) {
    joinFuture(null);
    lane = GlobalQueue._verdictLane(flushTransaction);
  }
  b._armLane = lane;
  if (false) b._ahead = lane !== null;
  collecting.add(b);
  for (const r of b._readers) {
    if (r._statusFlags & STATUS_PENDING && !(r._flags & REACTIVE_DISPOSED)) {
      flip(b);
      redraw(b);
      return;
    }
  }
}
function reset(b) {
  for (const r of [...b._readers])
    if (r._fn !== void 0 && !(r._flags & REACTIVE_DISPOSED)) recompute(r);
  schedule();
}
function createBoundary(type, fn, show, onFn) {
  if (false) {
    const message = "[NO_OWNER_BOUNDARY] Boundaries created outside a reactive context will never be disposed.";
    reportDiagnostic(
      emitDiagnostic({
        code: "NO_OWNER_BOUNDARY",
        kind: "lifecycle",
        severity: "warn",
        message,
        data: { boundaryType: type === STATUS_PENDING ? "loading" : "error" }
      })
    );
  }
  const owner = createOwner();
  const b = {
    _type: type,
    _parent: boundaryOf(owner) ?? null,
    _owner: owner,
    _tree: null,
    _output: null,
    _readers: /* @__PURE__ */ new Set(),
    _initialized: false,
    _armed: false,
    _armLane: null,
    _lane: null,
    _fallback: false,
    _runs: null,
    _reveal: null,
    _gated: false,
    _collapsed: false,
    _error: type === STATUS_ERROR ? signal(void 0, ERROR_SIGNAL) : null,
    _show: show
  };
  const controller = type === STATUS_PENDING ? owner._context[REVEAL] : null;
  if (getOwner())
    cleanup(() => {
      collecting.delete(b);
      if (controller) revealHooks._unregister(controller, b);
    });
  let arming;
  if (onFn) {
    let mounted = false;
    arming = runWithOwner(
      owner,
      () => computed(() => {
        try {
          onFn();
        } catch (e) {
          if (!(e instanceof NotReadyError)) {
            if (!globalQueue.notify(getOwner(), STATUS_ERROR, STATUS_ERROR, e)) {
              haltReactivity(e);
              throw e;
            }
            return;
          }
        }
        if (mounted) arm(b);
        else mounted = true;
      })
    );
    arming._config |= CONFIG_REDERIVE;
  }
  const context2 = { ...owner._context, [BOUNDARY]: b };
  if (revealHooks !== null) context2[REVEAL] = null;
  owner._context = context2;
  const tree = runWithOwner(owner, () => {
    const c = false ? computed(fn, { name: "children" }) : computed(fn);
    return false ? computed(() => flatten(read(c)), { name: "boundary" }) : computed(() => flatten(read(c)));
  });
  b._tree = tree;
  if (controller) revealHooks._register(controller, b);
  const output = computed(
    () => {
      if (arming) link(arming, getOwner());
      if (b._gated) {
        link(tree, getOwner());
        if (b._reveal !== null) revealHooks._changed(b._reveal);
        if (b._gated) {
          if (b._collapsed) {
            b._fallback = true;
            return void 0;
          }
          return fallback(b);
        }
      }
      const status = tree._statusFlags & (STATUS_PENDING | STATUS_ERROR);
      if (status !== 0) {
        link(tree, getOwner());
        if (status & type) {
          if (isCollecting(b)) {
            caught(b, tree, void 0);
            return fallback(b);
          }
          b._readers.add(tree);
          collecting.add(b);
        }
        throw tree._x._error;
      }
      if (isCollecting(b)) {
        const self = getOwner();
        if (b._readers.size !== 0 && self._statusFlags & STATUS_UNINITIALIZED && !(self._config & CONFIG_HELD))
          return fallback(b);
        if (prune(b, true) !== 0) return fallback(b);
      }
      let value;
      try {
        value = read(tree);
      } catch (e) {
        if (e instanceof NotReadyError ? type === STATUS_PENDING : type === STATUS_ERROR) {
          if (isCollecting(b)) {
            caught(b, tree, e);
            return fallback(b);
          }
          b._readers.add(tree);
          collecting.add(b);
        }
        throw e;
      }
      if (isCollecting(b) && b._readers.size !== 0) return fallback(b);
      b._initialized = true;
      if (false)
        attrHooks.boundaryFallback(b, b._tree, false);
      b._fallback = false;
      release(b);
      if (b._reveal !== null) {
        const controller2 = b._reveal;
        b._reveal = null;
        revealHooks._changed(controller2);
      }
      return value;
    },
    // Boundary structure, not a user source: its value is fallback-or-content
    // and legitimately swaps mid-hydration (resume), so it must never be
    // frozen by snapshot capture.
    false ? { name: "value", _noSnapshot: true } : { _noSnapshot: true }
  );
  output._config |= CONFIG_REDERIVE;
  b._output = output;
  return accessor(output);
}
function fallback(b) {
  if (b._lane !== null) {
    setPassLane(b._lane);
    b._output._flags |= REACTIVE_LANE_READ;
    b._lane = null;
  }
  if (false) {
    attrHooks.boundaryFallback(
      b,
      b._tree,
      true,
      passLane !== null ? null : flushTransaction !== null ? resolveTx2(flushTransaction) : passTx2
    );
    if (!globalQueue._running) schedule();
  }
  b._fallback = true;
  return b._show(b);
}
var ERROR_SIGNAL = { ownedWrite: true, _noSnapshot: true };
function createLoadingBoundary(fn, fallback3, options) {
  return createBoundary(STATUS_PENDING, fn, () => fallback3(), options?.on);
}
function createErrorBoundary(fn, fallback3) {
  return createBoundary(STATUS_ERROR, fn, (b) => fallback3(accessor(b._error), () => reset(b)));
}
GlobalQueue._catch = catchStatus;
GlobalQueue._fresh = (node) => node._statusFlags & STATUS_UNINITIALIZED && catchStatus(node, STATUS_PENDING, void 0, true);
GlobalQueue._hidden = hidden;
GlobalQueue._boundarySeam = boundarySeam;
GlobalQueue._heldRun = heldRun;

// packages/signals/src/experimental/layer.ts
function inputTime(input) {
  return typeof input._fn === "function" ? input._time : input._notifiedAt;
}
var boundaries = /* @__PURE__ */ new WeakMap();
function pendingInput(source) {
  const boundary = boundaries.get(source);
  return boundary?.statusInput ?? (boundary?.inputStatus ? boundary.input : void 0);
}
var proposals = /* @__PURE__ */ new Map();
var active = /* @__PURE__ */ new Set();
var scoped = /* @__PURE__ */ new Set();
var parents = /* @__PURE__ */ new WeakMap();
var candidateUpdates = /* @__PURE__ */ new Set();
var releasingInput = null;
var evaluation = null;
var evaluationReads = null;
var visit = 0;
var reachability = /* @__PURE__ */ new WeakMap();
var graphEpoch = 0;
var cacheReads = true;
var layerOwn2 = (node, update) => {
  const layer = boundaries.get(node);
  if (layer === void 0) return;
  graphEpoch++;
  if (layer && layer.update === null && layer.override !== NOT_PENDING && node._pendingValue !== NOT_PENDING && !Object.is(node._value, node._pendingValue))
    ownLayerUpdate(layer, update, inputUpdate(layer));
};
var layerHooks = {};
function wakeLayers() {
  setLayerCommit(prepareLayers, settleLayers);
  schedule();
}
function enableReads() {
  trackDependencies(true);
  setLayerReads(layerOwn2, mergeLayers, frameRead2);
}
function stopIfIdle() {
  if (candidateUpdates.size || active.size || scoped.size || proposals.size || layerHooks.active?.())
    return;
  setLayerCommit();
  setLayerReads();
  setLayerCompute();
  trackDependencies(false);
}
function parentSet(update) {
  return parents.get(resolveTx(update));
}
function watchParent(update) {
  enableReads();
  candidateUpdates.add(update);
  setLayerCompute(computeLayer, rerunLayer);
}
function isChildUpdate(update) {
  const resolved = resolveTx(update);
  const excluded = parents.get(resolved);
  if (excluded?.size === 0) return true;
  for (const parent of excluded || []) {
    if (resolveTx(parent) !== resolved) return true;
  }
  return false;
}
function inputUpdate(layer) {
  if (layer.input._config & CONFIG_HELD) return txOf(layer.input);
  if (layer.scope) return liveTx(layer.scope);
  const boundary = boundaries.get(layer.input);
  return boundary?.inputStatus ? inputUpdate(boundary) : null;
}
function resumeInput(layer, update) {
  graphEpoch++;
  layer.override = NOT_PENDING;
  if (layer.output._config & CONFIG_HELD) merge(txOf(layer.output), update);
  joinFuture(update);
  enqueueSub(layer.output);
}
function retire(layer) {
  const scope = liveTx(layer.scope);
  if (!scope) joinFuture(null);
  resumeInput(layer, scope ?? resolveTx(flushTransaction));
  layer.scope = null;
  scoped.delete(layer);
}
function prepareLayers() {
  if (!scoped.size && !candidateUpdates.size) return layerHooks.beforeCommit?.() ?? false;
  if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
  cacheReads = false;
  let changed = false;
  let waiting;
  for (const layer of scoped) {
    const scope = resolveTx(layer.scope);
    if (!scope._open && !(layer.output._flags & REACTIVE_DISPOSED) && layer.input._statusFlags & STATUS_PENDING)
      (waiting ??= /* @__PURE__ */ new Set()).add(scope);
  }
  for (const layer of scoped) {
    if (layer.output._flags & REACTIVE_DISPOSED) {
      scoped.delete(layer);
      layer.scope = null;
    } else if (resolveTx(layer.scope)._open === 0 && !waiting?.has(resolveTx(layer.scope))) {
      proposals.delete(layer);
      retire(layer);
      changed = true;
    }
  }
  changed = (layerHooks.beforeCommit?.() ?? false) || changed;
  for (const update of candidateUpdates) {
    const parent = liveTx(update);
    if (!parent || blocked(parent)) continue;
    let auditReaders = 0;
    for (const reader of parent._reruns || []) {
      if (++auditReaders > 100) {
        console.error("AUDIT stale-reader loop", reader._fn.toString(), reader._config, reader._flags, txOf(reader) === parent, isChildUpdate(parent), [...parentSet(parent) || []].map((p) => p === parent));
        throw new Error("AUDIT stale-reader loop");
      }
      if (!reader._type && reader._flags & REACTIVE_FRAME_READ && !(reader._flags & REACTIVE_DISPOSED)) {
        parent._reruns.delete(reader);
        reader._flags &= ~REACTIVE_FRAME_READ;
        const previous = releasingInput;
        releasingInput = parent;
        try {
          recomputeInUpdate(reader, parent);
        } finally {
          releasingInput = previous;
        }
        changed = true;
        if (resolveTx(parent) !== parent) break;
      }
    }
  }
  return changed;
}
function mergeLayers(from, into) {
  graphEpoch++;
  if (candidateUpdates.delete(from)) candidateUpdates.add(into);
  const source = parents.get(from);
  if (!source) return;
  const target = parents.get(into);
  if (target) for (const parent of source) target.add(parent);
  else parents.set(into, source);
  parents.delete(from);
}
function reachesBoundary(node, holder, cache, epoch, visit2) {
  const computed2 = node;
  const cached = cache.get(node);
  if (cached && epoch >= 0 && cached.epoch === epoch && cached.dependencies === dependencyEpoch && cached.tail === computed2._depsTail)
    return true;
  if (cached?.visit === visit2) return false;
  const entry = cached || { epoch: -1, dependencies: -1, tail: null, visit: visit2 };
  if (cached) entry.visit = visit2;
  else cache.set(node, entry);
  const boundary = boundaries.get(node);
  let found = false;
  if (boundary && boundary.override !== NOT_PENDING) {
    const input = inputUpdate(boundary);
    found = (input === null || !(boundary.output._config & CONFIG_HELD) || txOf(boundary.output) !== input) && (input === holder || !isChildUpdate(holder));
  } else {
    for (let edge = computed2._deps; edge; edge = edge._nextDep) {
      if (edge._gen !== computed2._depGen) continue;
      if (reachesBoundary(edge._dep, holder, cache, epoch, visit2)) {
        found = true;
        break;
      }
    }
  }
  if (found && epoch >= 0) {
    entry.epoch = epoch;
    entry.dependencies = dependencyEpoch;
    entry.tail = computed2._depsTail;
  }
  return found;
}
function includesBoundary(reader, holder) {
  let cache = reachability.get(holder);
  if (!cache) reachability.set(holder, cache = /* @__PURE__ */ new WeakMap());
  return reachesBoundary(
    reader,
    holder,
    cache,
    cacheReads && globalQueue._running ? graphEpoch : -1,
    ++visit
  );
}
function frameRead2(reader, source) {
  const update = flushTransaction;
  if (source._statusFlags & STATUS_UNINITIALIZED) return false;
  const excluded = update && parentSet(update);
  const holder = txOf(source);
  if (update && holder === resolveTx(update)) return false;
  if (excluded)
    for (const parent of excluded) {
      if (resolveTx(parent) === holder) {
        staleReader(reader, holder);
        return true;
      }
    }
  if (reader._type === EFFECT_RENDER) return false;
  if (includesBoundary(reader, holder)) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  if (evaluation === reader && (candidateUpdates.has(holder) || !isChildUpdate(holder))) {
    (evaluationReads ??= /* @__PURE__ */ new Map()).set(source, holder);
    joinFuture(null);
    const provisional = resolveTx(flushTransaction);
    const allowed = parentSet(provisional) || /* @__PURE__ */ new Set();
    allowed.add(holder);
    parents.set(provisional, allowed);
    reader._flags |= REACTIVE_JOINED;
    return true;
  }
  return false;
}
function rerunLayer(node) {
  if (node._type) return false;
  const own = txOf(node);
  if (!isChildUpdate(own)) return false;
  if (!flushTransaction) joinFuture(null);
  const incoming = resolveTx(flushTransaction);
  if (incoming === own || incoming === releasingInput) return false;
  if (isChildUpdate(incoming)) {
    let ancestor = false;
    for (const parent of parentSet(own) || []) {
      if (resolveTx(parent) === incoming) {
        ancestor = true;
        break;
      }
    }
    if (!ancestor) return false;
  }
  holdQueuedProposals(incoming);
  recomputeInUpdate(node, own);
  return true;
}
function computeLayer(node, previous, previousTail) {
  const outer = evaluation;
  let outerReads = evaluationReads;
  evaluation = node;
  evaluationReads = null;
  try {
    for (; ; ) {
      let result, error, failed = false;
      try {
        result = node._fn(previous);
      } catch (e) {
        error = e;
        failed = true;
      }
      if (node._depsTail !== previousTail) changedDependencies?.();
      let retry = false;
      const reads = evaluationReads;
      if (reads) {
        for (const holder of reads.values()) {
          const parent = resolveTx(holder);
          if (includesBoundary(node, parent)) {
            watchParent(parent);
            staleReader(node, parent);
          } else if (outer && node._parent === outer) {
            for (const [source, sourceHolder] of reads) {
              (outerReads ??= /* @__PURE__ */ new Map()).set(source, sourceHolder);
            }
            break;
          } else {
            joinFuture(parent);
            retry = true;
          }
        }
      }
      if (!retry) {
        if (failed) throw error;
        return result;
      }
      if (result && typeof result.then === "function") Promise.resolve(result).catch(() => {
      });
      disposeChildren(node);
      node._depsTail = null;
      node._depGen++;
      evaluationReads = null;
    }
  } finally {
    evaluation = outer;
    evaluationReads = outerReads;
  }
}
function takeOutput(layer, update) {
  const seen = /* @__PURE__ */ new Set();
  const visit2 = (node) => {
    if (seen.has(node)) return;
    seen.add(node);
    const boundary = boundaries.get(node);
    if (node !== layer.output && boundary && boundary.override !== NOT_PENDING) return;
    enqueueSub(node);
    const effect2 = node;
    if (effect2._modified && effect2._boundRunEffect) {
      update._queues[effect2._type - 1].push(effect2._boundRunEffect);
    }
    holdNode(node, update);
    for (let edge = node._subs; edge; edge = edge._nextSub) visit2(edge._sub);
  };
  visit2(layer.output);
}
function ownLayerUpdate(layer, update, input) {
  layer.update = update;
  active.add(layer);
  setLayerCompute(computeLayer, rerunLayer);
  const excluded = parentSet(update) || /* @__PURE__ */ new Set();
  if (input !== null && input !== update) {
    watchParent(input);
    excluded.add(input);
    for (const ancestor of parentSet(input) || []) excluded.add(ancestor);
  }
  parents.set(update, excluded);
  return excluded;
}
function stageLayer(layer, proposal) {
  graphEpoch++;
  const inputHolder = inputUpdate(layer);
  layer.override = proposal;
  if (layer.inputStatus && layer.scope === null && proposal !== NOT_PENDING) {
    clearDeps(layer.output);
  }
  layer.inputTime = inputTime(layer.input);
  if (!(layer.input._config & CONFIG_HELD) && !(layer.output._config & CONFIG_HELD) && (inputHolder === null || !hasHeldNodes())) {
    enableReads();
    enqueueSub(layer.output);
    return;
  }
  enableReads();
  const previous = layer.update && liveTx(layer.update);
  const update = previous && previous !== inputHolder && isChildUpdate(previous) ? previous : newTransaction(false);
  const excluded = ownLayerUpdate(layer, update, inputHolder);
  if (proposal === NOT_PENDING && inputHolder !== null) {
    for (const parent of excluded) if (resolveTx(parent) === inputHolder) excluded.delete(parent);
  }
  takeOutput(layer, update);
  joinFuture(update);
  enqueueSub(layer.output);
}
function settleLayers() {
  cacheReads = true;
  if (!candidateUpdates.size && !active.size && !proposals.size && !scoped.size) {
    layerHooks.afterCommit?.();
    stopIfIdle();
    return;
  }
  for (const update of candidateUpdates) if (!liveTx(update)) candidateUpdates.delete(update);
  if (!candidateUpdates.size) {
    if (!active.size) setLayerCompute();
    if (scoped.size && hasHeldNodes()) {
      for (const layer of scoped) if (layer.scope) watchParent(resolveTx(layer.scope));
    }
  }
  for (const layer of active) {
    if (!liveTx(layer.update)) {
      layer.update = null;
      active.delete(layer);
    }
  }
  if (proposals.size) {
    for (const [layer, proposal] of proposals) {
      if (layer.output._flags & REACTIVE_DISPOSED) continue;
      stageLayer(layer, proposal);
    }
    proposals.clear();
    return;
  }
  layerHooks.afterCommit?.();
  stopIfIdle();
}
function createLayer(input, options) {
  const source = input[$REFRESH];
  const producer = source || computed(input, { equals: false });
  const layer = createLayerBoundary(producer, void 0, void 0, !source);
  layer.inputStatus = true;
  return layerAccessors(layer, options);
}
function selectLayer(layer, fallback3, onEvaluate) {
  const producer = layer.input;
  onEvaluate?.(layer);
  if (layer.scope !== null && layer.override !== NOT_PENDING && !(producer._statusFlags & STATUS_PENDING) && inputTime(producer) !== layer.inputTime) {
    const scope = liveTx(layer.scope);
    if (scope) {
      if (producer._config & CONFIG_HELD) merge(txOf(producer), scope);
      joinFuture(scope);
    }
  }
  if (layer.override === NOT_PENDING) return fallback3 ? fallback3(layer) : read(producer);
  if (layer.scope !== null || !layer.inputStatus) link(producer, layer.output);
  return layer.override;
}
function createLayerBoundary(producer, fallback3, onEvaluate, ownInput = true, lazy = false) {
  if (ownInput) producer._config &= ~CONFIG_AUTO_DISPOSE;
  const layer = {
    input: producer,
    override: NOT_PENDING,
    update: null,
    scope: null,
    inputTime: inputTime(producer)
  };
  const output = computed(selectLayer.bind(null, layer, fallback3, onEvaluate), {
    lazy,
    _extraConfig: CONFIG_REDERIVE
  });
  if (!lazy) output._config &= ~CONFIG_AUTO_DISPOSE;
  layer.output = output;
  boundaries.set(output, layer);
  if (!boundaries.has(producer)) boundaries.set(producer, null);
  return layer;
}
function releaseLayer(layer) {
  scoped.delete(layer);
  active.delete(layer);
  proposals.delete(layer);
  layer.scope = layer.update = null;
  wakeLayers();
}
function layerAccessors(layer, options) {
  const output = layer.output;
  const propose = (value) => {
    const pending = proposals.get(layer);
    const previous = proposals.has(layer) && pending !== NOT_PENDING ? pending : layer.override !== NOT_PENDING ? layer.override : output._pendingValue !== NOT_PENDING ? output._pendingValue : output._value;
    const next = typeof value === "function" ? value(previous) : value;
    if (options?.lifetime === "action") {
      const scope = flushTransaction ?? (layer.scope && liveTx(layer.scope));
      if (!scope || !resolveTx(scope)._acted) {
        throw new Error("The action-lifetime experiment requires a guess inside an action.");
      }
      if (layer.scope) merge(scope, layer.scope);
      layer.scope = resolveTx(scope);
      scoped.add(layer);
    }
    output._cleanup ??= releaseLayer.bind(null, layer);
    proposals.set(layer, next);
    wakeLayers();
    return next;
  };
  const clear = () => {
    proposals.set(layer, NOT_PENDING);
    wakeLayers();
  };
  const accessor2 = () => read(output);
  accessor2[$REFRESH] = output;
  return [accessor2, propose, clear];
}

// packages/signals/src/experimental/window.ts
var current = null;
function dispatch(source, reader) {
  const window = current;
  current = window.parent;
  setVerdict(reader === window.owner ? window.previous : null);
  try {
    return reader === window.owner ? window.read(source, window) : read(source);
  } finally {
    current = window;
    setVerdict(dispatch);
  }
}
function withReadWindow(fn, observe, collect = false) {
  const window = {
    owner: context?._root ? context._parentComputed : context,
    parent: current,
    previous: verdict,
    read: observe,
    found: false
  };
  current = window;
  setVerdict(dispatch);
  try {
    const value = fn();
    return collect ? window.found : value;
  } catch (error) {
    if (!collect || error instanceof NotReadyError && context !== null) throw error;
    return window.found;
  } finally {
    current = window.parent;
    setVerdict(window.previous);
  }
}

// packages/signals/src/experimental/observation.ts
var dirty = /* @__PURE__ */ new Set();
var watching = /* @__PURE__ */ new Set();
layerHooks.active = () => !!(dirty.size || watching.size);
layerHooks.beforeCommit = () => {
  let changed = false;
  for (const record of watching) {
    if (record.output._flags & REACTIVE_DISPOSED) {
      watching.delete(record);
      dirty.delete(record);
      continue;
    }
    const parent = record.parent && liveTx(record.parent);
    if (!parent || record.retiring || blocked(parent)) continue;
    record.retiring = true;
    record.time = inputTime(record.input);
    resumeInput(record, parent);
    changed = true;
  }
  return changed;
};
layerHooks.afterCommit = () => {
  for (const record of watching) dirty.add(record);
  for (const record of dirty) {
    if (record.output._flags & REACTIVE_DISPOSED || record.input._statusFlags & STATUS_UNINITIALIZED) {
      watching.delete(record);
      continue;
    }
    if (record.retiring) {
      const live = record.parent && liveTx(record.parent);
      if (live && record.time === inputTime(record.input)) continue;
      record.retiring = false;
    }
    record.parent = record.input._config & CONFIG_HELD ? txOf(record.input) : null;
    const next = record.observation.sample(record);
    if (record.observation.active(record, next)) watching.add(record);
    else watching.delete(record);
    if (!Object.is(record.override, next)) stageLayer(record, next);
  }
  dirty.clear();
};
function initializeObservation(layer, kind3) {
  const record = layer;
  record.parent = null;
  record.retiring = false;
  record.time = inputTime(record.input);
  record.observation = kind3;
  return record;
}
function releaseObservation(record) {
  dirty.delete(record);
  watching.delete(record);
  record.parent = null;
  record.retiring = false;
  record.override = NOT_PENDING;
  if (record.output._config & CONFIG_AUTO_DISPOSE)
    record.output._statusFlags |= STATUS_UNINITIALIZED;
}
function markObservation(layer) {
  const record = layer;
  record.observation.observe?.(record);
  dirty.add(record);
  record.output._cleanup ??= releaseObservation.bind(null, record);
  wakeLayers();
}

// packages/signals/src/experimental/pending.ts
function proposedPending(input, incoming) {
  return !(input._statusFlags & STATUS_UNINITIALIZED) && !!(input._statusFlags & STATUS_PENDING || incoming && (incoming._statusFlags & STATUS_PENDING || incoming._pendingValue !== NOT_PENDING && (!input._equals || !input._equals(input._value, incoming._pendingValue))) || input._config & CONFIG_HELD && input._pendingValue !== NOT_PENDING && (!input._equals || !input._equals(input._value, input._pendingValue)));
}
function observeInput(record) {
  const incoming = record.incoming;
  if (!incoming) return;
  const output = record.output;
  link(incoming, output);
  if (incoming._height >= output._height) output._height = incoming._height + 1;
}
var kind = {
  sample: (record) => proposedPending(record.input, record.incoming),
  active: (_record, value) => value,
  observe: (record) => observeInput(record)
};
function pendingFallback(layer) {
  const source = layer.input;
  if (typeof source._fn === "function") prepareComputed(source, false);
  if (source._statusFlags & STATUS_UNINITIALIZED) read(source);
  const output = context;
  link(source, output);
  if (source._height >= output._height) output._height = source._height + 1;
  if (output._statusFlags & STATUS_UNINITIALIZED)
    return proposedPending(source, pendingInput(source));
  return false;
}
var observations = /* @__PURE__ */ new WeakMap();
function observation(layer) {
  const record = initializeObservation(layer, kind);
  record.incoming = pendingInput(layer.input);
  return record;
}
function pendingOutput(source) {
  const existing = observations.get(source);
  if (existing) return existing.output;
  const record = runWithOwner(
    null,
    () => observation(createLayerBoundary(source, pendingFallback, markObservation, false, true))
  );
  observations.set(source, record);
  return record.output;
}
function probe(source, window) {
  window.found = read(pendingOutput(source)) || window.found;
  const previous = verdict;
  setVerdict(null);
  try {
    return read(source);
  } catch (error) {
    if (error instanceof NotReadyError && !(source._statusFlags & STATUS_UNINITIALIZED))
      return source._value;
    throw error;
  } finally {
    setVerdict(previous);
  }
}
function isPending(input) {
  const source = input[$REFRESH];
  return source ? read(pendingOutput(source)) : withReadWindow(input, probe, true);
}

// packages/signals/src/experimental/latest.ts
var kind2 = {
  sample: (record) => {
    const source = record.input;
    if (source._statusFlags & STATUS_ERROR) return NOT_PENDING;
    if (!(source._config & CONFIG_HELD) && !(source._statusFlags & STATUS_PENDING)) {
      const output = record.output;
      const value = output._pendingValue !== NOT_PENDING ? output._pendingValue : output._value;
      return Object.is(value, source._value) ? NOT_PENDING : source._value;
    }
    return source._pendingValue !== NOT_PENDING ? source._pendingValue : source._value;
  },
  active: (record) => !!(record.input._config & CONFIG_HELD || record.input._statusFlags & STATUS_PENDING)
};
function fallback2(layer) {
  const source = layer.input;
  if (typeof source._fn === "function") prepareComputed(source, false);
  if (layer.retiring || source._statusFlags & (STATUS_ERROR | STATUS_UNINITIALIZED) || !(source._config & CONFIG_HELD) && !(source._statusFlags & STATUS_PENDING))
    return read(source);
  const output = context;
  link(source, output);
  if (source._height >= output._height) output._height = source._height + 1;
  if (output._statusFlags & STATUS_UNINITIALIZED) {
    const flushed = unflushedValue(source);
    return flushed !== NOT_PENDING ? flushed : source._pendingValue !== NOT_PENDING ? source._pendingValue : source._value;
  }
  return source._value;
}
var observations2 = /* @__PURE__ */ new WeakMap();
function latestOutput(source) {
  const existing = observations2.get(source);
  if (existing) return existing.output;
  const record = runWithOwner(
    null,
    () => initializeObservation(createLayerBoundary(source, fallback2, markObservation, false, true), kind2)
  );
  record.statusInput = source;
  observations2.set(source, record);
  return record.output;
}
function windowRead(source) {
  return read(latestOutput(source));
}
function latest(input) {
  const source = input[$REFRESH];
  return source ? read(latestOutput(source)) : withReadWindow(input, windowRead);
}

// packages/signals/src/experimental/scalar.ts
function createOptimistic(input) {
  if (typeof input !== "function") {
    throw new TypeError("The scalar experiment requires an optimistic input accessor.");
  }
  const [read2, guess] = createLayer(input, { lifetime: "action" });
  return [read2, guess];
}
export {
  action,
  createEffect,
  createErrorBoundary,
  createLoadingBoundary,
  createMemo,
  createOptimistic,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  isPending,
  latest,
  onCleanup,
  refresh
};
