/** User guesses and their action lifetime, published by the common layer core. */
import { computed, read, signal } from "../core/core.js";
import { enqueueSub } from "../core/heap.js";
import {
  $REFRESH,
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  NOT_PENDING,
  REACTIVE_DISPOSED,
  STATUS_PENDING
} from "../core/constants.js";
import {
  blocked,
  flushTransaction,
  holdNode,
  joinFuture,
  liveTx,
  merge,
  newTransaction,
  resolveTx,
  setLayerBlocked,
  txOf,
  type Transaction
} from "../core/scheduler.js";
import type { Computed, NodeOptions } from "../core/types.js";
import { layerPosition } from "./committed-dependencies.js";
import {
  createLayerBoundary,
  inputTime,
  inputUpdate,
  observed,
  positionOf,
  resumeInput,
  readOverride,
  setGuessLifecycle,
  stageLayer,
  wakeLayers,
  type Layer
} from "./coordination.js";

const proposals = new Map<Layer<any>, unknown>();
const scoped = new Set<Layer<any>>();

/** A guessed input's own flight keeps its action alive, as in next. This
 * does not make that input hold a different update merely because the
 * override is displayed. Its eventual correction uses ordinary joining. */
function pendingScope(update: Transaction): boolean {
  for (const layer of scoped)
    if (
      resolveTx(layer._scope!) === update &&
      layer._input._statusFlags & STATUS_PENDING &&
      observed(layer._output, update)
    )
      return true;
  return false;
}

function retire(layer: Layer<any>): void {
  // An input hidden by an override can outlive the action transaction. Its
  // eventual answer resumes in live ordinary work, never a completed hold.
  const scope = liveTx(layer._scope!);
  if (!scope) joinFuture(null);
  resumeInput(layer, scope ?? resolveTx(flushTransaction!));
  layer._scope = null;
  scoped.delete(layer);
  if (!scoped.size) setLayerBlocked();
}

function prepareGuesses(): boolean {
  let changed = false;
  // Ambient writes acquire the update that actually parks this flush. A
  // setter cannot know that update before downstream calculations have run.
  for (const layer of proposals.keys()) {
    if (layer._output._flags & REACTIVE_DISPOSED) {
      proposals.delete(layer);
      continue;
    }
    if (!layer._automatic || layer._scope) continue;
    let scope = inputUpdate(layer) ?? (flushTransaction && resolveTx(flushTransaction));
    if (!scope && layer._input._statusFlags & STATUS_PENDING) {
      // Keep this new lifetime alive until the guess has propagated once;
      // its displayed consumers then determine the ordinary input hold.
      scope = newTransaction(false);
      scope._open++;
      layer._opening = true;
      holdNode(layer._input, scope);
    }
    if (!scope) proposals.delete(layer);
    else bindScope(layer, scope);
  }
  // All scopes use ordinary readiness. pendingScope includes the selected
  // guesses' input flights in that same test, including shared action holds.
  for (const layer of scoped) {
    if (layer._output._flags & REACTIVE_DISPOSED) {
      releaseLayer(layer);
      continue;
    }
    const scope = resolveTx(layer._scope!);
    if (!blocked(scope)) {
      proposals.delete(layer);
      retire(layer);
      changed = true;
    }
  }
  return changed;
}

function selectProposal(proposal: unknown, layer: Layer<any>): void {
  layer._override = proposal;
  layer._position = undefined;
}

function positionProposal(_proposal: unknown, layer: Layer<any>): void {
  layer._position = 1 + Math.max(layerPosition(layer._input), positionOf(inputUpdate(layer)));
}

function applyProposal(proposal: unknown, layer: Layer<any>): void {
  if (!(layer._output._flags & REACTIVE_DISPOSED)) stageLayer(layer, proposal, layer._position);
  if (layer._opening) {
    resolveTx(layer._scope!)._open--;
    layer._opening = undefined;
  }
}

setGuessLifecycle({
  _prepare: prepareGuesses,
  _settle: () => {
    if (!proposals.size) return false;
    // Freeze the whole batch's selections before assigning contexts. This
    // prevents simultaneous nested guesses from depending on setter order.
    proposals.forEach(selectProposal);
    proposals.forEach(positionProposal);
    proposals.forEach(applyProposal);
    proposals.clear();
    return true;
  },
  _active: () => !!(scoped.size || proposals.size)
});

export function createLayer<T>(
  input: T | ((previous: NoInfer<T> | undefined) => T | PromiseLike<T> | AsyncIterable<T>),
  options?: { lifetime: "action"; node?: NodeOptions<T> }
) {
  // The producer records each input evaluation. Equality belongs at the
  // output: an answer equal to an earlier input may still replace a guess.
  // Keep this computation even for a source accessor: refreshing the boundary
  // must re-read its input, not invalidate that input's own computation.
  const config = options?.node;
  const producer = (
    typeof input === "function"
      ? computed<T>(input as (previous?: T) => T, {
          ...config,
          equals: false,
          unobserved: undefined
        })
      : signal<T>(input, config)
  ) as Computed<T>;
  const layer = createLayerBoundary<T>(producer, selectGuess, true, config?.lazy, config);
  layer._output._config &= ~CONFIG_AUTO_DISPOSE;
  layer._inputStatus = true;
  return layerAccessors(layer, options);
}

function selectGuess<T>(layer: Layer<T>): T {
  const producer = layer._input;
  if (
    layer._scope !== null &&
    layer._override !== NOT_PENDING &&
    !(producer._statusFlags & STATUS_PENDING) &&
    inputTime(producer) !== layer._inputTime
  ) {
    // An input answer joins the guessing actions, but the selector stays
    // overridden until their shared lifetime ends. Intermediate answers
    // must not start downstream work beneath the selected guess.
    const scope = liveTx(layer._scope);
    if (scope) {
      if (producer._config & CONFIG_HELD) merge(txOf(producer), scope);
      // A ready input can still be an unparked proposal in this flush.
      // Couple that input frame, not an independently preparing override.
      if (!(layer._output._config & CONFIG_HELD) || txOf(layer._output) !== flushTransaction)
        joinFuture(scope);
    }
    // The pre-commit phase releases the group once all its inputs are ready.
  }
  return layer._override === NOT_PENDING ? read(producer) : readOverride(layer);
}

function releaseLayer(layer: Layer<any>): void {
  if (layer._opening && layer._scope) resolveTx(layer._scope)._open--;
  layer._opening = undefined;
  scoped.delete(layer);
  if (!scoped.size) setLayerBlocked();
  proposals.delete(layer);
  layer._scope = null;
  // Disposal can be the last event while an input is permanently pending.
  // Recheck the shared transaction list and disable idle hooks without requiring
  // an unrelated future write to visit the disposed boundary.
  wakeLayers();
}

function bindScope(layer: Layer<any>, scope: Transaction): void {
  if (layer._scope) merge(scope, layer._scope);
  layer._scope = resolveTx(scope);
  // Incoming input proposals share the override's lifetime; the selected
  // output retains its independent publication update until correction.
  if (layer._input._config & CONFIG_HELD && !(layer._input._statusFlags & STATUS_PENDING))
    merge(txOf(layer._input), layer._scope);
  scoped.add(layer);
  setLayerBlocked(pendingScope);
}

function layerAccessors<T>(layer: Layer<T>, options?: { lifetime: "action" }) {
  const output = layer._output;
  if (options?.lifetime === "action") layer._automatic = true;
  const propose = (value: T | ((previous: T) => T)) => {
    const pending = proposals.get(layer);
    const previous =
      proposals.has(layer) && pending !== NOT_PENDING
        ? pending
        : layer._override !== NOT_PENDING
          ? layer._override
          : output._pendingValue !== NOT_PENDING
            ? output._pendingValue
            : output._value;
    const next = typeof value === "function" ? (value as (v: T) => T)(previous as T) : value;
    if (output._flags & REACTIVE_DISPOSED) return next;
    if (layer._automatic) {
      const scope = flushTransaction ?? (layer._scope && liveTx(layer._scope));
      if (scope) bindScope(layer, scope);
    }
    output._cleanup ??= releaseLayer.bind(null, layer);
    proposals.set(layer, next);
    wakeLayers();
    return next;
  };
  const clear = () => {
    proposals.set(layer, NOT_PENDING);
    wakeLayers();
  };
  const accessor = () => read(output);
  (accessor as any)[$REFRESH] = output;
  return [accessor, propose, clear] as const;
}
