/** One lazily created latest output per source, published by ordinary machinery. */
import { context, prepareComputed, read, runWithOwner, unflushedValue } from "../core/core.js";
import {
  $REFRESH,
  CONFIG_HELD,
  NOT_PENDING,
  STATUS_ERROR,
  STATUS_PENDING,
  STATUS_UNINITIALIZED
} from "../core/constants.js";
import { link } from "../core/graph.js";
import type { Computed, Signal } from "../core/types.js";
import { createLayerBoundary, type Layer } from "./layer.js";
import { withReadWindow } from "./window.js";
import {
  initializeObservation,
  markObservation,
  type Observation,
  type ObservationKind
} from "./observation.js";

const kind: ObservationKind<any> = {
  sample: record => {
    const source = record.input;
    if (source._statusFlags & STATUS_ERROR) return NOT_PENDING;
    if (!(source._config & CONFIG_HELD) && !(source._statusFlags & STATUS_PENDING)) {
      const output = record.output;
      const value = output._pendingValue !== NOT_PENDING ? output._pendingValue : output._value;
      // A held input may have committed after this output read its old
      // value. Finish that publication before returning to ordinary reads.
      return Object.is(value, source._value) ? NOT_PENDING : source._value;
    }
    return source._pendingValue !== NOT_PENDING ? source._pendingValue : source._value;
  },
  active: record =>
    !!(record.input._config & CONFIG_HELD || record.input._statusFlags & STATUS_PENDING)
};

function fallback(layer: Layer<any>): unknown {
  const source = layer.input;
  if (typeof source._fn === "function") prepareComputed(source, false);
  if (
    (layer as Observation<any>).retiring ||
    source._statusFlags & (STATUS_ERROR | STATUS_UNINITIALIZED) ||
    (!(source._config & CONFIG_HELD) && !(source._statusFlags & STATUS_PENDING))
  )
    return read(source);
  const output = context as Computed<any>;
  link(source, output);
  if (source._height >= output._height) output._height = source._height + 1;
  // A new output has no published frame to preserve. Initialize it from the
  // latest flushed proposal; ordinary creation and Loading then own any
  // initial async consequence. Existing outputs retain their published value.
  if (output._statusFlags & STATUS_UNINITIALIZED) {
    const flushed = unflushedValue(source);
    return flushed !== NOT_PENDING
      ? flushed
      : source._pendingValue !== NOT_PENDING
        ? source._pendingValue
        : source._value;
  }
  return source._value;
}

const observations = new WeakMap<Signal<any>, Observation<any>>();
function latestOutput(source: Computed<any>): Computed<any> {
  const existing = observations.get(source);
  if (existing) return existing.output;
  const record = runWithOwner(null, () =>
    initializeObservation(createLayerBoundary(source, fallback, markObservation, false, true), kind)
  );
  record.statusInput = source;
  observations.set(source, record);
  return record.output;
}

function windowRead(source: Signal<any>): unknown {
  return read(latestOutput(source as Computed<any>));
}

export function latest<T>(input: () => T): T {
  const source = (input as any)[$REFRESH] as Computed<any> | undefined;
  return source ? read(latestOutput(source)) : withReadWindow(input, windowRead);
}
