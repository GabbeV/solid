/** Source-owned pending output using the common layer publication path.
 * Callback queries read those same outputs. No verdict lane or reader flag. */
import {
  computed,
  context,
  read,
  runWithOwner,
  prepareComputed,
  verdict,
  setVerdict
} from "../core/core.js";
import { link } from "../core/graph.js";
import { NotReadyError } from "../core/error.js";
import { cleanup } from "../core/owner.js";
import {
  $REFRESH,
  CONFIG_HELD,
  NOT_PENDING,
  STATUS_PENDING,
  STATUS_UNINITIALIZED
} from "../core/constants.js";
import { createLayerBoundary, stageLayer, pendingInput, type Layer } from "./layer.js";
import { withReadWindow } from "./window.js";
import type { Computed, Signal } from "../core/types.js";

import {
  initializeObservation,
  markObservation,
  releaseObservation,
  type Observation as SharedObservation,
  type ObservationKind
} from "./observation.js";

type Observation = SharedObservation<boolean> & { incoming: Computed<any> | undefined };

function proposedPending(input: Computed<any>, incoming?: Computed<any>): boolean {
  return (
    !(input._statusFlags & STATUS_UNINITIALIZED) &&
    !!(
      input._statusFlags & STATUS_PENDING ||
      (incoming &&
        (incoming._statusFlags & STATUS_PENDING ||
          (incoming._pendingValue !== NOT_PENDING &&
            (!input._equals || !input._equals(input._value, incoming._pendingValue))))) ||
      (input._config & CONFIG_HELD &&
        input._pendingValue !== NOT_PENDING &&
        (!input._equals || !input._equals(input._value, input._pendingValue)))
    )
  );
}

function observeInput(record: Observation): void {
  const incoming = record.incoming;
  if (!incoming) return;
  const output = record.output;
  link(incoming, output);
  if (incoming._height >= output._height) output._height = incoming._height + 1;
}

const kind: ObservationKind<boolean> = {
  sample: record => proposedPending(record.input, (record as Observation).incoming),
  active: (_record, value) => value,
  observe: record => observeInput(record as Observation)
};

// The input identity is fixed for an observation's lifetime. Shared selector
// code avoids retaining another closure per observed source.
function pendingFallback(layer: Layer<boolean>): boolean {
  const source = layer.input;
  if (typeof source._fn === "function") prepareComputed(source, false);
  if (source._statusFlags & STATUS_UNINITIALIZED) read(source);
  const output = context as Computed<any>;
  link(source, output);
  if (source._height >= output._height) output._height = source._height + 1;
  if (output._statusFlags & STATUS_UNINITIALIZED)
    return proposedPending(source, pendingInput(source));
  return false;
}

export function createPending<T>(input: () => T): () => boolean {
  let record: Observation | undefined;
  const mark = () => {
    if (record) {
      markObservation(record);
    }
  };
  const source = (input as any)[$REFRESH] as Computed<any> | undefined;
  const producer =
    source ||
    computed(() => {
      try {
        return input();
      } finally {
        mark();
      }
    });
  const layer = createLayerBoundary(producer, pendingFallback, mark, !source);
  record = observation(layer);
  markObservation(record);
  cleanup(() => releaseObservation(record!));
  return () => read(layer.output);
}

// The input owns the identity of its pending output. A weak key adds no
// ordinary-node fields; the output uses the normal observation lifecycle.
const observations = new WeakMap<Signal<any>, Observation>();

function observation(layer: Layer<boolean>): Observation {
  const record = initializeObservation(layer, kind) as Observation;
  record.incoming = pendingInput(layer.input);
  return record;
}

function pendingOutput(source: Computed<any>): Computed<boolean> {
  const existing = observations.get(source);
  if (existing) return existing.output;
  const record = runWithOwner(null, () =>
    observation(createLayerBoundary(source, pendingFallback, markObservation, false, true))
  );
  observations.set(source, record);
  if (source._config & CONFIG_HELD && !(source._statusFlags & STATUS_UNINITIALIZED))
    stageLayer(record, proposedPending(source, record.incoming));
  return record.output;
}

// A callback window observes each source's existing pending output. Its
// return value is irrelevant, so an equal callback result cannot hide a
// pending read. Nested computations still perform their ordinary reads.
function probe(source: Signal<any>, window: { found: boolean }): unknown {
  // The output is an ordinary read, so an outer observation sees this
  // pending boolean. The callback's control flow still reads the source.
  window.found = read(pendingOutput(source as Computed<any>)) || window.found;
  const previous = verdict;
  setVerdict(null);
  try {
    return read(source);
  } catch (error) {
    if (
      error instanceof NotReadyError &&
      !((source as Computed<any>)._statusFlags & STATUS_UNINITIALIZED)
    )
      return source._value;
    throw error;
  } finally {
    setVerdict(previous);
  }
}

/** The input owns its pending output; calling computations only read it. */
export function isPending<T>(input: () => T): boolean {
  const source = (input as any)[$REFRESH] as Computed<any> | undefined;
  return source ? read(pendingOutput(source)) : withReadWindow(input, probe, true);
}
