/**
 * Scalar experiment: an input producer and an ordinary output computation.
 * Explicit propose/clear isolates publication; the optional action lifetime
 * retires overrides through the same ordinary derivation and commit paths.
 * This entry does not install or use the optimistic lane engine.
 */
import { computed, read, recompute } from "../core/core.js";
import { changedDependencies, dependencyEpoch, link, trackDependencies } from "../core/graph.js";
import { enqueueSub } from "../core/heap.js";
import { disposeChildren } from "../core/owner.js";
import {
  $REFRESH,
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  CONFIG_REDERIVE,
  EFFECT_RENDER,
  NOT_PENDING,
  REACTIVE_DISPOSED,
  REACTIVE_FRAME_READ,
  REACTIVE_JOINED,
  RETRY_COMPUTATION,
  STATUS_UNINITIALIZED,
  STATUS_PENDING,
  STATUS_ERROR
} from "../core/constants.js";
import {
  blocked,
  onScreen,
  setLayerObserved,
  setLayerVisibility,
  flushTransaction,
  passTx,
  restorePassTx,
  globalQueue,
  setLayerCommit,
  setLayerReads,
  setLayerCompute,
  holdNode,
  holdQueuedProposals,
  recomputeInUpdate,
  hasHeldNodes,
  joinFuture,
  liveTx,
  merge,
  newTransaction,
  resolveTx,
  schedule,
  staleReader,
  txOf,
  type Transaction
} from "../core/scheduler.js";
import type { Computed, Link, Signal } from "../core/types.js";
import {
  committedDependencies,
  layerPosition,
  registerBoundary
} from "./committed-dependencies.js";

export function inputTime(input: Computed<any>): number {
  return typeof input._fn === "function" ? input._time : input._notifiedAt;
}

export type Layer<T> = {
  input: Computed<any>;
  output: Computed<T>;
  override: T | typeof NOT_PENDING;
  update: Transaction | null;
  scope: Transaction | null;
  inputTime: number;
  inputStatus?: true;
  statusInput?: Computed<any>;
  position?: number;
  initial?: true;
};

const boundaries = new WeakMap<Signal<any>, Layer<any> | null>();
/** Value overrides retain the pending calculation of their relative input.
 * Observation boundaries do not inherit the pending state they describe. */
export function pendingInput(source: Signal<any>): Computed<any> | undefined {
  const boundary = boundaries.get(source);
  return boundary?.statusInput ?? (boundary?.inputStatus ? boundary.input : undefined);
}

const proposals = new Map<Layer<any>, unknown>();
const active = new Set<Layer<any>>();
const scoped = new Set<Layer<any>>();
// Active value boundaries forward demand, not values or notifications. No
// state is added to ordinary nodes; the scheduler consults this only for
// pending work during its existing readiness check.
const inputObservers = new Map<Computed<any>, Set<Layer<any>>>();
function forwardObservation(layer: Layer<any>, active: boolean): void {
  if (!layer.inputStatus) return;
  if (active) {
    let observers = inputObservers.get(layer.input);
    if (!observers) inputObservers.set(layer.input, (observers = new Set()));
    observers.add(layer);
    setLayerObserved(forwardedHold);
  } else {
    const observers = inputObservers.get(layer.input);
    if (observers?.delete(layer) && !observers.size) inputObservers.delete(layer.input);
    if (!inputObservers.size) setLayerObserved();
  }
}

function observed(
  node: Computed<any>,
  update: Transaction | null,
  seen = new Set<Computed<any>>()
): boolean {
  if (seen.has(node) || node._flags & REACTIVE_DISPOSED || !onScreen(node, update)) return false;
  seen.add(node);
  if ((node as any)._type === EFFECT_RENDER) return true;
  for (let edge = node._subs; edge; edge = edge._nextSub) {
    const reader = edge._sub;
    const replaces =
      update &&
      !(reader._statusFlags & (STATUS_PENDING | STATUS_ERROR)) &&
      reader._config & CONFIG_HELD &&
      txOf(reader) === resolveTx(update);
    let reads = edge._gen === reader._depGen;
    // A different pending update has not removed the displayed dependency.
    // The retained frame journal distinguishes old reads from new insertions.
    if (!reads && !replaces)
      for (const dependency of committedDependencies(reader))
        if (dependency === node) {
          reads = true;
          break;
        }
    if (reads && observed(reader, update, seen)) return true;
  }
  for (const boundary of inputObservers.get(node) || [])
    if (observed(boundary.output, update, seen)) return true;
  return false;
}

function forwardedHold(input: Computed<any>, update: Transaction | null): boolean {
  const observers = inputObservers.get(input);
  if (observers)
    for (const boundary of observers) if (observed(boundary.output, update)) return true;
  return false;
}

// CONFIG_REDERIVE absorbs status at the selector. Unlike a display boundary,
// an optimistic selector is not itself an observer once its readers disappear.
setLayerVisibility((output, update) => !boundaries.get(output) || observed(output, update));
// A child update may observe its input update's published frame without
// consuming that update's proposal. Only live child updates have this record.
const parents = new WeakMap<Transaction, Set<Transaction>>();
// Only optimistic transactions carry a context record. Settled ordinary reads
// and ordinary nodes retain the existing storage and fast paths.
const positions = new WeakMap<Transaction, number>();
function positionOf(update: Transaction | null): number {
  return update ? (positions.get(resolveTx(update)) ?? 0) : 0;
}
const candidateUpdates = new Set<Transaction>();
const preparingEffects = new WeakSet<Computed<any>>();
let releasingInput: Transaction | null = null;
type Evaluation = { node: Computed<any>; position: number; retry: Transaction | null };
let evaluation: Evaluation | null = null;
const pendingRetries = new WeakMap<Computed<any>, Transaction>();
const resultPositions = new WeakMap<Computed<any>, number>();
// Positive reachability only, scoped to a parent update and unchanged
// dependencies. Weak keys do not retain disposed nodes or completed updates.
type Reach = { epoch: number; dependencies: number; tail: Link | null; visit: number };
let visit = 0;
const reachability = new WeakMap<Transaction, WeakMap<Signal<any>, Reach>>();
let graphEpoch = 0;
let cacheReads = true;
const layerOwn = (node: Signal<any>, update: Transaction) => {
  const layer = boundaries.get(node);
  if (layer === undefined) return;
  graphEpoch++;
  // A settled selector propagates normally. If its consequences suspend,
  // ordinary parking supplies the output update and we record only its cut.
  // The selector retires its override before proposing any input answer.
  if (
    layer &&
    layer.update === null &&
    layer.override !== NOT_PENDING &&
    node._pendingValue !== NOT_PENDING &&
    !Object.is(node._value, node._pendingValue)
  )
    ownLayerUpdate(layer, update, inputUpdate(layer));
};

/** Observation boundaries install their lifecycle at these same seams.
 * Their proposals use stageLayer and the ordinary output machinery. */
export const layerHooks: {
  beforeCommit?: () => boolean;
  afterCommit?: () => void;
  active?: () => boolean;
} = {};

export function wakeLayers(): void {
  setLayerCommit(prepareLayers, settleLayers);
  schedule();
}

function enableReads(): void {
  trackDependencies(true);
  setLayerReads(layerOwn, mergeLayers, frameRead, rederiveStatus);
}

function stopIfIdle(): void {
  if (
    candidateUpdates.size ||
    active.size ||
    scoped.size ||
    proposals.size ||
    layerHooks.active?.()
  )
    return;
  setLayerCommit();
  setLayerReads();
  setLayerCompute();
  trackDependencies(inputObservers.size > 0);
}

function parentSet(update: Transaction): Set<Transaction> | undefined {
  return parents.get(resolveTx(update));
}

function watchParent(update: Transaction): void {
  enableReads();
  candidateUpdates.add(update);
  setLayerCompute(computeLayer, rerunLayer, readContext);
}

function isChildUpdate(update: Transaction): boolean {
  const resolved = resolveTx(update);
  const excluded = parents.get(resolved);
  // An explicit-clear override can start above a settled input. An empty
  // exclusion set still identifies its output update; no parent is pending.
  if (excluded?.size === 0) return true;
  for (const parent of excluded || []) {
    if (resolveTx(parent) !== resolved) return true;
  }
  return false;
}

function inputUpdate(layer: Layer<any>): Transaction | null {
  if (layer.input._config & CONFIG_HELD) return txOf(layer.input);
  if (layer.scope) return liveTx(layer.scope);
  const boundary = boundaries.get(layer.input);
  return boundary?.inputStatus ? inputUpdate(boundary) : null;
}

/** An input answer or the end of an action retires its override as work of
 * that action. Reading the input below then uses normal derivation joining.
 * Published output and owned children stay in the common committed slots. */
export function resumeInput(layer: Layer<any>, update: Transaction): void {
  graphEpoch++;
  forwardObservation(layer, false);
  layer.override = NOT_PENDING;
  // Retiring the cut makes its suspended consequences input work again.
  // Recompute will supersede obsolete flights in that common update.
  if (layer.output._config & CONFIG_HELD) merge(txOf(layer.output), update);
  joinFuture(update);
  enqueueSub(layer.output);
}

function retire(layer: Layer<any>): void {
  // An input hidden by an override can outlive the action transaction. Its
  // eventual answer resumes in live ordinary work, never a completed hold.
  const scope = liveTx(layer.scope!);
  if (!scope) joinFuture(null);
  resumeInput(layer, scope ?? resolveTx(flushTransaction!));
  layer.scope = null;
  scoped.delete(layer);
}

function prepareLayers(): boolean {
  if (!scoped.size && !candidateUpdates.size) return layerHooks.beforeCommit?.() ?? false;
  // This round can discover a lower flight after a child already re-ran.
  // Include all its proposals before deciding whether that input is ready.
  if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
  // Park/commit can change ownership without a computation running. Keep
  // those phases uncached; pure rounds reuse only structurally valid entries.
  cacheReads = false;
  let changed = false;
  // Guesses made in the same action hold have one lifetime. An input still
  // in flight keeps every override in that group selected, even after the
  // bodies return. This bookkeeping exists only for active optimistic scopes.
  let waiting: Set<Transaction> | undefined;
  for (const layer of scoped) {
    const scope = resolveTx(layer.scope!);
    if (
      !scope._open &&
      !(layer.output._flags & REACTIVE_DISPOSED) &&
      layer.input._statusFlags & STATUS_PENDING &&
      observed(layer.output, scope)
    )
      (waiting ??= new Set()).add(scope);
  }
  for (const layer of scoped) {
    if (layer.output._flags & REACTIVE_DISPOSED) {
      scoped.delete(layer);
      layer.scope = null;
    } else if (resolveTx(layer.scope!)._open === 0 && !waiting?.has(resolveTx(layer.scope!))) {
      proposals.delete(layer);
      retire(layer);
      changed = true;
    }
  }
  // Retire observations before replaying readers of the now-ready input.
  // A callback probe also reads that input for control flow. Replaying it
  // against a stale true observation would join the ready input to the
  // obsolete async consequence that the false observation must supersede.
  changed = (layerHooks.beforeCommit?.() ?? false) || changed;
  for (const update of candidateUpdates) {
    const parent = liveTx(update);
    if (!parent || blocked(parent)) continue;
    for (const reader of parent._reruns || []) {
      if (
        !(reader as any)._type &&
        reader._flags & REACTIVE_FRAME_READ &&
        !(reader._flags & REACTIVE_DISPOSED)
      ) {
        // Derivations of a committed parent frame must discover their next
        // async work before that parent publishes. A post-commit rerun is
        // sufficient for a direct binding, but would let a memo lag behind
        // an already-published input after its boundary dependency changes.
        parent._reruns!.delete(reader);
        reader._flags &= ~REACTIVE_FRAME_READ;
        const previous = releasingInput;
        releasingInput = parent;
        try {
          recomputeInUpdate(reader, parent);
        } finally {
          releasingInput = previous;
        }
        changed = true;
        // This pass can merge its holder into another update. Its remaining
        // readers moved there; reconsider that holder's readiness on the
        // next iteration instead of continuing against the emptied record.
        if (resolveTx(parent) !== parent) break;
      }
    }
  }
  return changed;
}

function mergeLayers(from: Transaction, into: Transaction): void {
  graphEpoch++;
  if (positions.has(from) || positions.has(into))
    positions.set(into, Math.min(positionOf(from), positionOf(into)));
  if (candidateUpdates.delete(from)) candidateUpdates.add(into);
  const source = parents.get(from);
  if (!source) return;
  const target = parents.get(into);
  if (target) for (const parent of source) target.add(parent);
  else parents.set(into, source);
  parents.delete(from);
}

function reachesBoundary(
  node: Signal<any>,
  holder: Transaction,
  cache: WeakMap<Signal<any>, Reach>,
  epoch: number,
  visit: number
): boolean {
  const computed = node as Computed<any>;
  const cached = cache.get(node);
  if (
    cached &&
    epoch >= 0 &&
    cached.epoch === epoch &&
    cached.dependencies === dependencyEpoch &&
    cached.tail === computed._depsTail
  )
    return true;
  if (cached?.visit === visit) return false;
  const entry = cached || { epoch: -1, dependencies: -1, tail: null, visit };
  if (cached) entry.visit = visit;
  else cache.set(node, entry);
  const boundary = boundaries.get(node);
  let found = false;
  if (boundary && boundary.override !== NOT_PENDING) {
    const input = inputUpdate(boundary);
    found =
      (input === null ||
        !(boundary.output._config & CONFIG_HELD) ||
        txOf(boundary.output) !== input) &&
      (input === holder || !isChildUpdate(holder));
  } else {
    for (let edge = computed._deps; edge; edge = edge._nextDep) {
      // A staged memo retains old links for its committed children's frame.
      // They do not describe the proposal consumed by an ordinary derivation.
      if (edge._gen !== computed._depGen) continue;
      if (reachesBoundary(edge._dep, holder, cache, epoch, visit)) {
        found = true;
        break;
      }
    }
  }
  if (found && epoch >= 0) {
    entry.epoch = epoch;
    entry.dependencies = dependencyEpoch;
    entry.tail = computed._depsTail;
  }
  return found;
}

function includesBoundary(reader: Computed<any>, holder: Transaction): boolean {
  const position = positionOf(holder);
  if (position > 0) return layerPosition(reader) > position;
  // Only current dependencies authorize a published-parent read. Cache
  // positive answers while dependencies are unchanged; the visit stamp bounds
  // cycles without allocating a Set and recursive closure for every read.
  let cache = reachability.get(holder);
  if (!cache) reachability.set(holder, (cache = new WeakMap()));
  return reachesBoundary(
    reader,
    holder,
    cache,
    cacheReads && globalQueue._running ? graphEpoch : -1,
    ++visit
  );
}

function frameRead(reader: Computed<any>, source: Signal<any>): boolean {
  const update = flushTransaction;
  if ((source as Computed<any>)._statusFlags & STATUS_UNINITIALIZED) return false;
  const excluded = update && parentSet(update);
  const holder = txOf(source);
  if (update && holder === resolveTx(update)) return false;
  const ownPosition = Math.max(
      positionOf(update ?? passTx),
      evaluation?.node === reader ? evaluation.position : 0
    ),
    heldPosition = positionOf(holder);
  if (ownPosition > heldPosition) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  if (ownPosition > 0 && heldPosition > 0) {
    if (ownPosition <= heldPosition) return false;
    staleReader(reader, holder);
    return true;
  }
  if (excluded)
    for (const parent of excluded) {
      if (resolveTx(parent) === holder) {
        staleReader(reader, holder);
        return true;
      }
    }
  // Direct bindings already have the common committed-frame read rule.
  // They do not need a speculative derivation or a provisional transaction.
  if ((reader as any)._type === EFFECT_RENDER) return false;
  if (false && includesBoundary(reader, holder)) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  return false;
}

/** A lower pending/error notification is an obligation to check, not a read
 * of its proposal. Let the existing higher calculation select its inputs;
 * inheriting status here would merge the contexts before that selection. */
function rederiveStatus(reader: Computed<any>, source: Computed<any>): boolean {
  if (!(reader._config & CONFIG_HELD)) return false;
  const incoming = source._config & CONFIG_HELD ? txOf(source) : flushTransaction;
  if (positionOf(txOf(reader)) <= positionOf(incoming)) return false;
  enqueueSub(reader);
  schedule();
  return true;
}

/** A notification does not consume its update's proposal. A held child's
 * pass first keeps its own context; actual reads can still merge peer work.
 * Ready input releases explicitly run in the input context instead. */
function rerunLayer(node: Computed<any>, create: boolean): boolean {
  if (evaluation?.node === node) return false;
  const outer = evaluation,
    previousPass = passTx;
  let update = pendingRetries.get(node) ?? null;
  pendingRetries.delete(node);
  if (
    !update &&
    !create &&
    node._config & CONFIG_HELD &&
    (!(node as any)._type || preparingEffects.delete(node))
  ) {
    const own = txOf(node),
      incoming = flushTransaction && resolveTx(flushTransaction);
    if (
      isChildUpdate(own) &&
      own !== incoming &&
      (!incoming || incoming !== releasingInput) &&
      (!incoming ||
        !isChildUpdate(incoming) ||
        [...(parentSet(own) || [])].some(parent => resolveTx(parent) === incoming))
    ) {
      if (incoming) holdQueuedProposals(incoming);
      update = own;
    }
  }
  const pass: Evaluation = {
    node,
    position: positionOf(update ?? flushTransaction ?? passTx),
    retry: null
  };
  evaluation = pass;
  try {
    let attempts = 0;
    for (;;) {
      if (++attempts > 12) throw new Error(`Retry did not converge: ${pass.position}: ${node._fn}`);
      pass.retry = null;
      if (update) recomputeInUpdate(node, update, true, create);
      else recompute(node, create);
      if (!pass.retry || node._flags & REACTIVE_DISPOSED) break;
      restorePassTx(previousPass);
      update = pass.retry;
      pass.position = positionOf(update);
      if (node._config & CONFIG_HELD) holdNode(node, update);
    }
    if (pass.position) resultPositions.set(node, pass.position);
    else resultPositions.delete(node);
  } finally {
    evaluation = outer;
  }
  return true;
}

function computeLayer(node: Computed<any>, result: any): any {
  // An async function converts the synchronous retry throw into a rejected
  // promise. The read also marked the attempt, so discard it before handleAsync.
  if ((evaluation?.node === node && evaluation.retry) || pendingRetries.has(node)) {
    if (result && typeof result.then === "function") Promise.resolve(result).catch(() => {});
    throw RETRY_COMPUTATION;
  }
  return result;
}

function readContext(reader: Computed<any>, source: Computed<any>): void {
  const pass = evaluation;
  if (
    (reader as any)._type === EFFECT_RENDER ||
    (source._statusFlags & STATUS_UNINITIALIZED && source._pendingValue === NOT_PENDING)
  )
    return;
  const boundary = boundaries.get(source);
  const holder = source._config & CONFIG_HELD ? txOf(source) : null;
  const position =
    boundary && (boundary.override !== NOT_PENDING || boundary.initial)
      ? (boundary.position ?? 1)
      : holder
        ? positionOf(holder)
        : (resultPositions.get(source) ?? 0);
  const current = pass?.node === reader ? pass : null;
  const incoming = flushTransaction ?? passTx;
  if (position <= (current?.position ?? positionOf(incoming))) return;
  // A ready lower release deliberately prepares the combined result. A
  // published boundary is not a reason to reinterpret that new input update.
  if (incoming && (incoming === releasingInput || (!holder && flushTransaction))) return;
  if (current) current.position = position;
  let update = holder;
  if (!update || positionOf(update) !== position) {
    update = newTransaction(false);
    positions.set(update, position);
    parents.set(update, new Set(incoming ? [resolveTx(incoming)] : []));
    if (incoming) watchParent(incoming);
  }
  if (current) current.retry = update;
  else pendingRetries.set(reader, update);
  throw RETRY_COMPUTATION;
}

/** An observation's first answer is already an explicit selected output. */
export function initialLayerProposal<T>(layer: Layer<T>, value: T): T {
  layer.initial = true;
  layer.position = 1 + Math.max(layerPosition(layer.input), positionOf(inputUpdate(layer)));
  const parent = inputUpdate(layer);
  if (parent) {
    watchParent(parent);
    const current = evaluation?.node === layer.output ? evaluation : null;
    layer.override = value;
    if ((current?.position ?? positionOf(flushTransaction ?? passTx)) < layer.position) {
      const update = newTransaction(false);
      layer.override = value;
      ownLayerUpdate(layer, update, parent);
      if (current) current.retry = update;
      else pendingRetries.set(layer.output, update);
      throw RETRY_COMPUTATION;
    }
    const update = flushTransaction ?? passTx;
    if (update) ownLayerUpdate(layer, update, parent);
  }
  return value;
}

/** Move proposals downstream of the cut to the new update, preserving every
 * published value and parked child frame. Old queued effects cannot publish
 * the proposals after ownership has moved. Nested active cuts stop the walk. */
function takeOutput(layer: Layer<any>, update: Transaction): void {
  const seen = new Set<Signal<any>>();
  const visit = (node: Signal<any>) => {
    if (seen.has(node)) return;
    seen.add(node);
    const boundary = boundaries.get(node);
    if (node !== layer.output && boundary && boundary.override !== NOT_PENDING) return;
    // A stale reader may not itself be held. An equal pending proposal
    // becoming this update's proposal still changes that reader's context.
    enqueueSub(node as Computed<any>);
    // Effects store their computed value privately and may owe a callback
    // without being held themselves. Requeue owed work under its new owner;
    // an older queue's copy is harmless once the callback has published.
    const effect = node as Computed<any> & {
      _modified?: boolean;
      _boundRunEffect?: (type: number) => void;
      _type?: number;
    };
    if (effect._type) preparingEffects.add(node as Computed<any>);
    if (effect._modified && effect._boundRunEffect) {
      update._queues[effect._type! - 1].push(effect._boundRunEffect);
    }
    holdNode(node, update);
    for (let edge = node._subs; edge; edge = edge._nextSub) visit(edge._sub);
  };
  visit(layer.output);
}

function ownLayerUpdate(layer: Layer<any>, update: Transaction, input: Transaction | null) {
  layer.update = update;
  positions.set(resolveTx(update), layer.position ?? 1 + layerPosition(layer.input));
  active.add(layer);
  setLayerCompute(computeLayer, rerunLayer, readContext);
  const excluded = parentSet(update) || new Set<Transaction>();
  if (input !== null && input !== update) {
    watchParent(input);
    excluded.add(input);
    for (const ancestor of parentSet(input) || []) excluded.add(ancestor);
  }
  parents.set(update, excluded);
  return excluded;
}

export function stageLayer(layer: Layer<any>, proposal: unknown, position?: number): void {
  graphEpoch++;
  const inputHolder = inputUpdate(layer);
  // Snapshot the context at the new proposal. A subsequently discovered input
  // dependency cannot promote this existing override or split its peer joins.
  layer.position = position ?? 1 + Math.max(layerPosition(layer.input), positionOf(inputHolder));
  layer.override = proposal;
  layer.initial = undefined;
  forwardObservation(layer, proposal !== NOT_PENDING);
  layer.inputTime = inputTime(layer.input);
  enableReads();
  // Selecting an equal, settled scalar output has no downstream proposal.
  // In particular a newly allocated pending observation must not replay its
  // consumers just to install its initial false selector.
  if (
    inputHolder === null &&
    !(layer.output._config & CONFIG_HELD) &&
    layer.output._pendingValue === NOT_PENDING &&
    proposal !== NOT_PENDING &&
    layer.output._equals &&
    layer.output._equals(layer.output._value, proposal)
  ) {
    enqueueSub(layer.output);
    return;
  }
  const previous = layer.update && liveTx(layer.update);
  // A correction may have merged the old output back into its input. A new
  // guess needs a new cut, rather than reusing that now-lower update.
  const update =
    previous &&
    previous !== inputHolder &&
    isChildUpdate(previous) &&
    positionOf(previous) === layer.position
      ? previous
      : newTransaction(false);
  const excluded = ownLayerUpdate(layer, update, inputHolder);
  if (proposal === NOT_PENDING && inputHolder !== null) {
    for (const parent of excluded) if (resolveTx(parent) === inputHolder) excluded.delete(parent);
  }
  takeOutput(layer, update);
  enqueueSub(layer.output);
}

function settleLayers(): void {
  cacheReads = true;
  if (!candidateUpdates.size && !active.size && !proposals.size && !scoped.size) {
    layerHooks.afterCommit?.();
    stopIfIdle();
    return;
  }
  for (const update of candidateUpdates) if (!liveTx(update)) candidateUpdates.delete(update);
  if (!candidateUpdates.size) {
    if (!active.size) setLayerCompute();
    // A later ordinary write can create a hold beneath an already published
    // override. Enable order-independent discovery once that hold exists.
    if (scoped.size && hasHeldNodes()) {
      for (const layer of scoped) if (layer.scope) watchParent(resolveTx(layer.scope));
    }
  }
  for (const layer of active) {
    if (!liveTx(layer.update!)) {
      layer.update = null;
      active.delete(layer);
    }
  }
  // First propagate value proposals. Their pending outputs describe the
  // resulting work, just as they do after an ordinary write's pure phase.
  // Staging both at once would merge a status update with the input update
  // it is meant to observe independently.
  if (proposals.size) {
    // Select all boundaries before assigning the new contexts, so simultaneous
    // nested guesses do not depend on setter order. Existing proposals outside
    // this batch keep their context, including across new parent activation.
    for (const [layer, proposal] of proposals) {
      layer.override = proposal;
      layer.position = undefined;
    }
    for (const [layer] of proposals)
      layer.position = 1 + Math.max(layerPosition(layer.input), positionOf(inputUpdate(layer)));
    for (const [layer, proposal] of proposals) {
      if (layer.output._flags & REACTIVE_DISPOSED) continue;
      stageLayer(layer, proposal, layer.position);
    }
    proposals.clear();
    return;
  }
  layerHooks.afterCommit?.();
  stopIfIdle();
}

export function createLayer<T>(input: () => T, options?: { lifetime: "action" }) {
  const source = (input as any)[$REFRESH] as Computed<T> | undefined;
  // The producer records each input evaluation. Equality belongs at the
  // output: an answer equal to an earlier input may still replace a guess.
  const producer = source || computed(input, { equals: false });
  const layer = createLayerBoundary<T>(producer, undefined, undefined, !source);
  layer.inputStatus = true;
  return layerAccessors(layer, options);
}

function selectLayer<T>(
  layer: Layer<T>,
  fallback: ((layer: Layer<T>) => T) | undefined,
  onEvaluate: ((layer: Layer<T>) => void) | undefined
): T {
  const producer = layer.input;
  onEvaluate?.(layer);
  if (
    layer.scope !== null &&
    layer.override !== NOT_PENDING &&
    !(producer._statusFlags & STATUS_PENDING) &&
    inputTime(producer) !== layer.inputTime
  ) {
    // An input answer joins the guessing actions, but the selector stays
    // overridden until their shared lifetime ends. Intermediate answers
    // must not start downstream work beneath the selected guess.
    const scope = liveTx(layer.scope);
    if (scope) {
      if (producer._config & CONFIG_HELD) merge(txOf(producer), scope);
      // A ready input can still be an unparked proposal in this flush.
      // Couple that input frame, not an independently preparing override.
      if (!layer.update || liveTx(layer.update) !== flushTransaction) joinFuture(scope);
    }
    // The pre-commit phase releases the group once all its inputs are ready.
  }
  if (layer.override === NOT_PENDING) return fallback ? fallback(layer) : read(producer);
  // Choosing an override subscribes to the input's changes, but does not
  // consume its proposal. No other read in the graph has this exemption.
  // The subscription keeps input work current; observation forwarding decides
  // whether it holds. Neither operation consumes the input's proposed value.
  link(producer, layer.output);
  return layer.override as T;
}

/** Internal construction shared by guesses and observations. */
export function createLayerBoundary<T>(
  producer: Computed<any>,
  fallback?: (layer: Layer<T>) => T,
  onEvaluate?: (layer: Layer<T>) => void,
  ownInput = true,
  lazy = false
) {
  if (ownInput) producer._config &= ~CONFIG_AUTO_DISPOSE;
  const layer = {
    input: producer,
    override: NOT_PENDING,
    update: null,
    scope: null,
    inputTime: inputTime(producer)
  } as Layer<T>;
  // Bind the shared selector instead of retaining a constructor closure and
  // its captured producer, callbacks and layer. Only boundaries pay this cost.
  const output = computed<T>((selectLayer<T>).bind(null, layer, fallback, onEvaluate), {
    lazy,
    _extraConfig: CONFIG_REDERIVE
  });
  if (!lazy) output._config &= ~CONFIG_AUTO_DISPOSE;
  layer.output = output;
  registerBoundary(layer);
  boundaries.set(output, layer);
  if (!boundaries.has(producer)) boundaries.set(producer, null);
  return layer;
}

function releaseLayer(layer: Layer<any>): void {
  forwardObservation(layer, false);
  scoped.delete(layer);
  active.delete(layer);
  proposals.delete(layer);
  layer.scope = layer.update = null;
  // Disposal can be the last event while an input is permanently pending.
  // Prune finished update references and disable idle hooks without requiring
  // an unrelated future write to visit the disposed boundary.
  wakeLayers();
}

function layerAccessors<T>(layer: Layer<T>, options?: { lifetime: "action" }) {
  const output = layer.output;
  const propose = (value: T | ((previous: T) => T)) => {
    const pending = proposals.get(layer);
    const previous =
      proposals.has(layer) && pending !== NOT_PENDING
        ? pending
        : layer.override !== NOT_PENDING
          ? layer.override
          : output._pendingValue !== NOT_PENDING
            ? output._pendingValue
            : output._value;
    const next = typeof value === "function" ? (value as (v: T) => T)(previous as T) : value;
    if (options?.lifetime === "action") {
      const scope = flushTransaction ?? (layer.scope && liveTx(layer.scope));
      if (!scope || !resolveTx(scope)._acted) {
        throw new Error("The action-lifetime experiment requires a guess inside an action.");
      }
      if (layer.scope) merge(scope, layer.scope);
      layer.scope = resolveTx(scope);
      // A ready input proposal can predate the guess. It has the same lifetime
      // relationship as an answer that arrives afterwards; its evaluation
      // timestamp cannot tell us whether this action has adopted that hold.
      // Only the input joins the action. The output proposal still gets its
      // own publication context when stageLayer selects the override.
      if (layer.input._config & CONFIG_HELD && !(layer.input._statusFlags & STATUS_PENDING))
        merge(txOf(layer.input), layer.scope);
      scoped.add(layer);
    }
    output._cleanup ??= releaseLayer.bind(null, layer);
    proposals.set(layer, next);
    wakeLayers();
    return next;
  };
  const clear = () => {
    proposals.set(layer, NOT_PENDING);
    wakeLayers();
  };
  const accessor = () => read(output);
  (accessor as any)[$REFRESH] = output;
  return [accessor, propose, clear] as const;
}

