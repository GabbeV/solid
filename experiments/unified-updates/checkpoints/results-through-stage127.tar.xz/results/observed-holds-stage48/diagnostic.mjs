import { UnifiedScheduler as Base } from '../../reference/unified-scheduler.mjs';
export class UnifiedScheduler extends Base {
  commit(group) {
    const before = this.nodes.map(n=>({name:n.name, value:this.value(n), dirty:this.pending(n).map(g=>g.name),
      candidate:n.candidate && {value:n.candidate.value,ready:n.candidate.ready,group:n.candidate.group?.name, reads:[...n.candidate.reads].map(([d,id])=>[d.name,id,d.frame?.id,d.candidate?.id])}}));
    super.commit(group);
    const frame=this.publications.at(-1);
    if(frame && frame['show:upper']!==(frame['show:top'] ? frame['show:c'] : frame['show:d'])) {
      console.log(JSON.stringify({group:group.name,frame,before},null,2));
    }
  }
}
