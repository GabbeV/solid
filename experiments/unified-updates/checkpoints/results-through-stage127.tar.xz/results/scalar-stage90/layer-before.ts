/**
 * Scalar experiment: an input producer and an ordinary output computation.
 * Explicit propose/clear isolates publication; the optional action lifetime
 * retires overrides through the same ordinary derivation and commit paths.
 * This entry does not install or use the optimistic lane engine.
 */
import { releaseFlightTeardown } from "../core/async.js";
import { computed, read, signal } from "../core/core.js";
import { link } from "../core/graph.js";
import { NotReadyError } from "../core/error.js";
import { enqueueSub } from "../core/heap.js";
import { disposeChildren } from "../core/owner.js";
import {
  $REFRESH,
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  CONFIG_PREVIOUS_COMMITTED,
  CONFIG_REDERIVE,
  CONFIG_STAGED,
  EFFECT_RENDER,
  NOT_PENDING,
  REACTIVE_DISPOSED,
  REACTIVE_FRAME_READ,
  REACTIVE_JOINED,
  REACTIVE_LANE_DIRTY,
  REACTIVE_RECOMPUTING_DEPS,
  REACTIVE_ZOMBIE,
  STATUS_UNINITIALIZED,
  STATUS_PENDING,
  STATUS_ERROR
} from "../core/constants.js";
import {
  blocked,
  onScreen,
  ownFlights,
  setLayerBlocked,
  setLayerVisibility,
  flushTransaction,
  globalQueue,
  setLayerCommit,
  setLayerReads,
  setLayerCompute,
  setLayerTransactions,
  holdNode,
  holdQueuedProposals,
  recomputeInUpdate,
  hasHeldNodes,
  hasUnheldProposals,
  insertSubs,
  joinFuture,
  liveTx,
  merge,
  newTransaction,
  resolveTx,
  schedule,
  staleReader,
  queueRerun,
  txOf,
  type NormalizeCalculation,
  type Transaction
} from "../core/scheduler.js";
import type { Computed, NodeOptions, Signal } from "../core/types.js";
import { boundaries } from "./boundary.js";
import { committedDependencies, layerPosition } from "./committed-dependencies.js";

export function inputTime(input: Computed<any>): number {
  return typeof input._fn === "function" ? input._time : input._notifiedAt;
}

export type Layer<T> = {
  input: Computed<any>;
  output: Computed<T>;
  override: T | typeof NOT_PENDING;
  update: Transaction | null;
  scope: Transaction | null;
  inputTime: number;
  inputStatus?: true;
  statusInput?: Computed<any>;
  position?: number;
  automatic?: true;
  opening?: true;
};

/** Value overrides retain the pending calculation of their relative input.
 * Observation boundaries do not inherit the pending state they describe. */
export function pendingInput(source: Signal<any>): Computed<any> | undefined {
  const boundary = boundaries.get(source);
  return boundary?.statusInput ?? (boundary?.inputStatus ? boundary.input : undefined);
}

const proposals = new Map<Layer<any>, unknown>();
const active = new Set<Layer<any>>();
const scoped = new Set<Layer<any>>();

/** A guessed input's own flight keeps its action alive, as in next. This
 * does not make that input hold a different update merely because the
 * override is displayed. Its eventual correction uses ordinary joining. */
function pendingScope(update: Transaction): boolean {
  for (const layer of scoped)
    if (
      resolveTx(layer.scope!) === update &&
      layer.input._statusFlags & STATUS_PENDING &&
      observed(layer.output, update)
    ) return true;
  return false;
}

function observed(
  node: Computed<any>,
  update: Transaction | null,
  seen = new Set<Computed<any>>()
): boolean {
  if (seen.has(node) || node._flags & REACTIVE_DISPOSED || !onScreen(node, update)) return false;
  seen.add(node);
  if ((node as any)._type === EFFECT_RENDER) return true;
  for (let edge = node._subs; edge; edge = edge._nextSub) {
    const reader = edge._sub;
    const replaces =
      update &&
      !(reader._statusFlags & (STATUS_PENDING | STATUS_ERROR)) &&
      reader._config & CONFIG_HELD &&
      txOf(reader) === resolveTx(update);
    let reads = edge._gen === reader._depGen;
    // A different pending update has not removed the displayed dependency.
    // The retained frame journal distinguishes old reads from new insertions.
    if (!reads && !replaces)
      for (const dependency of committedDependencies(reader))
        if (dependency === node) {
          reads = true;
          break;
        }
    if (reads && observed(reader, update, seen)) return true;
  }
  return false;
}

// CONFIG_REDERIVE absorbs status at the selector. Unlike a display boundary,
// an optimistic selector is not itself an observer once its readers disappear.
setLayerVisibility((output, update) => !boundaries.get(output) || observed(output, update));
// A child update may observe its input update's published frame without
// consuming that update's proposal. Only live child updates have this record.
// Only optimistic transactions carry a context record. Settled ordinary reads
// and ordinary nodes retain the existing storage and fast paths.
function positionOf(update: Transaction | null): number {
  return update ? (resolveTx(update)._level ?? 0) : 0;
}
const candidateUpdates = new Set<Transaction>();
const preparingEffects = new WeakSet<Computed<any>>();
let releasingInput: Transaction | null = null;
let evaluation: Computed<any> | null = null;
let evaluationReads: Map<Signal<any>, Transaction> | null = null;
let retryEvaluation = false;
let creationUpdate: Transaction | null = null;
const RETRY = Symbol("retry layer calculation");
const layerOwn = (node: Signal<any>, update: Transaction) => {
  const layer = boundaries.get(node);
  if (layer === undefined) return;
  // A settled selector propagates normally. If its consequences suspend,
  // ordinary parking supplies the output update and we record only its cut.
  // The selector retires its override before proposing any input answer.
  if (
    layer &&
    layer.update === null &&
    layer.override !== NOT_PENDING &&
    node._pendingValue !== NOT_PENDING &&
    !Object.is(node._value, node._pendingValue)
  )
    ownLayerUpdate(layer, update, inputUpdate(layer));
};

/** Observation boundaries install their lifecycle at these same seams.
 * Their proposals use stageLayer and the ordinary output machinery. */
let prepareObservations: (() => boolean) | undefined;
let settleObservations: (() => void) | undefined;
let activeObservations: (() => boolean) | undefined;
export function setObservationHooks(
  prepare: () => boolean,
  settle: () => void,
  active: () => boolean
): void {
  prepareObservations = prepare;
  settleObservations = settle;
  activeObservations = active;
}

export function wakeLayers(): void {
  setLayerCommit(prepareLayers, settleLayers);
  schedule();
}

function enableReads(): void {
  setLayerReads(layerOwn, mergeLayers, frameRead, rederiveStatus, notifyLayer);
}

function stopIfIdle(): void {
  if (
    candidateUpdates.size ||
    active.size ||
    scoped.size ||
    proposals.size ||
    activeObservations?.()
  )
    return;
  setLayerCommit();
  setLayerReads();
  setLayerCompute();
}

function watchParent(update: Transaction): void {
  update = resolveTx(update);
  if (candidateUpdates.has(update)) return;
  if (!candidateUpdates.size) {
    enableReads();
    setLayerCompute(computeLayer, rerunLayer, readContext, deferJoin, detachedOutput);
  }
  candidateUpdates.add(update);
}

function isChildUpdate(update: Transaction): boolean {
  return positionOf(update) > 0;
}

function inputUpdate(layer: Layer<any>): Transaction | null {
  if (layer.input._config & CONFIG_HELD) return txOf(layer.input);
  if (layer.scope) return liveTx(layer.scope);
  const boundary = boundaries.get(layer.input);
  return boundary?.inputStatus ? inputUpdate(boundary) : null;
}

/** An input answer or the end of an action retires its override as work of
 * that action. Reading the input below then uses normal derivation joining.
 * Published output and owned children stay in the common committed slots. */
export function resumeInput(layer: Layer<any>, update: Transaction): void {
  layer.override = NOT_PENDING;
  // Retiring the cut makes its suspended consequences input work again.
  // Recompute will supersede obsolete flights in that common update.
  if (layer.output._config & CONFIG_HELD) merge(txOf(layer.output), update);
  joinFuture(update);
  enqueueSub(layer.output);
}

function retire(layer: Layer<any>): void {
  // An input hidden by an override can outlive the action transaction. Its
  // eventual answer resumes in live ordinary work, never a completed hold.
  const scope = liveTx(layer.scope!);
  if (!scope) joinFuture(null);
  resumeInput(layer, scope ?? resolveTx(flushTransaction!));
  layer.scope = null;
  scoped.delete(layer);
  if (!scoped.size) setLayerBlocked();
}

let orderPublication = false;

/** A speculative pass can add or drop inputs without replacing the displayed
 * result. Only a change reaching that committed result requires preparation
 * before the lower update publishes. */
function committedUsesUpdate(
  node: Computed<any>,
  update: Transaction,
  seen = new Set<Signal<any>>()
): boolean {
  if (seen.has(node)) return false;
  seen.add(node);
  const boundary = boundaries.get(node);
  if (boundary && boundary.override !== NOT_PENDING) return false;
  for (const input of committedDependencies(node)) {
    if (input._config & CONFIG_HELD && txOf(input) === update) return true;
    if (
      typeof (input as Computed<any>)._fn === "function" &&
      committedUsesUpdate(input as Computed<any>, update, seen)
    ) return true;
  }
  return false;
}

function prepareLayers(): boolean {
  if (!scoped.size && !candidateUpdates.size && !proposals.size) return prepareObservations?.() ?? false;
  // This round can discover a lower flight after a child already re-ran.
  // Include all its proposals before deciding whether that input is ready.
  if (flushTransaction) holdQueuedProposals(resolveTx(flushTransaction));
  let changed = false;
  // Ambient writes acquire the update that actually parks this flush. A
  // setter cannot know that update before downstream calculations have run.
  for (const layer of proposals.keys()) {
    if (layer.output._flags & REACTIVE_DISPOSED) {
      proposals.delete(layer);
      continue;
    }
    if (!layer.automatic || layer.scope) continue;
    let scope = inputUpdate(layer) ?? (flushTransaction && resolveTx(flushTransaction));
    if (!scope && layer.input._statusFlags & STATUS_PENDING) {
      // Keep this new lifetime alive until the guess has propagated once;
      // its displayed consumers then determine the ordinary input hold.
      scope = newTransaction(false);
      scope._open++;
      layer.opening = true;
      holdNode(layer.input, scope);
    }
    if (!scope) proposals.delete(layer);
    else bindScope(layer, scope);
  }
  // Guesses made in the same action hold have one lifetime. An input still
  // in flight keeps every override in that group selected, even after the
  // bodies return. This bookkeeping exists only for active optimistic scopes.
  let waiting: Set<Transaction> | undefined;
  for (const layer of scoped) {
    const scope = resolveTx(layer.scope!);
    if (
      !scope._open &&
      !(layer.output._flags & REACTIVE_DISPOSED) &&
      layer.input._statusFlags & STATUS_PENDING &&
      observed(layer.output, scope)
    )
      (waiting ??= new Set()).add(scope);
  }
  for (const layer of scoped) {
    if (layer.output._flags & REACTIVE_DISPOSED) {
      releaseLayer(layer);
      continue;
    }
    const scope = resolveTx(layer.scope!);
    if (
      scope._acted
        ? scope._open === 0 && !ownFlights(scope) && !waiting?.has(scope)
        : !blocked(scope)
    ) {
      proposals.delete(layer);
      retire(layer);
      changed = true;
    }
  }
  // Retire observations before replaying readers of the now-ready input.
  // A callback probe also reads that input for control flow. Replaying it
  // against a stale true observation would join the ready input to the
  // obsolete async consequence that the false observation must supersede.
  changed = (prepareObservations?.() ?? false) || changed;
  for (const update of candidateUpdates) {
    const parent = liveTx(update);
    if (!parent || blocked(parent)) continue;
    for (const reader of parent._reruns || []) {
      const heldAbove =
        reader._config & CONFIG_HELD && positionOf(txOf(reader)) > positionOf(parent);
      const affectsCommitted = heldAbove && committedUsesUpdate(reader, parent);
      if (
        !(reader as any)._type &&
        (reader._flags & REACTIVE_FRAME_READ || affectsCommitted) &&
        !(reader._flags & REACTIVE_DISPOSED)
      ) {
        // A lower input used only by an unpublished upper branch can commit
        // independently. Its ordinary post-commit rerun refreshes that branch.
        if (heldAbove && !affectsCommitted) continue;
        const frame = unpublishedFrame(reader);
        if (frame && positionOf(frame) < positionOf(parent)) {
          orderPublication = true;
          continue;
        }
        // Derivations of a committed parent frame must discover their next
        // async work before that parent publishes. A post-commit rerun is
        // sufficient for a direct binding, but would let a memo lag behind
        // an already-published input after its boundary dependency changes.
        parent._reruns!.delete(reader);
        reader._flags &= ~REACTIVE_FRAME_READ;
        const previous = releasingInput;
        releasingInput = parent;
        try {
          recomputeInUpdate(reader, parent);
        } finally {
          releasingInput = previous;
        }
        changed = true;
        // This pass can merge its holder into another update. Its remaining
        // readers moved there; reconsider that holder's readiness on the
        // next iteration instead of continuing against the emptied record.
        if (resolveTx(parent) !== parent) break;
      }
    }
  }
  return changed;
}

function mergeLayers(from: Transaction, into: Transaction): void {
  const fromPosition = positionOf(from), intoPosition = positionOf(into);
  if (fromPosition !== intoPosition) {
    const higher = fromPosition > intoPosition ? from : into;
    for (const node of higher._nodes)
      if (node._config & CONFIG_HELD && txOf(node) === higher && node._pendingValue !== NOT_PENDING)
        node._config |= CONFIG_PREVIOUS_COMMITTED;
  }
  if (from._level || into._level) into._level = Math.min(positionOf(from), positionOf(into));
  if (candidateUpdates.delete(from)) candidateUpdates.add(into);
}

function includesBoundary(reader: Computed<any>, holder: Transaction): boolean {
  return currentPosition(reader) > positionOf(holder);
}

/** A new owned frame belongs to its creator's proposal until that creator
 * publishes. Parked children are the old visible frame and are not excluded. */
function unpublishedFrame(node: Computed<any>): Transaction | null {
  let child = node;
  for (let owner = node._parent; owner; child = owner as Computed<any>, owner = owner._parent) {
    if (child._flags & REACTIVE_ZOMBIE) return null;
    const parent = owner as Computed<any>;
    if (parent._flags & REACTIVE_RECOMPUTING_DEPS && parent._flags & REACTIVE_JOINED)
      return flushTransaction;
    if (parent._config & CONFIG_STAGED && parent._config & CONFIG_HELD) return txOf(parent);
  }
  return null;
}

function frameRead(reader: Computed<any>, source: Signal<any>): boolean {
  const update = flushTransaction;
  // Most active propagation reads a proposal from this exact update. Merged
  // holders still take the resolving path below.
  if (update && source._x!._transaction === update) return false;
  const uninitialized = (source as Computed<any>)._statusFlags & STATUS_UNINITIALIZED;
  const holder = txOf(source);
  if (update && holder === resolveTx(update)) return false;
  const ownPosition = positionOf(update),
    heldPosition = positionOf(holder);
  if (heldPosition > ownPosition && unpublishedFrame(reader)) {
    staleReader(reader, holder);
    // This frame can wait for publication without consuming the higher
    // proposal. With no committed value yet, its read simply suspends.
    if (uninitialized) throw new NotReadyError(source);
    return true;
  }
  if (uninitialized) return false;
  if (ownPosition > heldPosition) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  if (ownPosition > 0 && heldPosition > 0) return false;
  // Direct bindings already have the common committed-frame read rule.
  // They do not need a speculative derivation or a provisional transaction.
  if ((reader as any)._type === EFFECT_RENDER) return false;
  if (includesBoundary(reader, holder)) {
    watchParent(holder);
    staleReader(reader, holder);
    return true;
  }
  return false;
}

/** A lower pending/error notification is an obligation to check, not a read
 * of its proposal. Let the existing higher calculation select its inputs;
 * inheriting status here would merge the contexts before that selection. */
function rederiveStatus(reader: Computed<any>, source: Computed<any>): boolean {
  if (!(reader._config & CONFIG_HELD)) return false;
  const incoming = source._config & CONFIG_HELD ? txOf(source) : flushTransaction;
  const ownPosition = positionOf(txOf(reader)),
    incomingPosition = positionOf(incoming);
  if (
    ownPosition <= incomingPosition &&
    !(ownPosition < incomingPosition && unpublishedFrame(reader))
  )
    return false;
  enqueueSub(reader);
  schedule();
  return true;
}

/** A notification does not consume its update's proposal. A held child's
 * pass first keeps its own context; actual reads can still merge peer work.
 * Ready input releases explicitly run in the input context instead. */
function rerunLayer(node: Computed<any>, create: boolean): boolean {
  if (create) {
    if (globalQueue._running || flushTransaction || (node as any)._type) return false;
    // Discovery may select and merge a proposal context during a fresh
    // mainline calculation. Scope the entire pass, including its staging,
    // so that unrelated writes after construction stay outside that context.
    const previous = creationUpdate;
    creationUpdate = newTransaction(false);
    try {
      recomputeInUpdate(node, creationUpdate, false, true);
    } finally {
      creationUpdate = previous;
    }
    return true;
  }
  const frame = unpublishedFrame(node);
  if (
    frame &&
    flushTransaction &&
    frame !== resolveTx(flushTransaction) &&
    positionOf(frame) < positionOf(flushTransaction)
  ) {
    preparingEffects.delete(node);
    recomputeInUpdate(node, frame, true);
    return true;
  }
  if ((node as any)._type && !preparingEffects.delete(node)) return false;
  const own = txOf(node);
  if (!isChildUpdate(own)) return false;
  if (!flushTransaction && hasUnheldProposals()) joinFuture(null);
  const incoming = flushTransaction && resolveTx(flushTransaction);
  if (incoming === own || (incoming && incoming === releasingInput)) return false;
  if (positionOf(incoming) >= positionOf(own)) return false;
  if (incoming) holdQueuedProposals(incoming);
  recomputeInUpdate(node, own, true);
  // The displayed frame can still depend on the notifying update even when
  // this speculative pass drops that input. Its publication obligation must
  // survive independently of the reads performed by the replacement. Queue
  // preparation without stamping a stale value read: that flag also forwards
  // pending demand, which would incorrectly undo a Loading fallback's release.
  if (incoming && committedUsesUpdate(node, resolveTx(incoming))) {
    watchParent(incoming);
    queueRerun(incoming, node);
  }
  return true;
}

function deferJoin(reader: Computed<any>, source: Signal<any>): boolean {
  if (evaluation !== reader || (reader as any)._type === EFFECT_RENDER) return false;
  const holder = txOf(source);
  if (flushTransaction && resolveTx(flushTransaction) === holder) return false;
  (evaluationReads ??= new Map()).set(source, holder);
  // Isolate tentative reads before merging their holders. A fresh frame
  // adopts its accepted input context in computeLayer, after discovery.
  joinFuture(null);
  reader._flags |= REACTIVE_JOINED;
  return true;
}

/** The dependency prefix of this attempt selects its retry context. Existing
 * overrides retain their frozen position; discovering inputs cannot move them. */
function currentPosition(node: Signal<any>, seen = new Set<Signal<any>>()): number {
  if (seen.has(node)) return 0;
  seen.add(node);
  const boundary = boundaries.get(node);
  if (boundary && boundary.override !== NOT_PENDING) return boundary.position ?? 1;
  const computed = node as Computed<any>;
  let position = 0;
  for (let edge = computed._deps; edge; edge = edge._nextDep)
    if (edge._gen === computed._depGen)
      position = Math.max(position, currentPosition(edge._dep, seen));
  return position;
}

function readContext(reader: Computed<any>, _source: Computed<any>): void {
  if (evaluation !== reader || !evaluationReads) return;
  for (const holder of evaluationReads.values()) {
    const parent = resolveTx(holder);
    if (flushTransaction && parent === resolveTx(flushTransaction)) continue;
    const ownPosition = positionOf(flushTransaction),
      heldPosition = positionOf(parent);
    if (ownPosition > 0 && heldPosition >= ownPosition) continue;
    if (!includesBoundary(reader, parent)) continue;
    watchParent(parent);
    staleReader(reader, parent);
    joinFuture(null);
    const update = resolveTx(flushTransaction!);
    update._level = Math.max(positionOf(update), currentPosition(reader));
    retryEvaluation = true;
    throw RETRY;
  }
}

function detachedOutput(node: Computed<any>): boolean {
  const layer = boundaries.get(node);
  return !!layer && !layer.inputStatus;
}

/** Initial observation is already an explicitly selected output, not a lower
 * proposal inherited from whichever computation happened to call it first. */
export function initialObservation<T>(layer: Layer<T>, value: T): T {
  if (inputUpdate(layer)) {
    layer.override = value;
    layer.position = 1 + Math.max(layerPosition(layer.input), positionOf(inputUpdate(layer)));
  }
  return value;
}

function computeLayer(node: Computed<any>, previous: any, normalize?: NormalizeCalculation): any {
  const incoming = flushTransaction;
  const previousPosition = positionOf(incoming);
  const outer = evaluation,
    outerRetry = retryEvaluation;
  let outerReads = evaluationReads;
  evaluation = node;
  evaluationReads = null;
  retryEvaluation = false;
  try {
    for (;;) {
      let result: any,
        error: unknown,
        failed = false;
      try {
        const previousFlight = node._x?._inFlight;
        result = node._fn(previous);
        if (!retryEvaluation && normalize) result = normalize(node, result, previousFlight);
      } catch (e) {
        error = e;
        failed = true;
      }
      if (!retryEvaluation) {
        const reads = evaluationReads as Map<Signal<any>, Transaction> | null;
        if (reads) {
          if (outer && node._parent === outer) {
            for (const [source, holder] of reads) (outerReads ??= new Map()).set(source, holder);
          } else {
            // Accept the calculation before adopting its first consumed
            // context. During discovery a fresh frame must remain free to
            // retry above a deeper proposal encountered later in the body.
            if ((incoming === null || incoming === creationUpdate) && flushTransaction && !positionOf(flushTransaction))
              flushTransaction._level = positionOf(reads.values().next().value!);
            for (const holder of reads.values()) joinFuture(resolveTx(holder));
          }
        }
        if (failed) throw error;
        return result;
      }
      if (result && typeof result.then === "function") Promise.resolve(result).catch(() => {});
      if (positionOf(flushTransaction) !== previousPosition) {
        previous = node._value;
        node._config |= CONFIG_PREVIOUS_COMMITTED;
      }
      if (node._x !== null) node._x._inFlight = null;
      releaseFlightTeardown(node);
      disposeChildren(node);
      node._depsTail = null;
      node._depGen++;
      evaluationReads = null;
      retryEvaluation = false;
    }
  } finally {
    evaluation = outer;
    evaluationReads = outerReads;
    retryEvaluation = outerRetry;
  }
}

// Transactions, rather than ordinary node creation, activate coordination.
function orderUpdates(updates: Transaction[]): void {
  // Only a ready output with unpublished lower readers needs a landing order.
  // Independent ready updates and ordinary visible readers impose no order.
  if (!orderPublication) return;
  orderPublication = false;
  for (let i = 1; i < updates.length; i++) {
    if (positionOf(updates[i - 1]) <= positionOf(updates[i])) continue;
    updates.sort((a, b) => positionOf(a) - positionOf(b));
    return;
  }
}
setLayerTransactions(update => {
  watchParent(update);
  wakeLayers();
}, orderUpdates);

/** Assign notified work to its output update, preserving the committed frame.
 * Active boundaries and unpublished lower owners remain propagation cuts. */
function adoptOutput(node: Computed<any>, update: Transaction, origin = false, unchanged = false): void {
  const effect = node as Computed<any> & {
    _modified?: boolean;
    _boundRunEffect?: (type: number) => void;
    _type?: number;
  };
  if (effect._type) preparingEffects.add(node);
  // A lower notification cannot change an already selected upper context.
  // Its normal re-pass will read the lower update's committed value.
  if (!origin && node._config & CONFIG_HELD && positionOf(txOf(node)) > positionOf(update)) return;
  const frame = unpublishedFrame(node);
  if (!origin && frame && positionOf(frame) < positionOf(update)) {
    staleReader(node, update);
    return;
  }
  const boundary = boundaries.get(node);
  if (!origin && boundary && boundary.override !== NOT_PENDING) return;
  // A retained child still displays its owner's committed frame. Adoption by
  // an independent output update must bypass the ordinary removal deferral,
  // just as the legacy engine's independently published notifications do.
  if (node._flags & REACTIVE_ZOMBIE) node._flags |= REACTIVE_LANE_DIRTY;
  const transferredProposal =
    (node._pendingValue !== NOT_PENDING || node._statusFlags & (STATUS_PENDING | STATUS_ERROR)) &&
    (!(node._config & CONFIG_HELD) || txOf(node) !== update);
  if (
    node._pendingValue !== NOT_PENDING &&
    positionOf(node._config & CONFIG_HELD ? txOf(node) : null) !== positionOf(update)
  ) node._config |= CONFIG_PREVIOUS_COMMITTED;
  if (effect._modified && effect._boundRunEffect) {
    update._queues[effect._type! - 1].push(effect._boundRunEffect);
  }
  holdNode(node, update);
  // A previously computed proposal may compare equal on its next pass, and
  // repeated status propagation may short-circuit. Its consumers must still
  // follow that existing proposal/status into this update.
  if (transferredProposal && !unchanged) insertSubs(node);
  else if (transferredProposal) {
    // First selection can move an already calculated, identical proposal
    // into its output context. Preserve that work when every other read is
    // settled; a changed/held sibling input still requires a fresh pass.
    // Owned subtrees require their own frame transfer and are not reused here.
    for (let edge = node._subs; edge; edge = edge._nextSub) {
      const reader = edge._sub;
      let preserve =
        !reader._firstChild &&
        !(reader as any)._type &&
        !(reader._statusFlags & STATUS_ERROR) &&
        (!(reader._statusFlags & STATUS_PENDING) || !!reader._x?._inFlight);
      if (preserve) {
        for (let dependency = reader._deps; dependency; dependency = dependency._nextDep) {
          if (dependency._gen !== reader._depGen || dependency._dep === node) continue;
          const source = dependency._dep as Computed<any>;
          if (
            (source._pendingValue !== NOT_PENDING && !Object.is(source._pendingValue, source._value)) ||
            source._statusFlags & STATUS_PENDING
          ) {
            preserve = false;
            break;
          }
        }
      }
      adoptOutput(reader, update, false, preserve);
      if (!preserve) enqueueSub(reader);
    }
  }
}

/** Transfer context along value and status notifications. An unchanged
 * memo is a propagation stop for optimistic updates just as for ordinary ones. */
function notifyLayer(source: Signal<any>, reader: Computed<any>): void {
  if (!(source._config & CONFIG_HELD)) return;
  const update = txOf(source);
  if (isChildUpdate(update)) adoptOutput(reader, update);
}

function ownLayerUpdate(layer: Layer<any>, update: Transaction, input: Transaction | null) {
  layer.update = update;
  resolveTx(update)._level = layer.position ?? 1 + layerPosition(layer.input);
  active.add(layer);
  if (input !== null && input !== update) watchParent(input);
}

export function stageLayer(layer: Layer<any>, proposal: unknown, position?: number): void {
  const inputHolder = inputUpdate(layer);
  const selecting = layer.override === NOT_PENDING;
  // Snapshot the context at the new proposal. A subsequently discovered input
  // dependency cannot promote this existing override or split its peer joins.
  layer.position = position ?? 1 + Math.max(layerPosition(layer.input), positionOf(inputHolder));
  layer.override = proposal;
  layer.inputTime = inputTime(layer.input);
  enableReads();
  // Selecting an equal, settled scalar output has no downstream proposal.
  // In particular a newly allocated pending observation must not replay its
  // consumers just to install its initial false selector.
  if (
    inputHolder === null &&
    !(layer.output._config & CONFIG_HELD) &&
    layer.output._pendingValue === NOT_PENDING &&
    proposal !== NOT_PENDING &&
    layer.output._equals &&
    layer.output._equals(layer.output._value, proposal)
  ) {
    enqueueSub(layer.output);
    return;
  }
  const previous = layer.update && liveTx(layer.update);
  // A correction may have merged the old output back into its input. A new
  // guess needs a new cut, rather than reusing that now-lower update.
  const update =
    previous &&
    previous !== inputHolder &&
    isChildUpdate(previous) &&
    positionOf(previous) === layer.position
      ? previous
      : newTransaction(false);
  ownLayerUpdate(layer, update, inputHolder);
  const output = layer.output;
  const unchanged = selecting && Object.is(
    output._pendingValue !== NOT_PENDING ? output._pendingValue : output._value,
    proposal
  );
  adoptOutput(output, update, true, unchanged);
  enqueueSub(layer.output);
}

function forgetFinishedUpdate(update: Transaction): void {
  if (!liveTx(update)) candidateUpdates.delete(update);
}

function forgetFinishedLayer(layer: Layer<any>): void {
  if (!liveTx(layer.update!)) {
    layer.update = null;
    active.delete(layer);
  }
}

function selectProposal(proposal: unknown, layer: Layer<any>): void {
  layer.override = proposal;
  layer.position = undefined;
}

function positionProposal(_proposal: unknown, layer: Layer<any>): void {
  layer.position = 1 + Math.max(layerPosition(layer.input), positionOf(inputUpdate(layer)));
}

function applyProposal(proposal: unknown, layer: Layer<any>): void {
  if (!(layer.output._flags & REACTIVE_DISPOSED)) stageLayer(layer, proposal, layer.position);
  if (layer.opening) {
    resolveTx(layer.scope!)._open--;
    layer.opening = undefined;
  }
}

function settleLayers(): void {
  if (!candidateUpdates.size && !active.size && !proposals.size && !scoped.size) {
    settleObservations?.();
    stopIfIdle();
    return;
  }
  candidateUpdates.forEach(forgetFinishedUpdate);
  if (!candidateUpdates.size) {
    if (!active.size) setLayerCompute();
    // A later ordinary write can create a hold beneath an already published
    // override. Enable order-independent discovery once that hold exists.
    if (scoped.size && hasHeldNodes()) {
      for (const layer of scoped) if (layer.scope) watchParent(resolveTx(layer.scope));
    }
  }
  active.forEach(forgetFinishedLayer);
  // First propagate value proposals. Their pending outputs describe the
  // resulting work, just as they do after an ordinary write's pure phase.
  // Staging both at once would merge a status update with the input update
  // it is meant to observe independently.
  if (proposals.size) {
    // Select all boundaries before assigning the new contexts, so simultaneous
    // nested guesses do not depend on setter order. Existing proposals outside
    // this batch keep their context, including across new parent activation.
    proposals.forEach(selectProposal);
    proposals.forEach(positionProposal);
    proposals.forEach(applyProposal);
    proposals.clear();
    return;
  }
  settleObservations?.();
  stopIfIdle();
}

export function createLayer<T>(
  input: T | ((previous: NoInfer<T> | undefined) => T | PromiseLike<T> | AsyncIterable<T>),
  options?: { lifetime: "action"; node?: NodeOptions<T> }
) {
  // The producer records each input evaluation. Equality belongs at the
  // output: an answer equal to an earlier input may still replace a guess.
  // Keep this computation even for a source accessor: refreshing the boundary
  // must re-read its input, not invalidate that input's own computation.
  const config = options?.node;
  const producer = (typeof input === "function"
    ? computed<T>(input as (previous?: T) => T, { ...config, equals: false, unobserved: undefined })
    : signal<T>(input, config)) as Computed<T>;
  const layer = createLayerBoundary<T>(producer, undefined, undefined, true, config?.lazy, config);
  layer.output._config &= ~CONFIG_AUTO_DISPOSE;
  layer.inputStatus = true;
  return layerAccessors(layer, options);
}

function selectLayer<T>(
  layer: Layer<T>,
  fallback: ((layer: Layer<T>) => T) | undefined,
  onEvaluate: ((layer: Layer<T>) => void) | undefined
): T {
  const producer = layer.input;
  onEvaluate?.(layer);
  if (
    layer.scope !== null &&
    layer.override !== NOT_PENDING &&
    !(producer._statusFlags & STATUS_PENDING) &&
    inputTime(producer) !== layer.inputTime
  ) {
    // An input answer joins the guessing actions, but the selector stays
    // overridden until their shared lifetime ends. Intermediate answers
    // must not start downstream work beneath the selected guess.
    const scope = liveTx(layer.scope);
    if (scope) {
      if (producer._config & CONFIG_HELD) merge(txOf(producer), scope);
      // A ready input can still be an unparked proposal in this flush.
      // Couple that input frame, not an independently preparing override.
      if (!layer.update || liveTx(layer.update) !== flushTransaction) joinFuture(scope);
    }
    // The pre-commit phase releases the group once all its inputs are ready.
  }
  if (layer.override === NOT_PENDING) return fallback ? fallback(layer) : read(producer);
  // Choosing an override subscribes to the input's changes, but does not
  // consume its proposal. No other read in the graph has this exemption.
  // The subscription keeps input work current without making readers of the
  // override hold the update producing that input. Correction rejoins normally.
  link(producer, layer.output);
  return layer.override as T;
}

/** Internal construction shared by guesses and observations. */
export function createLayerBoundary<T>(
  producer: Computed<any>,
  fallback?: (layer: Layer<T>) => T,
  onEvaluate?: (layer: Layer<T>) => void,
  ownInput = true,
  lazy = false,
  options?: NodeOptions<T>
) {
  if (ownInput) producer._config &= ~CONFIG_AUTO_DISPOSE;
  const layer = {
    input: producer,
    override: NOT_PENDING,
    update: null,
    scope: null,
    inputTime: inputTime(producer)
  } as Layer<T>;
  // Bind the shared selector instead of retaining a constructor closure and
  // its captured producer, callbacks and layer. Only boundaries pay this cost.
  const output = computed<T>((selectLayer<T>).bind(null, layer, fallback, onEvaluate), {
    name: options?.name,
    equals: options?.equals,
    unobserved: options?.unobserved,
    lazy,
    sync: true,
    _extraConfig: CONFIG_REDERIVE
  });
  if (!lazy) output._config &= ~CONFIG_AUTO_DISPOSE;
  layer.output = output;
  boundaries.set(output, layer);
  if (!boundaries.has(producer)) boundaries.set(producer, null);
  return layer;
}

function releaseLayer(layer: Layer<any>): void {
  if (layer.opening && layer.scope) resolveTx(layer.scope)._open--;
  layer.opening = undefined;
  scoped.delete(layer);
  if (!scoped.size) setLayerBlocked();
  active.delete(layer);
  proposals.delete(layer);
  layer.scope = layer.update = null;
  // Disposal can be the last event while an input is permanently pending.
  // Prune finished update references and disable idle hooks without requiring
  // an unrelated future write to visit the disposed boundary.
  wakeLayers();
}

function bindScope(layer: Layer<any>, scope: Transaction): void {
  if (layer.scope) merge(scope, layer.scope);
  layer.scope = resolveTx(scope);
  // Incoming input proposals share the override's lifetime; the selected
  // output retains its independent publication update until correction.
  if (layer.input._config & CONFIG_HELD && !(layer.input._statusFlags & STATUS_PENDING))
    merge(txOf(layer.input), layer.scope);
  scoped.add(layer);
  setLayerBlocked(pendingScope);
}

function layerAccessors<T>(layer: Layer<T>, options?: { lifetime: "action" }) {
  const output = layer.output;
  if (options?.lifetime === "action") layer.automatic = true;
  const propose = (value: T | ((previous: T) => T)) => {
    const pending = proposals.get(layer);
    const previous =
      proposals.has(layer) && pending !== NOT_PENDING
        ? pending
        : layer.override !== NOT_PENDING
          ? layer.override
          : output._pendingValue !== NOT_PENDING
            ? output._pendingValue
            : output._value;
    const next = typeof value === "function" ? (value as (v: T) => T)(previous as T) : value;
    if (output._flags & REACTIVE_DISPOSED) return next;
    if (layer.automatic) {
      const scope = flushTransaction ?? (layer.scope && liveTx(layer.scope));
      if (scope) bindScope(layer, scope);
    }
    output._cleanup ??= releaseLayer.bind(null, layer);
    proposals.set(layer, next);
    wakeLayers();
    return next;
  };
  const clear = () => {
    proposals.set(layer, NOT_PENDING);
    wakeLayers();
  };
  const accessor = () => read(output);
  (accessor as any)[$REFRESH] = output;
  return [accessor, propose, clear] as const;
}
