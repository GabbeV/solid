from pathlib import Path
import subprocess,json
root=Path('/workspace/scratch/manual-held-errors-20261113');r=root/'runtime/packages/signals'; src=r/'src'
files={'scheduler-current.ts':src/'core/scheduler.ts','projection-current.ts':src/'store/projection.ts','store-current.ts':src/'store/store.ts','static-current.ts':src/'store/optimistic-static.ts','optimistic-current.ts':src/'layers/optimistic.ts'}
for mode in ['current','no-list-resolve','no-projection-stage','no-parent-selector','no-array-static-guard']:
 for a,b in files.items(): b.write_text((root/a).read_text())
 if mode=='no-list-resolve':
  p=src/'core/scheduler.ts';s=p.read_text().replace('  t = resolveTx(t);\n  if ((n as Computed<any>)', '  if ((n as Computed<any>)');p.write_text(s)
 if mode=='no-projection-stage':
  p=src/'store/projection.ts';s=p.read_text();i=s.index('          // A first async answer held');j=s.index('          // A landing (not the sync',i);s=s[:i]+s[j:];p.write_text(s)
 if mode=='no-parent-selector':
  p=src/'store/optimistic-static.ts';s=p.read_text();i=s.index('      () => {\n        if (Array.isArray(t.v)) readArrayStructure(t);\n        // A published descendant');j=s.index('\n    );\n    if (input !== node',i);s=s[:i]+s[j:];s=s.replace('          : undefined),\n\n    );','          : undefined)\n    );');p.write_text(s)
 if mode=='no-array-static-guard':
  p=src/'store/optimistic-static.ts';s=p.read_text().replace('        if (Array.isArray(t.v)) readArrayStructure(t);\n','');p.write_text(s)
 proc=subprocess.run(['node','../../node_modules/vitest/vitest.mjs','run','tests/latest-store-held-manual-write.test.ts','tests/optimistic-held-error-untracked-read-4489.test.ts','--reporter=json','--outputFile='+str(root/(mode+'.json'))],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (root/(mode+'.log')).write_text(proc.stdout)
 try:
  j=json.load(open(root/(mode+'.json')));print(mode,j['numPassedTests'],j['numFailedTests'],flush=True)
 except Exception: print(mode,proc.stdout[-1500:],flush=True)
