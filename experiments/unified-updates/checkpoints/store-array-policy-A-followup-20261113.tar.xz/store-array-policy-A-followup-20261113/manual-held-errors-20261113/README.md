# Manual latest held write and repeated error triage — 2026-11-13

## latest-store-held-manual-write

Both failures reflect the approved initial-write discard rule. The ordinary derived store has no commit zero when action sets manual=true. After its first async answer, final states are count1/manualfalse for an existing key and count1/manualmissing for a new key. The first screen remains withheld until the action ends. No runtime fix required.

Migrated the two preinitial test expectations and added two initialized controls: first commit count0, then new pending input plus separate held manual write; count1/manualtrue must wait for actionend. All four pass. No artificial loadingValue option was introduced.

## optimistic-held-error-untracked-read-4489

This is an array test. The ordinary createEffect publishes both errors correctly. Only createErrorBoundary screen stays at ERR declined instead of ERR declined again.

Isolated ablation matrix (original tests unchanged):
- current: 0/3 pass (two initial manual expectations, one repeated boundary error)
- no-list-resolve: 0/3; same failures
- no-projection-stage: 0/3; same failures
- no-parent-selector: 1/3; repeated boundary error fixed
- no-array-static-guard: 1/3; repeated boundary error fixed

The decisive last ablation removes ONLY `if (Array.isArray(t.v)) readArrayStructure(t)` from the parent value selector. This identifies the new array context guard, rather than scheduler list canonicalization or first-answer driver staging.

Trace in error-boundary-trace.log: at the second error the boundary tree/output remain STATUS_PENDING with held contexts open0, while its error signal still contains the first declined error. Ordinary error effect has already received declined again. Dependency trace saved separately.

Array incoming agent confirmed the guard read active length output too broadly and owns the runtime refinement. No runtime change for this error was made by pending_rule_fix agent.

ablations.py contains exact variants and runner; per-variant JSON/log files preserve outputs. Main test change is only latest-store-held-manual-write.test.ts.
