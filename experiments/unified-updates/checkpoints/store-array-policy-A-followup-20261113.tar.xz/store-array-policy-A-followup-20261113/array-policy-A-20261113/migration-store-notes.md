# Remaining store-suite triage

Scope: packages/signals/tests/store/createOptimisticStore.test.ts, tests/optimistic-keyed-fold.test.ts, tests/store/optimistic-chained-revert-3672-memo.test.ts. No runtime changes.

Five initial-trial newly failing cases were migrated under approved array rule A:

1. Separate source landing beside appended row: pending frame now retains Issue 0 A/B + Optimistic, then atomically reveals Issue 1 A/B at append retirement. Intermediate-frame assertion strengthened from accepting either question to requiring original selected question throughout the hold.
2. Draft-mutating producer version: same membership/append coordination and stronger intermediate-frame assertion.
3. Producer continuation after held replacement: continuation pushes 7 and therefore joins active append/held replacement; mid-hold expected [1,2], final [1,5,7] unchanged, including snapshot assertion.
4. Mainline truth longer than a reverse guess: incoming tail growth joins active permutation; mid-hold expected [b,a], final [b,a,s] unchanged. All length, key-presence, no-hole, direct/memo coherence, frame-order, mount and unmount assertions retained.
5. Chained source pop under append: the incoming base shrink itself joins the structural lifetime; base retains [a,b]. The subsequent optimistic pop selects complete [a,b] with memo a,b|2 until action ends; final base/view [a] with memo a|1. Removed old comment explicitly expecting a hole and replaced weak length/first-element checks with full base/view IDs, exact own index keys, and memo equality. Added checks immediately after source pop, before action continuation, to prove base remains complete and view retains a,b,c|3.

Verification:
- migration-store-before.json: 83 passed / 12 failed across three files.
- migration-store-after.json: 88 passed / 7 failed. Remaining seven exactly match baseline failing test names in signals-baseline.json; no new failures remain.
- migration-store-targeted.json: all six targeted cases passed (includes both in-action/mainline longer-reorder variants).

Seven baseline failures were deliberately left untouched. They are all in optimistic-keyed-fold.test.ts and all depend on the deferred until API. Three report its explicit integration-deferred error directly; the overlapping-push/nested/foreign-row and unpublished-guess cases can fail earlier assertions after the same unsupported API prematurely ends the action. Baseline confirms these same seven test names fail before rule A. This task neither changes until nor changes their coherence/identity assertions; they do not require a new array semantic ruling from this evidence.

No additional semantic ruling required for the five migrations. No commits by this task.
