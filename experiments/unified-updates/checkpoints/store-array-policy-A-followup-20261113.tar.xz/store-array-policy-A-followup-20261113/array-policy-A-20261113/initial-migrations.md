# Assigned preinitial store test migrations

Only test changes; no runtime changes.

- `unified-optimistic-store-before-first.test.ts`: store proposals are discarded, callback executes once, written and untouched seed keys remain hidden, and first input cannot publish before the writing action ends. Both input/action orders and array mapping remain tested. Scalar optimistic first guesses retain their original tests and assertions.
- `unified-cold-store-companion.test.ts`: three cold initial surfaces now require no proposal or seed publication and exactly the first real answer at completion. The first-guess consequence test additionally proves a discarded proposal starts no async consequence. Existing tests of an already published whole-parent guess retain their body and lifetime assertions through explicit `seedLoadingValue: true` commit #0 controls; titles and a comment state this prerequisite. Other initialized, errored, and held-source scenarios remain intact.
- `unified-store-parent-query-context.test.ts`: the uninitialized branch verifies discard/loading, then continues the original initialized parent/captured-child selected context scenario after the first answer publishes. The initialized branch remains intact.
- `unified-store-structural-source.test.ts`: initial added-property proposals never enter keys/deep output; the first real shape waits for action completion. Twelve-cycle initialized disposal/correction tests remain intact.

Validation `initial-migrations-{dev,prod}.json`: 26 passing / 2 intentionally unselected tests in both tiers across four files. The unselected cases are the unchanged `a cold latest index reads a held producer answer through its new companion` pair (`preread=false/true`). Their current latest length is 3 while their existing assertion expects 4; this is the array structural selector/latest work owned by the incoming-array agent, who was notified. The tests were not removed or weakened.

Patch: `initial-migrations.patch`. No commits by this agent.
