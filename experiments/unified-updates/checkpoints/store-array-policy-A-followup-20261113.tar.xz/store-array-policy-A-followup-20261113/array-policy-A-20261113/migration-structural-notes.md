# Six-file structural test migration

Approved rule A: value-only writes at existing indices remain independent. Length, index presence, keyed membership/order and permutations coordinate the whole update with active/future edits and incoming structure. Traversal creates no implicit vouch.

Reviewed changes:
- optimistic-sparse-independent-array: 18 source-shrink cases retain dense A/M until structural owner settles; six direct-growth retirement cases behave like push and retain A/M until both structural owners settle. Reader coherence and presence assertions remain. Added six mode/wrapper controls proving disjoint existing-index value writes settle independently, with ordinary saved flags settling on their own update lifetimes.
- unified-store-correction-layout-review: incoming shrink joins active append; selected frame retains dana/mine. Strengthened entire frame history to forbid absent/undefined rows and require direct/memo agreement.
- unified-store-keyed-row-boundary and unified-store-positional-row-boundary: incoming sibling membership waits behind active append and appears at retirement. Retained row identity assertion.
- store/deep-held-visibility: incoming array truth joins append; key/deep/snapshot families retain complete optimistic frame then reveal truth together. Reader-family equality assertions unchanged.
- store/unchanged-presence-no-hold-3743: incoming membership under append and later growth under swap retain complete selected frame until structural lifetime settles. Effect/snapshot equality retained. Object-presence/value tests untouched.

Additional two held-replacement failures were initially left unchanged and reported to root. Root explicitly authorized migration under the prior #4677 ruling: optimistic derivations never define their own lifetime. Traces now explicitly assert first/derived0 before action end, server/derived0 at action end, server/tick1 with derived0 after unrelated rerun, and late secondAnswer20 ignored. Unpublished optimistic work does not extend an ended action; the ready correction publishes coherently. Before-end first-frame expectations remain and now also assert derived0.

Receipts:
- migration-structural-before.json: initial owned run, 30 failed / 32 passed.
- migration-structural-after.json: structural migrations plus six controls, 66 passed / 2 failed.
- migration-structural-held-replacement.json: isolated reproduction of the two then-unmigrated held-replacement cases.
- migration-structural-final.json: complete six-file run, 68 passed / 0 failed, including saved flags and root-authorized retirement behavior.
- migration-structural-retirement.json: targeted rerun after strengthening before-end paired assertions.

No runtime edits or commits by this task.
