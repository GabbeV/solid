# Additional structural lifecycle assertions

Main test file: packages/signals/tests/unified-array-structural-lifecycle.test.ts
Validation: 6/6 passing, source build typecheck exit 0.

Command (packages/signals cwd): node node_modules/vitest/vitest.mjs run tests/unified-array-structural-lifecycle.test.ts --reporter=verbose
Typecheck command (repository cwd): node node_modules/typescript/bin/tsc --noEmit --emitDeclarationOnly false -p packages/signals/tsconfig.build.json

The copied test file records exact assertions on whole callback histories:
- Async chained answer before/during pending: ordinary inner source publishes only [A,B] while guess active; selected outer publishes [A,B], then [A,M]. After guess gate closes source publishes [], outer becomes [].
- Pending structural input before first direct guess, direct and chained: releasing input action first leaves ordinary input callback history exactly [[A,B]], and selected output history [[A,B],[A,M]]. Releasing edit publishes [] on source.
- Pure length-only growth with no output readers, direct and chained: incoming [] remains unpublished until guessed resize closes; ordinary source callback history [[A]] then [[A],[]].

These tests use public API and render-effect callbacks. No implementation introspection or cleanup test was added because this assignment did not establish a useful public count helper that could prove guard cleanup without mirroring implementation.
