import { appendFileSync } from "node:fs";
import { it, expect } from "vitest";
import { createOptimisticStore, createStore, createRoot, flush, NotReadyError } from "test-signals";
it("chained array push reads unresolved length before any mutation", async () => {
  const answer = Promise.withResolvers<string[]>();
  const [setOuter, dispose] = createRoot(dispose => {
    const [child] = createOptimisticStore(() => answer.promise, []);
    const [, setOuter] = createStore(() => {}, { child });
    return [setOuter, dispose] as const;
  });
  let calls=0, threw=false;
  try {
    flush();
    try { setOuter(draft => { calls++; draft.child.push("discarded"); }); }
    catch(error) { threw=error instanceof NotReadyError; if(!threw)throw error; }
    appendFileSync(process.env.RECEIPT!, JSON.stringify({calls, threw})+"\n");
    expect(calls).toBe(1); expect(threw).toBe(true);
  }finally { answer.resolve(["answer"]); await new Promise(r=>setTimeout(r,0)); dispose(); flush(); }
});
