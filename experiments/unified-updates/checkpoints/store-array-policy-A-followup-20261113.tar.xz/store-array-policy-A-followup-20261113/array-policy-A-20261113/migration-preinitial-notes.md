# Scoped preinitial migrations

Explicit ruling from root: setters before initial load discard proposals but entangle with the initial load. Seed and guess remain unpublished; first answer waits for the open action. Existing observedness rules remain unchanged.

Only two files edited:

- tests/optimistic-list-push-filter-push-4642.test.ts: renamed/commented the preinitial add case. After initial list resolves while save remains pending, now requires empty screen/cell list, loaded false, and untracked read throwing NotReadyError. Removed old per-slot jam/eggs frame expectation. Final milk/eggs/jam frame and IDs, untracked agreement, and error-free assertions retained. Existing initialized push/filter cases unchanged; all 13 tests pass.
- tests/unified-store-length-source.test.ts: push and resize both discard their preinitial writes. Both require no published length and direct NotReady before first answer; first answer still does not publish while action open; final length 2 publishes at action end. Added initialized push and resize controls, both expecting optimistic length 3 until action end and final 2. Both initialized controls pass.

Validation:
- migration-preinitial-before.json: 12 passed / 3 failed.
- migration-preinitial-after.json: 15 passed / 2 failed.

Runtime issue retained and escalated to root/initial agent: both preinitial length cases mount a reader AFTER discarded setter but BEFORE initial answer resolves. That reader publishes seed length 0 immediately, failing expected empty output. Existing preinitial not-ready/seed visibility semantics require no seed publication, so these assertions were not migrated. Initial answer timing after that assertion remains unverified by these two cases until runtime fix; separate initial-agent tests own related lifecycle coverage.

No runtime edits. Did not edit uninitialized-visibility.test.ts or initial-store-write-coordination.test.ts. No commits by this task.
