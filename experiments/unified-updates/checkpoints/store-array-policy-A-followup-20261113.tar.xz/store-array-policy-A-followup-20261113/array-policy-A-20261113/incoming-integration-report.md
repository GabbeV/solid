# Incoming structural array coordination, 2026-11-13

Initial assignment investigated without main edits; root subsequently authorized optimistic-static.ts ownership and incoming integration. No core/graph/scheduler/store/reconcile runtime edits required by this agent.

## Result

Implemented static incoming integration against the setter agent's shared `arrayStructureChanged`, `joinArrayIncoming`, and `resetArrayWrites` APIs.

- `pair` checks a raw nonchained target's committed input before reconcile adopts the incoming backing, and before derived drafts notify truth slots. Structural updates join every active direct owner via `joinFuture`, with the array module retaining ownership-only structural barriers for later setters.
- Every actively edited array has one intrinsic tracked raw-container guard. It pulls its family producer, reads its store-owned container node, and follows internal `$TARGET` chain boundaries recursively. Thus a derived store returning another store proxy has an actual input dependency even without application readers.
- The guard retains exact raw descriptors as comparison metadata, including initial published raw input when a producer is already pending. This metadata is never served as output and confers no optimistic ownership of unchanged values.
- Guard creation and retention include length-only resize/floor ownership. Guards retire once direct slots and length ownership become idle. Scalar reads acquire no guard work.
- Chained targets skip the `pair` comparison because their backing is another proxy. Their guard compares resolved raw producer bodies instead of reading selected proxy properties.

The shared array classifier is owned by the setter agent; it includes length, index presence, descriptors, keyed identity membership/order, and nontrivial same-multiset permutations. Replacement of an existing unkeyed value remains independent unless the whole update is a rearrangement.

## Why the hook suffices

A family derive is eager and retains dependencies with AUTO_DISPOSE cleared. `insertSubs` queues it even with no output subscribers, so signal -> memo -> family incoming structural answers reach `pair` in the same pure flush before source publication. No broad source graph listener is necessary for this path. The missing dependency is a derived store returning a stable store proxy; raw container guards close that path while active direct array edits exist.

`entangleOptimisticSlotRead` is a setter helper requiring an existing `flushTransaction`; using it at incoming `pair` misses ambient `setInput`. The first bounded scratch trial demonstrated this failure. `joinFuture(owner)` fixes both ambient and action-wrapped incoming updates.

## Validation

`incoming.test.ts` against main source: 15/15 passing assertions.

- signal, derived memo, chained optimistic store incoming shrink, each with no output reader / late output reader / full output reader (9).
- asynchronous chained answer with direct guess created before pending and during pending (2).
- held structural input action before the first direct guess; input action releases first; direct and chained (2). Source remains old until the new guess closes even with the array helper declining inactive marker creation.
- length-only direct resize over a chained or direct input, no output readers (2).

Assertions check actual render-effect callback publications of the ordinary input and/or inner source array, not merely speculative computation bodies. Async probes check the inner source array and selected outer array retain their prior coherent frame until the guessed edit closes; they do not claim that an earlier request parameter must remain unpublished before the answer shape is known.

`tsconfig.build.json` source typecheck passes. Full `tsconfig.json` reports existing test diagnostics; no source diagnostics appear in `types.log`.

Earlier bounded isolated copy: `trial2.jsonl` records successful source holding for absent/late observers and two-owner support withdrawal after replacing the setter merge helper with `joinFuture`. That copy predates final floor integration, so its push display frames are not a claim about final output correctness.

## Remaining scope

No semantic blocker established by these probes. Root and the independent test agent own the broader structural matrix, keyed/permutation coverage, ordinary-store chains, and final review. Async unknown future output topology cannot be classified until its answer exists; this implementation holds the structural landing transaction, not an already published unrelated request parameter. No guarantee about such an earlier parameter is claimed here.
