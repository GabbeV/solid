# Selected array latest structure investigation

## Final runtime change

The selected view of an actively edited array composes over its selected structure output, rather than whichever raw container the caller's read window supplied. Unoverridden value, presence, descriptor shape, and container outputs establish an ordinary dependency on active array length/structure outputs before reading strict input. An untracked first read lets the existing shared coordinator discover the selected context and retry before consuming a lower proposal; the following tracked read retains notification dependencies. Initial structural writes and incoming structural answers invalidate the array's already existing direct selected outputs so they establish these dependencies before later incoming input arrives.

This does not guess or retain unchanged element contents. It reads the committed lower input in the array's output context through the existing coordinator. Strict input status remains the pending authority. No generic latest filtering or graph changes were added.

## Causal evidence and controlled ablations

1. Baseline published ordinary [dana,mine] beside latest [absent,mine] when lower input proposed [].
2. Reading a structural output inside value/presence selectors alone did not fix the failing descriptor composition path. Instrumentation showed a context0 attempt returning undefined/false followed by a context1 attempt correctly returning dana/true.
3. In the early untracked-read variant the selectors returned only dana/true, yet latest still produced the hole. Instrumenting latest._sample showed it sampled raw container [dana] -> []; it did not sample a bad value/presence selected output at that failure. getOwnPropertyDescriptor's untracked path passed that raw proposed container into selectedView; composition added guessed index1 over an empty base.
4. Routing selectedView's base through structureSlot fixed the initial latest regression. Removing value/presence context reads then yielded absent/undefined at index0, proving the structure route alone was insufficient.
5. Removing initial structural discovery and the existing length dependency seemed to preserve final direct latest samples, but stronger all-publication tests caught transient holes at incoming source update and memo chains retained the bad proposal. Reinstating the full initial length+structure context registration fixed every tested publication in all nine latest fixtures (root/nested, direct indices, descriptors/enumeration, memo chain, async memo).

No failed trial code or instrumentation remains in main. Failed patches and debug logs are retained here.

## Validation

- Main targeted run: 16 files, 274 passing, 8 historical #4336 no-op callback-history expectations failed. Their observed values remained coherent; the migration owner is updating those expectations separately.
- All 61 structural/setter/dependency tests plus eight latest-reader variants pass after recording the exact newly repeated lifecycle frame.
- The two async lifecycle tests now record exact callback histories [initial, selected, selected, corrected]. A separate phase receipt proves the additional selected frame occurs when the ready structural landing establishes the shared output context, not while the request is merely pending. Every callback is complete; no once-only callback contract is asserted for fresh arrays. The assertion still preserves every frame, including the duplicate, and the final complete correction.
- Source tsconfig.build.json typecheck passes; formatting is clean.

Logs: main-targeted.log, readers-full-context.log, lifecycle-frames.log, typecheck.log.

## Costs and limits

Structural activation visits only this array's existing direct selected slot maps. An active selector reads up to two structural outputs twice (context discovery plus dependency tracking), using one closure and no temporary array. An inactive selector creates no such closure or dependency. Scalar store selector evaluation adds only an array check; scalar read paths and the core graph are unchanged. Shape/container companions now carry a selected-input callback. Full suite, bundle size, and benchmark acceptance remain root's responsibility.
