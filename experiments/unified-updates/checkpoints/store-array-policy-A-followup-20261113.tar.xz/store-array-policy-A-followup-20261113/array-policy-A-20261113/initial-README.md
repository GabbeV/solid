# Initial unpublished store writes — implementation receipts

User ruling: setters before the initial load discard proposed values but retain ordinary write coordination with their actual input producer. No initial seed becomes public. Existing observedness still controls whether an unobserved unfinished input holds other work after the action body ends. `seedLoadingValue: true` remains explicit commit #0.

Implemented in `/workspace/layered-solid`:

- `store.ts`: resolve the unresolved producer through the actual backing chain; merge prior ownership and hold that producer without proposing any value. Ordinary chained clone failures discard only that child's mutation (excluding ContextRetry and later pending/refetch), so other setter writes and one callback execution survive. Ordinary initial root drafts temporarily save/restore their backing and draft metadata, including a staged first answer, then discard and entangle. Returned replacements use the same initial ownership rule. A discarded write must not materialize a seed-only held leaf. Initial firewalls track their pending/initial producer, and an uninitialized producer is excluded from the stale render reader exception.
- `optimistic-static.ts`: the initial writes hook checks before composing/proposing slots, restores the saved backing, and entangles the actual producer. There is no surviving mutation-intent map to clear in the current array implementation. This small hook was included in checkpoint `1bc854293`; other static selector/array edits belong to other agents.
- `async.ts`: a held store's successful first answer stays uninitialized until actual commit. Its own pending status still clears through the ordinary landing machinery, allowing eager preparation.
- `projection.ts`: an actual held first async answer stages the same successful driver control value (`owner`) as the synchronous projection pass. Without this, a held initial driver had no staging, an untracked key could leak the first answer, and a settle diagnostic correctly detected no staged driver truth. This stages only after a real successful first answer, never at the discarded write.
- Scheduler `list` canonicalization, owned by the pending-rule agent, fixes a separately exposed lifecycle bug: born-held late bindings could append into an already absorbed transaction's emptied list and never publish. See `/workspace/scratch/initial-late-hold-trace-20261113/`.

Final targeted validation:

- `initial-final-dev.json`, `initial-final-prod.json`: 3 suites / 33 tests passed in each tier (24 initial coordination tests, one actual DOM test, 8 existing initial visibility tests).
- `initial-existing-after-control.json`: 13 files / 88 tests passed after the driver control fix, covering first answers, nested first answers, fresh/mount frames, initial visibility, held render bindings, eager swap identity, initial lane landing, first-load superseded answers, and answered-then-reasked paths.
- Source TypeScript check: `packages/signals/node_modules/.bin/tsc -p tsconfig.build.json --noEmit` passed after the internal driver control cast.
- Actual DOM regression builds answer span `7` eagerly while unattached; existing host and late `b` span remain empty while the action is open, then publish `7` and `8` at completion.
- Matrices cover both answer/action orders; ordinary/optimistic roots; push/replacement; ordinary nested loading child with retained sibling write; two children; repeated writes from two actions; no initial reader and late readers; preservation of observedness; failed setter after first answer stages; failed action; direct setter; explicit seed commit #0; ordinary sync derived setter before its first flush.

Known inherited callback scope, verified rather than broadened:

A chained array callback `draft.child.push('discarded')` can read unresolved `length` before its first mutation and throw NotReady before the clone hook. Both current source and the exact #4810 next-copy `/workspace/scratch/structural-entangle-next-edeb5db09` call the callback once and throw in the same way. See `initial-chained-array-probe.test.ts`, matching configs, and `initial-chained-array-{main,next}.jsonl`. No seed reads are fabricated and no setter callback is replayed to force this read-before-write callback to complete.

Snapshots `initial-{store,async,projection}-final.ts` and `initial-after-checkpoint.patch` preserve this agent's final source state and post-checkpoint changes. Runtime and test changes remain in the shared tree; this agent made no commits.
