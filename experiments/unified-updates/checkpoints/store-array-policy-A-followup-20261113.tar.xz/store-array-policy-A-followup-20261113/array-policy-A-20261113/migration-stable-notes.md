# Stable suite remaining array triage

Approved migrations applied only to held-truth-lane-only.test.ts and optimistic-outside-refetch-619.test.ts in this task.

Held-truth store-fold cases (three): root confirmed that latest of a selected output retains its active append context; latest input may expose producer truth separately. Updated latest selected output to 1,2,3 len3, and added an explicit latest read of the underlying container input expecting 1,2,3,4 len4. The selected output corrects to len4 when action ends. Ordinary user effects likewise consume the full selected context during an unrelated tick: len3 and index3 absent is coherent, since index3 is outside selected length. They publish that tick immediately, then publish len4/index3=4 together on correction. Exact effect histories retained; final truth assertions added for reverse read order.

Router619 extra callback: observed callbacks were exactly original indices, original indices, swapped indices. Instrumentation showed corresponding actual row contexts a:0 b:1 c:2; a:0 b:1 c:5; a:1 b:0 c:5. The second callback therefore represents the explicit c.order=5 leaf edit, despite equal rendered sorted indices. Updated exact history without deduplication and retained a parallel untracked row-context history proving the cause.

Untouched runtime cases escalated to incoming agent:
- shared-question-hold-review store none: native map remains fully selected and producer blocked() becomes false, but filter frame incorrectly stays open. Root explicitly preserved the prior no input-observedness-forwarding rule; unresolved input structural guard may not add a whole future wait. A provisional migration was reverted after this ruling. Original frame and blocked assertions remain.
- store/store-in-store-tracking native map through wrapper: ambient initialized append during refetch fails to show 100 while direct native.map/mapArray siblings do. Original assertions retained for runtime investigation.
- store/unchanged-presence-no-hold-3743 structural append/swap cases: snapshot throws at optimistic-static selectedView while ordinary effect has a complete selected array. Original coherence assertions retained.

Receipts: migration-stable-before.json contains original run including unrelated until-dependent cases; migration-stable-first.json passes all 11 accepted store-fold/router cases; migration-stable-final.json selects non-until scoped cases and retains the four runtime failures. migration-stable-shared.json documents the provisional held-demand broadening failing blocked()==true because actual producer blocked remains false; that broadening is not retained.

No runtime edits or commits by this task.
