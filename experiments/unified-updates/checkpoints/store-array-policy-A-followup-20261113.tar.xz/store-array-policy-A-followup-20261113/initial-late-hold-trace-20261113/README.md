# Initial optimistic first-answer late-mount ownership trace

Read-only tracing used an isolated copy of packages/signals with the main projection/async first-answer trial at snapshot time. No tracing code was copied to main.

Repro: tests/initial-store-write-coordination.test.ts -t 'eagerly calculates held first-answer optimistic'. Actual producer answer resolves while discarded-write action is open. Existing binding calculates7 but does not publish. Late binding calculates8 but originally never published after action end.

## Exact causal trace

trace-stack.json assigns IDs by first trace encounter. Late render is node16; producer driver is node3. Transaction9 absorbs earlier work, then merges9→12→14 while late binding discovers synthetic property inputs. Event87 calls list(node16,transaction9) with transaction9._into12 and resolveTx(transaction9)=14. Absorbed transaction9's list is empty. Event88 appends node16 to that obsolete list. Later txOf(node16) compresses its owner pointer to14 without moving links. Surviving transaction14 commits nodes3,5,1,6,8,10,11,13,15 and never16. Late render stays HELD/UNINITIALIZED with pending8 despite its dependencies committing.

The list-entry stack is core.ts recomputeBody born-held holdNode(el,flushTransaction??passTx), then recomputeInUpdate, coordination scopedCalculation/rerunLayer, and createRenderEffect. This is a general transaction ownership invariant violation: list accepted an absorbed transaction as owner. It is not caused by the parent pending selector or an absent calculated answer.

trace-scope.json adds scope-entry/joinFuture traces; IDs differ because more objects are observed. It independently confirms the same obsolete append.

## Applied main change

Root authorized canonicalizing t=resolveTx(t) at list entry, after dependencyFrame has run in holdNode. layerOwn calls setOutputDepth, which only assigns resolveTx(update)._level and does not merge or execute user code. Ordinary nonheld paths do not call list.

Main command (main-canonical-targeted.log):

    cd /workspace/layered-solid/packages/signals
    node ../../node_modules/vitest/vitest.mjs run tests/initial-store-write-coordination.test.ts tests/born-held.test.ts tests/unified-mount-frame.test.ts tests/unified-fresh-mount.test.ts tests/render-mount-held-binding.test.ts tests/mount-over-foreign-hold-3761.test.ts tests/stale-read-uninitialized-cross-transition.test.ts tests/fresh-boundary-born-held-reader.test.ts tests/unified-store-pending-derived-parent.test.ts

Result: 9 suites / 63 tests passed, including optimistic late initial-answer mount. git diff --check clean.

Natural nonstore async scalar memo-chain and nested-created-memo probes at depths1/2/3 passed even before canonicalization (scalar-probe.log, scalar-nested-probe.log). They were exploratory only and were not copied into main as nonregression tests. The real initial optimistic store case provides failing-before/passing-after coverage.
