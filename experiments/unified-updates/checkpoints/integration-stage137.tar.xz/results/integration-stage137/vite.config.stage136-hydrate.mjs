import { mergeConfig } from "vitest/config";
import config from "./vite.config.hydrate-local.mjs";
export default mergeConfig(config, {
 resolve: { alias: { "@solidjs/signals": "/workspace/scratch/unified-stage136-control/packages/signals/dist/dev.js" } },
 test: { server: { deps: { inline: ["solid-js", "@solidjs/signals"] } } }
});
