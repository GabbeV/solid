import {it,expect} from "vitest";
import {createSignal,createMemo,createRoot,createErrorBoundary,createLoadingBoundary,flush} from "../src/index.js";
import {$REFRESH,CONFIG_HELD,NOT_PENDING,CONFIG_STAGED_ERROR} from "../src/core/constants.js";
it("repeat",async()=>{
const [count,set]=createSignal(0);const requests:any[]=[];let data:any,view:any;
createRoot(()=>{
data=createMemo(async()=>{const value=count();const request=Promise.withResolvers<void>();requests.push(request);await request.promise;throw `error:${value}`;});
view=createErrorBoundary(()=>createLoadingBoundary(()=>data(),()=>"loading")(),e=>String(e()));
});
const ids=new WeakMap();let id=0;const key=(n:any)=>ids.get(n)||(ids.set(n,++id),id);
const dump=()=>{const seen=new Set();const walk=(n:any)=>{if(seen.has(n))return;seen.add(n);console.log("NODE",key(n),n._name,{status:n._statusFlags,held:!!(n._config&CONFIG_HELD),err:!!(n._config&CONFIG_STAGED_ERROR),shown:n._x?._shownError?.message,value:typeof n._value==='string'?n._value:typeof n._value,pending:n._pendingValue===NOT_PENDING?"none":n._pendingValue,depth:n._x?._transaction?._level},"deps",[...function*(){for(let d=n._deps;d;d=d._nextDep)yield key(d._dep);}()]);for(let l=n._subs;l;l=l._nextSub)walk(l._sub);};walk(data[$REFRESH]);};
expect(view()).toBe("loading");requests[0].resolve();await Promise.resolve();await Promise.resolve();flush();console.log("FIRST",view());dump();
set(1);flush();console.log("PENDING",view());dump();requests[1].resolve();await Promise.resolve();await Promise.resolve();flush();console.log("SECOND",view());dump();expect(view()).toBe("error:1");
});
