import { expect, it } from "vitest";
import { $REFRESH } from "../src/core/constants.js";
import {
  action,
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  latest,
  onCleanup,
  untrack
} from "../src/index.js";

const turn = async () => {
  await new Promise<void>(resolve => setTimeout(resolve, 0));
  flush();
};

  it("an untracked latest read inside a computation releases and revives", async () => {
    const [source, setSource] = createSignal(0);
    const read = () => latest(source);
    const sample = (): number => {
      let value = -1;
      const dispose = createRoot(dispose => {
        const probe = createMemo(() => {
          const first = untrack(read);
          expect(untrack(read)).toBe(first);
          return first;
        });
        createRenderEffect(probe, next => {
          value = next;
        });
        return dispose;
      });
      try {
        flush();
        return value;
      } finally {
        dispose();
        flush();
      }
    };
    expect(sample()).toBe(0);
    await turn();
    expect(source[$REFRESH]._subs).toBeNull();
    setSource(1);
    flush();
    expect(source[$REFRESH]._subs).toBeNull();
    expect(sample()).toBe(1);
    await turn();
    expect(source[$REFRESH]._subs).toBeNull();
  });

it("an untracked pending first answer keeps its request until it settles", async () => {
  const answer = Promise.withResolvers<number>();
  const [source] = createSignal(0);
  let requests = 0;
  let cleanups = 0;
  const resource = createMemo(() => {
    source();
    requests++;
    onCleanup(() => cleanups++);
    return answer.promise;
  });
  const dispose = createRoot(dispose => {
    const probe = createMemo(() => untrack(resource));
    createRenderEffect(probe, () => {});
    return dispose;
  });
  try {
    flush();
    dispose();
    flush();
    await turn();
    expect(requests).toBe(1);
    expect(cleanups).toBe(0);
    expect(source[$REFRESH]._subs).not.toBeNull();
    answer.resolve(7);
    await turn();
    expect(requests).toBe(1);
    expect(cleanups).toBe(1);
    expect(source[$REFRESH]._subs).toBeNull();
  } finally {
    answer.resolve(7);
    dispose();
    await turn();
  }
});

  it("an untracked latest output releases while an unrelated action stays open", async () => {
    const end = Promise.withResolvers<void>();
    const [source] = createSignal(0);
    const [held, setHeld] = createSignal(0);
    const read = () => latest(source);
    const dispose = createRoot(dispose => {
      const probe = createMemo(() => {
        held();
        return untrack(read);
      });
      createRenderEffect(probe, value => {
        expect(value).toBe(0);
      });
      return dispose;
    });
    let running: Promise<void> | undefined;
    try {
      flush();
      running = action(function* () {
        setHeld(1);
        yield end.promise;
      })();
      flush();
      await turn();
      // The output has no subscriber despite the still-live consumer scope.
      // An unrelated action's lifetime does not retain its source edge.
      expect(source[$REFRESH]._subs).toBeNull();
      end.resolve();
      await running;
      await turn();
      expect(source[$REFRESH]._subs).toBeNull();
    } finally {
      end.resolve();
      await running;
      dispose();
      await turn();
    }
  });
