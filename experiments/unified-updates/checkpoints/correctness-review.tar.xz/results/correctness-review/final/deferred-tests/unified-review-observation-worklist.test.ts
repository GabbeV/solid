import { expect, it } from "vitest";
import { $REFRESH } from "../src/core/constants.js";
import {
  comparatorObservation,
  heldComparatorObservation,
  observationQueries
} from "./fixtures/review-observation.js";

for (const query of observationQueries)
  for (const observed of query === "pending" || query === "latest" ? [false, true] : [false])
    it(`comparator observation cleanup releases unrelated ${query} (observed=${observed})`, async () => {
      await comparatorObservation(query, observed, (phase, state) => {
        if (phase === "held" && query === "latest") {
          // Internal maintenance must not make a source-owned output depend
          // on itself when a comparator queries it during initialization.
          for (let edge = state.unrelated[$REFRESH]._subs; edge; edge = edge._nextSub)
            for (let dependency = edge._sub._deps; dependency; dependency = dependency._nextDep)
              expect(dependency._dep).not.toBe(edge._sub);
        } else if (phase === "disposed") {
          expect(state.unrelated[$REFRESH]._subs).toBeNull();
        }
      });
    });

it("a latest companion queried by a comparator releases its held input subscriptions", async () => {
  await heldComparatorObservation((phase, state) => {
    if (phase === "disposed") expect(state.unrelated[$REFRESH]._subs).toBeNull();
  });
});
