import json
from pathlib import Path
base=Path('/workspace/layered-solid/experiments/unified-updates/results/integration-stage182/signals-full.json')
final=Path('/workspace/scratch/correctness-review/final/signals-retained.json')
def failures(r):
 return {(t['name'].split('/tests/')[-1],a['fullName']) for t in r['testResults'] for a in t['assertionResults'] if a['status']=='failed'}
def failed_files(r):
 return {t['name'].split('/tests/')[-1] for t in r['testResults'] if t['status']=='failed'}
before=json.loads(base.read_text()); after=json.loads(final.read_text())
b,a=failures(before),failures(after)
result={'passed':after['numPassedTests'],'failed':after['numFailedTests'],'pending':after['numPendingTests'],'files':len(after['testResults']),'new_failures':sorted(a-b),'removed_failures':sorted(b-a),'new_failed_files':sorted(failed_files(after)-failed_files(before)),'runtime_error_suites':after.get('numRuntimeErrorTestSuites')}
final.with_name('retained-failure-diff.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
