import { expect, it } from 'vitest';
import { createMemo, createRenderEffect, createRoot, createSignal, flush, latest, onCleanup, untrack, isPending } from '../src/index.js';
import { $REFRESH } from '../src/core/constants.js';
const turn = async () => { await new Promise<void>(r => setTimeout(r, 0)); flush(); };
it('an idle latest companion drains upstream cleanup writes with recursive flush', async () => {
  const [answer, setAnswer] = createSignal(0);
  let requests = 0, cleanups = 0;
  const source = createMemo(() => {
    requests++;
    onCleanup(() => { cleanups++; setAnswer(1); flush(); });
    return 0;
  });
  const seen: number[] = [];
  const dispose = createRoot(dispose => {
    createRenderEffect(answer, n => {seen.push(n)});
    const sample = createMemo(() => untrack(() => latest(source)));
    createRenderEffect(sample, n => { expect(n).toBe(0); });
    return dispose;
  });
  try {
    flush();
    await turn();
    expect(requests).toBe(1);
    expect(cleanups).toBe(1);
    expect(seen).toEqual([0, 1]);
    expect(source[$REFRESH]._subs).toBeNull();
  } finally { dispose(); flush(); }
});
it('owner death releases the observed pending question without restarting its request', async () => {
  const [value, setValue] = createSignal(0);
  let requests = 0, cleanups = 0;
  const end = Promise.withResolvers<number>();
  const dispose = createRoot(dispose => {
    const source = createMemo(() => {value();requests++;onCleanup(() => cleanups++);return end.promise});
    createRenderEffect(() => isPending(source), () => {});
    return dispose;
  });
  try {
    flush();
    dispose();
    await turn();
    setValue(1);
    await turn();
    expect(requests).toBe(1);
    expect(cleanups).toBe(1);
    expect(value[$REFRESH]._subs).toBeNull();
    end.resolve(1);
    await turn();
    expect(requests).toBe(1);
    expect(cleanups).toBe(1);
  } finally {end.resolve(1);dispose();flush()}
});
