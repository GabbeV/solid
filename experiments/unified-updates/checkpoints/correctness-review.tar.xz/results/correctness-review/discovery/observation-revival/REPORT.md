# Observation revival public regression

Owned repository addition: `packages/signals/tests/unified-review-observation-revival.test.ts`.
No runtime file edits, builds, installs, commits, or pushes were performed by this agent.

## Isolation

`head/src/` was extracted with `git archive HEAD packages/signals/src`, stripping `packages/signals/`. It has neither latest.ts/coordination.ts pending changes nor the observation agent's transient dormancy-enrollment change. The existing package configuration was copied, with only the Codspeed config import/plugin removed because scratch dependency resolution could not find that plugin. Runtime compile defines remain identical to the normal package config.

Direct command from `head/`:

```
node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/unified-review-observation-revival.test.ts tests/latest-revival.test.ts --maxWorkers=1
```

`head-result.log`: 3 pass, 1 fail. `head-prod-source-result.log`: identical result with `SIGNALS_TIER=prod` (source compiled with production defines, not a built artifact).

## Public sequence and differential

1. Mount a request memo driven by `value`, with a controlled promise; a render effect makes an ordinary value update wait for that request.
2. A second memo normally reads `condition()` and calls `untrack(() => isPending(condition))`, publishing `{value, pending}` through render and user effects.
3. Resolve initial request: both callbacks publish `{value:0,pending:false}`.
4. Set value to 5, flush; independently rerun the second memo while the request remains held. Both callbacks publish `{value:0,pending:true}`.
5. Variant only: call the same `isPending(condition)` query outside a consumer; it returns true. Flush.
6. Resolve the request and settle standard microtask turns + flush.

Without step 5, clean HEAD passes and both callbacks publish `{value:5,pending:false}`. With step 5, both callbacks instead publish `{value:5,pending:true}`. The query is read-only at the public API, but changes final publication. Finished pending=false is the already established landing contract, so no semantic decision is needed.

An additional scratch reduction removes the explicit flush in step 5: the standalone query alone still reproduces the failure (`head-query-no-flush.log`). The repository regression retains the explicit flush to make the original sequence clear.

## Latest control

`head/tests/latest-revival.test.ts` is the corresponding public value case using `latest(condition)`: both variants pass, publishing latest=5 while held and after landing. This does not prove latest lifecycle correctness, because the correct held and landed latest values are identical. No error-lifetime conclusion is drawn from this control.

## Shared runtime interference

The first shared-source run failed both query/no-query variants while observation_revival's narrow dormant enrollment was present. That is not the baseline diagnosis; clean HEAD isolates one failing query variant and one passing control. Observation lifecycle implementation diagnosis belongs to observation_revival; this report intentionally does not infer the exact internal fault solely from public evidence.
