import { expect, it } from 'vitest';
import { action, createSignal, flush, isPending, latest, createMemo, createRoot, createRenderEffect, onCleanup, untrack } from '../src/index.js';
const turn = async () => {await new Promise<void>(r => setTimeout(r, 0)); flush()};
const state = () => (globalThis as any).__observationState();
it('retires never-read-again dormant pending outputs across 20 actions', async () => {
  for (let i=0;i<20;i++) {
    const [source,setSource]=createSignal(0);
    const end=Promise.withResolvers<void>();
    const running=action(function*(){setSource(1);yield end.promise})();
    flush();
    expect(isPending(source)).toBe(true);
    flush();
    await turn();
    end.resolve();
    await running;
    await turn();
    await turn();
    expect(state()).toEqual({dirty:0,watching:0});
  }
});
it('drops watched first-load questions when their explicit owner dies', async () => {
  const end=Promise.withResolvers<number>();
  let cleanups=0;
  const dispose=createRoot(dispose=>{
    const source=createMemo(()=>{onCleanup(()=>cleanups++);return end.promise});
    createRenderEffect(()=>isPending(source),()=>{});
    return dispose;
  });
  flush();
  dispose();
  await turn();
  expect(cleanups).toBe(1);
  expect(state()).toEqual({dirty:0,watching:0});
  end.resolve(1);
  await turn();
  expect(state()).toEqual({dirty:0,watching:0});
});

it('retires 20 real held questions with no later output reads', async () => {
  for (let i=0;i<20;i++) {
    const [value,setValue]=createSignal(0);
    const [rerun,setRerun]=createSignal(0);
    let release!:()=>void;
    let query!:()=>boolean;
    let queryEnabled=true;
    const dispose=createRoot(dispose=>{
      const request=createMemo(()=>{const next=value();return new Promise<number>(r=>release=()=>r(next));});
      const condition=createMemo(value);
      query=()=>isPending(condition);
      const frame=createMemo(()=>{rerun();const next=condition();return {next,pending:queryEnabled?untrack(query):false}});
      createRenderEffect(request,()=>{});
      createRenderEffect(frame,()=>{});
      return dispose;
    });
    try {
      flush(); release(); await turn();
      setValue(5); flush(); setRerun(1); flush();
      expect(query()).toBe(true); flush(); await turn();
      expect(state().watching).toBeGreaterThan(0);
      queryEnabled=false;
      release(); await turn(); await turn();
      expect(state()).toEqual({dirty:0,watching:0});
    } finally {dispose();flush();await turn()}
  }
});
it('drops a real dormant question on owner death while its action stays open', async () => {
  const [value,setValue]=createSignal(0);
  const [rerun,setRerun]=createSignal(0);
  let release!:()=>void;
  let query!:()=>boolean;
  const dispose=createRoot(dispose=>{
    const request=createMemo(()=>{const next=value();return new Promise<number>(r=>release=()=>r(next));});
    const condition=createMemo(value);
    query=()=>isPending(condition);
    const frame=createMemo(()=>{rerun();const next=condition();return {next,pending:untrack(query)}});
    createRenderEffect(request,()=>{});
    createRenderEffect(frame,()=>{});
    return dispose;
  });
  const end=Promise.withResolvers<void>();
  let running:Promise<void>|undefined;
  try {
    flush();release();await turn();
    running=action(function*(){setValue(5);yield end.promise})();
    flush();setRerun(1);flush();
    expect(query()).toBe(true);flush();await turn();
    expect(state().watching).toBeGreaterThan(0);
    dispose();await turn();
    expect(state()).toEqual({dirty:0,watching:0});
  } finally {dispose();release();end.resolve();await running;await turn()}
});
it('releases the question of a lazy source detached before its owner dies', async () => {
  const [value,setValue]=createSignal(0);
  const [tick,setTick]=createSignal(0);
  let source!:()=>number;
  const dispose=createRoot(dispose=>{
    source=createMemo(value, {lazy:true});
    const probe=createMemo(()=>{tick();return untrack(()=>isPending(source));});
    createRenderEffect(probe,()=>{});
    return dispose;
  });
  const end=Promise.withResolvers<void>();
  let running:Promise<void>|undefined;
  try {
    flush();
    running=action(function*(){setValue(1);yield end.promise})();
    flush();setTick(1);flush();
    expect(isPending(source)).toBe(true);flush();await turn();
    expect(state().watching).toBeGreaterThan(0);
    dispose();
    // A dormant detached input is recognized at the next actual flush.
    const [other,setOther]=createSignal(0);
    const stop=createRoot(dispose=>{createRenderEffect(other,()=>{});return dispose});
    setOther(1);flush();stop();await turn();
    expect(state()).toEqual({dirty:0,watching:0});
  } finally {dispose();end.resolve();await running;await turn()}
});
