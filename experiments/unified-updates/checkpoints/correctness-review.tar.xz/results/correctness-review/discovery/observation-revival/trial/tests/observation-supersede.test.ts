import {writeFileSync} from 'node:fs';
import { expect,it } from 'vitest';
import {createSignal,createRoot,createMemo,createRenderEffect,isPending,latest,flush,untrack} from '../src/index.js';
const turn=async()=>{await new Promise<void>(r=>setTimeout(r,0));flush()};
const records=()=> (globalThis as any).__observationRecords().map(({record,parent,...r}:any)=>r);
it('probes a superseding flight while an earlier restoration stays held',async()=>{
 const [id,setId]=createSignal(0);
 const ends=[Promise.withResolvers<number>(),Promise.withResolvers<number>(),Promise.withResolvers<number>()];
 const restore=Promise.withResolvers<number>();
 let source!:()=>number;
 const events:unknown[]=[]; const snapshots:unknown[]=[];
 const dispose=createRoot(dispose=>{
  source=createMemo(()=>ends[id()].promise);
  const frame=createMemo(()=>{
   const value=source();
   const pending=untrack(()=>isPending(source));
   events.push([value,pending]);
   return value===1&&!pending ? restore.promise : value;
  });
  createRenderEffect(frame,()=>{});
  return dispose;
 });
 try {
  flush();ends[0].resolve(0);await turn();
  setId(1);flush();ends[1].resolve(1);await turn();
  snapshots.push(['RESTORING',[...events],records()]);
  isPending(source);flush();await turn();
  snapshots.push(['DORMANT',records()]);
  setId(2);
  try{untrack(source)}catch{}
  snapshots.push(['NEW',records(),isPending(source),latest(source)]);
  flush();snapshots.push(['POST',records()]);expect(isPending(source)).toBe(true);writeFileSync('/workspace/scratch/correctness-review/observation-revival/supersede-snapshots.json',JSON.stringify(snapshots,null,2));
 }finally{restore.resolve(1);ends[2].resolve(2);dispose();await turn()}
});
