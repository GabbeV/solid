import { expect, it } from 'vitest';
import { action, createMemo, createRenderEffect, createRoot, createSignal, flush, latest, onCleanup, untrack } from '../src/index.js';
it('records producer cleanup while unrelated action remains open', async () => {
  const end = Promise.withResolvers<void>();
  const [held, setHeld] = createSignal(0);
  let starts = 0, cleanups = 0;
  const source = createMemo(() => { starts++; onCleanup(() => { cleanups++; }); return 0; });
  const dispose = createRoot(dispose => {
    const probe = createMemo(() => { held(); return untrack(() => latest(source)); });
    createRenderEffect(probe, value => { expect(value).toBe(0); });
    return dispose;
  });
  const report = (phase: string) => console.log(JSON.stringify({ phase, starts, cleanups }));
  let running: Promise<void> | undefined;
  try {
    flush(); report('initial flush');
    running = action(function* () { setHeld(1); yield end.promise; })();
    flush(); report('held flush');
    for (let turn = 1; turn <= 3; turn++) {
      await new Promise<void>(resolve => setTimeout(resolve, 0));
      report(`turn ${turn} before flush`); flush(); report(`turn ${turn} after flush`);
    }
    end.resolve(); await running;
    await new Promise<void>(resolve => setTimeout(resolve, 0)); flush(); report('resolved');
  } finally { end.resolve(); await running; dispose(); flush(); report('disposed'); }
});
