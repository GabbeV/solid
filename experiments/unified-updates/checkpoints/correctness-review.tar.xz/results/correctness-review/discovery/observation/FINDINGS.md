# Comparator observation query discovery

No runtime edits. Focused source tests use maxWorkers=1.

Current test: `/workspace/layered-solid/packages/signals/tests/unified-review-observation-worklist.test.ts`.
A comparator always returns `Object.is(previous, next)`; its unrelated read is
only diagnostic, not an external dependency of its equality result. A scheduled
render observes `[source(), isPending(source)]`. Initially `[0,false]`; an action
sets source to 1 then waits on an explicit gate. Expected visible state during
that wait is `[0,true]`, followed by `[1,false]` after release.

| Comparator diagnostic read | Current branch | Next bcef1041 |
| --- | --- | --- |
| none (Object.is only) | passes | passes |
| unrelated ordinary signal | passes | passes |
| unrelated isPending, no observer | bounded nonquiescence failure | passes |
| unrelated isPending, observer | passes | passes |
| unrelated latest, no observer | visible assertions pass; teardown unhandled RangeError | passes |
| unrelated latest, observer | passes | passes |
| pre-created memo of unrelated isPending | passes | passes |

The guard stops comparator invocation 31; current pending failure's stack is
settleObservations:157 → pending._sample → proposedPending:78 → comparator.
Initial unbounded run reached the runtime's flush-loop guard (logs deliberately
not retained); all subsequent runs are bounded and quiet. The observation query
queues an untracked source companion for dormancy and schedules another flush;
next round sweeps it, but watched pending settlement reads it again. This is a
generic quiescence candidate, not evidence comparator reads must become tracked.

Latest's isolated run also reports recursive unobserved → clearDeps → unlinkSubs
teardown with Maximum call stack size exceeded. Cause remains unproven; do not
classify it as the same bug or patch it without reduction.

Receipts: `bounded.log`, `query-matrix.log`, `latest-isolated.log`, `next-matrix.log`.
Next matrix imports its unmodified source through owned `next/vite.config.ts` and
`next/tests/query-matrix.test.ts`; baseline omits outside source() assertions
because committed-read semantics differ. Next runtime/checkout was not modified.

Contract evidence: public NodeOptions.equals is a function signature without a
read prohibition. Located Solid 2 docs describe custom equality but no comparator
read restriction. Current core.ts:2772 explicitly anticipates comparator reads
of unresolved async sources. This does not decide dependency tracking semantics.
A user may query status simply to annotate equality diagnostics:

```ts
const [c] = createSignal(0);
const [source, setSource] = createSignal(0, {
  equals(prev, next) {
    diagnostics.push(isPending(c));
    return Object.is(prev, next);
  }
});
createRoot(dispose => {
  createRenderEffect(() => [source(), isPending(source)], render);
  return dispose;
});
flush();
const end = Promise.withResolvers<void>();
const running = action(function* () {
  setSource(1);
  yield end.promise;
})();
flush(); // current runtime does not quiesce; next does
end.resolve();
await running;
```

The checked-in discovery test adds a local armed flag and bounded guard for safe
worker execution and cleans up the action/root even after failure. One-shot
query controls also passed both observed/unobserved (original `bounded.log`).

## Latest reduction

Isolated bounded graph inspection proves a self-edge, not merely a teardown
stack with unknown cause. Before flush, unrelated source C's latest output L has
`deps=[C], subs=[]`. After flush, `deps=[C,L,C], subs=[L]`.
`latest-graph.jsonl` records node 1=C, node 4=L at this point.
`latest-calls.log` records this reentrant route:

1. prepareLayers calls holdQueuedProposals while B's proposal is not held yet.
2. B's equality comparator queries latest(C), reviving the dormant output L.
3. While computing L, latest fallback calls holdQueuedProposals again.
4. That nested sweep invokes B's comparator again, with context=L.
5. latest(C) reads L and records L as its own dependency.
6. Dormancy release later recursively clears/unlinks the self-edge through
   `unobserved → clearDeps → unlinkSubs → unobserved`, exhausting the stack.

Review candidate, not yet patched: run latest's queued-proposal registration as
bookkeeping via existing spectate(), keeping equality callbacks reached through
maintenance from recording dependencies/context on L. This changes bookkeeping
attribution, not the user's equality decision. A reentrancy guard around
holdQueuedProposals would break the exact observed recursion too, but could skip
newly queued nested proposals and needs more proof. Primary review required
before source edits; ordinary_scheduler independently owns pending quiescence.

## Prototype review: preserve current read context

Only owned source copies in `prototype/{native,untrack,spectate}` were modified.
Existing untrack keeps context, only changing tracking; core explicitly states
that untrack changes dependency tracking, not which world's value a read sees.
Spectate additionally sets spectating, which changes `serve` behavior for first
staged answers; it is broader than needed and is not recommended.

Wrapping only latest fallback's queued-proposal registration in untrack passes
both latest matrix variants plus a held-input adversarial control (3 cases,
`prototype/untrack-fallback-only.log`). The prepareLatest registration is left
unchanged in that final prototype. Native/current has the proven latest self-edge
and unhandled teardown error; the untrack variants have no unhandled errors.

Adversarial comparator calls latest(C), then reads held unrelated D and returns
`D === 1 || Object.is(prev,next)`. Current native, untrack, and spectate each read
D as `[0,1]`, have `[[0,false]]` during the hold and eventually
`[[0,false],[1,false]]`. Next instead reads `[0,0]`, showing
`[[0,false],[0,true]]` during the hold and adding `[1,false]` at completion.
That is an existing context/world-selection difference; untrack did not introduce
or settle it. The fixture records rather than asserts its desired semantics.
It retains latest(C) after the discriminating pass to avoid the already-known
native self-edge teardown error obscuring visibility receipts.

Recommendation: existing untrack solely around fallback's internal queued
registration; preserve current context/held-value reads and stop the internally
invoked comparator from attaching an edge to the unrelated source-owned L.
This is dependency corruption repair, not a proposal to track comparator inputs
or change equality sampling. Primary approval remains required before shared
source edits. Next comparison remains bcef1041, not the old size baseline.

## Accepted latest self-edge repair and scoped validation

Primary approved shared-source ownership of `layers/latest.ts` only. Applied
existing untrack around fallback's internal holdQueuedProposals registration;
prepareLatest and all value/context selection remain unchanged. Matrix adds a
bounded direct no-self-dependency assertion for latest companions and source
subscription cleanup checks. No shared graph/scheduler edits were made by me.

166 existing latest/first-value/error/owned-repeat/context-retry source cases
pass across five files (`latest-selection.log`). Both latest-specific matrix
variants pass, with no unhandled errors (`latest-matrix-patched.log`). At this
validation the only other runtime diff was ordinary_scheduler's narrow
coordination.ts equal-selector trial; graph/scheduler were restored to entry.

The new held-D comparator control preserves all current visibility assertions
but exposes independent eventual reclamation failure: after both gates, root
disposal, and five turn()+flush cycles, C still has its edge to unsubscribed L.
`held-final-graph.jsonl`: L flags16384/config16480/status0, subs=false, deps=[C]
for every cycle; no self-edge. This failure also reproduces without the narrow
coordination trial (ordinary_scheduler independently confirmed). Parent assigned
creator_publication its reduction/repair; final cleanup assertion remains in the
owned matrix. Whole matrix is not claimed passing while this failure is open.
No commits/builds/benchmarks were run.
