# Owned lazy cleanup revival isolation

All shared runtime files unchanged during this investigation. Four scratch
runtime copies distinguish the existing untracked enrollment patch from final
scheduler sweep. Original dormant-memo-chain-3554 assertions copied unchanged:

| Runtime | Passed / failed |
| --- | --- |
| entry HEAD core+scheduler | 6 / 0 |
| core eligibility only | 6 / 0 |
| final scheduler sweep only | 5 / 1 |
| combined | 5 / 1 |

The failure is the owned lazy m1 reawakened by old held-child cleanup; final
sweep removes m1 from owner chain before the existing checkpoint. Original
HEAD core still reproduces it. Narrowing new core eligibility alone cannot fix
this failure; this read was already eligible under original null-context rule.

Public counterpart in each `public-lifecycle.test.ts` logs function execution
and onCleanup instead of inspecting owner chain. Same fixture, adding:

```ts
const memo = createMemo(() => {
  events.push("run:" + generation);
  onCleanup(() => events.push("cleanup:" + generation));
  return generation;
}, { lazy: true });
// First child owns cleanup that calls the saved generation-1 memo.
onCleanup(() => { events.push("owner-cleanup:1"); m1(); });
```

After tick changes owner generation and flush runs:

- entry/core-only/current next bcef1041:
  `[owner-cleanup:1, run:1]`, same after an actual timer turn.
- final-sweep-only/combined:
  `[owner-cleanup:1, run:1, cleanup:1]`, same after timer turn.

Later m1() returns 1 everywhere. Entry/next reuse the calculation; final-sweep
variants execute run:1 again and cleanup:1 again at the following flush. Exact
per-variant public-receipt.json includes every boundary. This is observable
cleanup timing and extra recomputation, not merely white-box owner-chain shape.
The old version retains this node past timer, not only until a queued microtask.

Potential narrower repair for primary review: keep preheap sweep unchanged,
but final no-work sweep only ownerless computations. Source-owned companions
are allocated runWithOwner(null); plain ownerless memo cleanup also improves.
Owned lazy cleanup revival keeps original next/entry behavior. Skipped entries
must remain in dormantNodes for the next ordinary flush. No such patch applied;
graph/scheduler ownership remains with primary. No semantic decision made.
