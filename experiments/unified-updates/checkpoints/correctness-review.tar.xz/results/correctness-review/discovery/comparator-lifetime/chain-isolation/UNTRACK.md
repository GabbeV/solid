# Untrack lifetime regression isolation

Unchanged complete `untrack.test.ts` copied to the same isolated runtimes:

| Runtime | Pass/fail |
| --- | --- |
| entry HEAD core+scheduler | 3/0 |
| core eligibility only | 2/1 |
| final scheduler sweep only | 3/0 |
| combined | 2/1 |
| current next bcef1041 | 3/0 |

All failures are original `should not affect deep dependency being created`,
line74: memo body expected once, actually twice. Per-runtime untrack.json/log
preserve exact results; no assertions changed. No shared runtime edits made.

The owned effect reads untrack(ownerlessMemo), then flush completes and an
immediate imperative read checks the memo. Original active-context untrack kept
that memo alive; broad eligibility enrols it, so ordinary preheap sweep removes
it and the immediate read executes its body again. This can repeat allocations,
requests and cleanup registrations despite no write between reads. Existing
public test and current next both establish reuse across this boundary.

Recommendation: retract generic core !tracking extension. Existing generic
ownerless untracked lifetime should not be redefined to repair internal
source-owned companion reclamation. Instead observation creation/calculation
can enroll subscriberless AUTO_DISPOSE companions in the existing dormantNodes
worklist, with wakeLayers' existing scheduling and sweep's revalidation. This
keeps ordinary memo behavior unchanged. CONFIG_REDERIVE alone is not a safe
internal-companion discriminator: deferred/refresh/loading also use it.

The newly authored plain-memo release controls were diagnostic semantic probes;
they should not be retained as correctness assertions because they contradict
this existing public obligation. Latest companion release remains a supported
regression control (current next passes). Final sweep's owned-lazy teardown
regression is independent, documented in README.md beside this file.
