# Public upstream repro controls

Retained source branch at starting checkpoint cf6f20b00, 2026-11-11.
No runtime source edits. The tests use only public exports, controlled promises,
scheduled render effects, and post-flush/event-turn screen snapshots. They do not
require sibling callback order.

Initial exact four-case test run:
`packages/signals/node_modules/.bin/vitest run tests/unified-review-upstream-repros.test.ts --maxWorkers=1`
from `packages/signals`: **4 passed**, one file passed, duration 725 ms.

- #4775: guess 1 publishes; guess 2 waits on downstream request; unrelated tick
  changes its screen to tick 1 while both ordinary values remain 1. Answering the
  request publishes 2 on both screens. Broader equivalent already exists at
  `unified-experiment.test.ts:70`, using the internal explicit-layer adapter and
  adding a late reader. Exact public form passed; permanent duplication optional.
- #4776: an open action changes id 1->2 and filter 0->1. Latest memo and ordinary
  pair publish `2` and `2 / 0`; ordinary inputs stay 1/0. Action completion
  publishes ordinary inputs 2/1 and pair `2 / 1`. Exact composed-screen coverage
  was not found in adjacent latest tests.
- #4777: while id update 0->1 is held, enabling the request memo records only
  completed arguments `[0, 1, 0]` around `latest(id)` and publishes that answer
  with ordinary id still 0. Existing read-retry and stable-context tests cover
  the invariant across broader async/iterator/private-child matrices.
- #4778: direct and memo-wrapped pending derivations have each already returned
  an initial promise. Both settle false. During an open id action both start new
  promises and hold the shared pending output until both settle, then publish
  true together with the pending screen; ordinary id remains 0. Adjacent
  pending-async-feedback covers cancellation but not this paired async scenario.

No unexpected semantic differences from accepted experiment context rules and
no failing public scenario were found. No fix is justified by these repros.

After primary review, only the missing exact #4776 and #4778 controls were
retained. Combined focused source run with `unified-read-retry`,
`unified-pending-async-feedback`, and `unified-latest`: **58 passed**, four files
passed, duration 3.19 seconds, maxWorkers=1. Primary verification receipt is
`experiments/unified-updates/optimization-review/CORRECTNESS-upstream-repros.md`.

The first `pnpm exec` command triggered pnpm's automatic dependency check, which
refused an unsafe symlink target before running tests. No dependency installation
was requested; subsequent invocation used the existing executable directly.
