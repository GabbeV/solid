# Correctness review receipts

Retained source commit: d49bcd3f6; final/manifest.json pins runtime/artifact hashes.

final/signals-retained.json is the accepted source run (5802 passed /1953 failed /2 skipped).
final/signals-full.json is the REJECTED broader cleanup candidate (5790 /1967 /2).
The corresponding failure-diff files distinguish them. Final Solid and DOM failure
identities match stage182; web-loader-failure.json was an invalid compiler-loading
run, replaced by web-full.json using the existing rc.21 native binary.

final/production.json: 180 built-production controls; artifacts.json: 61 checks.
Production config is .mts because this scratch directory is outside the repository
ESM package boundary. Source/config paths are historical and must be adapted when
replaying elsewhere. Production defines are __DEV__=false, __OBSERVE__=false,
__TEST__=false; source suite uses normal development/test defines.

Size-before and size-after use the exact same three import scenarios and pinned
next baseline. Measurements are bytes, not throughput claims.

Discovery trials, diagnostic globals and deferred reclamation assertions are NOT
part of the shipped implementation. In particular the source-dormancy WeakSet/
microtask trial and generic core !tracking/final-sweep patches were not retained.
The normal packages contain the accepted tests. No old assertions were weakened.

The next producer-retention counter fixture is discovery/producer-retention-next.test.ts; copy it into the selected checkout’s packages/signals/tests to replay its relative source import. It records the retained-producer policy; it is not an accepted new reclamation assertion.
