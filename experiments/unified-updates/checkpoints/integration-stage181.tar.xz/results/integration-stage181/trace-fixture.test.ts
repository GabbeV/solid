import { appendFileSync } from "node:fs";
const trace = (...args: any[]) => appendFileSync(process.env.TRACE_OUTPUT!, JSON.stringify(args)+"\n");
/**
 * #4491: a reader that mounts while an unread derived store's derive has a
 * flight up reads the store like its memo (D-30, "in both forms").
 *
 * `createStore(d => { d.v = m1() }, {})` over `m1 = async(m0)` with
 * `m0 = memo(latest(s) + s)`: `m0` is a verdict reader, so `m1` and the
 * derive are verdict readers through what they read (D-25 / F-6). Nothing
 * reads the store when `m1` re-asks (s: 1 -> 2); a reader of the store then
 * mounts mid-flight.
 *
 * - memo form (the reader reads `m1()`): the mount consumes unanswered async
 *   and is held until `m1` answers (F-2): ["r:off", "--mounted", "r:4"].
 * - store form, before: the derive was served `m1`'s committed value and
 *   settled over it (A15's stale reader), so its leaf read as final. The
 *   reader showed the old question's answer `r:2` before `r:4`: in the
 *   mounting flush itself when the unread derive skips the flight (#4479),
 *   at the landing otherwise (the derive's landing pass, a frame reader,
 *   read the screen).
 *
 * The forms the #4479 review probed (a key read, `Object.keys`, a JSON
 * walk) must match the memo form, mounted mid-flight with and without a
 * plain write beside the flight (with it, the store form showed `r:5`, an
 * answer to a question between the two, before `r:6`). So must a reader
 * already on screen at the re-ask, with the plain write (before the fix the
 * whole-object readers showed `s:3` beside the old `v` ahead of `r:4`), and
 * a reader mounted after the landing, which shows at once: the hold reaches
 * neither.
 */
import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import {
  createMemo,
  getOwner,
  createRenderEffect,
  createRoot,
  createSignal,
  createStore,
  flush,
  latest,
  resetErrorHalt
} from "../src/index.js";
import { $REFRESH, CONFIG_VERDICT, STATUS_PENDING } from "../src/core/constants.js";
import type { Computed } from "../src/core/types.js";

beforeEach(() => vi.useFakeTimers());
afterEach(() => {
  vi.useRealTimers();
  resetErrorHalt();
});
const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));
const tick = async (ms: number) => {
  await vi.advanceTimersByTimeAsync(ms);
  flush();
};

type Form = "memo" | "forwardMemo" | "storeKey" | "storeKeys" | "storeJSON";
const storeForms = ["storeKey", "storeKeys", "storeJSON"] as const;

/** The reader's display of `v`: every form shows the same text. */
async function run(form: Form, at: "before" | "during" | "duringWrite" | "afterLanding") {
  const log: string[] = [];
  const nodes: Record<string, any> = {};
  const ids = new Map<any,number>(); const id = (x:any) => {if (!x) return null; if(!ids.has(x))ids.set(x,ids.size+1);return ids.get(x)};
  const snap = (phase: string) => {
    const resolve = (t:any):any => t?._into ? resolve(t._into) : t;
    const val = (v:any) => typeof v === "object" ? "object" : String(v);
    const list = (n:any) => ({id:id(n), status:n._statusFlags,flags:n._flags,config:n._config,value:val(n._value),proposal:val(n._pendingValue),tx:id(resolve(n._x?._transaction)),level:resolve(n._x?._transaction)?._level, deps:[...function*(){for(let e=n._deps;e;e=e._nextDep)yield id(e._dep)}()],pending:[...(n._x?._pendingSources??[])].map(id)});
    trace("STATE",form,phase,Object.fromEntries(Object.entries(nodes).map(([key,n])=>[key,list(n)])));
  };
  const [s, setS] = createSignal(1);
  const [on, setOn] = createSignal(at === "before");
  createRoot(() => {
    const m0 = createMemo(() => {
      const v = latest(s) + s();
      trace("M0", form, v, Date.now());
      return v;
    });
    const m1 = createMemo(async () => {
      const v = m0();
      trace("ASK", form, v, Date.now());
      await sleep(100);
      trace("ANSWER", form, v, Date.now());
      return v;
    });
    Object.assign(nodes,{s:(s as any)[$REFRESH],m0:(m0 as any)[$REFRESH],m1:(m1 as any)[$REFRESH]});
    let read: () => unknown = () => m1();
    if (form === "forwardMemo") {read = createMemo(() => m1()); nodes.fw = (read as any)[$REFRESH];}
    else if (form !== "memo") {
      const [st] = createStore<{ v?: number }>(d => {
        d.v = m1();
      }, {});
      nodes.fw = (st as any)[$REFRESH];
      read =
        form === "storeKey"
          ? () => st.v
          : form === "storeKeys"
            ? () => (Object.keys(st).join() === "v" ? (st as any).v : "keys?")
            : () => JSON.parse(JSON.stringify(st)).v;
    }
    if (at !== "during")
      createRenderEffect(
        () => `s:${s()}`,
        v => void log.push(v)
      );
    createRenderEffect(
      () => {nodes.reader=getOwner();return on() ? `r:${read()}` : "r:off";},
      v => void log.push(v)
    );
  });
  flush();
  await tick(150);
  setS(2); // m1 re-asks
  flush();
  log.push("--reask");
  snap("reask");
  await tick(20);
  if (at === "during" || at === "duringWrite") {
    setOn(true); // a reader mounts mid-flight; nothing read the store before
    flush();
    log.push("--mounted");
    snap("mounted");
  }
  if (at !== "during") {
    await tick(10);
    (globalThis as any).__holdTrace = (tag: string, n:any, other:any) => {
      const name = Object.keys(nodes).find(k=>nodes[k]===n);
      if(!name)return;
      const resolve = (t:any):any => t?._into ? resolve(t._into) : t;
      trace(tag,form,name,{status:n._statusFlags,config:n._config,tx:id(resolve(n._x?._transaction)),level:resolve(n._x?._transaction)?._level, other:id(other),otherTx:id(resolve(other?._x?._transaction)),otherLevel:resolve(other?._x?._transaction??other)?._level});
    };
    (globalThis as any).__txTrace = (tag: string,t:any,r:any,members:any[]) => {
      trace(tag,form,id(t),t._level,r,t._mayPend,members.map(n=>({name:Object.keys(nodes).find(k=>nodes[k]===n),id:id(n),status:n._statusFlags,flags:n._flags,config:n._config, sources:[...(n._x?._pendingSources??[])].map(id),subs:[...function*(){for(let e=n._subs;e;e=e._nextSub)yield [id(e._sub),e._sub._statusFlags,e._gen,e._sub._depGen]}()]})));
    };
    setS(3); // a plain write beside the flight
    flush();
    log.push("--plain write");
    snap("write");
    (globalThis as any).__holdTrace = undefined;
    (globalThis as any).__txTrace = undefined;
  }
  await tick(300);
  if (at === "afterLanding") {
    setOn(true);
    flush();
    log.push("--mounted");
  }
  await tick(300);
  trace("TIMELINE", form, at, JSON.stringify(log));
  return log;
}

describe("a reader mounted mid-flight reads a derived store like its memo (#4491)", () => {
  test("memo form: the mount is held until m1 answers (F-2)", async () => {
    expect(await run("memo", "during")).toEqual(["r:off", "--reask", "--mounted", "r:4"]);
  });
  test("memo form, a plain write beside the flight: held with it, re-asked once", async () => {
    expect(await run("memo", "duringWrite")).toEqual([
      "s:1",
      "r:off",
      "s:2",
      "--reask",
      "--mounted",
      "--plain write",
      "r:6",
      "s:3"
    ]);
  });
  for (const form of storeForms)
    test(`${form}: held like the memo form, never the old question's r:2 (D-30)`, async () => {
      expect(await run(form, "during")).toEqual(await run("memo", "during"));
      // The write beside the flight shows no answer of a question between
      // the two (`r:5`) either: the memo form's screen, frame for frame.
      expect(await run(form, "duringWrite")).toEqual(await run("memo", "duringWrite"));
    });
});

describe("readers the hold does not reach (#4491)", () => {
  test("memo form, reader on screen at the re-ask; reader mounted after the landing", async () => {
    expect(await run("memo", "before")).toEqual([
      "s:1",
      "r:2",
      "--reask",
      "--plain write",
      "r:4",
      "s:3",
      "r:6"
    ]);
    expect(await run("memo", "afterLanding")).toEqual([
      "s:1",
      "r:off",
      "s:2",
      "--reask",
      "s:3",
      "--plain write",
      "r:6",
      "--mounted"
    ]);
  });
  for (const form of storeForms)
    test(`${form}: as the memo form`, async () => {
      expect(await run(form, "before")).toEqual(await run("memo", "before"));
      expect(await run(form, "afterLanding")).toEqual(await run("memo", "afterLanding"));
    });
});

/** The derive's posture after the held mount. The read that held the reader
 * writes nothing on the derive: it marks the derive's next pass (`fam.w`),
 * a read that finds no flight up clears the mark, and the posture stays the
 * pass's own reads (core `recompute`). A later flight of `m1`, the reader on
 * screen, then shows what a store read from the start and the memo form
 * show — whether the landing changed the leaf (the derive re-ran) or equalled
 * it (it did not). After an equal landing the flight wakes the held derive
 * pending, and that pass reads the pending `m1` plainly: a read of a pending
 * node hands no posture to a pass that is the hold's work (#4504; D-25), as
 * a memo between `m1` and the reader posts none. The posture during the
 * flight is internal; the screen is the rule (D-30).
 */
describe("the derive's posture after the held mount (#4491)", () => {
  async function later(form: "memo" | "storeKey", mountMidFlight: boolean, equal: boolean) {
    const log: string[] = [];
    const [s, setS] = createSignal(1);
    const [on, setOn] = createSignal(!mountMidFlight);
    let derive: Computed<any> | null = null;
    createRoot(() => {
      const m0 = createMemo(() => {
      const v = latest(s) + s();
      trace("M0", form, v, Date.now());
      return v;
    });
      const m1 = createMemo(async () => {
        const v = m0();
        await sleep(100);
        return equal ? 0 : v;
      });
      let read: () => unknown = () => m1();
      if (form === "storeKey") {
        const [st] = createStore<{ v?: number }>(d => {
          d.v = m1();
        }, {});
        derive = (st as any)[$REFRESH];
        read = () => st.v;
      }
      createRenderEffect(
        () => (on() ? `r:${read()}` : "r:off"),
        v => void log.push(v)
      );
    });
    const posture = (tag: string) =>
      log.push(
        derive
          ? `${tag} verdict=${!!(derive._config & CONFIG_VERDICT)} pending=${!!(derive._statusFlags & STATUS_PENDING)}`
          : tag
      );
    flush();
    await tick(150);
    setS(2); // m1 re-asks
    flush();
    await tick(20);
    setOn(true); // mid-flight: held on the flight
    flush();
    await tick(300);
    posture("--landed");
    setS(3); // a later flight, the reader on screen
    flush();
    posture("--reask");
    await tick(300);
    // From the first landing on.
    trace("LATER", form, mountMidFlight, equal, JSON.stringify(log));
    return log.slice(log.findIndex(x => x.startsWith("--landed")) - 1);
  }
  const screen = (log: string[]) => log.map(x => x.split(" ")[0]);

  for (const equal of [false, true])
    test(`a later flight after ${equal ? "an equal" : "a changed"} landing`, async () => {
      const held = await later("storeKey", true, equal);
      expect(screen(held)).toEqual(screen(await later("storeKey", false, equal)));
      expect(screen(held)).toEqual(screen(await later("memo", true, equal)));
      expect(held).toContain("--landed verdict=true pending=false");
    });
});

test("trace all publication timelines", async () => {for (const form of ["memo", ...storeForms] as const) for (const at of ["before", "during", "duringWrite", "afterLanding"] as const) await run(form, at);});

test("trace two mounts", async () => {await run("memo","duringWrite");await run("storeKey","duringWrite");});

test("trace forwarding memo", async () => {await run("forwardMemo","duringWrite");});
