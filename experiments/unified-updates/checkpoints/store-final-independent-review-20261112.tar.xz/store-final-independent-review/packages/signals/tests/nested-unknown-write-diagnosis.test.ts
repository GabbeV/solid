import { it } from "vitest";
import {
  action,
  createOptimisticStore,
  createRenderEffect,
  createRoot,
  flush
} from "../src/index.js";
const tick = async () => {
  for (let i = 0; i < 4; i++) {
    await new Promise(r => setTimeout(r, 0));
    flush();
  }
};
it("diagnose a nested write through an unknown chained child", async () => {
  const input = Promise.withResolvers<{ x: number }>(),
    end = Promise.withResolvers<void>();
  const steps: string[] = [],
    frames: number[] = [];
  let dispose!: () => void, write!: (fn: (d: any) => void) => void;
  let running: Promise<unknown> | undefined, rejected: any;
  createRoot(d => {
    dispose = d;
    const [inner] = createOptimisticStore(() => input.promise, { x: -111 });
    const [outer, set] = createOptimisticStore(() => ({ child: inner }), { child: { x: -222 } });
    write = set;
    createRenderEffect(
      () => outer.child.x,
      v => {
        frames.push(v);
      }
    );
  });
  try {
    flush();
    running = action(function* () {
      steps.push("before setter");
      write(d => {
        steps.push("before child read");
        const child = d.child;
        steps.push("after child read");
        child.x = 9;
        steps.push("after x write");
      });
      steps.push("after setter");
      yield end.promise;
    })();
    running.catch(e => {
      rejected = { name: e?.constructor?.name, message: String(e), creationStack: e?.stack };
    });
    await tick();
    console.log(
      JSON.stringify({ point: "active", steps: [...steps], frames: [...frames], rejected })
    );
    input.resolve({ x: 2 });
    await tick();
    end.resolve();
    await Promise.allSettled([running]);
    await tick();
    console.log(JSON.stringify({ point: "settled", steps, frames, rejected }));
  } finally {
    input.resolve({ x: 2 });
    end.resolve();
    dispose();
    await Promise.allSettled([running]);
    flush();
  }
});
