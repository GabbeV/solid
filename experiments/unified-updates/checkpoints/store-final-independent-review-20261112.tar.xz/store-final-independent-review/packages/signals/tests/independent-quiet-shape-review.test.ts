import { expect,it } from 'vitest';
import { action,createOptimisticStore,createRenderEffect,createRoot,flush,refresh } from '../src/index.js';
const turn=async()=>{for(let i=0;i<4;i++){await new Promise(r=>setTimeout(r,0));flush();}};
for(const kind of ['static-chain','derived-chain'] as const)it(`cold ${kind} metadata during quiet refresh does not invoke accessor or throw`,async()=>{
 const requests:Array<PromiseWithResolvers<any>>=[];const end=Promise.withResolvers<void>();let calls=0,dispose!:()=>void,start!:()=>Promise<unknown>,read!:()=>any,refreshInput!:()=>void;let running:Promise<unknown>|undefined;
 createRoot(d=>{dispose=d;const[inner]=createOptimisticStore(async(d:any)=>{const p=Promise.withResolvers<number>();requests.push(p);d.x=await p.promise;Object.defineProperty(d,"doubled",{get(){calls++;return this.x*2;},configurable:true,enumerable:true});},{x:0});const[outer,set]=kind==='static-chain'?createOptimisticStore(inner):createOptimisticStore(()=>inner,{x:0});refreshInput=()=>{void refresh(inner);};read=()=>outer;createRenderEffect(()=>inner.x,()=>{});start=action(function*(){set(d=>{d.x=15;});yield end.promise;});});
 const answer=()=>10;
 try{flush();requests[0].resolve(answer());await turn();const before=calls;refreshInput();flush();running=start();await turn();expect(read().x).toBe(15);expect(calls).toBe(before);expect(read().doubled).toBe(30);expect(calls).toBeGreaterThan(0);requests[1].resolve(answer());await turn();expect(read().x).toBe(15);end.resolve();await running;await turn();expect(read().x).toBe(10);}finally{end.resolve();for(const p of requests)p.resolve(answer());dispose();await Promise.allSettled([running]);flush();}
});
it('cold nested shape through an unknown inner store cannot expose its seed',async()=>{
 const first=Promise.withResolvers<{x:number}>(),end=Promise.withResolvers<void>();let set!:(fn:(d:any)=>void)=>void,dispose!:()=>void;const frames:number[]=[];let running:Promise<unknown>|undefined;
 createRoot(d=>{dispose=d;const[inner]=createOptimisticStore(()=>first.promise,{x:-111});const[outer,write]=createOptimisticStore(()=>({child:inner}),{child:{x:-222}});set=write;createRenderEffect(()=>outer.child.x,v=>{frames.push(v);});});
 try{flush();expect(frames).toEqual([]);running=action(function*(){set(d=>{d.child.x=9;});yield end.promise;})();await turn();expect(frames).not.toContain(-111);expect(frames).not.toContain(-222);expect(frames.at(-1)).toBe(9);first.resolve({x:2});await turn();expect(frames.at(-1)).toBe(9);end.resolve();await running;await turn();expect(frames.at(-1)).toBe(2);}finally{first.resolve({x:2});end.resolve();dispose();await Promise.allSettled([running]);flush();}
});
