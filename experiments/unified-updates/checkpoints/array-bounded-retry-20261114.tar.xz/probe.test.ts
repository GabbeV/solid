import {appendFileSync} from "node:fs";
import { it } from 'vitest';
import { action, createOptimisticStore, createRenderEffect, createRoot, createSignal, flush, latest } from '/workspace/layered-solid/packages/signals/src/index.js';
for (const mode of ['values', 'presence', 'descriptors']) {
  for (const observeLatest of [false, true]) it(`${mode}, latest=${observeLatest}`, async () => {
    const ends = [Promise.withResolvers<void>(), Promise.withResolvers<void>()];
    const frames: any[][] = [[], []], leading: any[][] = [[], []];
    const read = (rows: string[]) => {
      const result: any = { length: rows.length };
      if (mode === 'values') result.items = Array.from({length: rows.length}, (_, i) => rows[i]);
      if (mode === 'presence') result.items = Array.from({length: rows.length}, (_, i) => i in rows);
      if (mode === 'descriptors') result.items = Array.from({length: rows.length}, (_, i) => Object.getOwnPropertyDescriptor(rows, i)?.value);
      return result;
    };
    const app = createRoot(dispose => {
      const [source, setSource] = createSignal(['A', 'B']);
      const [inner, setInner] = createOptimisticStore(source, []);
      const [outer, setOuter] = createOptimisticStore(() => inner, []);
      for (const [i, rows] of [inner, outer].entries()) {
        createRenderEffect(() => read(rows), value => { frames[i].push(value); });
        if (observeLatest) createRenderEffect(() => latest(() => read(rows)), value => { leading[i].push(value); });
      }
      createRenderEffect(source, () => {});
      return {dispose, setSource, setInner, setOuter};
    });
    flush();
    const a = action(function*(){app.setInner(rows => { rows[1] = 'I'; }); yield ends[0].promise;})();
    flush();
    const b = action(function*(){app.setOuter(rows => { rows.push('M'); }); yield ends[1].promise;})();
    flush();
    const before = frames.map(f => f.at(-1));
    app.setSource([]);
    flush();
    appendFileSync("/workspace/scratch/array-single-case-20261114/timelines.jsonl", JSON.stringify({mode,observeLatest,before,after:frames.map(f=>f.at(-1)),leading:leading.map(f=>f.at(-1))})+"\n");
    ends.forEach(e=>e.resolve()); await Promise.all([a,b]); flush(); app.dispose(); flush();
  });
}
