import base from '/workspace/layered-solid/packages/element/vite.config.mjs';
export default {...base,test:{...base.test,setupFiles:['/workspace/layered-solid/packages/web/test/setup-jest-dom.ts',...(base.test.setupFiles||[])]}};
