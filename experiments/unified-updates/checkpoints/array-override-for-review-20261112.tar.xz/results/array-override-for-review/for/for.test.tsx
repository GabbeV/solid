import { test, expect } from 'vitest';
import { writeFileSync } from 'node:fs';
import { action, createOptimisticStore, createStore, createSignal, createRenderEffect, flush, For } from 'solid-js';
import { render } from '@solidjs/web';
const results: unknown[] = [];
const save = () => writeFileSync(process.env.PROBE_OUTPUT!, JSON.stringify(results,null,2));
const turn = async () => { await new Promise<void>(r => setTimeout(r,0)); flush(); };
const describe = (items: number[]) => ({length:items.length,keys:Object.keys(items),values:Array.from(items, String)});
function mount(each: () => number[]) {
 const callbacks:string[] = [];
 const host = document.createElement('div'); document.body.append(host);
 const dispose = render(() => <ul><For each={each()}>{item => { callbacks.push(String(item)); return <li>{String(item)}</li>; }}</For></ul>,host);
 flush();
 return {host,callbacks,dispose, view:() => ({rows:Array.from(host.querySelectorAll('li'), el=>el.textContent),html:host.innerHTML,callbacks:[...callbacks]})};
}
test('optimistic array B then A, B resolves first', async () => {
 const [items,guess] = createOptimisticStore<number[]>([]);
 const [savedB,setSavedB] = createSignal(false);
 const endA = Promise.withResolvers<void>(), endB = Promise.withResolvers<void>();
 const ui=mount(()=>items), timeline:unknown[]=[];
 let saved = false;
 const disposeSaved=render(()=>{createRenderEffect(savedB, v=>{saved=v});return null},document.createElement('div'));
 const note=(phase:string)=>timeline.push({phase,array:describe(items),savedB:saved,...ui.view()});
 let a:Promise<unknown>|undefined,b:Promise<unknown>|undefined;
 try {
 note('initial');
 b=action(function*(){guess(draft=>{draft[1]=2});setSavedB(true);yield endB.promise})();flush();note('B live');
 a=action(function*(){guess(draft=>{draft[0]=1});yield endA.promise})();flush();note('A and B live');
 endB.resolve();await b;await turn();note('B finished, A live');
 endA.resolve();await a;await turn();note('both finished');
 expect(timeline.map((entry: any) => entry.rows)).toEqual([[],['undefined','2'],['1','2'],['1','2'],[]]);
 expect(ui.callbacks).toEqual(['undefined','2','1']);
 results.push({kind:'optimistic',timeline});save();
 } finally {endA.resolve();endB.resolve();await Promise.all([a,b]);ui.dispose();disposeSaved();ui.host.remove();flush()}
});
test('ordinary signal sparse-array control',()=>{
 const [items,setItems]=createSignal<number[]>([]);
 const ui=mount(items),timeline:unknown[]=[];
 const note=(phase:string)=>timeline.push({phase,array:describe(items()),...ui.view()});
 try {
 note('initial');const sparse:number[]=[];sparse[1]=2;setItems(sparse);flush();note('set sparse [hole,2]');
 setItems([1,2]);flush();note('set [1,2]');setItems([]);flush();note('set []');
 expect(timeline[1]).toMatchObject({rows:['undefined','2']});
 results.push({kind:'ordinary signal',timeline});save();
 }finally{ui.dispose();ui.host.remove();flush()}
});
test('ordinary store sparse-array control',()=>{
 const [items,setItems]=createStore<number[]>([]);
 const ui=mount(()=>items),timeline:unknown[]=[];
 const note=(phase:string)=>timeline.push({phase,array:describe(items),...ui.view()});
 try {
 note('initial');setItems(draft=>{draft[1]=2});flush();note('set index 1');
 setItems(draft=>{draft[0]=1});flush();note('set index 0');setItems(draft=>{draft.length=0});flush();note('clear');
 expect(timeline[1]).toMatchObject({rows:['undefined','2']});
 results.push({kind:'ordinary store',timeline});save();
 }finally{ui.dispose();ui.host.remove();flush()}
});
