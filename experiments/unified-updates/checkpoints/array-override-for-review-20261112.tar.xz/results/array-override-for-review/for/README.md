# Executable For DOM receipt

All runtime imports resolve to source in the selected PROBE_ROOT (signals, solid, solid/internal, and web); no runtime dist is used. The installed rc.21 native compiler transforms the actual TSX through a tiny scratch Vite plugin. Tests run in jsdom. No repository runtime files were modified; no dependencies were installed.

```
PROBE_ROOT=/workspace/scratch/solid-pr4717-review PROBE_OUTPUT=/workspace/scratch/store-length-review/for/bcef.json node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config /workspace/scratch/store-length-review/for/probe.config.mts
PROBE_ROOT=/workspace/layered-next-4fe75321 PROBE_OUTPUT=/workspace/scratch/store-length-review/for/4fe.json node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config /workspace/scratch/store-length-review/for/probe.config.mts
```

Both revisions pass 3 tests. Exact default-keyed JSX is `<For each={each()}>{item => { callbacks.push(String(item)); return <li>{String(item)}</li>; }}</For>`. `item` is the raw row value. Callback values are recorded before constructing each li.

| Phase | li text, both revisions | savedB bcef | savedB 4fe |
| --- | --- | --- | --- |
| initial | [] | false | false |
| B guesses index 1 = 2 | ["undefined", "2"] | false | false |
| A guesses index 0 = 1 | ["1", "2"] | false | false |
| B finishes, A remains live | ["1", "2"] | true | false |
| A finishes | [] | true | true |

Callback history is initially empty, then ["undefined","2"], then ["undefined","2","1"]. It stays unchanged at both action finishes. Thus B's completion does not publish a new undefined row; it retains the existing 2 row. JSON also records exact HTML, length, own keys, and array values.

The ordinary signal control constructs `const sparse=[]; sparse[1]=2` and publishes it; the ordinary store control writes `draft[1]=2`. Both render the same ["undefined","2"] rows, replacing the first row with 1 after writing index 0. This initial undefined row is normal For enumeration of a JavaScript sparse array, independent of action/revert behavior. The index-1 retention until A finishes is separate from the initial hole.
