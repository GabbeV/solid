import { createRequire } from 'node:module';
const {transform} = createRequire(import.meta.url)('/workspace/scratch/pending-repro-rc21/node_modules/@solidjs/compiler/index.js');
const root = process.env.PROBE_ROOT!;
export default {
 root:"/workspace/layered-solid",
 plugins:[{name:'local-native-jsx',enforce:'pre',transform(code,id){if(id.endsWith('.tsx'))return transform(code,{filename:id,generate:'dom',dev:true,sourceMap:true})}}],
 define:{__DEV__:'true',__OBSERVE__:'true',__TEST__:'true'},
 test:{environment:'jsdom',globals:true,include:['/workspace/scratch/store-length-review/for/for.test.tsx'],pool:'threads',maxWorkers:1,testTimeout:20000},
 resolve:{conditions:['development','browser'],alias:[
 {find:'solid-js/internal',replacement:`${root}/packages/solid/src/internal.ts`},
 {find:'solid-js',replacement:`${root}/packages/solid/src/index.ts`},
 {find:'@solidjs/signals',replacement:`${root}/packages/signals/src/index.ts`},
 {find:'@solidjs/web',replacement:`${root}/packages/web/src/index.ts`}
 ]}
};
