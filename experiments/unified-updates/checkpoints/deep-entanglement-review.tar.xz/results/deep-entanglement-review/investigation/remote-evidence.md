# Remote evidence: does deep(store) intentionally entangle disjoint actions?

Read-only GitHub connector investigation, 2026-11-11. No posts, edits, or runtime changes.

## Finding

I found **no direct Ryan first-person statement that calling deep(store) should merge the ownership/lifetimes of independent optimistic actions changing disjoint fields**. The strongest relevant Ryan-account statement rejects over-entangling disjoint actions merely because their subscribers share scheduling affinity. There is historical contrary language about store-wide optimistic scope; it does not mention deep and must not be silently reconciled into a present deep-specific rule. Container-wide read/hold semantics are explicitly documented remotely, but they are a different question from merging the underlying action owners.

Authorship caution: GitHub `user.login=ryansolid` proves account attribution, not that Ryan personally composed the prose. Comments below that expressly say “Claude via Cursor” are labeled AI text. Other implementation summaries have no explicit AI signature; I label them Ryan-account reports, not verified first-person human design statements. No source/test/issue-author prose is elevated to a Ryan ruling.

## Most relevant ownership evidence

1. **#2912 — Ryan-account implementation report; no explicit AI signature.**
   https://github.com/solidjs/solid/issues/2912#issuecomment-5010352787

   > “lanes are scheduling affinity and the shared-subscriber merge is correct for effect flushing, but `resolveTransition` following the merged lane root's `_transition` let the lane channel transfer transaction ownership.”

   > “Neither of the two proposed directions merged transactions on lane merge (that would over-entangle disjoint actions and undo #2899); instead ownership now lives on the node”

   > “genuinely entangled same-key writers share the joint root”

   Scope: shared subscriber/lane merging must not transfer ownership; same-key writers entangle. The issue author's body explicitly offered merging transactions as one possible direction, but the account's response rejected that direction. This supports independence generally; it does **not** explicitly classify a lazily allocated deep-witness guess as a subscriber vs intentional shared write.

2. **#2899 — Ryan-account implementation report; no explicit AI signature.**
   https://github.com/solidjs/solid/issues/2899#issuecomment-5000829601

   > “`clearOptimisticOverride` scopes the settle-path clear to the completing transaction's own keys (merge chains resolved via `currentTransition`, so same-key writes still entangle and settle jointly”

   > “Pinned in `tests/optimistic-store-layer-scope.test.ts` (disjoint keys, nested rows, same-key entanglement, deletes, ambient)”

   Scope: correction of whole-store override clearing for disjoint writers. Issue body is by brenelz, not Ryan, and does not test deep-observer-induced ownership.

## Conflicting historical language

3. **#2728 — Ryan-account report; no explicit AI signature, not first-person human evidence.**
   https://github.com/solidjs/solid/issues/2728#issuecomment-4911391452

   > “with the store-wide mask, the store is the entanglement unit — two mutations touching the same optimistic store entangle because they share the store's optimistic scope, not because their refreshes happened to overlap.”

   This directly supports store-wide entanglement in that historical model, but never mentions deep. The same comment says optimistic stores mask pending store-wide and declines affects; those are historical policies that cannot simply be treated as current authority. #2899/#2912 subsequently describe per-key ownership and reject disjoint-action over-entanglement. Do not cite only this sentence while omitting that conflict.

   The earlier comment https://github.com/solidjs/solid/issues/2728#issuecomment-4793753802 mentioning `isPending(() => deep(store))` and coarse store entanglement is **GabbeV's argument**, not Ryan's statement.

## Deep-specific evidence and its limits

4. **#3688 — explicitly AI-authored, posted by Ryan account.**
   https://github.com/solidjs/solid/issues/3688#issuecomment-5877647073

   > “the unit of a store hold is the **key** the fold staged, not the container”

   > “Reading a key the action *did* write still holds, as A29 requires; `ownKeys`, `$TRACK` and `deep()` remain container-wide.”

   Signed “Claude via Cursor.” This explicitly preserves broad reads joining a container's held work. It does not say deep observing two independent actions must merge their ownership or keep both overrides alive until both actions finish.

5. **#3707 — explicitly AI review direction, not Ryan first-person prose.**
   https://github.com/solidjs/solid/pull/3707#issuecomment-5885166957

   > “Keep the keyless-read exclusions (`ownKeys`, `$TRACK`, `deep()`), chained backings and optimistic families exactly as they are”

   Signed “Claude via Cursor.” The follow-up https://github.com/solidjs/solid/pull/3707#issuecomment-5897719599 explicitly speaks of Ryan in the third person (“Ryan went with the recorded-keys variant”), confirming why account attribution is insufficient. This is read precision, not owner entanglement.

6. **#3147 — Ryan-account short implementation report; no explicit AI signature.**
   https://github.com/solidjs/solid/issues/3147#issuecomment-5500621176

   > “deep()/snapshot readers and per-key readers now share a single held-landing visibility decision, so they no longer disagree while a transaction holds store landings.”

   Requires coherent values during a hold; does not prescribe whether disjoint action owners merge.

7. **#3323 and #3283 — expressly AI-generated fix reports.**
   https://github.com/solidjs/solid/issues/3323#issuecomment-5607971905
   https://github.com/solidjs/solid/issues/3283#issuecomment-5546693824

   Both signed “Claude via Cursor.” They address deep subscription completeness/chained views/overlay enumeration, not independent-action lifetime. #3323's “reader-families-agree rule applies to subscription as much as to value” cannot by itself establish ownership merging.

8. **#2850 — Ryan-account historical value-coherence report; no explicit AI signature.**
   https://github.com/solidjs/solid/issues/2850#issuecomment-4906672027

   > “`snapshot()` and `deep()` now resolve values optimistic-overlay-first, the same order as the proxy traps and `reconcile`.”

   Value selection only; no owner merge statement.

## Search coverage and limits

Searched GitHub issues and PRs in solidjs/solid for combinations of deep/deep(), entangle/entanglement, optimistic, disjoint, scope, independent, coarse; fetched issue/comment threads #2899, #2912, #2728, #3147, #3323, #3283, #2850, #2718, #4771, #3141, #2864, #3688; fetched PR comments #3019, #4603, #4553, #3707. PR searches surfaced #3275; the primary investigator is independently reviewing that thread. #2718 and #4771 had no comments in fetched results. No first-person deep-ownership direction surfaced. Search absence is not proof that no such statement exists anywhere.

Practical conclusion: preserve-next vs independence remains an implementation/explicit-user-ruling choice, pending local-history evidence. Remote evidence does not authorize asserting “Ryan intentionally wants deep() to entangle disjoint actions,” nor does it alone authorize changing behavior.

## Follow-up: commits introducing dk and optimistic dk writes

Primary's local trace identifies #3019 (079721584) for coarse dk and #3774 (1b9ceb679) for `optimisticWrite(t.dk,{})`; I fetched both PR bodies and complete connector comment timelines remotely.

- https://github.com/solidjs/solid/pull/3019 — Ryan-account body, expressly “Made with Cursor.” States “transactions/optimism ride core lanes” and “semantics were mined from ~17k lines of existing store tests into 217 pinned rules before implementation”. No deep/disjoint-owner decision appears in body. Four fetched comments are automated changeset/coverage/performance reports, with no human review discussion.
- https://github.com/solidjs/solid/pull/3774 — Ryan-account body, expressly “Co-authored-by: Claude via Cursor.” States “No public API change from the carve” and discusses “the deep tick's last ~10%” as an open performance point, but no deep-observer action-entanglement policy. Four fetched comments are bot reports; no human review discussion.

Neither introduction PR provides a remote statement endorsing the resulting ownership merge. These are AI-marked implementation/rebuild descriptions, not evidence of Ryan personally choosing deep-induced lifetime coupling.
