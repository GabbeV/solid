import { expect, test } from 'vitest';
import { action, createOptimisticStore, createRenderEffect, createRoot, createSignal, deep, flush } from 'probe-runtime';
function gate() {
  let resolve!: () => void;
  const promise = new Promise<void>(r => { resolve = r; });
  return { resolve, promise };
}
async function tick() { await new Promise(r => setTimeout(r, 0)); flush(); }
for (const withDeep of [false, true]) {
  test(`deep=${withDeep}: ordinary action writes share the entanglement`, async () => {
    let guess!: (f: (s: { a: number; b: number }) => void) => void;
    let setA!: (n: number) => void;
    let setB!: (n: number) => void;
    let visibleA = -1, visibleB = -1;
    const dispose = createRoot(dispose => {
      const [s, set] = createOptimisticStore({ a: 0, b: 0 });
      const [a, sa] = createSignal(0), [b, sb] = createSignal(0);
      guess = set; setA = sa; setB = sb;
      createRenderEffect(() => s.a, () => {});
      createRenderEffect(() => s.b, () => {});
      createRenderEffect(a, v => { visibleA = v; });
      createRenderEffect(b, v => { visibleB = v; });
      if (withDeep) createRenderEffect(() => deep(s), () => {});
      return dispose;
    });
    flush();
    const ga = gate(), gb = gate();
    const pa = action(function* () { setA(1); guess(s => { s.a = 1; }); yield ga.promise; })();
    flush();
    const pb = action(function* () { setB(2); guess(s => { s.b = 2; }); yield gb.promise; })();
    flush();
    expect([visibleA, visibleB]).toEqual([0, 0]);
    ga.resolve(); await tick();
    expect([visibleA, visibleB]).toEqual(withDeep ? [0, 0] : [1, 0]);
    gb.resolve(); await tick(); await Promise.all([pa, pb]);
    expect([visibleA, visibleB]).toEqual([1, 2]);
    dispose();
  });
}
