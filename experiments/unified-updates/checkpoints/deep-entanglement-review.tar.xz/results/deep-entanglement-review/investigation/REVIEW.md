# Primary review: deep observation and action entanglement

Main runtime unchanged at 743bfbd11. This is evidence and design review, not an implemented semantic change.

Verified independently:
- #2899 and #2912 comments distinguish per-key ownership from shared-reader scheduling; no deep-specific choice is stated.
- At next bcef1041, optimistic.ts guesses the shared dk, guesses.ts merges its prior parent owner with the new action. Historical source at 41fdf9696 already arms dk for the generic optimistic setter hook: #3774 is not established as the origin of the behavior.
- action-publication.test.ts adds ordinary signal writes to separate disjoint-guess actions. With deep, A's ordinary write waits after A's gate resolves until B finishes; without deep it publishes at A completion. Two tests pass on each of next 4fe75321 and bcef1041. They use separate scheduled renderers and real timer turns, no observations of internal state.
- #3275 describes ancestor witness bumps being deliberately ordinary to avoid accidentally creating an override. This abandoned AI-marked performance PR is a different case, not a ruling against direct dk ownership.

Implementation assessment:
- Independence avoids explicitly assigning action ownership to the notification witness.
- Preservation can potentially associate existing dk with its current action owner, merge that owner through existing scalar bindScope/merge, hand off ambient proposals when their scope is assigned, and retain the witness while that owner is live using existing store release handling.
- This avoids an additional full computed output. It still adds policy bookkeeping: a weak owner association and pending handoff, plus a retention hook. The agent's tens-of-lines estimate is an unimplemented design estimate, not measured shipped bytes or proven complete support.
- Both choices still owe nested/array invalidation, context-correct snapshots and cleanup. Comparing a complete preserving implementation with the current all-leaf prototype would be misleading.

Recommendation: preserve next initially under the user's preference to limit scope. No explicit deep-specific maintainer ruling was recovered, but neither has a substantial complete-implementation size advantage for independence been demonstrated. Revisit if actual integration reveals disproportionate complexity. Do not silently replace the publication invariant with this compatibility preference.

Evidence limits: searches cover recorded local docs/git and linked public GitHub discussions, not private Discord. Account authorship and merged AI-generated prose are not proof that Ryan personally considered this exact consequence.
