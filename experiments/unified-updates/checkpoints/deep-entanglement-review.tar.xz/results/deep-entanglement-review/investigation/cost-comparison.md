# Deep observer action entanglement: implementation cost

Preserving next's behavior is feasible at a modest additional cost in the shared engine. Independence avoids that extra lifetime policy, but there is currently no evidence of a large architectural or shipped-size advantage. If compatibility is the deciding preference, preserving next is a reasonable recommendation.

This is a source-backed design comparison, not a completed implementation or a byte/performance measurement. Main and both isolated store candidates remain unchanged by this investigation.

## Observable difference

With a deep observer, disjoint optimistic guesses A(a=1) and B(b=2) in separate events currently share the deep witness in next. Completing A while B remains open retains both guesses. It also keeps A's ordinary signal writes held: this is entire-action entanglement, not merely delaying one deep callback. Without the deep observer, A can publish its ordinary writes and correct its guess independently. The primary's executable receipt is `action-publication.test.ts` in this directory; next bcef passes both branches.

Next implements the overlap mechanically: `store/optimistic.ts:217` guesses `t.dk` whenever that witness exists. This uses the same guess machinery as a written property, so ordinary same-output scope overlap joins A and B. It is not a separate deep-specific scheduler.

The grouped static candidate instead has `deep()` read selected property outputs. Ordinary consumers can coordinate publication across those outputs, but that does not merge their action scopes. Its current direct-leaf subscription strategy is an interim notification implementation, not a complete efficient deep-store architecture.

## Smallest credible preservation mechanism

Reuse the existing **dk signal as a scope alias**, without allocating a second optimistic computed just to represent the witness:

1. A validated changed setter records its existing `target.dk`, if present, alongside its property proposals. No-change setters register no alias.
2. When each proposal obtains its action scope through existing scalar `bindScope`, merge that scope with the witness's previous live action owner, then update the witness owner pointer to the resolved scope. Existing `merge` and scalar `_merge` already union all guesses and retain ordinary writes for both actions.
3. Explicit action scopes can bind immediately. Ambient proposals acquire a scope in `prepareGuesses`, so a short pending alias handoff is necessary; a bare proposal that expires without a scope must clear its pending registration instead of retaining an owner indefinitely.
4. Extend store `slotKept` through an optional optimistic retention hook. Retain dk while its owner scope is live OR a registered proposal still awaits scope selection. Otherwise reuse the existing last-subscriber `deferredReleases`/`releaseSlot` path. In particular, dropping the deep reader while A is open must not discard the witness and let B escape the overlap that next would retain.

A plausible compact representation is two optional WeakMaps: witness -> {owner, pending count}, and layer -> pending witness. Stale owner pointers are judged through `liveTx`/`resolveTx`; weak keys avoid a global record-retention registry. Per-layer pending registration must clear on binding, proposal expiry, replacement and disposal. Multiple changed properties from one setter must not leak the pending count.

This is additional store-feature policy around the existing scope binder; ordinary signals need no new fields, and a full witness output/lifecycle system is unnecessary. The helpers should remain internal to store integration rather than expose dk as a public guessing API.

**Estimated additional executable source: roughly 40–70 lines**, plus meaningful lifecycle/ambient tests, across the slot adapter, store hook interface/retention check, and setter registration. This is an engineering estimate from identified insertion points, not a measured patch. The pending-registration and last-reader cases make a claim of “just one pointer assignment” too optimistic.

## What independence saves—and what it does not

Independence omits the witness owner map, pending alias handoff/count, scope-alias merge and dk-specific retention hook. It continues using property/arrangement outputs' existing action scopes.

Both policies still need complete deep notification and snapshot correctness: nested descendants, late-created slots, presence/deletions, arrays/length/holes, replacement/adoption, row identity, derived/async status, reader disposal, and correction publication. The grouped candidate's all-leaf deep hook supplies a working static-record notification baseline, but it can materialize/subscribe to many property nodes. Retaining the existing one-witness-per-record notification strategy efficiently requires further shared-engine integration under EITHER policy. Those common costs must not be counted only against preservation or ignored when calling independence cheaper.

The preservation alias itself extends naturally to nested targets and arrays: register the existing dk of each changed record, just where next currently sends its witness guess. A root deep traversal subscribes to descendant witnesses; it does not imply one global root witness or store-wide entanglement. Which records are touched, and which witness nodes exist, remain the current store notification rules. Structural edits need their normal presence/arrangement publication integration regardless of lifetime policy.

## Publication grouping is separate

The grouped candidate merges **output publication transactions** for one setter's changed properties before consumers run. This fixes the verified a=0/b=1 partial publication while a's async consequence waits. Those output groups retire after publication and do not extend the guessing actions' lifetimes.

Preserving deep overlap would additionally merge **action scopes** when different setters share dk. That deliberately extends A's ordinary writes and all its guesses until B completes. Reusing the writer-publication grouping as a substitute would implement the wrong behavior.

## Exact source verification points

All candidate references below are in `/workspace/scratch/unified-store-groups/packages/signals/src/`:

- `layers/optimistic.ts:63` scopes registry; `:133` prepareGuesses/ambient binding; `:212` merge hook unions scope membership; `:392` bindScope invokes normal merge; `:370` removeScope; `:380` releaseLayer; `:406` existing-input slot adapter; `:426` one-setter output proposal grouping.
- `core/scheduler.ts:532` liveTx; `:557` merge resolves both transactions, transfers held nodes/queues, and invokes existing layer merge policy.
- `store/store.ts:512` lazy getDeepNode; `:522` ordinary bumpDeep; `:346` slotKept; `:350` last-subscriber hook; `:929` deferred release sweep; `:309` releaseSlot clears `t.dk` for the $DEEP node.
- `core/graph.ts:35` unlinkSubs invokes the existing store last-subscriber hook.
- `/workspace/layered-next-4fe75321/packages/signals/src/store/optimistic.ts:217` is the preserved behavior's direct witness-guess cause.

Before adopting preservation, verify ambient late binding/expiry, reader disposal before and after scope binding, no-op/equal writes, scope merging after overlapping property guesses, late deep mounting, and nested/array witness release. These are implementation controls, not new semantic approval requirements.
