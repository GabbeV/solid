# Local history: deep-store transaction entanglement

**Finding:** Local history establishes an intentional coarse notification optimization and a concrete implementation that merges parent action transactions. I found **no explicit Ryan quote or narrowly stated ruling that adding `deep(store)` should merge otherwise disjoint actions**. Generic same-node overlap rules explain the result once `dk` is made an optimistic output; they do not establish that choosing this representation was intended to change transaction membership. There is substantial counterevidence favoring disjoint ownership.

Scope: read-only source/docs/git inspection in `/workspace/layered-solid` and `/workspace/scratch/solid-pr4717-review` (`bcef1041c`). No runtime or test changes. Remote discussions are outside this report. Existing minimal executable receipts are in `/workspace/scratch/store-integration-inventory/structural/minimal-{next4fe,nextbcef,candidate-scalar}.json`.

## Proven mechanism, not merely shared lifetime

At `bcef1041c`, [optimistic.ts:412](/workspace/scratch/solid-pr4717-review/packages/signals/src/store/optimistic.ts:412) executes:

```ts
if (t.dk !== null) optimisticWrite(t.dk, {} as any);
```

Both independent setters therefore guess the **same synthetic witness output** when a deep observer exists. [guesses.ts:154](/workspace/scratch/solid-pr4717-review/packages/signals/src/core/guesses.ts:154) obtains the existing lane's parent as `holder`; [guesses.ts:181](/workspace/scratch/solid-pr4717-review/packages/signals/src/core/guesses.ts:181) calls `merge(parent, holder)`. These are the **parent action transactions**, not just scheduling lanes or coincident retirement timers. This also explains why unrelated extra work in either merged action can become involved; the effect is broader than retaining one witness.

`git blame` attributes the `dk` guess line to **`1b9ceb679` (#3774, 2026-10-04)**; it survives the later carrier rewrite **`c98168082` (#4729)**. The current line is at 412; the main older implementation has the same statement at [optimistic.ts:218](/workspace/layered-solid/packages/signals/src/store/optimistic.ts:218).

## What history explicitly says about deep

1. **`079721584` (#3019, 2026-08-19), `.changeset/store-deep-witness-node.md`:**
   > “`deep()` subscribes one witness node per record instead of one node per path.”

   > “write channels bump the witness only when it exists”

   The changeset describes recovering a roughly 40% regression caused by creating property nodes per reachable path, and preserving `affects()`/`isPending()` coverage. The squashed commit subsection “store: deep() witness node” reports **21.7ms → 15.18ms**, compared with 15.24ms baseline. This is explicit **performance and notification intent**, not an explicit entanglement ruling.

   That version's `packages/solid-signals/src/store/next/optimistic.ts:226–228` says:
   > “Deep-witness: optimistic value writes notify deep() subscribers too”

   and calls `bumpDeep(t)`. `getDeepNode` in `src/store/next/store.ts` arms the witness for optimistic families. Thus the notification representation predates L2; L2 later makes the optimistic witness guess explicit. This does not by itself prove the exact disjoint-action behavior of every historical revision.

2. **`ae0ec3f54` (#3323, 2026-09-09)** says deep over a chained optimistic view “never re-ran on base writes” and fixes subscription to the inner witnesses; it also fixes deep observation of rows added under an action. [deep-chained-view.test.ts:15](/workspace/layered-solid/packages/signals/tests/store/deep-chained-view.test.ts:15) and its tests verify **notification and stable identity**, not disjoint-action transaction merging.

3. The public description [04-stores.md:220](/workspace/layered-solid/documentation/solid-2.0/04-stores.md:220) says:
   > “It subscribes to every nested property and returns a plain (non-proxy) snapshot.”

   It describes deep observation as the alternative to property tracking and says nothing about extending action transactions. Internal [target.ts:90](/workspace/layered-solid/packages/signals/src/store/target.ts:90) explicitly frames one witness per record as replacing “one per path,” with a separate witness so `$TRACK`/`mapArray` do not rerun on leaf changes.

**Provenance caveat:** These are accepted commit messages, changesets, comments and docs. The cited commits list Ryan as author and AI coauthors; author metadata and merge acceptance do **not** establish that every explanation is a verbatim personal Ryan ruling.

## Counterevidence and its strength

- **Accepted commit `d57d2c95b` (#2899, 2026-07-17):** fixes concurrent actions writing disjoint keys. Exact message:
  > “the settle-path clear consumes only the completing transaction's keys, resolving merge chains so same-key entanglement still settles jointly.”

  It calls this “A18's per-transaction override lifetime.” The tests at [optimistic-store-layer-scope.test.ts:27](/workspace/layered-solid/packages/signals/tests/optimistic-store-layer-scope.test.ts:27), :77, :119, and :164 distinguish disjoint fields/rows and delete-plus-independent-edit from same-key transaction entanglement. **Strong accepted behavior evidence**, but none of these cases adds a deep observer.

- **Accepted commit `5ab7d175e` (#2912, 2026-07-18):**
  > “A shared subscriber merges lanes across transactions — correct for effect scheduling”

  The bug was allowing the merged scheduling root to answer override ownership, thereby reverting another action's override and entangling follow-up writes with the wrong transaction. [optimistic-lane-transaction-ownership.test.ts:1](/workspace/layered-solid/packages/signals/tests/optimistic-lane-transaction-ownership.test.ts:1) is particularly explicit:
  > “that merge must not transfer TRANSACTION ownership of overrides”

  **Strong counterevidence against deriving transaction merging merely from one observer reading multiple outputs.** It does not specifically discuss a synthesized witness that is itself written by both actions.

- [SPEC-ASYNC-SEMANTICS.md:87](/workspace/layered-solid/packages/signals/docs/SPEC-ASYNC-SEMANTICS.md:87), labeled store/node ownership corollaries of #2899/#2912:
  > “concurrent actions on disjoint keys revert independently”

  > “ownership never travels through lanes”

  This is **recorded specification/editorial synthesis with attribution**, not a recovered raw Ryan message. The rules-mining summaries at [optimistic-store.md:72](/workspace/layered-solid/packages/signals/docs/rules-mining/optimistic-store.md:72) and [optimistic-lanes.md:71](/workspace/layered-solid/packages/signals/docs/rules-mining/optimistic-lanes.md:71) agree. They explicitly derive these from tests; they are not independent rulings.

- [size-reduction-carve-step1.md:546](/workspace/layered-solid/documentation/plans/size-reduction-carve-step1.md:546) introduces its quotation as **“Maintainer, 2026-10-01 … (normalized)”**:
  > “Ownership in itself doesn't entangle.”

  > “One exception to the overlap rule is render effects … overlap there does not entangle”

  This is an **attributed normalized ruling**, not independently verified verbatim source. It supports separating observation from transaction membership, but does not explicitly address `deep`'s write-side witness.

- [INTERNALS-STORE-STATE.md:94](/workspace/layered-solid/packages/signals/docs/INTERNALS-STORE-STATE.md:94): “node existence must be unobservable”; :98 records Ryan's signal-parity heuristic. These raise a representation concern, but **do not mechanically decide this case**: adding an observer changes the program, and is different from merely materializing a node within the same program. The relevant question is whether coarse subscription was intended to have stronger transaction semantics than equivalent property reads.

## What supports the implementation, without settling intent

[guesses.ts:140](/workspace/scratch/solid-pr4717-review/packages/signals/src/core/guesses.ts:140) says a second guess for an already held slot cannot finish apart (A34). Applying that generic rule to `dk` explains the merge. [size-reduction-carve-step1.md:4583](/workspace/layered-solid/documentation/plans/size-reduction-carve-step1.md:4583) explicitly discusses **structural array guesses** entangling because they share a container node. This is a different case: an arrangement/length output represents genuinely shared structure. Neither source specifically rules that a deep observer of **disjoint existing fields** should create shared write ownership.

**Unresolved semantic boundary:** notification of every deep mutation is clearly intended; merged parent transactions caused solely by the coarse notification witness are observable and implemented, but their deliberate semantic approval is not established by the local sources inspected. No new semantics are selected here.

## Follow-up: predecessor before #3774 already guessed the witness

**Verified: this was not an ordinary unowned notification before #3774.** The explicit `optimisticWrite(t.dk, ...)` line is not evidence of a newly introduced semantic change. The predecessor already routed deep bumps through the generic optimistic hooks.

Exact revision: **`41fdf9696b54e91978281cef8685d18c236d2ff8`**, the first parent of `1b9ceb679` (`git show 1b9ceb679^:<path>` reproduces the following evidence):

| Predecessor path | Lines | Source proof |
|---|---:|---|
| `packages/signals/src/store/next/store.ts` | 632–658 | `getDeepNode` creates the shared record witness; for optimistic families it executes `ext(created)._overrideValue = NOT_PENDING` and `created._config |= CONFIG_OPTIMISTIC` at 650–652. The witness is armed as an optimistic output. |
| Same | 661–665 | `bumpDeep` executes `if (t.dk !== null) setSignal(t.dk, 1 as any)`. |
| `packages/signals/src/store/next/optimistic.ts` | 668–671 | After notifying optimistic writes: “Deep-witness: optimistic value writes notify deep() subscribers too”; calls `bumpDeep(t)`. |
| `packages/signals/src/core/core.ts` | 2573–2580 | `setSignal` checks `CONFIG_OPTIMISTIC`; outside authoritative projection writes, it returns `GlobalQueue._optimisticWrite!(el, v)`. |
| `packages/signals/src/core/optimistic.ts` | 94–110 | An active override's repeat write calls `globalQueue.initTransition(resolveTransition(el))`; changed-value active overrides enter that transition as well. The comment explicitly says the current action's transition “must outlast all overlapping actions.” |
| Same | 118–121 | “Stamp ownership on the node (post-merge, so entangled writers share the joint root)”; assigns `ext(el)._overrideOwner = activeTransition`. |

Even at **`079721584` (#3019)**, the same source chain is present under `packages/solid-signals`: `src/store/next/store.ts:265–290` arms the witness's `_overrideValue` and bumps it via `setSignal`; `src/store/next/optimistic.ts:226–228` calls that bump; `src/core/core.ts:1060` routes it into `_optimisticWrite`; `src/core/optimistic.ts:65–84` enters the existing override's transaction and stamps `_overrideOwner` “post-merge.” This optimization therefore already had the generic guess-ownership path in its introducing squashed revision.

**Bounded conclusion:** source evidence establishes predecessor optimistic witness ownership and the transaction-joining route; it rules out characterizing pre-#3774 `dk` as a merely ordinary notification. No historical executable run was made, so this is source-path evidence rather than a measured timeline at those older revisions. Whether the coarse witness's consequent disjoint-action merging was specifically understood and deliberately approved remains unproven by the local history.
