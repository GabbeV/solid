# Static setter output publication groups

Worktree: /workspace/scratch/unified-store-groups
Base: 743bfbd11d8c007bfe56c7beb0cf7caceeab7830, with frozen static-slice complete.patch applied first.
No main integration, commits, pushes, installs, builds, full suites or performance work. Frozen ungrouped worktree/artifacts preserved unchanged.

## Change from frozen trial

layers/optimistic.ts adds internal proposeOptimisticSlots(entries). It submits ordinary scalar slot proposals and records one setter's changed layers. Existing lifecycle selection first freezes all proposals, assigns positions and stages each output as before. Before consumers run, each setter group merges only its resulting held output transactions through existing scheduler.merge. Action scopes and scope binding are unchanged. Group records clear immediately after publication joins are installed. Singleton/scalar proposals retain their existing paths.

Only equal-depth output groups are supported. A depth mismatch throws an explicit internal unsupported error rather than silently flattening depth. Current public interim store accepts static non-chained records, whose truth inputs are at the same depth; no nested/mixed-depth behavior claimed.

store/optimistic-static.ts now gathers the fully validated draft differences into one batch submission. No fake observer/memo, eager flush, legacy lane, root-wide boundary or second scheduler was introduced.

## Receipts

- single-setter-control.log: optimistic and ordinary standalone controls both PASS (2/2). Before grouping the identical optimistic probe FAILED with a=0,b=1,asyncA=0. Both pinned next controls pass unchanged; originals remain in ../writer-publication/.
- targeted-source.log: 25/25 PASS across new 5 writer-group tests, prior 6 static-slice tests, unchanged scalar API and cancellation suites (14 cases).
- existing-flat-controls.log: 3/3 existing flat #2899 cases PASS, 2 nested/structural outside-slice cases filtered out by name.
- git diff --check PASS.

Writer-group tests use separate scheduled effects for a,b,asyncA. Controls cover one setter changing multiple properties with suspended consequences; unrelated reruns; late reader; superseding setter/obsolete answer; cancellation back to committed for one pending property while another changes; overlapping (a,b)/(b,c) batches and same-key action lifetime; later separate-event disjoint action independence after grouped publication. Prior static tests cover creator/first-reader disposal, raw function/Promise values and rejected structural drafts.

## Artifacts

complete.patch includes every tracked AND new source/test file relative to the recorded base. complete-source.tar.gz contains all seven changed/new complete files. base.txt/status.txt preserve provenance.

## Scope and remaining review

Supported/unsupported static surfaces are otherwise unchanged from ../static-slice/README.md. Deep-witness lifetime ruling remains pending; no old deep action joining was added. Enumeration still composes selected backing under untrack; its calculation-context versus descriptor-collection tradeoff remains open. This grouping trial fixes the independently established writer-publication acceptance gap, not the remaining store integration scope. Same-tick A/B/C expectation remains unestablished under ordinary batching; no runtime fix or old test expectation change.
