const fs = require('node:fs');
const esbuild = require('/workspace/layered-solid/node_modules/esbuild');
const root = '/workspace/scratch/store-review-next-20261112';
const aliases = {
 'solid-js/internal':root+'/packages/solid/src/internal.ts',
 'solid-js':root+'/packages/solid/src/index.ts',
 '@solidjs/signals':root+'/packages/signals/src/index.ts',
 '@solidjs/web':root+'/packages/web/src/index.ts'
};
(async()=>{
 const result=await esbuild.build({stdin:{contents:`export {action, createOptimistic, createOptimisticStore, createStore, createMemo, createSignal, isPending, deep, Loading, For, Errored, Show, createComponent, createRenderEffect, createEffect, getOwner, onMount, createRoot, onCleanup, untrack} from 'solid-js';\nexport * from '${root}/packages/web/src/client.ts';\nexport {render} from '@solidjs/web';\nexport * from 'solid-js/internal';`,resolveDir:root,sourcefile:'runtime-entry.ts',loader:'ts'},bundle:true,format:'esm',platform:'browser',conditions:['browser','development'],alias:aliases,define:{__DEV__:'true',__OBSERVE__:'true',__TEST__:'false'},plugins:[{name:'build-flags',setup(b){b.onLoad({filter:/\.[jt]s$/},args=>{if(!args.path.startsWith(root))return;return {contents:fs.readFileSync(args.path,'utf8').replaceAll('"_SOLID_DEV_"','true').replaceAll('"_SOLID_OBSERVE_"','true'),loader:args.path.endsWith('.ts')?'ts':'js'}})}}],minifyWhitespace:true,minifySyntax:true,minifyIdentifiers:true,keepNames:true,metafile:true,write:false});
 fs.writeFileSync(__dirname+'/runtime.js','// Unmodified Solid next dfb18120a407f7b505bfd7cde25c745d8d965932, development flags.\n'+result.outputFiles[0].text);
 fs.writeFileSync(__dirname+'/runtime-metafile.json',JSON.stringify(result.metafile,null,2));
 console.log(result.outputFiles[0].text.length);
})().catch(e=>{console.error(e);process.exitCode=1});
