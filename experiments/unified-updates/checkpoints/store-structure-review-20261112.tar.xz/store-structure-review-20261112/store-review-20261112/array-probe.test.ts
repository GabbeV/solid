import { appendFileSync } from "node:fs";
const record = (data: unknown) => appendFileSync(process.env.RECEIPT!, JSON.stringify(data)+"\n");
import { it } from 'vitest';
import { action, createOptimistic, createOptimisticStore, createRenderEffect, createRoot, createSignal, flush, isPending } from 'test-signals';
const turn = async () => { await new Promise(resolve => setTimeout(resolve, 0)); flush(); };
const view = (array: string[]) => ({ values: Array.from(array, x => x ?? '<hole>'), length: array.length, keys: Object.keys(array) });
it('single structural guess over shrinking independent input', async () => {
 const [input, setInput] = createSignal(['A']);
 const end = Promise.withResolvers<void>(); const shown:any[]=[]; const raw:any[]=[];
 const [rows, guess, dispose] = createRoot(dispose => {
  const [rows, guess] = createOptimisticStore(() => input(), ['A']);
  createRenderEffect(() => view(rows), x => {shown.push(x)});
  createRenderEffect(input, x => {raw.push([...x])});
  return [rows, guess, dispose] as const;
 });
 let running:Promise<any>|undefined; const phases:any[]=[];
 const sample=(at:string)=>phases.push({at,shown:shown.at(-1),input:raw.at(-1),pending:isPending(()=>rows.length)});
 try {
  flush();sample('initial');
  running=action(function*(){guess(d=>{d.push('M')});yield end.promise})();
  running.catch(()=>{});flush();sample('guess');
  setInput([]);flush();sample('input empty');
  end.resolve();await running;await turn();sample('action ended');
  record({case:'shrink',phases,shown,raw});
 } finally {end.resolve();await Promise.allSettled([running]);dispose();flush()}
});
for(const seedLoadingValue of [false,true]) it('push before first answer '+seedLoadingValue,async()=>{
 const answer=Promise.withResolvers<string[]>(), end=Promise.withResolvers<void>();
 const shown:any[]=[];let calls=0;let rejected:string|undefined;let setterSeen:any;const phases:any[]=[];
 const [rows,guess,dispose]=createRoot(dispose=>{
  const [rows,guess]=createOptimisticStore(()=>answer.promise,[],{seedLoadingValue});
  createRenderEffect(()=>view(rows),x=>{shown.push(x)});
  return [rows,guess,dispose] as const;
 });
 let running:Promise<any>|undefined;
 const sample=(at:string)=>phases.push({at,shown:shown.at(-1)??'loading',calls,rejected,setterSeen});
 try{
  flush();sample('initial');
  running=action(function*(){guess(d=>{calls++;setterSeen=view(d);d.push('M')});yield end.promise})();
  running.catch(e=>{rejected=e?.message??String(e)});await turn();sample('guess');
  answer.resolve(['A','B']);await turn();sample('first answer');
  end.resolve();await Promise.allSettled([running]);await turn();sample('action ended');
  record({case:'initial',seedLoadingValue,phases,shown});
 }finally{answer.resolve(['A','B']);end.resolve();await Promise.allSettled([running]);dispose();flush()}
});

it('whole array scalar boundary control',async()=>{
 const [input,setInput]=createSignal(['A']); const end=Promise.withResolvers<void>();const shown:any[]=[];const raw:any[]=[];const phases:any[]=[];
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimistic(()=>input());createRenderEffect(()=>view(rows()),x=>{shown.push(x)});createRenderEffect(input,x=>{raw.push([...x])});return [rows,guess,dispose] as const});
 let running:Promise<any>|undefined;const sample=(at:string)=>phases.push({at,shown:shown.at(-1),input:raw.at(-1)});
 try{flush();sample('initial');running=action(function*(){guess(a=>[...a,'M']);yield end.promise})();flush();sample('guess');setInput([]);flush();sample('input empty');end.resolve();await running;await turn();sample('action ended');record({case:'whole-array',phases});}finally{end.resolve();await Promise.allSettled([running]);dispose();flush()}
});
