import json,subprocess,pathlib,sys,os
base=pathlib.Path(__file__).parent
for label,repo in [('next-pr4793','/workspace/scratch/store-review-next-pr4793-20261112')]:
 config=base/(label+'.config.mts')
 config.write_text('export default '+json.dumps({'define':{'__DEV__':'true','__OBSERVE__':'true','__TEST__':'true'},'resolve':{'alias':{'test-signals':repo+'/packages/signals/src/index.ts'}},'test':{'globals':True,'include':[str(base/'array-probe.test.ts')],'pool':'threads'}}))
 cmd=['node','/workspace/layered-solid/node_modules/vitest/vitest.mjs','run','--config',str(config)]
 receipt=base/(label+'-array.jsonl');receipt.write_text('')
 with (base/(label+'-array.log')).open('w') as f:r=subprocess.run(cmd,cwd=repo+'/packages/signals',env={**os.environ,'RECEIPT':str(receipt)},stdout=f,stderr=subprocess.STDOUT)
 rows=[json.loads(l) for l in receipt.read_text().splitlines()]
 (base/(label+'-array.json')).write_text(json.dumps(rows,indent=2)+'\n');print(label,'exit',r.returncode,json.dumps(rows),flush=True)
