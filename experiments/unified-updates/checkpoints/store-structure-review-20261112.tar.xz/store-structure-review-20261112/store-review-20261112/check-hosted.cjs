const {chromium}=require('/workspace/pr3886/browser/node_modules/playwright');
const fs=require('node:fs');
const name=process.argv[2];const root=__dirname+'/repros/'+name;
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,proxy:{server:process.env.HTTPS_PROXY},args:['--no-sandbox']});
 try{
  const context=await browser.newContext({viewport:{width:1300,height:850}});
  const cookies=fs.readFileSync('/workspace/scratch/pending-repro-rc21/playground.cookies','utf8').split('\n').filter(l=>l&&(!l.startsWith('#')||l.startsWith('#HttpOnly_'))).map(l=>{const httpOnly=l.startsWith('#HttpOnly_');const[domain,,path,secure,expiry,name,value]=l.replace(/^#HttpOnly_/,'').split('\t');return {name,value,domain,path,secure:secure==='TRUE',httpOnly,...(+expiry?{expires:+expiry}:{})}});await context.addCookies(cookies);
  const page=await context.newPage();const errors=[],failed=[],consoleMessages=[];page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));page.on('console',m=>{if(m.type()==='error')consoleMessages.push(m.text())});
  const key=JSON.parse(fs.readFileSync(root+'/save.json')).key;const url='https://s.olid.uk/id/'+key;fs.writeFileSync(root+'/url.txt',url+'\n');await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});
  let frame;
  for(let i=0;i<60;i++){frame=page.frames().find(f=>f!==page.mainFrame()&&f.url()!=='about:blank');if(frame&&await frame.locator('main button').count()){await page.waitForTimeout(5000);if(await frame.locator('main button').count())break;}await page.waitForTimeout(500)}
  const samples=[];const sample=async at=>samples.push({at,text:await frame.locator('main').innerText()});
  if(frame&&await frame.locator('main button').count()) {await sample('initial');await frame.locator('main button').click();await page.waitForTimeout(150);await sample('150ms');await page.waitForTimeout(500);await sample('650ms');await page.waitForTimeout(1000);await sample('1650ms');await frame.locator('main').screenshot({path:root+'/final.png'});} else {consoleMessages.push('No runnable main found: '+(await page.locator('body').innerText()).slice(-3500));}
  const actualMap = frame ? await frame.evaluate(() => document.querySelector('script[type="importmap"]')?.textContent ?? '') : '';
  const expectedMap=JSON.parse(JSON.parse(fs.readFileSync(root+'/payload.json','utf8')).state.importMap);
  let runtimeMatches=false;try{const m=JSON.parse(actualMap);runtimeMatches=Object.entries(expectedMap.imports).every(([k,v])=>m.imports[k]===v)}catch{}
  fs.writeFileSync(root+'/browser.json',JSON.stringify({url,samples,errors,failed,consoleMessages,runtimeMatches,frames:page.frames().map(f=>f.url())},null,2));console.log(JSON.stringify({url,samples,errors,consoleMessages},null,2));
  if(!samples.length||errors.length)process.exitCode=1;
  if(name==='shrink' && (!samples[2]?.text.includes('Optimistic array: ["A","M"]') || !samples[3]?.text.includes('Input: []')))process.exitCode=1;
  if(name==='nested-seed' && (!samples[1]?.text.includes('NotReadyError') || !samples[3]?.text.includes('Visible child.x: 2')))process.exitCode=1;
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
