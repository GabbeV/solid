# Nested pending query comparison, 2026-11-12

Sources are pinned in `sources.json`. Runtime source is imported by absolute alias from each selected worktree. Dependency symlinks resolve tooling only, not the tested `subject` import. No runtime edits were made.

Run from this directory:

```sh
SUBJECT=/workspace/layered-solid RECEIPT="$PWD/repeat.jsonl" node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config vite.config.mjs
```

Use the old/current next source paths in sources.json for comparisons. `CASE=action-compare.test.ts` selects the separate open-action control. Receipts append to JSONL, so choose a fresh filename per run.

The core program creates an async optimistic store with `{ object: { guessed, unguessed }, scalar }`. It resolves the first answer, updates a source signal to start a second pending answer, then guesses `object.guessed = 99` while the second answer remains unresolved. A render effect publishes an object of five independent isPending queries: the object reference, the guessed child, the unguessed child, deep(object), and scalar. A separate render effect publishes the guessed value. The receipt records every published status frame, direct probes, and the published guessed value.

## Actual published frame during second request

All queries start true before a guess. These rows are after an ambient leaf guess:

| Source | object reference | guessed child | unguessed child | deep(object) | scalar | published guessed |
| --- | --- | --- | --- | --- | --- | --- |
| old next bcef1041c | true | true | true | true | true | 99 |
| current next dfb18120a | true | true | true | true | true | 99 |
| experiment 8c35af093 | false | true | true | true | true | 99 |

The difference is real and narrow. The reference query asks only about availability of the selected proxy; it does not enumerate the object's children. Deep explicitly queries the contents and stays pending. This supports treating the proxy as an independently available identity, but does not by itself establish a required API contract. Both next versions conservatively retain pending on that reference.

Controls: replacing the entire object, guessing a scalar, or putting the leaf guess inside an open action keeps all five probes true on all three sources. An active leaf write preserves the object proxy identity on all three (retained reference equals current reference, shown child is 77).

Initial request: with seedLoadingValue:true, the seed is available and all five probes publish false on all three sources. With default first-load behavior, no status frame publishes before the answer; outside an owner the loading probes return false. That is loading, not evidence that the query has settled. Both next versions reject an initial optimistic write; the experiment accepts it, while the tested status effect still publishes no initial frame. This is separate from the second-request reference distinction.

Validation: final compare.test.ts runs two tests on each source with all passing, in verified-experiment.log, verified-old-next.log, verified-current-next.log and matching JSONL. Open-action control uses action-compare.test.ts and experiment.jsonl/old-next.jsonl/current-next.jsonl. Earlier scratch logs are retained, including harness failures before fixing effect callbacks and handling next's first-load rejection.

No DOM test was needed for this query: render-effect callbacks are the publication channel tested here. No maintainer statement requiring ancestor pending to summarize all descendant pending was found or assumed.
