import { appendFileSync } from "node:fs";
import { expect, it } from "vitest";
import {
  action, createMemo, createRenderEffect, createRoot, createSignal, flush, isPending, untrack
} from "../src/index.js";

const turn = async () => { await new Promise(resolve => setTimeout(resolve, 0)); flush(); };

for (const asyncInput of [false, true])
  for (const scope of ["imperative", "tracked", "untracked", "held-untracked"] as const)
    it(`callback values async=${asyncInput}, ${scope}`, async () => {
      const answer = Promise.withResolvers<{ key: number }>();
      const lifetime = Promise.withResolvers<void>();
      const [id, setId] = createSignal(0);
      const [revision, setRevision] = createSignal(0);
      const [left] = createSignal("left");
      const [right] = createSignal("right");
      const reads: unknown[] = [], frames: unknown[] = [];
      let phase = "initial", shown: unknown;
      let probe!: () => boolean;
      const dispose = createRoot(dispose => {
        const choice = createMemo(() => id() === 0 ? { key: 0 } :
          asyncInput ? answer.promise : { key: 1 });
        probe = () => {
          let key: number | undefined, leaf: string | undefined;
          const pending = isPending(() => {
            key = choice().key;
            leaf = key === 0 ? left() : right();
          });
          reads.push({ phase, key, leaf, pending });
          return pending;
        };
        createRenderEffect(choice, value => { shown = value.key; });
        if (scope !== "imperative") {
          const reader = createMemo(() => {
            revision();
            if (scope === "held-untracked") id();
            return scope === "tracked" ? probe() : untrack(probe);
          });
          createRenderEffect(reader, () => {});
        }
        return dispose;
      });
      const capture = () => {
        if (scope === "imperative") probe();
        frames.push({phase, shown});
      };
      let running: Promise<unknown> | undefined;
      try {
        flush(); capture();
        phase = "write";
        running = action(function* () { setId(1); yield lifetime.promise; })();
        flush(); capture();
        phase = "held";
        setRevision(1); flush(); capture();
        phase = "answered-held";
        answer.resolve({key: 1}); await turn(); capture();
        phase = "rerun-answered-held";
        setRevision(2); flush(); capture();
        phase = "committed";
        lifetime.resolve(); await running; await turn(); capture();
        expect(frames.map((f:any) => f.shown)).toEqual([0,0,0,0,0,1]);
        appendFileSync(process.env.PROBE_RESULT!, JSON.stringify({asyncInput, scope, reads, frames}) + "\n");
      } finally { lifetime.resolve(); dispose(); flush(); }
    });
