import config from '/workspace/layered-solid/packages/signals/vite.config.ts';
export default async args => {const r=typeof config === 'function' ? await config(args) : config;return {...r,resolve:{alias:[{find:/^(?:\.\.\/)+src\/(.*)\.js$/,replacement:'/workspace/scratch/array-regressions-20261115/baseline/packages/signals/src/$1.ts'}]}}};
