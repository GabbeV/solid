import config from '/workspace/layered-solid/packages/signals/vite.config.ts';
export default async args => {
const result=typeof config==='function'?await config(args):config;
return {...result,test:{...result.test,dir:'/workspace/scratch/callback-trace/tests'},resolve:{alias:[{find:/^(?:\.\.\/)+src\/(.*)\.js$/,replacement:'/workspace/scratch/callback-trace/src-baseline/$1.ts'}]}};
};
