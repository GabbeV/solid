/**
 * Store — the engine's optional-machinery slots, in a module of their own so
 * an installer reaches them without importing store.ts (whose top level
 * installs the engine): the store half of `affects()` installs through here
 * from `affects()`, and an app without stores carries none of the engine.
 * A slot no installer reaches stays `null`, and a bundler folds its sites.
 */
import type { Transaction } from "../core/scheduler.js";
import type { Computed, Signal } from "../core/types.js";
import type { StoreFamily, StoreTarget } from "./target.js";

/** The optimistic machinery (optimistic.ts, S4), installed when it loads
 * — a plain store pays nothing for it (#2883): the plain paths reach it
 * only through a family with `opt` set, which only `createOptimisticStore`
 * sets. */
export interface OptHooks {
  /** The selected companion, for structural subscription identity. */
  node?(t: StoreTarget, node: Signal<any>): Signal<any>;
  /** Select a store-owned truth slot through its shared optimistic output. */
  read?(t: StoreTarget, node: Signal<any>): unknown;
  /** A selected accessor descriptor serves through its getter with the proxy receiver. */
  accessor?(t: StoreTarget, key: PropertyKey, receiver: object): { value: unknown } | undefined;
  /** Whether a selected descriptor supersedes a cached accessor flag. */
  accessorKind?(t: StoreTarget, key: PropertyKey): boolean | undefined;
  /** A selected parent object supplies an unguessed child value. */
  rowValue?(t: StoreTarget, key: PropertyKey, receiver: object): { value: unknown } | undefined;
  /** Track the selected flat leaves for a deep read. */
  deep?(t: StoreTarget): void;
  /** A user setter's draft on an optimistic family: a clone of the
   * writer's view (a staging already on the target is set aside). */
  draft(t: StoreTarget): Record<PropertyKey, any>;
  /** A user's draft operation, excluding internal copying and comparison. */
  draftRead?(t: StoreTarget, key: PropertyKey | undefined, kind: "value" | "has" | "keys"): void;
  /** Array-only selected length and successful user draft mutations. */
  length?(t: StoreTarget, base: () => number): number;
  draftWrite?(
    t: StoreTarget,
    key: PropertyKey,
    before: number,
    after: number,
    kind: "set" | "delete"
  ): void;
  /** The setter's exit: the draft becomes guesses; returns the staging the
   * draft set aside (`null`: none). */
  writes(t: StoreTarget, pb: Record<PropertyKey, any>): Record<PropertyKey, any> | null;
  /** `src` with the lanes' values over it (`writer`: the next write's base
   * — the unflushed guesses too). */
  view(t: StoreTarget, src: Record<PropertyKey, any>, writer?: boolean): Record<PropertyKey, any>;
  /** An untracked `key in store`: the presence guess, or `undefined`. */
  has(t: StoreTarget, key: PropertyKey): boolean | undefined;
  /** A guessed key's descriptor (`null`: removed; `undefined`: no guess). */
  descriptor(
    t: StoreTarget,
    key: PropertyKey,
    source: Record<PropertyKey, any>
  ): PropertyDescriptor | null | undefined;
  /** The flush's commit: targets no lane holds leave `_overlaid`. */
  sweep(): void;
  /** The container comparator's lane arm: an arrangement guess against a
   * landing (or another arrangement), by row identity. */
  arrangement(t: StoreTarget, a: any, b: any): boolean;
  /** A user's `reconcile` on an optimistic family: the keyed diff written
   * into the draft. */
  reconcile(draft: any, incoming: any, keyFn: ((item: any) => any) | null): void;
  /** The derive's draft wrote `pb` on `t`: the new object at a guessed
   * row's slot (by key in a keyed list) is adopted by that row's target. */
  pair(t: StoreTarget, pb: Record<PropertyKey, any>): void;
  /** The derive of `fam` went in flight (#4336): a new question asked over
   * the family's guesses is judged by its reads (`stands`) and at the seam
   * (`park`). Returns, for a `refresh()`, the leaves its wake skips. */
  ask(fam: StoreFamily): ((n: any) => unknown) | void;
  /** The flush parks with `t`: a guess a frame still reads, over a family
   * asked a new question this flush, holds `t` with its action (D-34). */
  park(t: Transaction): void;
  /** A read of `t` while its family's derive is in flight: the family's
   * guesses stand in for the flight (no suspension). */
  stands(t: StoreTarget, key?: PropertyKey, presence?: boolean): boolean;
  /** A concrete selected parent body supplies the source for child slots. */
  inputBody?(t: StoreTarget): Record<PropertyKey, any> | undefined;
  /** This key's selected output owns the producer input and its status cut. */
  ownsFirewall?(t: StoreTarget, key?: PropertyKey, presence?: boolean): boolean;
}
// Set before any family is optimistic (`fam.opt`): a call site checks the
// hooks first, so a build that does not import optimistic.ts folds the arm
// away.
export let optHooks: OptHooks | null = null;
export function installOptHooks(hooks: OptHooks): void {
  optHooks = hooks;
}

/** The store half of `affects()` (store/affects.ts), installed by the first
 * store-targeted declaration: a node born on a covered record inherits the
 * live mark; an untracked verdict probe through a record with no node is
 * witnessed. */
export interface AffectsHooks {
  _born(t: StoreTarget, node: Signal<any>, key: PropertyKey): void;
  _witness(t: StoreTarget, key: PropertyKey | undefined): void;
}
export let affectsHooks: AffectsHooks | null = null;
export function installAffectsHooks(hooks: AffectsHooks): void {
  affectsHooks = hooks;
}
