import {it, expect} from 'vitest';
import {appendFileSync} from 'node:fs';
import {action, affects, createErrorBoundary, createRenderEffect, createMemo, createRoot, createSignal, flush, isPending, latest, resetErrorHalt} from '../src/index.js';
const tick=async()=>{await new Promise(r=>setTimeout(r,0));flush()};
const attempt=(f:()=>unknown)=>{try{return f()}catch(e:any){return `E:${e?.cause?.message??e?.message}`}};
for(const scenario of ['persistent','recovery','new-error'] as const)
for(const order of ['source-first','error-first'] as const)
it(`${scenario}/${order}`,async()=>{
const rows:any[]=[];
for(const mode of ['mark-upstream','mark-direct','async'] as const){
 const gate=Promise.withResolvers<number>(), hold=Promise.withResolvers<void>();
 const outputs:any[]=[],verdicts:any[]=[];
 const app=createRoot(dispose=>{
  const [id,setId]=createSignal(0), [error,setError]=createSignal(scenario!=='new-error');
  const source=createMemo(()=>id()===0?0:gate.promise);
  const failed=createMemo(()=>{if(order==='source-first'){const value=source();if(error())throw new Error('boom');return value+10;}if(error())throw new Error('boom');return source()+10;});
  const child=createMemo(()=>failed()+100);
  const boundary=createErrorBoundary(child,e=>`E:${(e() as Error).message}`);
  createRenderEffect(boundary,v=>void outputs.push(v));
  createRenderEffect(()=>[isPending(source),isPending(failed),isPending(child),isPending(boundary)],v=>void verdicts.push(v));
  return {dispose,setId,setError,source,failed,child,boundary};
 });flush();
 const snap=(phase:string)=>rows.push({mode,phase,p:[isPending(app.source),isPending(app.failed),isPending(app.child),isPending(app.boundary)],v:[attempt(app.failed),attempt(app.child),attempt(app.boundary)],l:[attempt(()=>latest(app.failed)),attempt(()=>latest(app.child)),attempt(()=>latest(app.boundary))],outputs:[...outputs],verdicts:[...verdicts]});
 snap('initial');
 const running=action(function*(){if(mode==='mark-upstream')affects(app.source);else if(mode==='mark-direct')affects(app.failed);else app.setId(1);if(scenario!=='persistent')app.setError(scenario==='new-error');yield hold.promise;})();
 try{flush();snap('pending');gate.resolve(0);await tick();snap('gate-resolved');}finally{gate.resolve(0);hold.resolve();await running;await tick();snap('done');app.dispose();resetErrorHalt();}
}
appendFileSync('/workspace/scratch/affects-model-20261115/error-agent-matrix.jsonl',JSON.stringify({scenario,order,rows})+'\n');expect(rows.length).toBe(12);
});
