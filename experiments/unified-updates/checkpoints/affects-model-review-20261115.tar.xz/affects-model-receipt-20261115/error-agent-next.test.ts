import {it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {action,affects,createMemo,createSignal,createRoot,createRenderEffect,createErrorBoundary,isPending,flush,resetErrorHalt} from '../src/index.js';
it('minimal',async()=>{const rows:any[]=[];
for(const mode of ['mark','async'] as const){
const gate=Promise.withResolvers<number>(),hold=Promise.withResolvers<void>();let screen:unknown;const seen:any[]=[];
const app=createRoot(dispose=>{const [id,setId]=createSignal(0);const source=createMemo(()=>id()===0?0:gate.promise);const failed=createMemo(()=>{source();throw new Error('boom')});const child=createMemo(()=>failed());const boundary=createErrorBoundary(child,e=>`E:${(e() as Error).message}`);createRenderEffect(boundary,v=>{screen=v});createRenderEffect(()=>[isPending(source),isPending(failed),isPending(child),isPending(boundary)],v=>void seen.push(v));return{source,failed,child,boundary,setId,dispose}});flush();
const snap=(phase:string)=>rows.push({mode,phase,screen,p:[isPending(app.source),isPending(app.failed),isPending(app.child),isPending(app.boundary)],seen:[...seen]});snap('initial');const running=action(function*(){if(mode==='mark')affects(app.source);else app.setId(1);yield hold.promise})();try{flush();snap('pending');gate.resolve(0);await new Promise(r=>setTimeout(r,0));flush();snap('gate');}finally{gate.resolve(0);hold.resolve();await running;await new Promise(r=>setTimeout(r,0));flush();snap('done');app.dispose();resetErrorHalt()}}
writeFileSync('/workspace/scratch/affects-model-20261115/error-agent-minimal-next.json',JSON.stringify(rows,null,2));expect(rows.length).toBe(8)});
