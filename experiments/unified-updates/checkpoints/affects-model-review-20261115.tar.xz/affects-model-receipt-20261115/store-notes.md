Store scope investigation, 2026-11-15
Runtime baseline: experiment 7a54e5ccf. Next freshly fetched: 221b5f99f.
No runtime changes retained. Probes are exploratory, not accepted expectations.

store-model-probes.test.ts: copy to packages/signals/tests/tmp-affects-store-model.test.ts and run Vitest from packages/signals. next.config.mts redirects source imports to the fetched source snapshot. Remove temporary test afterward.

Four downstream declaration probes (keyed/keyless, active/inactive override) pass in both: marking the derived optimistic output reports pending there without marking the upstream store.
New child inserted into a plain store after declaration: captured child reports false. Active optimistic insertion reports true in experiment, false in next. Derived plain/optimistic store producer replacement: both report length=true, captured child=false.

Bounded trial: append the root family's producer node to storeMarks' registration list (only t.u===null and t._fam.node). This makes both derived replacement probes pass without breaking the 19 focused existing/lifetime tests. Full targeted run:26 pass,1 plain-store case fails. Trial restored; no full suite or perf claim. Does not handle plain stores without a producer, and does not establish complete output-side behavior.

Shared alias control (last two probes) verified both experiment and next:
const [shared] = createStore({name:'new'});
const [list,write] = createStore({rows:[]});
Insert shared before or after affects(list) starts in a held action.
After insertion list.rows[0] === shared.
Through-list probe is true in both orderings.
Captured/shared probes are true if insertion preceded declaration, false if after.
This exposes a remaining policy choice: source-local dependency versus covering all reachable aliased data. Do not silently infer this from implementation parent pointers: wrap deduplicates raw targets and .u records their first wrapping parent, not every alias path.

Error investigation independently recorded in error-agent-notes.md. Unexpected error-boundary final undefined reproduced in next and experiment; separate unresolved observation, not attributed to affects and not a demonstrated experiment regression.
