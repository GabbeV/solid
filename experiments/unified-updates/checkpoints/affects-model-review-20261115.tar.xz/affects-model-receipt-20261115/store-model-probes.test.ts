import {it, expect} from 'vitest';
import {action, affects, createMemo, createOptimisticStore, createRoot, createSignal, createStore, flush, isPending} from '../src/index.js';

for (const override of [false,true]) for (const keyed of [false,true]) it(`downstream declaration override=${override} keyed=${keyed}`, async () => {
  const end = Promise.withResolvers<void>();
  const app = createRoot(dispose => {
    const [source] = createOptimisticStore(() => ({a:1,b:2}),{a:0,b:0});
    const [view,guess] = createOptimisticStore(() => source,{a:0,b:0});
    return {source,view,guess,dispose};
  });
  flush();
  const running = action(function*(){
    if (override) app.guess(v => {v.a=9;});
    if (keyed) affects(app.view,'a'); else affects(app.view);
    yield end.promise;
  })();
  try {
    flush();
    expect({sourceA:isPending(() => app.source.a),viewA:isPending(() => app.view.a),sourceB:isPending(() => app.source.b),viewB:isPending(() => app.view.b)}).toEqual({sourceA:false,viewA:true,sourceB:false,viewB:!keyed});
  } finally {end.resolve(); await running; app.dispose(); flush();}
});

for (const optimistic of [false,true]) it(`new child optimistic=${optimistic}`, async () => {
  const end = Promise.withResolvers<void>();
  const app = createRoot(dispose => {
    const [store,write] = optimistic ? createOptimisticStore<{rows:{name:string}[]}>({rows:[]}) : createStore<{rows:{name:string}[]}>({rows:[]});
    return {store,write,dispose};
  });
  const running = action(function*(){affects(app.store);yield end.promise;})();
  flush();
  // A separate event supplies the expected change while the declaration is live.
  const write = () => app.write(s => {s.rows.push({name:'new'});});
  const writing = optimistic ? action(function*(){write();yield end.promise;})() : (write(),undefined);
  flush();
  try {
    const child = app.store.rows[0];
    expect(child?.name).toBe('new');
    expect(isPending(() => child.name)).toBe(true);
  } finally {end.resolve(); await running; await writing; app.dispose(); flush();}
});

for (const optimistic of [false,true]) it(`derived replacement optimistic=${optimistic}`, async () => {
  const end = Promise.withResolvers<void>();
  const app = createRoot(dispose => {
    const [version,setVersion] = createSignal(0);
    const derive = () => ({rows: version() === 0 ? [] : [{name:'new'}]});
    const [store] = optimistic ? createOptimisticStore(derive,{rows:[]}) : createStore(derive,{rows:[]});
    return {store,setVersion,dispose};
  });
  flush();
  const running = action(function*(){affects(app.store);yield end.promise;})();
  flush();
  app.setVersion(1);
  flush();
  try {
    const child=app.store.rows[0];
    expect(child?.name).toBe('new');
    expect({length:isPending(() => app.store.rows.length),child:isPending(() => child.name)}).toEqual({length:true,child:true});
  } finally {end.resolve();await running;app.dispose();flush();}
});

for (const alias of [false,true]) it(`captured inserted child has prior alias=${alias}`, async () => {
  const end = Promise.withResolvers<void>();
  const app = createRoot(dispose => {
    const [outside] = createStore({name:'new'});
    const [state,write] = createStore<{rows:{name:string}[]}>({rows:[]});
    return {outside,state,write,dispose};
  });
  const running = action(function*(){affects(app.state);yield end.promise;})();
  flush();
  app.write(s => {s.rows.push(alias ? app.outside : {name:'new'});});
  flush();
  try {
    const child = app.state.rows[0];
    expect({through:isPending(() => app.state.rows[0].name),captured:isPending(() => child.name),outside:isPending(() => app.outside.name)}).toEqual({through:true,captured:true,outside:alias});
  } finally {end.resolve();await running;app.dispose();flush();}
});

for (const before of [false,true]) it(`shared child inserted before declaration=${before}`, async () => {
  const end = Promise.withResolvers<void>();
  const app = createRoot(dispose => {
    const [shared] = createStore({name:'new'});
    const [list,write] = createStore<{rows:{name:string}[]}>({rows:[]});
    return {shared,list,write,dispose};
  });
  if(before){app.write(s=>{s.rows.push(app.shared);});flush();}
  const running=action(function*(){affects(app.list);yield end.promise;})();
  flush();
  if(!before){app.write(s=>{s.rows.push(app.shared);});flush();}
  try {
    const captured=app.list.rows[0];
    expect({same:captured===app.shared,through:isPending(()=>app.list.rows[0].name),captured:isPending(()=>captured.name),shared:isPending(()=>app.shared.name)}).toEqual({same:true,through:true,captured:before,shared:before});
  } finally {end.resolve();await running;app.dispose();flush();}
});
