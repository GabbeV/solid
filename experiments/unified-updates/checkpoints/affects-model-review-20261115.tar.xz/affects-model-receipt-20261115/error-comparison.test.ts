import {it, expect} from 'vitest';
import {action, affects, createErrorBoundary, createRenderEffect, createMemo, createRoot, createSignal, flush, isPending} from '../src/index.js';

for (const mode of ['mark','async'] as const) it(mode, async () => {
  const gate = Promise.withResolvers<void>();
  const hold = Promise.withResolvers<void>();
  const app = createRoot(dispose => {
    const [id,setId] = createSignal(0);
    const source = createMemo(() => id() === 0 ? 0 : gate.promise.then(() => 1));
    const failed = createMemo(() => { source(); throw new Error('boom'); });
    const errors = createErrorBoundary(failed, () => -1);
    createRenderEffect(errors, () => {});
    return {dispose, source, failed, setId};
  });
  flush();
  const running = action(function* () {
    if (mode === 'mark') affects(app.source);
    else app.setId(1);
    yield hold.promise;
  })();
  try {
  flush();
  expect([isPending(app.source), isPending(app.failed)]).toEqual([true, true]);
  gate.resolve();
  await new Promise(r => setTimeout(r, 0));
  flush();
  expect(isPending(app.source)).toBe(true);
  } finally {
  gate.resolve();
  hold.resolve();
  await running;
  flush();
  app.dispose();
  }
});
