Bounded error comparison, 2026-11-15

No production code or existing tests changed. Temporary tests removed from repository; copies retained here. Matrix tests are observational (only row count asserted), not acceptance tests.

Reproduce from /workspace/layered-solid/packages/signals:

    cp /workspace/scratch/affects-model-20261115/error-agent-minimal.test.ts tests/tmp-affects-error-agent-minimal.test.ts
    node ../../node_modules/vitest/vitest.mjs run tests/tmp-affects-error-agent-minimal.test.ts
    rm tests/tmp-affects-error-agent-minimal.test.ts

Use matrix instead of minimal for broader comparisons. Output is written to error-agent-minimal.json or appended to error-agent-matrix.jsonl in this directory. Both runs passed (1 minimal, 6 matrix tests). pnpm exec was unusable due existing unsafe modules-directory symlink error; direct Vitest works.

Minimal scene: source initially returns 0; failed reads source then throws boom; identity reads failed; error boundary catches identity; render effects observe boundary and four pending verdicts. During held action either affects(source) or setter makes source return an unresolved Promise<number>. Promise resolves to the same original source value, 0, before held action finishes.

Pending vectors [source, failed, identity, boundary]:
- mark: initial FFFF -> unresolved TFFF -> resolved TFFF -> action done FFFF.
- async: initial FFFF -> unresolved TFFT -> resolved FFFT -> action done FFFF.
- unresolved screen remains E:boom in both modes.
- Async final screen is undefined in this concrete probe, while mark final screen remains E:boom. This was reproduced with and without latest probes, but not diagnosed; do not attribute it to mark cutoff or classify semantics from this receipt.

Matrix direct-mark check (persistent error): marking failed yields FTFF, whereas marking source yields TFFF. The identity is already errored and blocks even the inherited mark from failed. Direct-mark check occurs before STATUS_ERROR cutoff in src/affects-marks.ts:68-70. This matches the documented implementation, not a semantic ruling.

Matrix error-first persistent scene never reads source before throwing, so source is not a dependency of failed: both upstream mark and upstream async leave failed/identity/boundary verdict false and screen E:boom. This is a dependency negative control.

Recovery matrix: action also sets error=false. Both modes eventually show 110. Pending failed/identity is true with upstream mark, false with async while source blocks. Async postpones computing the recovery value until source resolves. Thus this comparison necessarily involves actual recomputation/blocking, and does not isolate a mark error cutoff.

New-error matrix: action also sets error=true. Both modes eventually show E:boom. Mark/new-error and async/new-error both give failed/identity pending=true. Boundary verdict differs depending source-first versus error-first, as recorded in JSONL; no semantic classification made.

Implementation evidence:
- src/affects-marks.ts:68 direct mark succeeds; :70 error cuts inherited walk; :78-81 traverse current dependencies.
- src/core/verdict.ts:493 invokes mark walk before status/value branches; :382-393 isPending swallows ordinary errors; :673-685 pending with no initialized value throws, as does settled errored memo.
- src/core/core.ts:2443-2482 tracked reader of actual pending source blocks with NotReady; :684-707 catch distinguishes NotReady and reports STATUS_PENDING, not STATUS_ERROR.
- src/boundaries.ts:297-300 explicitly records pending passing an error fallback, preserving error display while retry waits.

Conclusion: no demonstrated difference between inherited affects and real pending for isPending(alreadyErroredMemo) itself (both false), and direct mark is observably special. Boundary/retry lifecycle differs from no-recompute mark; these observations do not by themselves show that inherited mark stopping at errors violates the proposed invisible-pending model.

Follow-up: final undefined classification

Exact minimal probe run using next.config.mts aliasing fetched next 221b5f99f has identical rows, including final undefined. Error boundary API is correct: boundaries.ts:1156-1160 accepts accessor content and callback returning U, and returns Accessor<T | U>. Probe callback returns string. Effect callbacks return undefined and dispose occurs strictly after final reads.

Further controls removed affects entirely, toggled identity child and presence of verdict watcher independently, and took two final ticks before reading. All four controls produce the same final undefined screen/boundary on experiment and next. Final raw failed and child reads still throw boom. This is reproducible upstream behavior, not experiment-only and not dependent on verdict watcher, identity child, or root disposal. No deeper cause diagnosed. See error-agent-controls.json and error-agent-controls-next.json (identical).

Reproduce controls by copying error-agent-controls.test.ts into packages/signals/tests/tmp-affects-error-agent-controls.test.ts, setting ERROR_PROBE_RESULT to a scratch output path, and running direct Vitest as above; add --config /workspace/scratch/affects-model-20261115/next.config.mts for upstream. Remove the temporary test afterward. Four tests passed in each run.
