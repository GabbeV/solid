import {it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {action,createMemo,createSignal,createRoot,createRenderEffect,createErrorBoundary,isPending,flush,resetErrorHalt} from '../src/index.js';
const rows:any[]=[];const tick=async()=>{await new Promise(r=>setTimeout(r,0));flush()};
for(const identity of [false,true])for(const watcher of [false,true])it(`${identity}/${watcher}`,async()=>{
 const gate=Promise.withResolvers<number>(),hold=Promise.withResolvers<void>();const screens:any[]=[];
 const app=createRoot(dispose=>{const [id,setId]=createSignal(0);const source=createMemo(()=>id()===0?0:gate.promise);const failed=createMemo(()=>{source();throw new Error('boom')});const child=identity?createMemo(()=>failed()):failed;const boundary=createErrorBoundary(child,e=>`E:${(e() as Error).message}`);createRenderEffect(boundary,v=>void screens.push(v===undefined?'undefined':v));if(watcher)createRenderEffect(()=>[isPending(source),isPending(failed),isPending(child),isPending(boundary)],()=>{});return{dispose,setId,source,failed,child,boundary}});flush();
 const running=action(function*(){app.setId(1);yield hold.promise})();flush();gate.resolve(0);await tick();hold.resolve();await running;await tick();await tick();
 const read=(fn:()=>unknown)=>{try{const v=fn();return v===undefined?'undefined':v}catch(e:any){return`E:${e?.cause?.message??e?.message}`}};
 rows.push({identity,watcher,screens,failed:read(app.failed),child:read(app.child),boundary:read(app.boundary)});app.dispose();resetErrorHalt();writeFileSync(process.env.ERROR_PROBE_RESULT!,JSON.stringify(rows,null,2));expect(screens.length).toBeGreaterThan(0);
});
