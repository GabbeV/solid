/**
 * @jsxImportSource @solidjs/web
 * @vitest-environment jsdom
 */
import { test } from 'vitest';
import { action, createSignal, latest, flush, Show } from 'solid-js';
import { render } from '../src/index.js';
const turn = async () => { await new Promise(r => setTimeout(r,0)); flush(); };
test('private initialization', async () => {
  const div=document.createElement('div');
  const first=Promise.withResolvers<void>(), second=Promise.withResolvers<void>();
  const created: {node:HTMLElement, initial:string|null}[]=[];
  let start!:()=>void;
  const dispose=render(()=>{
    const [count,setCount]=createSignal(0);
    start=action(function*(){setCount(1);yield first.promise;setCount(2);yield second.promise;});
    const Child=()=>{
      const node=<span>{latest(count)*10}</span> as HTMLElement;
      created.push({node, initial:node.textContent});
      return node;
    };
    return <Show when={count()>0} fallback="off"><Child/></Show>;
  },div);
  const record=(step:string)=>process.stdout.write(JSON.stringify({step,visible:div.textContent,created:created.map(x=>({initial:x.initial,now:x.node.textContent,attached:div.contains(x.node)}))})+'\n');
  try {
    flush();start();await turn();record('first');
    first.resolve();await turn();record('second');
    second.resolve();await turn();record('done');
  }finally{first.resolve();second.resolve();dispose();flush();}
});
