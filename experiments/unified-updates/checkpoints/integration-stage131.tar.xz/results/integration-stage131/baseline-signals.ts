import { createOptimisticPair } from "./layers/optimistic.js";
import { refresh as refreshLayerInput } from "./layers/refresh.js";
import type { Computed, Disposable, Owner, Refreshable } from "./core/index.js";
import {
  $REFRESH,
  cleanup,
  computed,
  CONFIG_AUTO_DISPOSE,
  CONFIG_HELD,
  CONFIG_CHILDREN_FORBIDDEN,
  createRoot,
  dispose,
  effect,
  EFFECT_USER,
  getObserver,
  getOwner,
  NotReadyError,
  read,
  runWithOwner,
  setMemo,
  setSignal,
  signalHook,
  signal,
  trackedEffect,
  untrack,
  CONFIG_REDERIVE
} from "./core/index.js";
import {
  devGuardOptimisticBeforeLoad,
  emitDiagnostic,
  forgetThrownRead,
  registerGraph,
  reportDiagnostic
} from "./core/dev.js";
import {
  dirtyQueue,
  flushTransaction,
  globalQueue,
  resolveTx,
  schedule,
  staleReader,
  txOf,
  type Transaction
} from "./core/scheduler.js";
import { REACTIVE_WRITABLE_COMPUTED, STATUS_ERROR, STATUS_PENDING } from "./core/constants.js";
import { unwrapStatusError } from "./core/error.js";

/**
 * Low-level reactive-cleanup primitive. Registers a callback that runs when
 * the surrounding owner is disposed.
 *
 * **In 2.0 user code this is rare.** The two cases where you might reach for
 * it have better-shaped tools:
 *
 * - **Component lifecycle (mount/unmount, listeners, intervals):** use
 *   {@link onSettled} and **return** a cleanup function. Setup and teardown
 *   stay paired in one block. This replaces the 1.x `onMount` + `onCleanup`
 *   pairing.
 * - **Cleanup tied to an effect run:** `onCleanup` does not belong in
 *   `createEffect`'s apply phase. If a compute phase genuinely needs per-run
 *   teardown, that's usually a sign the work should be a memo/projection
 *   instead, or moved to `onSettled` if it's lifecycle-shaped.
 *
 * Where `onCleanup` is the right tool is **library / custom-primitive
 * internals** — coordinating disposal inside a `createRoot` body, or wiring
 * cleanup to a captured owner via `runWithOwner` from a custom factory.
 * Application code rarely needs to write any of those shapes directly.
 *
 * Must be called inside an owner. Calling outside an owner is a no-op (with a
 * dev-mode warning).
 *
 * Cannot be used inside `createTrackedEffect` or `onSettled` — return a
 * cleanup function from the callback body instead.
 *
 * Cleanups run in unwind order: an owner's children are disposed before its
 * own cleanups, and within one owner later registrations run before earlier
 * ones. In production a component body shares its enclosing owner, so
 * register cleanup before creating children when the order between them
 * matters.
 *
 * @example
 * ```ts
 * // Library shape: thread a resource's disposal into a *captured* owner
 * // from a factory that has no settle-phase setup of its own. `onSettled`
 * // would queue a callback we don't need; `onCleanup` is the leaner
 * // primitive when the only job is "register disposal on this owner".
 * function bindToOwner<T extends { dispose(): void }>(owner: Owner, resource: T): T {
 *   runWithOwner(owner, () => onCleanup(() => resource.dispose()));
 *   return resource;
 * }
 * ```
 */
export function onCleanup(fn: Disposable): Disposable {
  if (__DEV__) {
    const owner = getOwner();
    if (!owner) {
      const message =
        "[NO_OWNER_CLEANUP] onCleanup called outside a reactive context will never be run";
      reportDiagnostic(
        emitDiagnostic({
          code: "NO_OWNER_CLEANUP",
          kind: "lifecycle",
          severity: "warn",
          message
        })
      );
    } else if (owner._config & CONFIG_CHILDREN_FORBIDDEN) {
      const message =
        "[CLEANUP_IN_FORBIDDEN_SCOPE] Cannot use onCleanup inside createTrackedEffect or onSettled; return a cleanup function instead";
      emitDiagnostic({
        code: "CLEANUP_IN_FORBIDDEN_SCOPE",
        kind: "lifecycle",
        severity: "error",
        message,
        ownerId: owner.id,
        ownerName: (owner as any)._name
      });
      throw new Error(message);
    }
  }
  return cleanup(fn);
}

/**
 * A zero-arg getter for a reactive value. Calling it inside a tracking scope
 * (memo, effect compute, JSX expression) subscribes the scope to changes.
 *
 * Reading outside any tracking scope simply returns the current value without
 * creating a subscription.
 */
export type Accessor<T> = () => T;
export type SourceAccessor<T> = Refreshable<Accessor<T>>;

export function accessor<T>(node: any): SourceAccessor<T> {
  const fn = read.bind(null, node) as SourceAccessor<T>;
  (fn as any)[$REFRESH] = node;
  return fn;
}

/**
 * A signal setter. Accepts either a new value or an updater `(prev) => next`.
 *
 * If the type permits `undefined`, `setState()` (no args) clears to `undefined`.
 *
 * To store a function as the value itself (rather than as an updater), wrap it
 * with an updater: `setHandler(() => myHandler)`.
 */
export type Setter<in out T> = {
  <U extends T>(
    ...args: undefined extends T ? [] : [value: Exclude<U, Function> | ((prev: T) => U)]
  ): undefined extends T ? undefined : U;
  <U extends T>(value: (prev: T) => U): U;
  <U extends T>(value: Exclude<U, Function>): U;
  <U extends T>(value: Exclude<U, Function> | ((prev: T) => U)): U;
};

/** A `[get, set]` pair returned from `createSignal` / `createOptimistic`. */
export type Signal<T> = [get: SourceAccessor<T>, set: Setter<T>];

export type ComputeFunction<Prev, Next extends Prev = Prev> = (
  v: Prev
) => PromiseLike<Next> | AsyncIterable<Next> | Next;
export type EffectFunction<Prev, Next extends Prev = Prev> = (
  v: Next,
  p?: Prev
) => (() => void) | void;
export type EffectBundle<Prev, Next extends Prev = Prev> = {
  effect: EffectFunction<Prev, Next>;
  /**
   * Intercepts compute-phase errors (thrown by the compute function or arriving
   * from upstream sources). Effect-phase throws are NOT routed here — they are
   * your own imperative code and escalate to the nearest error boundary.
   *
   * This is the error arm of the effect phase: it runs on the same queue and
   * in the same imperative, writable scope as `effect` (signal writes are
   * legal), receives the error the user code threw, and observes settled
   * outcomes — an error that recovers before the effect phase runs the
   * `effect` arm instead, and a held transition defers it like `effect`.
   */
  error: (err: unknown, cleanup: () => void) => void;
};

/** Options shared by every effect primitive. */
interface BaseEffectOptions {
  /** Debug name (dev mode only) */
  name?: string;
  /**
   * Source location (`file:line:col`, root-relative) written by the
   * compiler's `sourceNames` `locations` kind beside `name`; dev and observe
   * builds keep it for console reports and diagnostic events, production
   * ignores it. Not meant to be written by hand.
   */
  loc?: string;
}

/** Options for effect primitives that support deferring/scheduling their initial run (`createEffect`, `createRenderEffect`, `createReaction`). */
export interface EffectOptions extends BaseEffectOptions {
  /** When true, defers the initial effect execution until the next change */
  defer?: boolean;
  /**
   * When true, enqueues the initial effect callback through the effect queue instead of running
   * it synchronously at creation. Lets the initial run participate in transitions -- if any
   * source throws `NotReadyError` during the compute phase, the callback is held until the
   * transition settles.
   *
   * Primarily for render effects that need transition-aware initial mounts (e.g. the root
   * `insert()` in `render()`).
   */
  schedule?: boolean;
  /**
   * Advanced. When true, asserts the compute function returns synchronous
   * values only (never `PromiseLike` / `AsyncIterable`). Skips the
   * async-shape probe in `recompute` for a small fixed-cost win per run.
   * Intended for compiler emissions (`_$effect`) and library code that
   * provably returns sync values. Returning a Promise or async iterable
   * from a `sync: true` effect is undefined behavior — the value will be
   * stored as-is and never awaited.
   */
  sync?: boolean;
  /**
   * Advanced (integration tier). When true, the effect is invisible to the
   * hydration id scheme: it inherits its parent's id instead of consuming a
   * child slot, and during hydration its compute runs live instead of
   * adopting the serialized server value (its first run is not frozen to
   * the server's decision).
   *
   * For **client-only effects created while hydrating** — effects with no
   * server-rendered counterpart (a router wiring link state, scroll
   * restoration, etc.). An id-consuming node the server never created would
   * shift every later sibling's hydration id, making serialized lookups and
   * template claims after it miss. `transparent` is also the supported
   * alternative to branching on hydration state
   * (`if (hydrating) createEffect(...)`), which freezes whatever the first
   * run decided: create the effect unconditionally and let it observe live
   * state instead.
   *
   * SSR ignores this option (a server-side effect always allocates its id
   * slot), so only mark effects the server does not create. Outside
   * hydration it is a no-op.
   */
  transparent?: boolean;
}

/** Options for plain signals created with `createSignal(value)` or `createOptimistic(value)`. */
export interface SignalOptions<T> {
  /** Debug name (dev mode only) */
  name?: string;
  /**
   * Source location (`file:line:col`, root-relative) written by the
   * compiler's `sourceNames` `locations` kind beside `name`; dev and observe
   * builds keep it for console reports and diagnostic events, production
   * ignores it. Not meant to be written by hand.
   */
  loc?: string;
  /**
   * Custom equality function, or `false` to always notify subscribers.
   * Defaults to reference equality (`isEqual`). Pass a comparator (e.g.
   * `(a, b) => a.id === b.id`) for value-based equality, or `false` to
   * notify on every write regardless of equality.
   */
  equals?: false | ((prev: T, next: T) => boolean);
  /** Suppress dev-mode warnings when writing inside an owned scope */
  ownedWrite?: boolean;
  /** Callback invoked when the signal loses all subscribers */
  unobserved?: () => void;
}

/**
 * Options for read-only memos created with `createMemo`.
 * Also used in combination with `SignalOptions` for writable memos
 * (`createSignal(fn)` / `createOptimistic(fn)`).
 */
export interface MemoOptions<T> {
  /** Stable identifier for the owner hierarchy */
  id?: string;
  /** Debug name (dev mode only) */
  name?: string;
  /**
   * Source location (`file:line:col`, root-relative) written by the
   * compiler's `sourceNames` `locations` kind beside `name`; dev and observe
   * builds keep it for console reports and diagnostic events, production
   * ignores it. Not meant to be written by hand.
   */
  loc?: string;
  /**
   * Advanced (integration tier). When true, the memo is invisible to the
   * hydration id scheme: it inherits its parent's id instead of consuming a
   * child slot, and during hydration it computes live instead of adopting
   * the serialized server value. For client-only memos with no
   * server-rendered counterpart — see {@link EffectOptions.transparent} for
   * the full semantics. No-op outside hydration.
   */
  transparent?: boolean;
  /**
   * @internal Framework plumbing (the `solid-js/refresh` HMR memo): in the
   * observe tiers the memo has no name, is no owner-path segment, and the
   * attribution engine records nothing about it, while what it owns stays
   * observed. Not part of the public API.
   */
  _plumbing?: boolean;
  /**
   * Custom equality function, or `false` to always notify subscribers.
   * Defaults to reference equality (`isEqual`). Pass a comparator (e.g.
   * `(a, b) => a.id === b.id`) for value-based equality, or `false` to
   * notify on every recompute regardless of equality.
   */
  equals?: false | ((prev: T, next: T) => boolean);
  /** Callback invoked when the computed loses all subscribers */
  unobserved?: () => void;
  /**
   * When true, defers the initial computation until the value is first read,
   * **and** opts the memo into autodisposal — once it has no remaining
   * subscribers it is torn down and recomputed from scratch on the next read.
   * Use it for compute-on-demand values that should not retain state across
   * idle periods. Non-lazy owned memos live for their owner's lifetime and
   * never autodispose.
   */
  lazy?: boolean;
  /**
   * Advanced. When true, asserts the compute function returns synchronous
   * values only (never `PromiseLike` / `AsyncIterable`). Skips the
   * async-shape probe in `recompute` for a small fixed-cost win per run.
   * Intended for compiler emissions (`_$memo`) and library code that
   * provably returns sync values. Returning a Promise or async iterable
   * from a `sync: true` memo is undefined behavior — the value will be
   * stored as-is and never awaited.
   */
  sync?: boolean;
  /**
   * Commit #0: a committed value the memo is born with, shown until the
   * compute's first real answer lands. While that first answer is in flight
   * the memo reads as a settled value everywhere — nothing suspends to a
   * `<Loading>` boundary, no transition is held (first-flight work is
   * loading-class, like a boundary fallback), and `isPending(memo)` stays
   * **false**: commit #0 answers the question by declaration, so first-load
   * affordances are driven from the value itself (a `null` placeholder, a
   * `skeleton: true` field, etc.). Once the first answer lands, the loading
   * value leaves the lineage forever: refetches use normal pending semantics
   * (stale value shown, `isPending` true, boundaries/transitions coordinate)
   * — the canonical guard is `data.skeleton || isPending(data)`, whose two
   * terms cover the two disjoint states.
   *
   * Typed strictly as `T`: to use `null`/`undefined` as the placeholder,
   * declare it in the memo's type (e.g. `createMemo<User | null>(...)`), so
   * every consumer sees the nullable window honestly. If the placeholder is
   * shaped data standing in for real data, encode its provenance in the data
   * (e.g. a `skeleton: true` field) rather than letting it impersonate truth.
   *
   * The loading value is also the compute's first `prev`, so `prev`-based
   * memos fold from it.
   */
  loadingValue?: T;
}

// Magic type that when used at sites where generic types are inferred from, will prevent those sites from being involved in the inference.
// https://github.com/microsoft/TypeScript/issues/14829
// TypeScript Discord conversation: https://discord.com/channels/508357248330760243/508357248330760249/911266491024949328
export type NoInfer<T extends any> = [T][T extends any ? 0 : never];

/**
 * Creates a simple reactive state with a getter and setter.
 *
 * When called with a plain value, creates a signal with `SignalOptions` (name, equals, ownedWrite, unobserved).
 * When called with a function, creates a writable memo with `SignalOptions & MemoOptions` (adds id, lazy).
 *
 * ```typescript
 * // Plain signal
 * const [state, setState] = createSignal<T>(value, options?: SignalOptions<T>);
 * // Writable memo (function overload)
 * const [state, setState] = createSignal<T>(fn, initialValue?, options?: SignalOptions<T> & MemoOptions<T>);
 * ```
 * @param value initial value of the state; if empty, the state's type will automatically extended with undefined
 * @param options optional object with a name for debugging purposes and equals, a comparator function for the previous and next value to allow fine-grained control over the reactivity
 *
 * @returns `[state: Accessor<T>, setState: Setter<T>]`
 *
 * @example
 * ```ts
 * const [count, setCount] = createSignal(0);
 *
 * count();              // 0
 * setCount(1);          // explicit value
 * setCount(c => c + 1); // updater
 * ```
 *
 * @example
 * ```ts
 * // Writable memo: derives from `fn()` and can be written like a signal.
 * const [user, setUser] = createSignal(() => fetchUser(userId()));
 *
 * // A write lands at once and never re-runs `fn` on its own; when `userId`
 * // changes, in the same update or later, `fn` re-runs and receives the
 * // written value as `prev`. While a transaction holds a re-derived value, a
 * // write from outside it does not replace that derivation — it becomes its
 * // `prev`.
 * setUser({ ...user(), name: "Alice" });
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-signal
 */
export function createSignal<T>(): Signal<T | undefined>;
export function createSignal<T>(value: Exclude<T, Function>, options?: SignalOptions<T>): Signal<T>;
export function createSignal<T>(
  fn: ComputeFunction<T>,
  options?: SignalOptions<T> & MemoOptions<T>
): Signal<T>;
export function createSignal<T>(
  first?: T | ComputeFunction<T>,
  second?: SignalOptions<T> & MemoOptions<T>
): Signal<T | undefined> {
  if (typeof first === "function") {
    const node = computed<T>(first as any, second as any);
    node._config &= ~CONFIG_AUTO_DISPOSE;
    node._flags |= REACTIVE_WRITABLE_COMPUTED;
    return [
      accessor<T | undefined>(node),
      setMemo.bind(null, node as any) as Setter<T | undefined>
    ];
  }
  const node = signal<T>(first as any, second as SignalOptions<T>);
  if (__OBSERVE__) registerGraph(node, getOwner());
  if (signalHook !== null) signalHook(node);
  return [accessor<T>(node), setSignal.bind(null, node as any) as Setter<T | undefined>];
}

/**
 * Creates an optimistic signal: a value that can be set optimistically inside
 * a transition and reverts to the value it covered when the transition ends.
 *
 * The write is a guess over the transition of the frame it is made in — the
 * frame's held writes are its base, and it shows at once while they wait.
 * Outside such a frame (nothing is held) the write is as if it never
 * happened. With a function, the memo form: its own recompute is the truth
 * — equal to the guess it confirms silently, different it corrects at the
 * transition's commit.
 *
 * ```typescript
 * const [state, setState] = createOptimistic<T>(value, options?: SignalOptions<T>);
 * const [state, setState] = createOptimistic<T>(fn, options?: SignalOptions<T> & MemoOptions<T>);
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-optimistic
 */
export function createOptimistic<T>(): Signal<T | undefined>;
export function createOptimistic<T>(
  value: Exclude<T, Function>,
  options?: SignalOptions<T>
): Signal<T>;
export function createOptimistic<T>(
  fn: ComputeFunction<T>,
  options?: SignalOptions<T> & MemoOptions<T>
): Signal<T>;
export function createOptimistic<T>(
  first?: T | ComputeFunction<T>,
  second?: SignalOptions<T> & MemoOptions<T>
): Signal<T | undefined> {
  return createOptimisticPair(first as any, second as any) as Signal<T | undefined>;
}

/**
 * Creates a readonly derived reactive memoized signal.
 *
 * ```typescript
 * const value = createMemo<T>(compute, options?: MemoOptions<T>);
 * ```
 * @param compute a function that receives its previous value and returns a new value used to react on a computation
 * @param options `MemoOptions` -- id, name, equals, unobserved, lazy, transparent
 *
 * @example
 * ```ts
 * const [first, setFirst] = createSignal("Ada");
 * const [last, setLast] = createSignal("Lovelace");
 *
 * const fullName = createMemo(() => `${first()} ${last()}`);
 *
 * fullName(); // "Ada Lovelace"
 * ```
 *
 * @example
 * ```ts
 * // Async memo — reads surface as pending inside <Loading>
 * const user = createMemo(async () => {
 *   const res = await fetch(`/users/${id()}`);
 *   return res.json();
 * });
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-memo
 */
// NoInfer keeps the previous-value parameter from influencing T inference, so
// the memo/effect result type is still driven by the compute return type.
// With a loadingValue the compute's `prev` is never undefined — commit #0 is
// the first prev — so that overload drops `undefined` from the parameter.
export function createMemo<T>(
  compute: ComputeFunction<NoInfer<T>, T>,
  options: MemoOptions<T> & { loadingValue: T }
): SourceAccessor<T>;
export function createMemo<T>(
  compute: ComputeFunction<undefined | NoInfer<T>, T>,
  options?: MemoOptions<T>
): SourceAccessor<T>;
export function createMemo<T>(
  compute: ComputeFunction<undefined | NoInfer<T>, T>,
  options?: MemoOptions<T>
): SourceAccessor<T> {
  return accessor<T>(computed<T>(compute as any, options));
}

/**
 * Creates a reactive effect with **separate compute and effect phases**.
 *
 * - `compute(prev)` runs reactively — *put all reactive reads here*. The
 *   returned value is passed to `effect` and is also the new "previous" value
 *   for the next run.
 * - `effect(next, prev?)` runs imperatively (untracked) after the queue
 *   flushes. *Put DOM writes / fetch / logging / subscriptions here.* It may
 *   return a cleanup function which runs before the next effect or on
 *   disposal.
 *
 * Reactive reads inside `effect` will *not* re-trigger this effect — that's
 * intentional. If you need a single-phase tracked effect, use
 * `createTrackedEffect` (with the tradeoffs noted there).
 *
 * Pass an `EffectBundle` (`{ effect, error }`) instead of a plain function to
 * intercept **compute-phase** errors — errors thrown by `compute` or arriving
 * from upstream reactive sources (including async rejections), which your own
 * code has no frame to `try/catch`. The `error` handler is the error arm of
 * the effect phase: it runs on the same schedule and in the same imperative,
 * writable scope as `effect` (setting error state via signals is fine), and
 * only for *settled* errors — a transient error that recovers before the
 * effect phase runs `effect` with the recovered value instead, and a held
 * transition defers it exactly as it defers `effect`. Without an `error`
 * handler a compute-phase error is logged and the effect simply skips that
 * run — a non-render effect's reactivity failing does not crash the app.
 * Rethrowing from `error` escalates it to the nearest error boundary
 * (halting the system if none exists).
 *
 * The **effect phase is different**: it is your own imperative code, so handle
 * failures with `try/catch` where they occur. An uncaught effect-phase throw
 * is treated as an unhandled application error — caught by the nearest
 * `createErrorBoundary`/`<Errored>`, and permanently halting the reactive
 * system if there is none. It is *not* routed to the bundle's `error` handler.
 *
 * ```typescript
 * createEffect<T>(compute, effectFn | { effect, error }, options?: EffectOptions);
 * ```
 * @param compute a function that receives its previous value and returns a new value used to react on a computation
 * @param effectFn a function that receives the new value and is used to perform side effects (return a cleanup function), or an `EffectBundle` with `effect` and `error` handlers
 * @param options `EffectOptions` -- name, defer, schedule, transparent
 *
 * @example
 * ```ts
 * const [count, setCount] = createSignal(0);
 *
 * createEffect(
 *   () => count(),                  // compute: tracks `count`
 *   value => console.log(value)     // effect: side effect
 * );
 *
 * setCount(1); // logs 1 after the next flush
 * ```
 *
 * @example
 * ```ts
 * createEffect(
 *   () => userId(),
 *   id => {
 *     const ctrl = new AbortController();
 *     fetch(`/users/${id}`, { signal: ctrl.signal });
 *     return () => ctrl.abort(); // cleanup before next run / disposal
 *   }
 * );
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-effect
 */
export function createEffect<const T>(
  compute: ComputeFunction<undefined | NoInfer<T>, T>,
  effectFn: EffectFunction<NoInfer<T>, T> | EffectBundle<NoInfer<T>, T>,
  options?: EffectOptions
): void {
  if (__DEV__ && effectFn === undefined) {
    const message =
      "[MISSING_EFFECT_FN] createEffect requires both a compute function and an effect function. " +
      "Use `createEffect(() => signal(), value => doWork(value))`. " +
      "If you want a derived value, use `createMemo`. " +
      "If you want a one-shot side effect, just call the function directly.";
    emitDiagnostic({
      code: "MISSING_EFFECT_FN",
      kind: "lifecycle",
      severity: "error",
      message
    });
    throw new Error(message);
  }
  effect(compute as any, (effectFn as any).effect || effectFn, (effectFn as any).error, {
    user: true,
    ...options
  });
}

/**
 * Creates a reactive computation that runs during the render phase as DOM elements
 * are created and updated but not necessarily connected.
 *
 * Same compute / effect split as `createEffect`, but scheduled inside the render
 * queue rather than after it. Reach for this only when authoring renderer
 * plumbing (custom DOM bindings, JSX-generated `insert()` / `spread()` calls).
 * App code should use `createEffect`.
 *
 * ```typescript
 * createRenderEffect<T>(compute, effectFn, options?: EffectOptions);
 * ```
 * @param compute a function that receives its previous value and returns a new value used to react on a computation
 * @param effectFn a function that receives the new value and is used to perform side effects
 * @param options `EffectOptions` -- name, defer, schedule, transparent
 *
 * @example
 * ```ts
 * // Custom directive: bind an element's textContent to a reactive source.
 * function bindText(el: HTMLElement, source: () => string) {
 *   createRenderEffect(
 *     () => source(),
 *     value => { el.textContent = value; }
 *   );
 * }
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/advanced/specialized-reactivity/create-render-effect
 */
export function createRenderEffect<const T>(
  compute: ComputeFunction<undefined | NoInfer<T>, T>,
  effectFn: EffectFunction<NoInfer<T>, T>,
  options?: EffectOptions
): void {
  effect(compute as any, effectFn, undefined, options);
}

/**
 * Creates a tracked reactive effect where dependency tracking and side effects happen
 * in the same scope.
 *
 * @deprecated Do not use in new code. For a side effect that follows reactive
 * state, use `createEffect(compute, effect)` — it separates tracking from the
 * side effect, knows its dependencies before it runs, and participates in
 * async and transitions. For one-time DOM work after render (measuring,
 * attaching third-party widgets to a ref), use `onSettled`. Tracking from
 * inside the effect phase — the only thing this primitive adds — is retained
 * solely to ease 1.x migration: it runs beside user-effect callbacks after
 * values commit, never holds a transition, and cannot observe a write staged
 * earlier in the same flush by a signal it has not read yet.
 *
 * WARNING: Because tracking and effects happen in the same scope, this primitive
 * may run multiple times for a single change or show tearing (reading inconsistent
 * state). Use only when dynamic subscription patterns require same-scope tracking.
 *
 * The callback runs during the flush itself: writes made inside it are queued
 * into the same flush's continuation and are never visible to the callback's
 * own reads (reads return settled values, as in every effect-phase scope), and
 * `flush()` cannot be called from inside it (dev throws; production is a
 * no-op) — defer with `queueMicrotask(() => flush())` if needed.
 *
 * ```typescript
 * createTrackedEffect(compute, options?: { name?: string });
 * ```
 * @param compute a function that contains reactive reads to track and returns an optional cleanup function to run on disposal or before next execution
 * @param options -- name
 *
 * @example
 * ```ts
 * createTrackedEffect(() => {
 *   const target = focusedNode();
 *   if (!target) return;
 *
 *   const handler = () => log(target.value());
 *   target.on("change", handler);
 *
 *   return () => target.off("change", handler);
 * });
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/advanced/specialized-reactivity/create-tracked-effect
 */
export function createTrackedEffect(
  compute: () => void | (() => void),
  options?: BaseEffectOptions
): void {
  trackedEffect(compute, options);
}

/**
 * Creates a reactive computation that runs after the render phase with flexible tracking.
 *
 * ```typescript
 * const track = createReaction(effectFn, options?: EffectOptions);
 * track(() => { // reactive reads });
 * ```
 * @param effectFn a function (or `EffectBundle`) that is called when tracked function is invalidated
 * @param options `EffectOptions` -- name, defer
 *
 * @example
 * ```ts
 * const [count, setCount] = createSignal(0);
 *
 * const track = createReaction(() => {
 *   console.log("count changed once, re-arm to listen again");
 *   track(() => count()); // re-arm
 * });
 *
 * track(() => count()); // initial arm
 *
 * setCount(1); // logs once, reaction re-armed for next change
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/advanced/specialized-reactivity/create-reaction
 */
export function createReaction(
  effectFn: EffectFunction<undefined> | EffectBundle<undefined>,
  options?: EffectOptions
) {
  let cl: (() => void) | undefined = undefined;
  cleanup(() => cl?.());
  const owner = getOwner();
  // The currently armed effect node. `track()` replaces the previous
  // subscription (1.x semantics): without disposing the superseded arm, its
  // sources stayed live (firing the callback for replaced dependencies), each
  // accumulated arm delivered its own fire, and un-fired arms leaked as live
  // effect nodes until the owner disposed (#2861).
  let arm: Owner | undefined;
  return (tracking: () => void) => {
    if (arm) {
      dispose(arm as any);
      arm = undefined;
    }
    runWithOwner(owner!, () => {
      effect(
        () => {
          const node = getOwner()!;
          arm = node;
          tracking();
          return node;
        },
        node => {
          arm = undefined;
          cl?.();
          const cleanup = ((effectFn as any).effect || effectFn)?.();
          if (__DEV__ && cleanup !== undefined && typeof cleanup !== "function") {
            throw new Error(
              "Reaction callback returned an invalid cleanup value. Return a cleanup function or undefined."
            );
          }
          cl = cleanup as (() => void) | undefined;
          dispose(node as any);
        },
        (effectFn as any).error,
        {
          ...options,
          user: true,
          defer: true
        }
      );
    });
  };
}

/** A promise over a reactive expression (`resolve`): a pass that
 * runs the expression and settles on a microtask. Not an effect — an
 * effect's run is the flush's effect phase, and a flush parked by the
 * action that is `yield`ing on this promise stashes its runs with the
 * transaction (#2930); the heap runs a pass parked or not. A pending read
 * re-runs it when the source lands (the pass is pending itself); the
 * expression throwing settles the rejection. */
/** The promise-delivery reader's pass (`resolve`): delivers what it read on a microtask. By posture (#3482, #3490):
 * - the reader of the transaction it was created in (`own`: an action's
 *   body, a `refresh()` called there — the waiter reads its slice's frame on
 *   a later microtask) delivers that frame — the staged landing an action
 *   holds (the action awaits the promise that would otherwise wait on its
 *   own settle);
 * - a mainline reader whose pass read a frame another transaction holds
 *   joined it (L2, born held — A29) and delivers at that commit: the
 *   committed view, never a foreign hold's unrevealed frame. */
function watch<T>(
  fn: () => T,
  onValue: (v: T) => void,
  onError: (e: unknown) => void,
  own: Transaction | null = flushTransaction
): void {
  let generation = 0;
  computed(
    () => {
      const current = ++generation;
      let v: T,
        failed = false;
      try {
        v = fn();
      } catch (e) {
        if (e instanceof NotReadyError) throw e;
        // An error is an answer (D-41): delivered by the same frame rule.
        // (D-42, dev: the runtime's catch, not a user's.)
        if (__DEV__) forgetThrownRead();
        v = unwrapStatusError(e) as T;
        failed = true;
      }
      const c = getOwner() as Computed<any>;
      // Delivery is imperative, after this pass has accepted its update.
      // Registering a foreign hold inside the calculation would immediately
      // re-add this waiter during the coordinator's preparation walk.
      queueMicrotask(() => {
        if (current !== generation) return;
        const holder = c._config & CONFIG_HELD ? txOf(c) : null;
        if (holder && (own === null || resolveTx(own) !== holder)) {
          staleReader(c, holder);
          return;
        }
        failed ? onError(v) : onValue(v);
      });
    }
  )._config |= CONFIG_REDERIVE;
}

/**
 * Awaits a reactive expression and returns its first fully-settled value as a
 * `Promise`. Pending async reads (`createMemo` returning a promise, etc.) are
 * waited on; once the expression returns synchronously without `NotReadyError`
 * the promise resolves with that value. If the expression settles with an
 * error instead — including an async source that rejects — the promise
 * rejects with it.
 *
 * Must be called *outside* a tracking scope — it doesn't subscribe, it just
 * resolves the current value once.
 *
 * @example
 * ```ts
 * const user = createMemo(() => fetch(`/users/${id()}`).then(r => r.json()));
 *
 * // outside any reactive scope
 * const initial = await resolve(() => user());
 * ```
 *
 * @param fn a reactive expression to resolve
 */
export function resolve<T>(fn: () => T): Promise<T> {
  if (__DEV__ && getObserver()) {
    throw new Error(
      "Cannot call resolve inside a reactive scope; it only resolves the current value and does not track updates."
    );
  }
  return new Promise((res, rej) => {
    createRoot(dispose =>
      watch(
        fn,
        value => (res(value), dispose()),
        err => (rej(err), dispose())
      )
    );
  });
}

/**
 * Invalidates one reactive source, forcing it to re-execute even if its inputs
 * haven't changed, and returns a promise for the target's NEXT QUIESCENT
 * STATE — the re-ask (and anything that supersedes it) has settled.
 *
 * Pass either a Solid-created accessor or a projected store created from
 * `createStore(fn, ...)` / `createProjection(...)`. `refresh()` is a
 * write-like invalidation operation: it does not read the target's value, and
 * refreshing a plain signal accessor is a no-op that resolves immediately.
 *
 * The returned promise is safe to ignore (fire-and-forget refresh is
 * unchanged, and a failed refetch will not surface an unhandled rejection).
 * Awaiting it gives imperative flows the settle point without a reactive
 * read:
 * - Accessor targets resolve with the settled value; store targets resolve
 *   with the store node passed (reads through it are fresh after the await).
 * - A failed re-ask rejects with the error.
 * - Semantics are quiescence, not flight identity: if another refresh (or
 *   any invalidation) supersedes this one mid-flight, the promise waits for
 *   — and delivers — whatever finally lands.
 *
 * @example
 * ```ts
 * const user = createMemo(async () => fetch(`/users/${id()}`).then(r => r.json()));
 *
 * // Fire-and-forget re-fetch
 * <button onClick={() => refresh(user)}>Reload</button>;
 *
 * // Imperative settle point
 * const fresh = await refresh(user);
 * ```
 */
export function refresh<T>(
  target: Refreshable<T>
): Promise<T extends (...args: any) => infer V ? V : T> {
  return refreshLayerInput(target);
}

/** Falsy values a truthy predicate result is narrowed against. */
export type Truthy<T> = Exclude<T, false | 0 | 0n | "" | null | undefined>;

/**
 * The global `AbortSignal` when the consumer's libs declare one (DOM,
 * WebWorker, `@types/node`), else the surface `until` uses — so these
 * declarations check under neither lib without widening the global type.
 */
type GlobalAbortSignal = typeof globalThis extends { AbortSignal: { prototype: infer S } }
  ? S
  : {
      readonly aborted: boolean;
      readonly reason: any;
      addEventListener(type: "abort", listener: () => void, options?: { once?: boolean }): void;
      removeEventListener(type: "abort", listener: () => void): void;
    };

export interface UntilOptions {
  /** Reject with `TimeoutError` if the predicate has not turned truthy within
   * this many milliseconds. Strongly recommended when the confirming truth
   * arrives over a transport that can drop (sockets, subscriptions). */
  timeout?: number;
  /** Reject with `signal.reason` on abort. */
  signal?: GlobalAbortSignal;
}

/**
 * Awaits a reactive predicate and resolves the first time it settles *truthy*,
 * with that (narrowed) value. Falsy results and pending async reads both mean
 * "not yet": the subscription stays live and re-evaluates as sources change.
 * If the predicate settles with an error — a throw, or an async source that
 * rejects — the promise rejects with it, as do timeout and abort.
 *
 * Where {@link resolve} answers "what is this value" (first settled value,
 * whatever it is), `until` answers "when does the world confirm this
 * condition".
 *
 * This is the acknowledgment mechanism for mutations confirmed on a live data
 * channel (sockets, subscriptions, live queries) rather than by the mutation's
 * own response: correlate by a client-generated id or version in the predicate,
 * and let truth arrive however it arrives — push, refetch, or another tab.
 *
 * Must be called *outside* a tracking scope.
 *
 * @example
 * ```ts
 * const clientId = crypto.randomUUID();
 * await socket.send({ clientId, text }); // fire-and-forget transport
 * // Wait until the live source echoes the write:
 * await until(() => messages.some(m => m.clientId === clientId), { timeout: 10_000 });
 * ```
 *
 * @param fn a reactive predicate
 * @param options optional `timeout` (ms) and abort `signal`
 */
export function until<T>(_fn: () => T, _options?: UntilOptions): Promise<Truthy<T>> {
  throw new Error("until is deferred while the shared update engine is integrated.");
}

/**
 * Schedules `callback` to run **once** after the reactive graph has fully
 * settled — i.e. once every pending async read inside the current owner has
 * resolved and the queue has flushed. Each call registers a single fire; it
 * does not create an ongoing subscription.
 *
 * The canonical lifecycle primitive in 2.0. Three main usages:
 *
 * - **Component-level setup-and-teardown** *(the most common shape)*: run
 *   setup after the component's first stable render and **return a cleanup
 *   function** to dispose it on owner disposal. This is the replacement for
 *   the 1.x `onMount` + `onCleanup` pairing — setup and teardown live in one
 *   block, and `onCleanup` is no longer the right tool for component
 *   bodies. (`onMount` no longer exists in 2.0.)
 * - **Post-settle "ready" hook:** run once after a component's first stable
 *   render — analytics ping, focus, scroll-into-view, etc. No cleanup needed.
 * - **Inside an event handler:** schedule work to run after the action /
 *   transition triggered by the event has completed.
 *
 * Reactive reads inside the callback are *not* tracked — to react to
 * subsequent settles, register a new `onSettled` each time.
 *
 * The callback runs during the settle flush itself, which gives it the same
 * write semantics as every other effect-phase scope (the effect half of
 * `createEffect`, event handlers):
 *
 * - **Writes** are queued into the same flush's continuation — dependent memos
 *   and effects update before the flush returns — but reads inside the
 *   callback keep returning the settled (pre-write) values. A callback never
 *   observes its own unsettled write. Functional setters still compose:
 *   `set(v => v + 1)` twice increments twice.
 * - **`flush()` cannot be called** from inside the callback — the flush is
 *   already running (dev throws; production is a no-op). To force a drain
 *   after this settle, defer it: `queueMicrotask(() => flush())`.
 *
 * `onCleanup` is **not** allowed inside the callback — return a cleanup
 * function instead. The returned cleanup runs on owner disposal.
 *
 * A cleanup return is only honored when `onSettled` is called from an **owned**
 * scope (e.g. a component body). When it fires out of band from an *unowned*
 * scope — an event handler, a tracked effect, or another `onSettled` — there is
 * no owner lifecycle to bind a cleanup to; returning one is a dev-mode error
 * (and is dropped in production). Use the post-settle/event-handler forms below
 * for one-shot work, and keep setup-with-teardown in an owned scope.
 *
 * @example
 * ```tsx
 * // Component-level setup + teardown — replaces onMount + onCleanup.
 * // Subscribe to an external source on mount, unsubscribe on dispose.
 * function useViewportWidth() {
 *   const [width, setWidth] = createSignal(window.innerWidth);
 *   onSettled(() => {
 *     const onResize = () => setWidth(window.innerWidth);
 *     window.addEventListener("resize", onResize);
 *     return () => window.removeEventListener("resize", onResize);
 *   });
 *   return width;
 * }
 * ```
 *
 * @example
 * ```tsx
 * // Post-settle "ready" hook — no cleanup needed.
 * function Dashboard() {
 *   const data = createMemo(async () => fetchData());
 *
 *   onSettled(() => {
 *     analytics.track("dashboard.ready");
 *   });
 *
 *   return <Loading fallback={<Spinner />}><pre>{data()}</pre></Loading>;
 * }
 * ```
 *
 * @example
 * ```tsx
 * // Event-handler — runs after the action settles.
 * function SaveButton() {
 *   const save = action(function* () {
 *     yield api.save();
 *   });
 *
 *   const handleClick = () => {
 *     save();
 *     onSettled(() => toast("Saved!"));
 *   };
 *
 *   return <button onClick={handleClick}>Save</button>;
 * }
 * ```
 *
 * @param callback Function to run; may return a cleanup function that fires
 *   on owner disposal
 */
export function onSettled(callback: () => void | (() => void)): void {
  const owner = getOwner();
  owner && !(owner._config & CONFIG_CHILDREN_FORBIDDEN)
    ? trackedEffect(() => untrack(callback), __OBSERVE__ ? { name: "onSettled" } : undefined)
    : globalQueue.enqueue(EFFECT_USER, function fire() {
        // Settled means derived. A settle that reverts optimism (or replays
        // gated reads) only enqueues the affected subscribers; the pass after
        // the commit re-derives them. Fired in the commit pass, the callback
        // read the optimistic source already reverted beside a sync memo of it
        // still holding the optimistic value — reads do not pull (#3411). Fall
        // to the next pass while the heap has work; `run` swapped the queue,
        // so this lands there, and `enqueue` keeps the drain alive.
        if (dirtyQueue._max >= dirtyQueue._min) return globalQueue.enqueue(EFFECT_USER, fire);
        // Unowned, out-of-band fire (no owner, or a children-forbidden one this
        // one-shot must not bind to): a returned cleanup has no lifecycle to
        // attach to. Reject it in dev; in production the return is simply
        // dropped — never bound to an unrelated owner or run eagerly.
        const cleanup = callback();
        if (__DEV__ && cleanup !== undefined) {
          const message =
            "[SETTLED_CLEANUP_UNOWNED] onSettled returned a cleanup in an unowned scope; a cleanup can only be honored under an owner. Call your setup helper from an owned scope (e.g. the component body) instead of from inside an event handler, tracked effect, or another onSettled.";
          emitDiagnostic({
            code: "SETTLED_CLEANUP_UNOWNED",
            kind: "lifecycle",
            severity: "error",
            message
          });
          throw new Error(message);
        }
      });
}

/**
 * Schedules `callback` to run **once**, right after the pending flush
 * finishes, in the same microtask checkpoint (before the browser paints).
 * Unlike `onSettled`, it never waits on async work: if that flush is held by
 * a pending transition, the callback still runs.
 *
 * Its main use is keeping a write out of another update's hold. Writes made
 * in the same synchronous frame are applied together, so when one of them
 * starts async work (a route change, a fetch), the others are held with it
 * until it resolves. A write made in `onFlush` happens after that flush, so
 * it is its own update: it commits on its own unless something it changes
 * also derives from the held work (a memo or `createEffect` reading both),
 * in which case it joins that hold as any later write would.
 *
 * Call it from event handlers and effect callbacks (including
 * `createTrackedEffect` and `onSettled` bodies). In an owned scope such as a
 * component body or a computation it warns in dev: use `onSettled` there.
 *
 * - A write in the callback lands after any write made inline in the same
 *   frame. Don't write the same signal both inside and outside it; use a
 *   functional setter if the order matters.
 * - Several `onFlush` callbacks run in call order and batch into one flush.
 * - `queueMicrotask` is not a substitute: called before the frame's first
 *   write, it runs before that flush and its write joins it.
 *
 * @example
 * ```tsx
 * // A menu closes now even when the consumer's onSelect starts async work.
 * const select = (id: string) => {
 *   onFlush(() => setOpen(false));
 *   props.onSelect?.(id);
 * };
 * ```
 *
 * @param callback Function to run once after the pending flush
 */
export function onFlush(callback: () => void): void {
  if (__DEV__) {
    const owner = getOwner();
    if (owner && !(owner._config & CONFIG_CHILDREN_FORBIDDEN)) {
      const message =
        "[ON_FLUSH_IN_OWNED_SCOPE] onFlush called in an owned scope (a component body or a computation). It is meant for event handlers and effect callbacks; to run work after this scope's first stable render, use onSettled.";
      reportDiagnostic(
        emitDiagnostic({
          code: "ON_FLUSH_IN_OWNED_SCOPE",
          kind: "lifecycle",
          severity: "warn",
          message,
          ownerId: owner.id,
          ownerName: (owner as any)._name
        })
      );
    }
  }
  // The frame's flush is queued (or already draining) ahead of this
  // microtask, so the callback's writes start a flush of their own.
  schedule();
  queueMicrotask(callback);
}
