import os,subprocess,json
from pathlib import Path
here=Path('/workspace/layered-solid/experiments/unified-updates/results/integration-stage171')
roots={'next':Path('/workspace/layered-next-4fe75321/packages/signals'),'experiment':Path('/workspace/layered-solid/packages/signals')}
for sample in range(5):
 for name in (['next','experiment'] if sample%2==0 else ['experiment','next']):
  with open(here/f'bench-{sample}-{name}.log','w') as out:
   result=subprocess.run(['taskset','-c','4','node','node_modules/vitest/vitest.mjs','bench','--run','tests/core/creation.bench.ts','tests/core/reactivity.bench.ts','--outputJson',str(here/f'bench-{sample}-{name}.json')],cwd=roots[name],stdout=out,stderr=subprocess.STDOUT)
  print(sample,name,result.returncode,flush=True)
  if result.returncode:raise SystemExit(result.returncode)
