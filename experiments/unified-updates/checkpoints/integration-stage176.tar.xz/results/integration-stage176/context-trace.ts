let counter = 0;
const ids = new WeakMap<object, number>();
function id(x: any): any { if (!x || typeof x !== "object") return x; let n = ids.get(x); if (!n) ids.set(x, n = ++counter); return n; }
function simple(x: any): any { return typeof x === "symbol" ? "sentinel" : x && typeof x === "object" ? Array.isArray(x) ? x : "object" : x; }
export function desc(x: any): any {
 if (!x) return null;
 if ("_level" in x) return {tx:id(x),level:x._level,into:id(x._into),open:x._open};
 return {n:id(x), name:x._name, parent:id(x._parent), flags:x._flags, config:x._config, status:x._statusFlags, value:simple(x._value), proposed:simple(x._pendingValue), tx:id(x._x?._transaction)};
}
export function trace(event:string, ...objects:any[]) { console.log(event, JSON.stringify(objects.map(desc))); }
