import { debugArrayState } from "../../src/store/optimistic-array.js";
import {action,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush,latest,snapshot,type Refreshable} from "../../src/index.js";
import {$TARGET} from "../../src/store/types.js";
const settle = async () => { await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); flush(); };
      it("holds structural continuation with a replacement and an open append", async () => {
        const events: unknown[] = [];
        let feed!: (value: number) => void;
        let notify!: { promise: Promise<number>; resolve: (value: number) => void };
        const reset = () => {
          let resolve!: (value: number) => void;
          const promise = new Promise<number>(r => (resolve = r));
          notify = { promise, resolve };
        };
        reset();
        feed = value => {
          const current = notify;
          reset();
          current.resolve(value);
        };
        let serverData = [1];
        const fetches: Array<() => void> = [];
        let setVersion!: (fn: (v: number) => number) => number;
        let items!: Refreshable<readonly number[]>;
        let setItems!: (fn: (values: number[]) => void) => void;
        const rendered: number[][] = [];
        const dispose = createRoot(dispose => {
          const [version, setV] = createSignal(0);
          setVersion = setV;
          [items, setItems] = createOptimisticStore(async function* (store) {
            version();
            const data = await new Promise<number[]>(resolve => {
              fetches.push(() => resolve([...serverData]));
            });
            events.push({event:"yield replacement", data});
            yield data;
            while (true) {
              const value = await notify.promise;
              events.push({event:"continuation received", value});
              yield;
              store.push(value);
              events.push({event:"continuation pushed", value});
            }
          }, [] as number[]);
          createRenderEffect(
            () => items.map(n => n),
            value => {
              rendered.push(value);
              events.push({event:"callback", value});
            }
          );
          return dispose;
        });
        flush();
        fetches.shift()!();
        await settle();
        expect(rendered.at(-1)).toEqual([1]);

        let confirm!: () => void;
        const add = action(function* () {
          setItems(store => {
            store.push(2);
          });
          yield new Promise<void>(resolve => {
            confirm = resolve;
          });
        })();
        flush();
        expect(rendered.at(-1)).toEqual([1, 2]);

        // The replacement remains held in its producer's own refresh frame.
        serverData = [1, 5];
        setVersion(v => v + 1);
        flush();
        fetches.shift()!();
        await settle();
        expect(rendered.at(-1)).toEqual([1, 2]);

        // Later structural growth joins the same open array lifetime.
        feed(7);
        await settle();
        await settle();
        expect(rendered.at(-1)).toEqual([1, 2]);

        // Settle: the edit dies with its transaction; the reveal is the
        // full composed truth — refresh + continuation, no resurrected add.
        confirm();
        await add;
        await settle();
        const t = (items as any)[$TARGET];
        console.log(JSON.stringify({events, rendered, final: { length: items.length, indexed: [items[0],items[1],items[2]], latest: latest(() => ({length:items.length,indexed:[items[0],items[1],items[2]],mapped:items.map(n=>n)})), state: debugArrayState(t), raw: {v: t.v, pb:t.pb} }}));
        expect(rendered.at(-1)).toEqual([1, 5, 7]);
        expect(snapshot(items)).toEqual([1, 5, 7]);
        dispose();
      });
