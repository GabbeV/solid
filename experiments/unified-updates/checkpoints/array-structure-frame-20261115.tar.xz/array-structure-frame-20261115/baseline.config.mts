import config from '/workspace/layered-solid/packages/signals/vite.config.ts';
export default async args => {
  const result = typeof config === 'function' ? await config(args) : config;
  return { ...result, resolve: { alias: [{ find: /^(?:\.\.\/)+src\/(.*)\.js$/, replacement: '/workspace/scratch/array-structure-frame-20261115/baseline/packages/signals/src/$1.ts' }] } };
};
