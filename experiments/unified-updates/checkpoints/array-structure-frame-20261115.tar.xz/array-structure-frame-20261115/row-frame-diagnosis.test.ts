import {debugArrayValues} from "../src/store/optimistic-static.js";
import {debugArrayFrame} from "../src/store/optimistic-array.js";
import {$TARGET} from "../src/store/types.js";
import { expect, it } from "vitest";
import {
  action,
  createMemo,
  createOptimisticStore,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  refresh
} from "../src/index.js";

const settle = async () => {
  await Promise.resolve();
  await Promise.resolve();
  await Promise.resolve();
  flush();
};
const turn = () => new Promise<void>(resolve => setTimeout(resolve, 0));

it("keeps the published row while the action is open and retires unpublished replacement work at its end", async () => {
  type Row = { id: number; pending: boolean; tag: string };
  let server: Row[] = [];
  const fetches: Array<() => void> = [];
  const next = Promise.withResolvers<void>();
  const end = Promise.withResolvers<void>();
  const secondAnswer = Promise.withResolvers<number>();
  const [tick, setTick] = createSignal(0);
  const shown: Array<[string | undefined, number]> = [];
  const derivedShown: number[] = [];
  const [rows, setRows, dispose] = createRoot(dispose => {
    const [rows, setRows] = createOptimisticStore(
      () =>
        new Promise<Row[]>(resolve => {
          fetches.push(() => resolve(structuredClone(server)));
        }),
      [] as Row[],
      { key: "id" }
    );
    const derived = createMemo(() => (rows[0]?.tag === "second" ? secondAnswer.promise : 0));
    createRenderEffect(
      () => [rows[0]?.tag, tick()] as [string | undefined, number],
      value => {
        shown.push(value);
      }
    );
    createRenderEffect(derived, value => {
      derivedShown.push(value);
    });
    return [rows, setRows, dispose] as const;
  });
  let running: Promise<unknown> | undefined;
  try {
    flush();
    fetches.shift()!();
    await settle();
    running = action(function* () {
      setRows(d => {
        d.push({ id: 1, pending: true, tag: "first" });
      });
      yield next.promise;
      setRows(d => {
        d[0] = { id: 2, pending: true, tag: "second" };
      });
      yield end.promise;
    })();
    flush();
    expect([shown.at(-1), derivedShown.at(-1)]).toEqual([["first", 0], 0]);
    next.resolve();
    await turn();
    flush();
    expect([shown.at(-1), derivedShown.at(-1)]).toEqual([["first", 0], 0]);
    server = [{ id: 1, pending: false, tag: "server" }];
    refresh(rows);
    flush();
    fetches.shift()!();
    await settle();
    expect([shown.at(-1), derivedShown.at(-1)]).toEqual([["first", 0], 0]);
    end.resolve();
    await running;
    await turn();
    flush();
    // The unpublished replacement's async derivation does not extend the
    // action lifetime. The ready producer correction publishes at its end.
    console.log("row-state", JSON.stringify({shown,derivedShown, shape:debugArrayFrame((rows as any)[$TARGET]),slots:debugArrayValues((rows as any)[$TARGET])}));
    expect([shown.at(-1), derivedShown.at(-1)]).toEqual([["server", 0], 0]);
    setTick(1);
    flush();
    expect([shown.at(-1), derivedShown.at(-1)]).toEqual([["server", 1], 0]);
    secondAnswer.resolve(20);
    await turn();
    flush();
    expect([shown.at(-1), derivedShown.at(-1)]).toEqual([["server", 1], 0]);
    expect(derivedShown).not.toContain(20);
  } finally {
    next.resolve();
    end.resolve();
    secondAnswer.resolve(20);
    await running;
    dispose();
    flush();
  }
});
