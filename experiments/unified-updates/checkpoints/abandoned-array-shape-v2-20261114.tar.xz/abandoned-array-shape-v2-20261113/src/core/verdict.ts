// Verdicts (plan sec. 28 replay, 2026-10-02; maintainer, 2026-10-01: verdicts are
// optimistic state the system supplies). `isPending(fn)` asks whether what
// `fn` reads is final; `latest(fn)` reads the proposal — the staged write or
// landing, the lane's value — instead of the screen. A verdict is a guess
// ("pending, until this lands"; "the proposal is the value") and its readers
// break out of the hold the way a lane's do: work of the holder's verdict
// lane (lanes.ts), shown now, re-derived at the landing, ending with it. A
// verdict reader is a frame reader: its plain reads of held nodes see the
// screen (core.ts `frameRead`), so `[isPending(x), x()]` never pairs the
// fresh value with pending (A10).

import {
  CONFIG_CHILDREN_FORBIDDEN,
  CONFIG_GUESS,
  CONFIG_ASYNC,
  CONFIG_OWN_PROBE,
  CONFIG_FRAME,
  CONFIG_HELD,
  CONFIG_HELD_FRAME,
  CONFIG_IN_SNAPSHOT_SCOPE,
  CONFIG_INPUTS_PUBLISHED,
  CONFIG_OVERRIDE,
  CONFIG_REDERIVE,
  CONFIG_STAGED,
  CONFIG_STAGED_ERROR,
  CONFIG_VERDICT,
  EFFECT_RENDER,
  EFFECT_TRACKED,
  NOT_PENDING,
  NO_SNAPSHOT,
  REACTIVE_CHECK,
  REACTIVE_DIRTY,
  REACTIVE_DISPOSED,
  REACTIVE_FRAME_READ,
  REACTIVE_JOINED,
  REACTIVE_LANE_READ,
  REACTIVE_PROBED,
  REACTIVE_REASK,
  REACTIVE_SNAPSHOT_STALE,
  REACTIVE_PROBE_UNANSWERED,
  REACTIVE_STAGED_READ,
  REACTIVE_WINDOW,
  STATUS_ERROR,
  STATUS_PENDING,
  STATUS_UNINITIALIZED
} from "./constants.js";
import {
  bornInto,
  context,
  creatorPass,
  creatorReads,
  ext,
  joinPass,
  markLateLinker,
  prepareComputed,
  pullComputed,
  setVerdict,
  snapshotCaptureActive,
  spectating,
  strictRead,
  strictReadActive,
  tracking,
  unflushedValue,
  verdict
} from "./core.js";
import { quietPending, settlePendingSource } from "./async.js";
import { forgetThrownRead, warnStrictReadUntracked } from "./dev.js";
import { NotReadyError } from "./error.js";
import { link } from "./graph.js";
import { ahead, display, laneValueOf, verdictLane, waiting } from "./lanes.js";
import { deleteFromHeap, enqueueSub } from "./heap.js";
import {
  blocked,
  dirtyQueue,
  clock,
  flushTransaction,
  globalQueue,
  GlobalQueue,
  hiddenHook,
  insertSubs,
  joinFuture,
  passLane,
  queuePendingNode,
  resolveTx,
  setPassLane,
  stagedReaders,
  staleReader,
  queueRerun,
  txOf,
  type Transaction,
  installVerdictHooks
} from "./scheduler.js";
import {
  SLOT_C,
  SLOT_DV,
  SLOT_LV,
  SLOT_P,
  SLOT_SNAPSHOT,
  shadowActual,
  shadowExpect,
  shadowWindow
} from "./seat.js";
import type { Computed, Owner, Signal } from "./types.js";

/** A verdict reader whose answer this flush could not give yet: the node it
 * asked about is staged and not held — whether it will be is the seam's
 * verdict. It read the staging as the screen: if the flush parks it runs
 * again next round, as lane work that did the same does (`stagedReaders`,
 * lanes.ts — entering the verdict lane then voids what it staged); if it
 * commits, the answer stood. */
function watchVerdict(c: Computed<any>, unanswered = false): void {
  if (unanswered) c._flags |= REACTIVE_PROBE_UNANSWERED;
  stagedReaders.push(c);
}

/** The reading pass is the holder's verdict lane's — unless already lane
 * work, or already the transaction's (it derives from the future — a held
 * node's, or the staging of a write this flush may hold — and the verdict
 * does not rescue it: its result shows at the landing, re-derived), or a
 * member of the frame a held pass of that hold built (CONFIG_HELD_FRAME,
 * `bornInto`): the hold's own work, born in its world, reads plainly and
 * its run is the frame's (D-25, D-27) — the same leaf reading a memo of the
 * `latest()` waits for the landing too (`enterLane`; E2, #4284). A lane
 * read, for `recompute`'s tail (REACTIVE_LANE_READ). */
function route(c: Computed<any>, t: Transaction): void {
  if (
    !passLane &&
    !(c._flags & (REACTIVE_JOINED | REACTIVE_STAGED_READ)) &&
    !(c._config & CONFIG_HELD_FRAME && bornInto(c, resolveTx(t)))
  )
    setPassLane(verdictLane(t));
  c._flags |= REACTIVE_LANE_READ;
}

/** A verdict reader served a flight's committed value (the A31 frame-reader
 * case) still observed the flight — A15's stale reader "derives from the
 * flight all the same": the frame holds (the flush's transaction opens if
 * none has, as the throw would have had it), the reader is that
 * transaction's verdict lane's (shown now, with the flight's verdict), and
 * re-derives at the landing (REACTIVE_FRAME_READ — which is also what makes
 * it a blocker of the hold, `blockedBy`; a probe alone is neither). The
 * hold is on the flight: a reader served committed never goes pending, so
 * the transaction waits on it only through the flight's node — one that
 * went pending this flush is queued for the seam to hold; one in the air
 * from before, held by nobody (a lane's derivation whose lane dissolved at
 * its parent's landing with the flight still up; a flight nothing displayed,
 * #3305), is registered by this, its first observer (A15, #3458): queued for
 * the seam as if it had gone pending here, so the transaction has an entry
 * for what it now shows a reader of. Held by nothing, it landed at this very
 * seam and its `_reruns` re-derived the reader into the same observation,
 * every flush (fuzzer F12). True when the reader is served the committed
 * value — not over a flight committed beneath inputs already on screen (A15
 * reveal corollary, #3305): that value would tear against them, and the
 * reveal observes the flight. Nor for a reader born into the flight's
 * transaction (`bornInto`, #4010): it has no screen — it waits on the flight
 * with the rest of its frame. */
function observeFlight(c: Computed<any>, el: Computed<any>): boolean {
  // A render effect routed into a verdict lane reads the screen as lane
  // work (D-26). A memo still observes the flight: a plain read after its
  // window is the frame's read, as one before it is (A10, F-6, #4661).
  if (passLane && (c as any)._type && !(c._statusFlags & STATUS_UNINITIALIZED)) return true;
  if (el._config & CONFIG_INPUTS_PUBLISHED || (el._config & CONFIG_HELD && bornInto(c, txOf(el))))
    return false;
  // A derived store's derive whose store has no reader (`fam.live` empty:
  // no leaf has a node) is no display: it observes nothing and holds nothing
  // (F-3, D-11) — it stays live only to keep the store's data.
  if (globalQueue._running && (c as any)._fam?.live.size !== 0) {
    joinFuture(null);
    if (!(el._config & CONFIG_HELD)) queuePendingNode(el);
    ahead.splice(ahead.indexOf(c) >>> 0, 1);
    verdictRead(c, flushTransaction!, true);
  }
  return true;
}

/** Verdict windows. Inside `latest(fn)` a read of a held node serves the
 * proposal (above the async, the held write; below it, the committed value
 * — nothing newer exists) instead of joining or throwing; inside
 * `isPending(fn)` a read records whether what it saw is final. Either way
 * the reader breaks out: work of the holder's verdict lane, shown now and
 * re-derived at the landing. */
let latestActive = false;
let probing = false;
let probeFound = false;

/** A verdict read of a node a transaction (or lane) holds: the reading pass
 * is the holder's verdict lane's and re-derives at the holder's landing
 * (`_reruns`, as a stale reader). `isPending` flips at the landing with no
 * value notifying anyone (a held write's commit; a held landing's): its
 * reader re-derives there. `latest` shows the proposal that lands — a
 * rewrite or a landing reaches its reader through the link it holds — so a
 * re-run would only repeat the frame. */
function verdictRead(c: Computed<any>, t: Transaction, plain?: boolean): void {
  route(c, t);
  if (plain) staleReader(c, t);
  else if (probing) queueRerun(t, c);
}

/** A verdict read of a node staged or in flight but not held yet: whether it
 * will be is the seam's.
 *
 * `isPending` asks exactly that — final unless the flush parks — so its
 * reader cannot be answered before the seam: a flush that has joined a
 * transaction parks, and the node with it — the reader is that
 * transaction's verdict lane's now; before anything joined, the reader
 * watches the seam and runs again if the flush parks (a plain sync write
 * never glitches it true).
 *
 * `latest` has its answer either way — the proposal — but its reader's
 * membership is the seam's too: the frame opens no transaction for it
 * (#4365 — one opened for the read alone made a plain read after the window
 * take it for a hold, `stagedScreen`, and serve the screen beside the
 * staging in a frame nothing held). The reader watches the seam like a
 * probe before anything joined: its pass is the frame's, and runs again in
 * the verdict lane if the flush parks. Once the flush has joined a
 * transaction, the reader is its verdict lane's at once; a pass that also
 * read the frame's own stagings plainly (REACTIVE_STAGED_READ) stays the
 * frame's (`route` does not move it). */
function provisionalVerdict(c: Computed<any>, notFinal: boolean): void {
  if (flushTransaction) {
    if (probing && notFinal) probeFound = true;
    verdictRead(c, flushTransaction);
    if (probing && c._flags & REACTIVE_STAGED_READ) watchVerdict(c);
    return;
  }
  // Before anything joined, a staging that would not be final held has no
  // answer yet: whatever the seam decides, the pass runs again — a later
  // plain read of the same pass may route it into the verdict lane
  // (`observeFlight`), which the seam must not take as this probe's answer.
  // `latest` opens no transaction for its answer either (#4365): the plain
  // read of a staging after it took one opened for it for a hold and paired
  // the staging with the screen, in a frame nothing held. Its pass is the
  // frame's — whole — and re-derives once if the flush parks (unanswered:
  // its membership is the seam's, not the transaction it joins).
  watchVerdict(c, !probing || notFinal);
}

/** `isPending`'s answer for a held node (A19), relative to what the reader
 * sees — a verdict reader is a frame reader and sees the committed value: a
 * flight still up (cause ii) is not final unless quiet; a held write or
 * landing (staged — cause i/iii) is not final unless it answers the question
 * already shown (a quiet re-ask, through its reveal), is the node's first
 * landing (commit #0: loading, not pending), or the probe sits inside a
 * `latest` window, whose view of the node IS the proposal (A10: a reader
 * that observed the fresh value is not told it is pending; inside `latest`,
 * `isPending` asks whether the latest view is final). A member of a held
 * frame with neither is final. A24: pending iff a value change is in
 * flight — a staging equal to what is displayed changes nothing when it
 * lands: final now (maintainer, 2026-10-02). Asked of a node with a
 * committed value only (`verdictValue`'s held arm): a first landing never
 * gets here. Truthy when not final. */
function heldNotFinal(owner: Computed<any>): unknown {
  if ((owner._statusFlags & STATUS_PENDING) !== 0 && !quietPending(owner)) return true;
  return (
    owner._pendingValue !== NOT_PENDING &&
    !latestActive &&
    !owner._x!._reask &&
    (owner._x!._shownError ||
      !owner._equals ||
      !owner._equals(owner._value as any, owner._pendingValue as any))
  );
}

/** `isPending`'s answer for an unheld node whose flight is up (cause ii). */
function pendingVerdict(c: Computed<any> | null, el: Computed<any>): void {
  if (probing && !quietPending(el)) probeFound = true;
  if (c && tracking) {
    if (el._config & CONFIG_HELD) verdictRead(c, txOf(el));
    else if (globalQueue._running) {
      // `latest` of a flight serves the committed value, the frame's and the
      // lane's alike (D-22): nothing is the seam's, so the reader is the
      // verdict lane's now, as a plain read of a flight makes it
      // (`observeFlight`). Its frame pass re-derived in the lane (R5) asked
      // its question again (F-9, #4397). A staging's is the seam's (#4365).
      // A probe in a transaction only that opened is the lane's too, with no
      // re-run at its landing: nothing it holds flips the verdict — the
      // flight's own landing re-derives the reader — and it lands at this
      // seam, where a re-run would open it again, every flush (F-6, D-23).
      // (The mark is the transaction's own — `Transaction.latest` — so
      // nothing outlives its landing.)
      // Read ahead of, by a pass no plain read of a flight routed yet
      // (`observeFlight`): no frame read of it (F-6, #4661; lanes.ts
      // `laneSeams`). Once routed, the pass's later plain reads are the
      // lane's and mark nothing.
      if (!probing) {
        c._flags & REACTIVE_LANE_READ || ahead.push(c);
        flushTransaction ||
          (joinFuture(null), ((flushTransaction as Transaction | null)!.latest = 1));
      } else if (flushTransaction?.latest) return route(c, flushTransaction);
      provisionalVerdict(c, false); // decided above
    }
  }
}

/** The pass entering a verdict window is a verdict reader (CONFIG_VERDICT):
 * a dependency going pending re-derives it, the verdict having changed. Not
 * an untracked window: that is a snapshot, like any untracked read (#3946 —
 * a router's link claim probing inside the computation that creates the
 * anchor). A throw still reaches the pass through `untrack`. */
function markVerdictReader(window: number): void {
  const c = creatorPass(context);
  if (c && tracking) {
    // A pass run inside passes still running — its creator's, theirs — one
    // of which read the future or a staging (a branch a held or staged
    // condition opened, and whatever that branch creates) has no screen: the
    // branch exists only in that world. It reads that world as any
    // derivation of it does (`bornInto` once held) and stays its pass
    // (`route`); a verdict reader from its next pass. #4341: a memo born in
    // a newly opened <Match> read the screen, where its branch was closed.
    // Not such a pass: a verdict reader now.
    c._config &= ~CONFIG_ASYNC;
    c._flags |=
      REACTIVE_PROBED |
      REACTIVE_WINDOW |
      (creatorReads(c, 0) || ((c._config |= CONFIG_VERDICT), 0));
    if (__TEST__) shadowWindow(c);
    // Observe tier: which windows this pass entered (1 `isPending`, 2
    // `latest`) — the hold census names the affordance (attribution.ts).
    if (__OBSERVE__) (c as any)._devWindows = ((c as any)._devWindows ?? 0) | window;
  }
}

/** The windows. `read` dispatches to `verdictValue` while one is open; each
 * restores the dispatch it found — none inside a memo's pass a window
 * pulled (`verdictValue`). */
export function latest<T>(fn: () => T): T {
  markVerdictReader(2);
  const prev = latestActive,
    prevVerdict = verdict;
  latestActive = true;
  setVerdict(verdictValue);
  try {
    return fn();
  } finally {
    latestActive = prev;
    setVerdict(prevVerdict);
  }
}

/**
 * Reports whether what `fn` reads is still waiting on an update. Read the
 * values in question inside `fn`: the probe answers `true` while any of
 * them depends on a change that is in flight — a write or an async source
 * that has started producing a new value whose result has not landed yet —
 * and `false` once the latest value is the one on screen. The answer is
 * tracked like any read, so a memo or effect that calls `isPending` re-runs
 * when it flips.
 *
 * A read that has no value yet is loading, not pending: inside `fn` it
 * follows the surrounding `Loading` path like any other read, and the probe
 * reports only updates to a value that already exists. A bare `refresh()`
 * does not flip `isPending`; pair it with `affects()` to make the re-ask
 * visible.
 *
 * @param fn expression to probe; read the values in question inside it
 *
 * @returns `true` while a read inside `fn` depends on a change that has not committed yet
 *
 * @example
 * ```ts
 * const [query, setQuery] = createSignal("");
 * const results = createMemo(() => searchProducts(query()));
 * const stale = createMemo(() => isPending(results));
 *
 * setQuery("shoes");
 * // stale() is true until the new results land, while results() keeps
 * // serving the previous list — dim it instead of showing a spinner.
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/is-pending
 */
export function isPending(fn: () => any): boolean {
  markVerdictReader(1);
  const prevProbing = probing;
  const prevFound = probeFound;
  const prevVerdict = verdict;
  probing = true;
  probeFound = false;
  setVerdict(verdictValue);
  try {
    fn();
    return probeFound;
  } catch (e) {
    // A pending node is served inside the probe; what still throws is an
    // uninitialized one — loading, not pending (A19 exc. 1) — whose NotReady
    // propagates to boundaries from inside an owner (B5a; a component body
    // suspends on it like any read, #2928) and is swallowed outside one. A
    // verdict never throws anything else: a thunk that errors is simply not
    // pending.
    if (e instanceof NotReadyError && !probeFound && context !== null) throw e;
    // D-42 (dev): the swallow is the probe's mechanism, not a user catch.
    if (__DEV__) forgetThrownRead();
    return probeFound;
  } finally {
    probing = prevProbing;
    probeFound = prevFound;
    setVerdict(prevVerdict);
  }
}

/** The staging, or the staged error thrown (D-41). */
function staged(el: Signal<any> | Computed<any>): unknown {
  if (el._config & CONFIG_STAGED_ERROR) throw el._pendingValue;
  return el._pendingValue;
}
/** `latest()` of a held node: the flushed staging — the proposal — and, for
 * a tracked reader of a rewrite not yet flushed, the late-linker re-run in
 * the flush that carries it. */
function heldLatest(el: Signal<any> | Computed<any>, c: Computed<any> | null): unknown {
  const u = unflushedValue(el);
  if (u === NOT_PENDING) return staged(el);
  if (c) markLateLinker(c);
  return u;
}
/** The verdict windows' read — `latest(fn)` and `isPending(fn)` — in one
 * cold path off `read`'s. It links and pulls like a plain read, then answers
 * for what the reader sees (a verdict reader is a frame reader):
 * - a lane's node: the reader is the holder's verdict lane's (not the
 *   lane's — a lane blocked on its own flight would hold the reader's run,
 *   the opposite of a verdict's display-ahead). A guess is the value (A17),
 *   not final while its own question flies or a truth held beneath it
 *   differs (A24, A18 provenance). A derivation: `latest` sees the lane's
 *   latest (a landing a blocked lane holds has answered its question — the
 *   checkout's shipping text updates independently of the tax in flight),
 *   `isPending` the screen; not final while its own flight is up. A
 *   derivation's first load in flight (nothing produced yet — an async memo
 *   over a verdict memo, F-6) reads as the flight below: loading (D-22);
 * - a held node: the reader breaks out as the holder's verdict lane's and
 *   re-derives at the landing; `latest` serves the proposal (`heldLatest`),
 *   `isPending` answers `heldNotFinal`;
 * - a node staged this flush and not yet held: the seam's verdict
 *   (`provisionalVerdict`) — or, with a newer question already in flight
 *   (#3376, the stale first hop of a chain), its flight's;
 * - a flight (cause ii): `isPending` records it (`pendingVerdict`), `latest`
 *   serves the committed value — below the async nothing newer exists; an
 *   uninitialized one throws NotReady: loading, not pending (A19 exc. 1);
 * - an errored derivation throws for every reader (#2897). */
function verdictValue(el: Signal<any> | Computed<any>, c: Computed<any> | null): unknown {
  const owner = el as Computed<any>;
  const owned = !!c && !(c._config & CONFIG_CHILDREN_FORBIDDEN);
  const tracked = owned && tracking;
  // A31: the pulled memo's pass is its own, not the probe's — it reads
  // outside the window, and the probe's read below answers for what the pass
  // produced. So is a lazy or dormant memo's wake (an unowned memo with no
  // reader left, #4366): woken inside the window, it read its sources as the
  // probe does, the committed value under a landing. (A signal has no
  // `_flags`: the wake is a no-op for it.) So is the probe's state (#4429):
  // a `latest()` the pass makes itself does not join a hold through the
  // probe's arm, and what the pass reads does not answer the outer probe
  // (`probeFound` is only set while `probing`). So is the window's kind: an
  // `isPending` the pass makes itself answers for what it reads, not as a
  // probe inside the outer `latest()`.
  const prevProbing = probing;
  const prevLatest = latestActive;
  probing = false;
  latestActive = false;
  setVerdict(null);
  prepareComputed(owner, false);
  if (c && tracking) {
    link(el, c);
    // #4544: asked of this staging, under its hold or this flush.
    if (el._pendingValue !== NOT_PENDING)
      ext(el)._askedIn = el._config & CONFIG_HELD ? txOf(el) : flushTransaction || clock;
    if ((el as any)._fn) pullComputed(owner, c);
  }
  setVerdict(verdictValue);
  latestActive = prevLatest;
  probing = prevProbing;
  // A reader in a snapshot scope (a hydration claim) is served the value the
  // server rendered with, as `read` serves a plain one: `latest(a)` beside
  // `a()` in a claim shows the server's frame whole (F-1), not a client
  // write's flight the markup never had — which would put a boundary over
  // it in a fallback the server never rendered, claimed against nothing
  // (#4570). `isPending` answers for that frame: nothing in flight. The
  // reader replays at the scope's release.
  const sv =
      snapshotCaptureActive && c && c._config & CONFIG_IN_SNAPSHOT_SCOPE
        ? el._x?._snapshotValue
        : undefined,
    served = sv !== undefined && !(owner._statusFlags & STATUS_ERROR);
  // Shadow (S0): the window's decision point — the rows Vl*/Vp*.
  if (__TEST__) shadowExpect(c, el, tracking, latestActive ? 2 : 1, spectating, served);
  if (served) {
    const snapshot = sv === NO_SNAPSHOT ? undefined : sv;
    if ((el._pendingValue !== NOT_PENDING ? el._pendingValue : el._value) !== snapshot)
      c!._flags |= REACTIVE_SNAPSHOT_STALE;
    if (__TEST__) shadowActual(SLOT_SNAPSHOT);
    return snapshot;
  }
  // A live `affects()` mark on the node or a dependency (affects.ts): not
  // final by declaration — the value itself is read as below. The verdict is
  // display-ahead like any: in a transaction's flush (the declaring action's
  // body) the reader is its verdict lane's, not a staging the frame parks.
  if (probing && GlobalQueue._marked?.(owner)) {
    probeFound = true;
    if (tracked && flushTransaction) verdictRead(c!, flushTransaction);
  }
  if (
    el._config & CONFIG_OVERRIDE &&
    !(owner._statusFlags & STATUS_ERROR && !(el._config & CONFIG_GUESS))
  ) {
    const l = txOf(el),
      flying = (owner._statusFlags & STATUS_PENDING) !== 0 && !quietPending(owner),
      guess = el._config & CONFIG_GUESS,
      // NOT_PENDING: a node born in the lane with nothing in it yet has no
      // value in either view — loading, not pending, and no verdict to read
      // ahead: it is read as any uninitialized node, NotReady below (A7, A19
      // exc. 1; #4363), its reader not moved into the verdict lane.
      v = guess ? 0 : latestActive && !flying ? laneValueOf(el) : display(el);
    if (v !== NOT_PENDING) {
      if (tracked) verdictRead(c!, l._parent ?? l);
      if (guess) {
        if (
          probing &&
          (flying ||
            (el._pendingValue !== NOT_PENDING &&
              (!el._equals || !el._equals(el._x!._lane as any, el._pendingValue as any))))
        )
          probeFound = true;
        // A lane a correction folded under (D-34): `latest()` shows the hold's
        // world whole — the truth beneath each guess, else what it covered.
        if (latestActive && l.folded) {
          if (__TEST__) shadowActual(el._pendingValue !== NOT_PENDING ? SLOT_P : SLOT_C);
          return l.folded(null, el);
        }
        if (__TEST__) shadowActual(SLOT_LV);
        return el._x!._lane;
      }
      // A first load in flight with nothing produced yet: loading, for
      // `latest` (D-22) as for `isPending` (A19 exc. 1) — unless an error
      // answered it first: its re-ask is pending, the error its display
      // (D-41, #4375).
      if (
        flying &&
        v === el._value &&
        owner._statusFlags & STATUS_UNINITIALIZED &&
        (latestActive || !owner._x!._shownError)
      )
        throw owner._x!._error;
      if (probing && flying) probeFound = true;
      if (__TEST__) shadowActual(latestActive && !flying ? SLOT_LV : SLOT_DV);
      return v;
    }
  }
  // Dev strict-read scopes (a component body, an effect callback) warn on a
  // verdict read as on any untracked read; the pending throw they add for a
  // plain read does not apply — a verdict read is a sanctioned read of a
  // pending node (an uninitialized one still throws NotReady below).
  if (__DEV__ && strictRead && strictReadActive())
    warnStrictReadUntracked(strictRead, {
      ownerId: c?.id,
      ownerName: (c as any)?._name,
      nodeName: (owner as any)?._name
    });
  const uninitialized = (owner._statusFlags & STATUS_UNINITIALIZED) !== 0;
  if (el._config & CONFIG_HELD) {
    if (!uninitialized) {
      const t = txOf(el);
      // A render effect re-run (or mounted) outside the verdict lane's flush
      // while the lane is blocked — its display held on its own derivation
      // in flight — is a stale reader of the lane (#3460, as `laneRead`): the
      // committed value now, re-derived at the reveal. Not inside a probe:
      // `isPending` is answered below either way.
      if (
        tracked &&
        !probing &&
        (c as any)._type === EFFECT_RENDER &&
        !passLane &&
        t._verdict?._held &&
        flushTransaction !== t
      ) {
        staleReader(c!, t._verdict);
        if (__TEST__) shadowActual(SLOT_C);
        return el._value;
      }
      if (tracked) verdictRead(c!, t);
      // #4648: a pass the hold holds (it read the frame's staging) is the
      // hold's work, shown at the landing: its probe is final there, never
      // `true` beside the fresh value its plain read saw (D-23), in either
      // read order. What the probe read is the committed value (maintainer,
      // #4662: "during the hold, reads outside latest() get the committed
      // value"), so the pass is a stale reader of it and re-derives on the
      // landed world (A15, F-1). Not an async memo (`_q`, a flight asked):
      // its re-run would ask the hold's question again (F-9).
      if (probing)
        if (c?._config! & CONFIG_HELD) {
          // In the flush that lands the hold (nothing blocks it now: the
          // pass is the hold's own work, D-25), the probe reads the landed
          // world and the pass is final in the landing frame (F-1). If a
          // later node blocks the hold again, the seam re-runs it, held, on
          // the committed value (`watchVerdict`; ruling on #4662).
          if (el._pendingValue !== NOT_PENDING && !blocked(t)) {
            watchVerdict(c!);
            if (__TEST__) shadowActual(SLOT_P);
            return staged(el);
          }
          if (!c!._x!._q) staleReader(c!, t);
        } else {
          if (heldNotFinal(owner)) probeFound = true;
          // A pass that first reads the held node in this flush is not held
          // yet, in either read order: if the flush parks with it, it runs
          // again next round, held, and its probe is final there (D-23). Not
          // an async memo or a first pass (it may be async): F-9.
          if (owned && !tracked && !c!._x?._q && !(c!._statusFlags & STATUS_UNINITIALIZED))
            watchVerdict(c!);
        }
      if (latestActive && el._pendingValue !== NOT_PENDING) {
        // An action body reading another transaction's proposal derives
        // from it: the two settle as one (A15; posture C, 2026-09-15). An
        // untracked read elsewhere has no transaction to entangle.
        if (!tracked && flushTransaction && !globalQueue._running) joinFuture(t);
        if (__TEST__) shadowActual(SLOT_P);
        return heldLatest(el, tracked ? c : null);
      }
      if (__TEST__) shadowActual(SLOT_C);
      return el._value;
    }
    // Born into the future: its staging is its only value. It has no
    // committed value, so no verdict: `isPending` reads it as its read does —
    // the owner joins the hold (held with it, or caught by a boundary that
    // has not shown content) and answers for the commit, where it is final.
    if (el._pendingValue !== NOT_PENDING && !(owner._statusFlags & STATUS_PENDING)) {
      if (probing && owned) joinPass(c!, el);
      if (__TEST__) shadowActual(SLOT_P);
      return staged(el);
    }
  } else if (el._pendingValue !== NOT_PENDING) {
    // A first value staged this flush and re-asked in it (an async first
    // answer landing in the tick a write re-asks it) is answered: the
    // re-ask is a new question (F-9, D-22). An error is no value (D-41).
    // `latest` serves the staging below.
    if (
      owner._statusFlags & STATUS_PENDING &&
      (!uninitialized || (probing && !(el._config & CONFIG_STAGED_ERROR)))
    )
      pendingVerdict(tracked ? c : null, owner);
    // D-8: a signal's staging equal to its committed value is writes that
    // netted — no proposal: the seam holds nothing of it and no landing
    // flips its verdict, so it is final (F-9, D-23) and the reader is not
    // re-run at the landing (#4485; `read`'s plain arm likewise, #4452). The
    // reader is still the tick's verdict reader, shown now (D-25: the
    // posture is the pass's). A signal's staging only, as `read`'s arm.
    else if (tracked && globalQueue._running)
      flushTransaction &&
      !(el as any)._fn &&
      el._pendingValue === el._value &&
      Object.is(el._pendingValue, el._value)
        ? route(c!, flushTransaction)
        : provisionalVerdict(c!, !latestActive && !uninitialized);
    // Outside a flush, the staging is an unflushed write (A28): the probe
    // answers for the flushed world, and watches the seam of the flush that
    // carries the write — a memo of `isPending(x)` created after the write
    // flips if that flush parks (#3078). (The write's own fan-out ran before
    // the reader existed; nothing else would re-derive it.)
    else if (tracked && probing) watchVerdict(c!);
    if (latestActive || uninitialized || (owned && !tracked)) {
      // A28: an unflushed write is not what `latest` serves; a tracked
      // reader derived from the flushed world runs again in the carrying
      // flush. A probe in a pass reads as its plain read does (#4648): a
      // first value staged this flush has no committed value (D-23 exc. 1,
      // F-9), and an untracked read sees the flush's staging — the staging
      // flush is a normal flush, not the hold (F-10, D-24; ruled 2026-11-03).
      // If the flush parks, what the pass read is the hold's frame.
      if (globalQueue._running) {
        if (__TEST__) shadowActual(SLOT_P);
        return staged(el);
      }
      if (c) markLateLinker(c);
    }
    if (__TEST__) shadowActual(SLOT_C);
    return el._value;
  }
  if (owner._statusFlags & STATUS_PENDING) {
    if (!uninitialized) {
      pendingVerdict(tracked ? c : null, owner);
      if (__TEST__) shadowActual(SLOT_C);
      return el._value;
    }
    // As `read()`: an untracked read of a pending node still re-runs its
    // reader when the node settles (a projection's pull reads its firewall
    // untracked, store/store.ts).
    if (c && !tracking && !spectating && el !== c) link(el, c);
    throw owner._x?._error;
  }
  if ((el as any)._fn && owner._statusFlags & STATUS_ERROR) throw owner._x!._error;
  if (__TEST__) shadowActual(SLOT_C);
  return el._value;
}

/** D-25: a node whose fetch a hold is waiting on is that hold's work, not a
 * verdict reader — a pass that re-runs it reads plainly — and a memo's
 * posture is what it reads: one that reads a verdict reader's value is a
 * verdict reader itself (#4050). An async memo with no verdict window of its
 * own (REACTIVE_WINDOW: it read a verdict memo, it called neither `latest`
 * nor `isPending`) is a verdict reader between its flights, and the hold's
 * work while one is up or its hold re-runs it.
 *
 * At a pass's head (core.ts `recompute`): a pending node's pass — its
 * flight is the transition's own work (#3884) — and a held one's re-run of
 * such a memo read plainly: the write that re-ran it is its hold's, and
 * served the screen it re-asked a question it had answered (A10, #4397).
 * Only a memo that never asked: D-25's "a verdict posture outlives the pass
 * that asked" is a pass that called `latest`/`isPending`, which clears
 * CONFIG_ASYNC and stays a verdict reader whoever dirties it.
 *
 * On `source` going pending (`propagateStatus`): such a memo waits on it
 * like any derivation (F-9) instead of re-deriving — what it read changed
 * no value, so its re-run re-asked the question it was answering. Unless
 * its own flight is up outside a lane on a new question of the source's:
 * its re-run supersedes a flight asked of a value the source has moved past
 * (re-asked by a `refresh()`, the source's question is the same one).
 *
 * Waiting, it is the hold's work until a pass of it reads a verdict again,
 * so the verdict posture drops here, at the wait (the pass's own reads
 * stamp it again, `read`). Kept, the source's next pending — its verdict
 * lane's re-derive at the park (#4393) — re-derived the waiting memo as a
 * verdict reader into that lane while the hold's flight it waits on was
 * still up, and the pass the landing runs, its hold re-running it, read as
 * a verdict reader: the head that drops the posture for such a pass sees
 * neither pending (the landing settles the node first) nor held (a lane's
 * node). #4408: `m1` entered the s lane early, the lane was unshown when
 * `m1:22` landed, nothing held the frame `m0b:1100` landed into, and the
 * lane's reader `latest(m2)` showed `c1101` while `m1:1122` was in flight. */
function holdWork(n: Computed<any>, source: Computed<any>): unknown {
  // CONFIG_ASYNC records an async memo with no window of its own: its last
  // answering pass registered a flight (`handleAsync`) and called neither
  // `latest` nor `isPending`. A window (`markVerdictReader`), a sync answer or
  // an error clears it; a pass left pending keeps the last answer's.
  // Waiting drops the posture; the result stays truthy (CONFIG_ASYNC is kept).
  if (
    n._config & CONFIG_ASYNC &&
    (!(n._statusFlags & STATUS_PENDING) ||
      n._x!._transaction?._lane ||
      source._flags & REACTIVE_REASK)
  )
    return (n._config &= ~CONFIG_VERDICT);
}

// Installed at module evaluation — present exactly when something imports
// `latest` or `isPending`. (`read` dispatches to `verdictValue` through
// `verdict`, set while a window is open.)
/** D-41: a derivation of a staged error carries it, staged with the same
 * frame — marked, not re-run, as a published error marks it (a re-run would
 * replace the frame its content owns) — and its own verdict readers
 * re-derive (the settle walk). Only a verdict reads a derivation's staging
 * before its commit, so only the verdict engine marks. Not a boundary's
 * output, an async memo, an effect or a boundary's tree (`EFFECT_TRACKED <<
 * 23` spans CONFIG_FRAME and every effect type), nor one already carrying a
 * staged error: the commit's publish reaches them. A pending mark supersedes
 * the staging (`propagateStatus`). Installed as `stageMarkHook`: the settle
 * walk (`settlePendingSource`) marks every node it reaches from a staged
 * error — a diamond's revisited join and a chain's single arrival alike
 * (#4562). */
function stageMark(node: Computed<any>, el: Computed<any>): void {
  if (
    el._config & CONFIG_STAGED_ERROR &&
    !(node._config & (CONFIG_REDERIVE | CONFIG_STAGED_ERROR | (EFFECT_TRACKED << 23)))
  ) {
    // Only a node that reads a staging carries it. The walk also reaches the
    // readers of a node it does not mark (a boundary's output, whose pass
    // decides content or fallback): what they get comes through that node,
    // not as the staging. An async memo over a staging is marked, so its
    // readers stay pending until the commit (F-9, D-22, D-23).
    // A memo over an error boundary's output is a plain reader of it (F-3:
    // where the memo sits does not matter); marked, it threw the error past
    // the boundary that caught it, and the commit halted (#4640).
    for (let d = node._deps; d; d = d._nextDep)
      if (d._dep._config & CONFIG_STAGED_ERROR) {
        node._pendingValue = el._pendingValue;
        node._config |= CONFIG_STAGED_ERROR;
        queuePendingNode(node);
        // A derived store's readers are its family's (store/projection.ts): they
        // re-derive from the staging, as from the derive's status (#4189).
        (node as any)._fam?.st(STATUS_ERROR);
        return settlePendingSource(node);
      }
  }
}

/** #4417: `el`, republished mainline at a park re-derive, re-derived the
 * staging it superseded. A held reader whose only held read was `el` read
 * that same value: it keeps its pass and children, its staging published
 * mainline as it is — one key, one child — instead of re-running. */
function keepReaders(el: Computed<any>): void {
  for (let s = el._subs; s !== null; s = s._nextSub) {
    const r = s._sub;
    if (
      (r._config & (CONFIG_HELD | CONFIG_STAGED)) !== (CONFIG_HELD | CONFIG_STAGED) ||
      (r as any)._type
    )
      continue;
    let d = r._deps;
    while (d !== null && (d._dep === el || !(d._dep._config & CONFIG_HELD))) d = d._nextDep;
    if (d !== null) continue;
    deleteFromHeap(r, dirtyQueue);
    r._flags &= ~(REACTIVE_DIRTY | REACTIVE_CHECK);
    r._config &= ~CONFIG_HELD;
    queuePendingNode(r);
    insertSubs(r);
  }
}

/** #4574 (S-46): a render effect born into an open hold, not behind a
 * fallback, that has not run. */
function bornHeldOpen(owner: Owner | null): Transaction | null {
  for (let c = owner?._firstChild ?? null; c !== null; c = c._nextSibling) {
    const n = c as Computed<any>;
    if (n._flags & REACTIVE_DISPOSED || hiddenHook?.(n)) continue;
    if (
      (n as any)._type === EFFECT_RENDER &&
      n._statusFlags & STATUS_UNINITIALIZED &&
      n._config & CONFIG_HELD &&
      n._pendingValue !== NOT_PENDING
    ) {
      const t = txOf(n);
      if (!t._lane && blocked(t)) return t;
    }
    const inner = bornHeldOpen(c);
    if (inner) return inner;
  }
  return null;
}

function valueInserts(v: unknown): boolean {
  if (typeof v !== "object" || v === null) return false;
  if (Array.isArray(v)) return v.some(valueInserts);
  return (v as { nodeType?: number }).nodeType! > 0;
}

/** #4574: a lane or verdict render effect inserting a node whose subtree (or
 * a value it reads) holds such a hole waits for that hold — the attach runs
 * at the landing with its content, never as an empty shell now. */
function attachWaits(node: Computed<any>): boolean {
  // A run of the frame a landing holds for its re-derivation (lanes.ts
  // `waiting`) runs next round, with the landing's held runs.
  if (waiting?.has(node))
    return (
      globalQueue.enqueue(
        (node as any)._type,
        ((node as any)._boundRunEffect ??= GlobalQueue._runEffect.bind(null, node))
      ),
      true
    );
  if (
    (node as any)._type !== EFFECT_RENDER ||
    !(node._config & CONFIG_VERDICT || node._x?._transaction?._lane) ||
    !valueInserts(node._pendingValue !== NOT_PENDING ? node._pendingValue : node._value)
  )
    return false;
  let t = bornHeldOpen(node);
  for (let d = node._deps; d !== null && t === null; d = d._nextDep) {
    t = bornHeldOpen(d._dep as Owner);
    if (d === node._depsTail) break;
  }
  if (t === null) return false;
  t._queues[0].push(((node as any)._boundRunEffect ??= GlobalQueue._runEffect.bind(null, node)));
  return true;
}

/** #4544: a verdict reader whose posture is only inherited (it read a
 * verdict memo, and neither this pass nor its last opened a window,
 * CONFIG_OWN_PROBE; no unanswered probe) is the hold's work where it reads
 * the hold's own sync write: not an async memo's answer (a flight's, A10),
 * not a lane's, and not a staging a window asked of under the hold that
 * holds it, or in this flush (`_askedIn`: `[latest(x), x()]` through a memo
 * stays atomic, D-26 — a mark that expires with that hold). It is served
 * that staging — held (`frameRead`), or this flush's before it parks
 * (`stagedScreen`), leaving the verdict lane an earlier read of the verdict
 * memo seated it in (D-25: either read order). A frame (a render effect, a
 * boundary's structure) reads the screen as before. No `el` is a store
 * key's node-less staging (store.ts `readSource`): by construction this
 * flush's own sync write to a plain store, with no node for a window to
 * have asked through — the posture alone decides, as it does for the
 * signal (R2, signal parity). */
function holdStaging(c: Computed<any>, el?: Signal<any> | Computed<any>): unknown {
  const a = el?._x?._askedIn;
  return (
    !(
      c._config & (CONFIG_OWN_PROBE | CONFIG_FRAME) ||
      c._flags & (REACTIVE_WINDOW | REACTIVE_PROBE_UNANSWERED)
    ) &&
    (!el ||
      (el._pendingValue !== NOT_PENDING &&
        !(el._config & (CONFIG_ASYNC | CONFIG_OVERRIDE)) &&
        a !== clock &&
        !(
          typeof a == "object" &&
          resolveTx(a) ===
            resolveTx(el._config & CONFIG_HELD ? el._x!._transaction! : flushTransaction!)
        ))) &&
    (!passLane || (passLane._parent!._verdict === passLane && (setPassLane(null), true)))
  );
}

installVerdictHooks(observeFlight, holdWork, stageMark, keepReaders, attachWaits, holdStaging);
/** A store read inside an untracked `isPending` probe found a live mark on
 * a record with no node to carry it (store/affects.ts): not final. */
GlobalQueue._witnessMark = () => {
  if (probing) probeFound = true;
};
