/**
 * Thrown by a tracked read whose value is currently pending (an async memo /
 * `createSignal(asyncFn)` / projection / store derivation that hasn't settled
 * yet). Surfacing through the reactive graph is what suspends the consumer
 * scope — the nearest enclosing `<Loading>` boundary catches the throw and
 * renders its fallback until the source resolves.
 *
 * Also identifies a synchronous context retry: a read of optimistic state,
 * including `latest` or `isPending`, can require restarting a calculation whose
 * earlier reads used a different update context. The runtime retries that
 * calculation instead of treating this as an async wait or a user error.
 *
 * App code rarely catches this directly; `<Loading>` is the canonical
 * handler. The error type is exposed for advanced cases — e.g. interop layers
 * that bridge Solid's pending-throw protocol to a different async strategy,
 * or tests that want to assert on the suspension shape.
 *
 * @example
 * ```ts
 * // Advanced: distinguish "not ready yet" from a real error in custom
 * // boundary plumbing. App code should rely on `<Loading>` / `<Errored>`.
 * try {
 *   const value = readReactiveSource();
 * } catch (err) {
 *   if (err instanceof NotReadyError) throw err; // re-throw to suspend
 *   reportError(err);
 * }
 * ```
 */
export class NotReadyError extends Error {
  /**
   * Tags a visibility-only notification on the affects() boundary channel:
   * boundaries update display state from it, but the root queue never
   * registers a reporter — marks are invisible to completion accounting by
   * construction.
   */
  declare _markVisual?: boolean;
  // `declare`: assigned in the constructor; a class field would only add
  // bytes (an extra define before the assignment).
  declare source: any;
  constructor(source: any) {
    // Control-flow throw: it happens on every read of a pending source, so in
    // production skip V8's eager stack capture (proportional to stack depth —
    // real cost under SSR) by zeroing the V8-specific stackTraceLimit around
    // super(). Dev keeps the stack for debuggability; non-V8 engines (no
    // stackTraceLimit) take the plain path.
    const ErrorCtor = Error as unknown as { stackTraceLimit?: number };
    const limit = !__DEV__ ? ErrorCtor.stackTraceLimit : undefined;
    if (limit !== undefined) ErrorCtor.stackTraceLimit = 0;
    super();
    if (limit !== undefined) ErrorCtor.stackTraceLimit = limit;
    this.source = source;
  }
}

/** Internal synchronous suspension: abort this attempt and retry in its selected
 * update context. Applications recognize NotReadyError; the runtime must not
 * park this attempt on the source as though it were an unfinished async flight. */
export class ContextRetry extends NotReadyError {}

export class StatusError extends Error {
  declare source: any;
  constructor(source: any, original: any) {
    // Best-effort message: formatting must never replace the original (#4112).
    try {
      var message: string | undefined = String(
        original instanceof Error ? original.message : original
      );
    } catch {}
    super(message, { cause: original });
    this.source = source;
  }
}

/** Return the user's error from an internal status wrapper. */
export function unwrapStatusError(error: unknown): unknown {
  return error instanceof StatusError ? error.cause : error;
}

/**
 * Rejection value of `until(fn, { timeout })` when the predicate does not turn
 * truthy within the window. Inside an `action()`, the rejection is thrown back
 * in at the `yield` point — catchable there, or the action fails and its
 * optimistic state reverts.
 */
export class TimeoutError extends Error {
  constructor(message = "Timed out waiting for condition") {
    super(message);
    this.name = "TimeoutError";
  }
}

export class NoOwnerError extends Error {
  constructor() {
    super(__DEV__ ? "Context can only be accessed under a reactive root." : "");
  }
}

export class ContextNotFoundError extends Error {
  /**
   * In dev, a read site passes the context (and whether a provider above set
   * it to `undefined`) so the message can name it and say why it has no
   * value (#4181). Read through `arguments` so production — where the message
   * is empty — keeps the zero-parameter constructor byte for byte.
   */
  constructor(context?: { id: symbol }, providedUndefined?: boolean);
  constructor() {
    super(__DEV__ ? contextNotFoundMessage(arguments[0], arguments[1]) : "");
  }
}

/**
 * Dev message for a context read with no value. `undefined` means "not
 * provided" for context, from either side — no default, or a provider
 * passing `undefined` — so the message says which happened and points at
 * `null` as the explicit empty value.
 */
function contextNotFoundMessage(
  context: { id: symbol; _undefinedDefault?: boolean } | undefined,
  providedUndefined: boolean | undefined
): string {
  if (!context)
    return "Context must either be created with a default value or a value must be provided before accessing it.";
  const description = context.id.description;
  const name = description ? `Context "${description}"` : "Context";
  if (providedUndefined)
    return `${name} was provided with \`undefined\`, which counts as not provided: \`undefined\` means "no value" for context. To provide an empty value, create the context with a \`null\` default (\`createContext<T | null>(null)\`) and pass \`null\`.`;
  if (context._undefinedDefault)
    return `${name} has no provider above this read, and \`createContext(undefined)\` does not give it a default: \`undefined\` means "no value" for context. Mount a provider above this read, or use \`null\` as an explicit empty default: \`createContext<T | null>(null)\`.`;
  return `${name} has no provider above this read and no default value. Mount a provider above this read, or create the context with a default; for an optional context, use \`null\` as the empty default (\`createContext<T | null>(null)\`), not \`undefined\`.`;
}
