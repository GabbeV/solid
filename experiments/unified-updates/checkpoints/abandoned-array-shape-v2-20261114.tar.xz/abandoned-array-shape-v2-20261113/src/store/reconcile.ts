/**
 * Store — reconcile: the immutable-diff adoption channel (INTERNALS §3).
 *
 * Reconcile never merge-writes into backing objects: it adopts `incoming`
 * as the backing at every proxied level (an internal pointer swap at the
 * fold — no clones, no user-object mutation), value-notifies only where
 * nodes exist, and descends into a changed child pair only where a target
 * with nodes or the sticky descendants flag exists below (§6d: diff the
 * listened path, not every cell). Reference-equal unowned pairs skip
 * outright (an owned backing is setter-diverged and must diff).
 *
 * Keyed arrays: the aligned prefix is walked positionally; from the first
 * misalignment rows match by key (surviving rows keep their proxy
 * identity), unkeyed items fall back to position.
 */
import { isEqual } from "../core/core.js";
import {
  $OWNER,
  isOwned,
  lookupTarget,
  storeLookup,
  type StoreFamily,
  type StoreTarget
} from "./target.js";
import {
  adoptPB,
  bumpDeep,
  hasAccessorFlag,
  materializePB,
  notifyFold,
  notifyFoldTail,
  notifyKeyDiff,
  notifyKeyValue,
  sameKey,
  sameRow,
  targetsEqual,
  unwrapValue,
  userWriting
} from "./store.js";
import { optHooks } from "./hooks.js";
import { $TARGET, isRawValue, isWrappable, markRawIngest, rawValuesUsed } from "./types.js";

type KeyFn = (item: any) => any;

export function reconcileState(
  value: any,
  state: any,
  key: string | KeyFn | null | undefined,
  replace = false
): void {
  if (state == null) throw new Error(__DEV__ ? "Cannot reconcile null or undefined state" : "");
  const t: StoreTarget = state[$TARGET];
  if (t?.px !== state) throw new Error(__DEV__ ? "reconcile target is not a store proxy" : "");
  const keyFn: KeyFn | null =
    key === null ? null : typeof key === "string" ? (item: any) => item?.[key] : (key as KeyFn);
  // A user's reconcile on an optimistic family (S4): not an adoption of
  // truth but an optimistic edit — the keyed diff is written into the draft
  // (a matched row keeps its proxy, its changed leaves become its guesses),
  // and the setter's exit turns the draft into guesses like any.
  if (optHooks && userWriting() && t._fam?.opt === true) {
    optHooks.reconcile(state, unwrapValue(value), keyFn);
    return;
  }
  // Replace-mode root handed another store's proxy: chain to it (§7b).
  if (replace && value !== state && value?.[$TARGET] !== undefined) {
    const prev = t.pb ?? t.v;
    if (prev === value) return; // already chained to this store
    adoptPB(t, value);
    return;
  }
  const incoming = unwrapValue(value);
  if (keyFn) {
    const prev = t.pb ?? t.v;
    const eq = keyFn(prev);
    if (eq !== undefined && !sameKey(keyFn(incoming), eq)) {
      if (!replace)
        throw new Error(__DEV__ ? "Cannot reconcile states with different identity" : "");
      // A different entity at the root: the old backing is disowned (wraps
      // fresh if re-handed) and the new one adopted whole.
      if (isOwned(prev)) delete (prev as any)[$OWNER];
      else (t._fam?.map ?? storeLookup).delete(prev);
      adoptPB(t, incoming);
      return;
    }
  }
  applyAdopt(t, incoming, keyFn, replace);
}

/** Adopt `incoming` at `t` and notify its nodes — one leaf write per
 * changed observed key, the structural nodes once — descending into
 * changed child pairs that are proxied below. */
function applyAdopt(t: StoreTarget, incoming: any, keyFn: KeyFn | null, proj = false): void {
  // The diff base is the view the nodes were last told (#3296). A nested
  // overlay draft (`Object.create(v)`, #3044) reads a key the draft deleted
  // as present through its prototype; materialized first — `adoptPB` does
  // so anyway, after the base was taken — so a deletion the draft made is
  // a deletion here (#3743: the presence and value diffs both read `old`).
  const old = t.ovl ? materializePB(t) : (t.pb ?? t.v);
  if (incoming === old && !isOwned(old)) return;
  // Returned producer answers use adoption rather than draft notification.
  // Pair rows retained by selected guesses before the parent adopts them.
  if (optHooks && t._fam?.opt === true) optHooks.pair(t, incoming);
  // Q-D: a landing on an optimistic family is reconciled against the VIEW
  // — key matching from the arrangement the guesses made (R28), so a row
  // the guess added keeps its proxy when the server returns it.
  const prevView = optHooks && t._fam?.opt === true ? optHooks.view(t, old, true) : old;
  const nextArr = Array.isArray(incoming);
  const shallow = t.s === true;
  adoptPB(t, incoming, false);
  if (shallow) markRawIngest(incoming);
  // The deep witness is bumped once per adoption (none to bump: done).
  let bumped = t.dk === null;
  // A live chained base (a store proxy, §7b) reads the inner store's
  // current frame, not what the nodes were last told — nothing to diff
  // against: the fold writes every node (#4361).
  if (Array.isArray(prevView) !== nextArr || old[$TARGET]) {
    notifyFold(t, old, incoming);
    return;
  }
  if (nextArr) {
    const nodes = t.n;
    let nodesHit = 0;
    if (keyFn && !shallow) {
      const plen = prevView.length;
      const nlen = incoming.length;
      let i = 0;
      // Aligned prefix: same row (by reference or key) at the same index.
      for (const end = Math.min(plen, nlen); i < end; i++) {
        const nv = incoming[i];
        const pvRaw = prevView[i];
        if (pvRaw !== nv && !sameRow(pvRaw, nv, keyFn)) break; // misaligned: fall to the keyed remainder below
        if (nv !== null && typeof nv === "object" && (pvRaw !== nv || isOwned(nv)))
          descend(unwrapValue(pvRaw), nv, keyFn, proj, t, i);
        if (
          !bumped &&
          !(nv !== null && typeof nv === "object" ? targetsEqual(pvRaw, nv) : isEqual(pvRaw, nv))
        ) {
          bumpDeep(t);
          bumped = true;
        }
        if (nodes !== null) {
          const node = nodes[i];
          if (node !== undefined) {
            nodesHit++;
            notifyKeyValue(node, i as any, (old as any)[i], nv, old, incoming);
          }
        }
      }
      if (!bumped && i < incoming.length) bumpDeep(t);
      const structStart = i; // misalignment point (== nlen on aligned ticks)
      let prevByKey: Map<any, any> | null = null;
      for (; i < incoming.length; i++) {
        const nv = incoming[i];
        if (nv !== null && typeof nv === "object") {
          const nk = keyFn(nv);
          let pv: any;
          if (nk !== undefined) {
            if (prevByKey === null) {
              prevByKey = new Map();
              for (let j = structStart; j < prevView.length; j++) {
                const p = unwrapValue(prevView[j]);
                if (p !== null && typeof p === "object") {
                  const pk = keyFn(p);
                  if (pk === undefined) continue;
                  const existing = prevByKey.get(pk);
                  if (existing === undefined) prevByKey.set(pk, j);
                  else if (Array.isArray(existing)) existing.push(j);
                  else prevByKey.set(pk, [existing, j]);
                }
              }
            }
            const m = prevByKey.get(nk);
            if (m === undefined) pv = undefined;
            else if (Array.isArray(m)) {
              pv = unwrapValue(prevView[m.shift()!]);
              if (m.length === 1) prevByKey.set(nk, m[0]);
            } else {
              pv = unwrapValue(prevView[m]);
              prevByKey.delete(nk);
            }
          } else {
            pv = unwrapValue(prevView[i]); // keyless item: positional fallback
          }
          descend(pv, nv, keyFn, proj, t, i);
        }
        if (nodes !== null) {
          const node = nodes[i];
          if (node !== undefined) {
            nodesHit++;
            notifyKeyDiff(node, i as any, old, incoming, false);
          }
        }
      }
    } else {
      const dlen = Math.min(prevView.length, incoming.length);
      const nlen = incoming.length;
      for (let i = 0; i < nlen; i++) {
        const nvP = incoming[i];
        if (!shallow && i < dlen && nvP !== null && typeof nvP === "object")
          descend(unwrapValue(prevView[i]), nvP, keyFn, proj, t, i);
        if (
          !bumped &&
          !(nvP !== null && typeof nvP === "object"
            ? targetsEqual(prevView[i], nvP)
            : isEqual(prevView[i], nvP))
        ) {
          bumpDeep(t);
          bumped = true;
        }
        if (nodes !== null) {
          const node = nodes[i];
          if (node !== undefined) {
            nodesHit++;
            notifyKeyDiff(node, i as any, old, incoming, false);
          }
        }
      }
    }
    // Indices past the new length (and `length` itself) still have nodes.
    if (nodes !== null && nodesHit < t.nc) {
      for (const key of Reflect.ownKeys(nodes)) {
        const idx = typeof key === "string" ? +key : NaN;
        if (!(idx >= 0 && idx < incoming.length))
          notifyKeyDiff(nodes[key as any], key, old, incoming, false);
      }
    }
    notifyFoldTail(t, old, incoming);
    return;
  }
  const nodes = t.n;
  let nodesHit = 0;
  for (const k in incoming) {
    const nv = (incoming as any)[k];
    let ov = (old as any)[k];
    // A key under a guess is judged against the guess too (D-34): a truth
    // equal to the value the guess covered still answers it.
    if (optHooks && ov === nv && prevView !== old) ov = (prevView as any)[k];
    const isObj = nv !== null && typeof nv === "object";
    if (
      ov === nv &&
      (!isObj || !isOwned(nv)) &&
      (nodes === null || nodes[k] === undefined || !hasAccessorFlag(nodes[k]))
    ) {
      if (nodes?.[k] !== undefined) nodesHit++;
      continue;
    }
    if (isObj && !shallow) descend(unwrapValue((prevView as any)[k]), nv, keyFn, proj, t, k);
    if (!bumped && !(isObj ? targetsEqual(ov, nv) : isEqual(ov, nv))) {
      bumpDeep(t);
      bumped = true;
    }
    if (nodes !== null) {
      const node = nodes[k];
      if (node !== undefined) {
        nodesHit++;
        notifyKeyValue(node, k, ov, nv, old, incoming);
      }
    }
  }
  const syms = Object.getOwnPropertySymbols(incoming);
  for (let i = 0; i < syms.length; i++) {
    const k = syms[i];
    if (k === $OWNER) continue;
    const nv = (incoming as any)[k];
    if (!shallow && nv !== null && typeof nv === "object")
      descend(unwrapValue((old as any)[k]), nv, keyFn, proj, t, k);
    if (nodes !== null) {
      const node = nodes[k as any];
      if (node !== undefined) {
        nodesHit++;
        notifyKeyValue(node, k, (old as any)[k], nv, old, incoming);
      }
    }
  }
  // Keys the incoming object no longer has still have nodes.
  if (nodes !== null && nodesHit < t.nc) {
    for (const key of Reflect.ownKeys(nodes)) {
      // A removed `__proto__` reads absent, not the prototype (core R30,
      // #4672).
      if (!hasOwnP.call(incoming, key))
        notifyKeyDiff(
          nodes[key as any],
          key,
          old,
          key === "__proto__" ? Object.create(null) : incoming,
          false
        );
    }
  }
  notifyFoldTail(t, old, incoming);
}

const hasOwnP = Object.prototype.hasOwnProperty;

/** Descend into a changed child pair — only where something is proxied
 * below (§6d), never into a raw-marked leaf, never across array/object or a
 * key mismatch (that is a replacement, handled by the parent's slot).
 *
 * A raw in both frames (the same objects swapped, reordered or shifted,
 * #4001) must not leave two slots on one row. A raw already a live row keeps
 * it at the slot it moved to; a row's `pk` follows the slot it sits at (a
 * move or a pairing writes it), so a row whose raw is at that slot of the
 * incoming frame is spoken for and not paired again here; a raw still
 * resolving to a row that moved on drops the lookup (it wraps fresh, or is
 * paired here). One lookup of `nv` on the common path, no allocation. */
function descend(
  pv: any,
  nv: any,
  keyFn: KeyFn | null,
  proj: boolean,
  t: StoreTarget,
  k: PropertyKey
): void {
  // `nv` is an object at every call site.
  if (pv === null || typeof pv !== "object") return;
  const fam = t._fam;
  nv = unwrapValue(nv);
  let ct = lookupTarget(pv, fam);
  const nt = lookupTarget(nv, fam);
  if (ct !== undefined && ct.pk !== k) {
    if (ct.pk != k && t.v[ct.pk as any] === ct.v) ct = undefined;
    else if (ct.u === t) ct.pk = k;
  }
  if (nt !== undefined && nt !== ct) {
    if (nt.v === nv) {
      if (nt.u === t) nt.pk = k;
      return;
    }
    (fam?.map ?? storeLookup).delete(nv);
  }
  if (ct === undefined) return; // nothing proxied below this pair
  if (!isWrappable(nv)) return;
  if (rawValuesUsed && isRawValue(nv)) return;
  if (Array.isArray(pv) !== Array.isArray(nv)) return;
  // An array slot was paired by key already (or both rows are keyless).
  if (typeof k !== "number" && keyFn) {
    const pk = keyFn(pv);
    const nk = keyFn(nv);
    if (pk !== undefined && nk !== undefined && !sameKey(pk, nk)) return;
  }
  if (!proj && keyFn !== null && !ct.d) return;
  applyAdopt(ct, nv, keyFn, proj);
}
