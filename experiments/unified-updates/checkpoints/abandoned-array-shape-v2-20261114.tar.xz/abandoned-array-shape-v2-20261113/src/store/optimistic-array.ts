/** Array structure owns a publication boundary without guessing array contents. */
import { read, untrack } from "../core/core.js";
import { flushTransaction, joinFuture, schedule } from "../core/scheduler.js";
import {
  createOptimisticSlot,
  entangleOptimisticSlotRead,
} from "../layers/optimistic.js";
import { targetsEqual, sameKey, unwrapValue } from "./store.js";
import { enqueueSub, markNode } from "../core/heap.js";
import type { StoreTarget } from "./target.js";
import { isWrappable } from "./types.js";

type Slot = ReturnType<typeof createOptimisticSlot<any>>;
type ArraySlots = {
  slots: Map<PropertyKey, Slot>;
  presence: Map<PropertyKey, Slot>;
  shape: Map<PropertyKey, Slot>;
};
type ArrayState = { structure?: Slot; conflict?: boolean };
const arrays = new WeakMap<StoreTarget, ArrayState>();

function state(t: StoreTarget): ArrayState {
  let r = arrays.get(t);
  if (!r) arrays.set(t, (r = {}));
  return r;
}
function discoverStructure(slots: ArraySlots): void {
  for (const map of [slots.slots, slots.presence, slots.shape])
    for (const slot of map.values()) {
      markNode(slot.output);
      enqueueSub(slot.output);
    }
  schedule();
}
export function arrayIndex(key: PropertyKey): number {
  if (typeof key !== "string" || key === "") return -1;
  const n = Number(key);
  return Number.isInteger(n) && n >= 0 && n < 4294967295 && String(n) === key
    ? n
    : -1;
}

export function arrayGrowthStands(t: StoreTarget): boolean {
  return !!arrays.get(t)?.structure?.activeOwner();
}

/** Establish the array's selected context before consulting a lower input,
 * then track that structural output for subsequent changes. */
export function readArrayStructure(t: StoreTarget): void {
  const r = arrays.get(t);
  const slot = r?.structure;
  if (!r?.conflict || !slot?.activeOwner()) return;
  untrack(() => read(slot.output));
  read(slot.output);
}

/** Shared net array-shape test; row arrangement can add another boundary. */
export function arrayStructureChanged(
  t: StoreTarget,
  previous: Record<PropertyKey, any>,
  next: Record<PropertyKey, any>,
): boolean {
  if (previous.length !== next.length) return true;
  for (const key of new Set([
    ...Reflect.ownKeys(previous),
    ...Reflect.ownKeys(next),
  ])) {
    if (arrayIndex(key) < 0) continue;
    const before = Object.getOwnPropertyDescriptor(previous, key);
    const after = Object.getOwnPropertyDescriptor(next, key);
    if (
      !!before !== !!after ||
      before?.enumerable !== after?.enumerable ||
      before?.configurable !== after?.configurable ||
      before?.writable !== after?.writable ||
      before?.get !== after?.get ||
      before?.set !== after?.set
    )
      return true;
  }
  const keyFn = t._fam?.key;
  if (keyFn) {
    for (const key of Reflect.ownKeys(previous)) {
      if (arrayIndex(key) < 0) continue;
      const a = unwrapValue(
        Object.getOwnPropertyDescriptor(previous, key)?.value,
      );
      const b = unwrapValue(Object.getOwnPropertyDescriptor(next, key)?.value);
      const before = isWrappable(a) ? keyFn(a) : undefined;
      const after = isWrappable(b) ? keyFn(b) : undefined;
      if (
        (before !== undefined || after !== undefined) &&
        !sameKey(before, after)
      )
        return true;
    }
  }
  // A permutation rearranges existing positional identities. Replacing a
  // value with a new value leaves the multiset different and remains a leaf edit.
  const counts = new Map<any, number>();
  const negativeZero = {};
  const identity = (value: any) =>
    Object.is(value, -0) ? negativeZero : value;
  let moved = false;
  for (const key of Reflect.ownKeys(previous)) {
    if (arrayIndex(key) < 0) continue;
    const a = unwrapValue(
      Object.getOwnPropertyDescriptor(previous, key)?.value,
    );
    const b = unwrapValue(Object.getOwnPropertyDescriptor(next, key)?.value);
    moved ||= !Object.is(a, b) && !targetsEqual(a, b);
    const before = identity(a),
      after = identity(b);
    counts.set(before, (counts.get(before) ?? 0) + 1);
    counts.set(after, (counts.get(after) ?? 0) - 1);
  }
  return moved && [...counts.values()].every((count) => count === 0);
}

export function registerArrayStructure(t: StoreTarget, slot: Slot): void {
  const r = state(t);
  r.structure = slot;
}

/** An incoming structural answer joins active direct edits, and retains that
 * boundary for setters arriving before the structural answer publishes. */
export function joinArrayIncoming(
  t: StoreTarget,
  slots: ArraySlots,
  retained?: unknown,
): void {
  let r = arrays.get(t);
  const alreadySelected = !!r?.structure?.activeOwner();
  let selected = false;
  const join = (slot: Slot) => {
    const owner = slot.activeOwner();
    if (owner) {
      selected = true;
      joinFuture(owner);
    }
  };
  for (const map of [slots.slots, slots.presence, slots.shape])
    for (const slot of map.values()) join(slot);
  if (r) {
    if (r.structure) join(r.structure);
  }
  if (!selected || !flushTransaction) return;
  r ??= state(t);
  if (!r.structure) return;
  r.conflict = true;
  if (!alreadySelected) r.structure.propose(retained ?? r.structure.output._value);
  discoverStructure(slots);
}

/** Coordinate the final setter diff, after its direct slots have been created.
 * A structural marker carries ownership only, never an array-value snapshot. */
export function coordinateArrayWrites(
  t: StoreTarget,
  previous: Record<PropertyKey, any>,
  next: Record<PropertyKey, any>,
  slots: ArraySlots,
  rearranged = false,
  nextShape?: unknown,
): void {
  if (!Array.isArray(next)) return;
  const keys = new Set([
    ...Reflect.ownKeys(previous),
    ...Reflect.ownKeys(next),
  ]);
  const structural = rearranged || arrayStructureChanged(t, previous, next);
  let changed = structural;
  for (const key of keys) {
    if (key === "length") continue;
    const before = Object.getOwnPropertyDescriptor(previous, key);
    const after = Object.getOwnPropertyDescriptor(next, key);
    const presence = !!before !== !!after;
    const a = unwrapValue(before?.value),
      b = unwrapValue(after?.value);
    const value = !Object.is(a, b) && !targetsEqual(a, b);
    const metadata =
      before?.enumerable !== after?.enumerable ||
      before?.configurable !== after?.configurable ||
      before?.writable !== after?.writable ||
      before?.get !== after?.get ||
      before?.set !== after?.set;
    if (presence || value || metadata) changed = true;
  }
  if (!changed) return;
  let r = arrays.get(t);
  if (r?.structure) entangleOptimisticSlotRead(r.structure);
  if (structural) {
    r ??= state(t);
    for (const map of [slots.slots, slots.presence, slots.shape])
      for (const slot of map.values()) entangleOptimisticSlotRead(slot);
    if (r.structure) r.structure.propose(nextShape);
  }
  if (structural) discoverStructure(slots);
}

/** Structural token/input disposal belongs to the static slot adapter. */
export function sweepArrays(): void {}
