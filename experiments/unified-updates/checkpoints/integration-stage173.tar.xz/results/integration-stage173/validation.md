# Stage 173 reproduction

Baseline: unmodified next `4fe75321d61f9e4f1e1c63edc2087d099a36e9e1`.
Starting experiment commit: see `base-commit.txt`.

Commands below run in `packages/signals`, except the web suite.

```sh
node node_modules/typescript/bin/tsc -p tsconfig.build.json
node node_modules/rollup/dist/bin/rollup -c
node scripts/mangle-props.mjs dist/prod dist/observe
node scripts/check-pure.mjs dist/prod
node scripts/check-pure.mjs dist/observe
node node_modules/vitest/vitest.mjs run --maxWorkers=2 --reporter=json --outputFile=../../experiments/unified-updates/results/integration-stage173/signals-retained.json
```

For the selected production check, temporarily copy this directory's
`vite.config.trace-dist.ts` to `packages/signals/`, then run:

```sh
TRACE_DIST=/workspace/layered-solid/packages/signals/dist/prod/index.js node node_modules/vitest/vitest.mjs run --config vite.config.trace-dist.ts --maxWorkers=2 --reporter=json --outputFile=../../experiments/unified-updates/results/integration-stage173/production-retained.json tests/latest-shadow-owned-write.test.ts tests/latest-unread-identity-memo-4474.test.ts tests/unified-context-retry-error.test.ts tests/unified-owned-migration.test.ts tests/unified-owner-context-retry.test.ts tests/unified-publication-adversarial.test.ts
```

Remove that temporary config afterwards. The selected tests use only public
APIs; do not mix the internal source adapter with the built runtime.

In `packages/web`, with the signals dev build ready:

```sh
SOLID_COMPILER_NATIVE=/workspace/scratch/pending-repro-rc21/node_modules/@solidjs/compiler-linux-x64-gnu/compiler.linux-x64-gnu.node node ../signals/node_modules/vitest/vitest.mjs run --maxWorkers=2 --reporter=json --outputFile=../../experiments/unified-updates/results/integration-stage173/web-retained.json
```

`measure-size.mjs` records the size scenarios and pinned checkout paths.
The full suites intentionally return failure status; compare test identities
with stage 172 rather than treating their exit codes as acceptance.
