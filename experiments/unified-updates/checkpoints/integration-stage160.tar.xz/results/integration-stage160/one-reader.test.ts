import { writeFileSync } from "node:fs";
import { it, expect } from "vitest";
import { createLoadingBoundary, createMemo, createRenderEffect, createRoot, createSignal, flush, latest } from "../src/index.js";
const turn = async () => { for (let i=0;i<8;i++) await Promise.resolve(); flush(); };
it("one latest reader discovers its own async hold", async () => {
 expect.assertions(2);
 const frames: unknown[]=[];
 const asks: {value:number; resolve:(value:number)=>void}[]=[];
 const shown:number[]=[];
 const app=createRoot(dispose=>{
   const [id,setId]=createSignal(1);
   const data=createMemo(()=>{
     const value=10*latest(id)+id();
     return new Promise<number>(resolve=>asks.push({value,resolve}));
   });
   createLoadingBoundary(() => { createRenderEffect(data,value=>{shown.push(value)}); return null; }, () => null);
   return {dispose,setId};
 });
 try {
   flush(); asks[0].resolve(asks[0].value); await turn(); await turn();
   expect(shown).toEqual([11]);
   asks.length=0; shown.length=0;
   app.setId(2); flush(); await turn();
   frames.push({step:"write", asks:asks.map(a=>a.value),shown:[...shown]});
   for(const ask of asks.filter(a=>a.value===21)) ask.resolve(ask.value);
   await turn(); await turn();
   frames.push({step:"21", asks:asks.map(a=>a.value),shown:[...shown]});
   for(const ask of asks.filter(a=>a.value===22)) ask.resolve(ask.value);
   await turn(); await turn();
   frames.push({step:"22", asks:asks.map(a=>a.value),shown:[...shown]});
   writeFileSync(process.env.TRACE_REPORT!,JSON.stringify(frames,null,2));
   expect(shown.at(-1)).toBe(22);
 } finally {app.dispose(); flush();}
});
