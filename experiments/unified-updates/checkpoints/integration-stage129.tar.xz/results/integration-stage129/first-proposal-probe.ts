import { expect, it } from "vitest";
import {
  action,
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  latest
} from "../src/index.js";

const turn = () => new Promise<void>(resolve => setTimeout(resolve, 0));

it.each([false, true])(
  "latest exposes and replaces a held first proposal (async consequence: %s)",
  async asyncConsequence => {
    const end = Promise.withResolvers<void>();
    const detailAnswer = Promise.withResolvers<number>();
    const details: number[] = [];
    const [source, setSource] = createSignal(0);
    const values: number[] = [];
    let first!: () => number;
    let stop = () => {};
    const running = action(function* () {
      setSource(1);
      yield end.promise;
    })();
    flush();
    try {
      stop = createRoot(dispose => {
        first = createMemo(source);
        const detail = createMemo(() => {
          const value = latest(first);
          return asyncConsequence && value === 2 ? detailAnswer.promise : value;
        });
        createRenderEffect(
          () => latest(first),
          value => void values.push(value)
        );
        createRenderEffect(detail, value => void details.push(value));
        return dispose;
      });
      flush();
      expect(values).toEqual([1]);
      expect(source()).toBe(0);
      setSource(2);
      flush();
      expect(values).toEqual(asyncConsequence ? [1] : [1, 2]);
      expect(details).toEqual(values);
      expect(source()).toBe(0);
      detailAnswer.resolve(2);
      await turn();
      expect(values).toEqual([1, 2]);
      expect(details).toEqual(values);
      end.resolve();
      await running;
      await turn();
      expect(first()).toBe(2);
      expect(values).toEqual([1, 2]);
    } finally {
      end.resolve();
      await running;
      stop();
    }
  }
);
