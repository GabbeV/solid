import { expect, it } from "vitest";
import { createMemo, createRenderEffect, createRoot, createSignal, createLoadingBoundary, createErrorBoundary, isPending, latest, flush } from "../src/index.js";
const turn = async () => { await new Promise(resolve => setTimeout(resolve,0)); flush(); };
it("a source error supersedes unresolved latest derivations", async () => {
 const flights:{value:number,resolve:(value:number)=>void}[]=[];
 const frames:string[]=[];
 const app=createRoot(dispose=>{
  const [id,setId]=createSignal(0);
  const source=createMemo(()=> { const value=1+id(); if(value===2)throw new Error("source:2"); return value; });
  const ask=(value:number)=>new Promise<number>(resolve=>flights.push({value,resolve}));
  const first=createMemo(()=>ask(1+latest(source)+latest(id)));
  const second=createMemo(()=>ask(1+latest(first)));
  const boundary=createErrorBoundary(()=>createLoadingBoundary(()=>{
   createRenderEffect(()=>isPending(source),()=>{});
   createRenderEffect(()=>isPending(second),()=>{});
   return second;
  },()=>"loading"),()=>"error");
  createRenderEffect(()=> {const v=boundary();return String(typeof v==='function'?v():v);},v=>{frames.push(v);});
  return {dispose,setId};
 });
 try {
  flush(); await Promise.resolve(); app.setId(1); await turn();
  let i=0;
  while(i<flights.length){if(i>20)throw Error("endless flights");const f=flights[i++];f.resolve(f.value);await turn();}
  await turn();
  expect(frames.at(-1),JSON.stringify({frames,requests:flights.map(f=>f.value)})).toBe("error");
 } finally {app.dispose();flush();}
});
