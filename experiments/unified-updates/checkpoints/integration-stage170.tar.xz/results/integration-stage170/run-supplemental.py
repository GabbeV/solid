import os,subprocess,json,statistics,hashlib
from pathlib import Path
here=Path(__file__).resolve().parent
repo=here.parents[3]
workers=repo/'experiments/unified-updates'
roots={'next':Path('/workspace/layered-next-4fe75321'),'experiment':repo}
for name,root in roots.items():
 entry=root/'packages/signals/dist/prod/index.js'
 (here/f'{name}-adapter.mjs').write_text(f'export * from {json.dumps(str(entry))};\nexport {{ createOptimistic as optimistic }} from {json.dumps(str(entry))};\n')
runs=[]
scenarios=[('sync-bench.mjs',x) for x in ['signal-read','memo-read','write-flush','memo-write','chain','diamond','fanout-effects','memo-create-dispose']]
scenarios += [('inactive-sync-bench.mjs',x) for x in ['signal-read','memo-write']]
scenarios += [('node-cost-bench.mjs',None),('active-contexts-bench.mjs',None),('memory.mjs',None)]
for worker,scenario in scenarios:
 for sample in range(5 if scenario is None else 7):
  for name in (['next','experiment'] if sample%2==0 else ['experiment','next']):
   args=['taskset','-c','4','node','--expose-gc',str(workers/worker),str(here/f'{name}-adapter.mjs')]
   if scenario:args.append(scenario)
   p=subprocess.run(args,text=True,capture_output=True)
   if p.returncode:
    (here/'supplemental-error.log').write_text(p.stdout+'\n'+p.stderr);raise SystemExit(p.returncode)
   result=json.loads(p.stdout)
   runs.append({'worker':worker,'scenario':scenario,'sample':sample,'name':name,'result':result})
   (here/'supplemental-raw.json').write_text(json.dumps(runs,indent=2))
 print(worker,scenario,'done',flush=True)
