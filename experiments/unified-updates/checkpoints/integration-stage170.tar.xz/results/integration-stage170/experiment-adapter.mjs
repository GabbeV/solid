export * from "/workspace/layered-solid/packages/signals/dist/prod/index.js";
export { createOptimistic as optimistic } from "/workspace/layered-solid/packages/signals/dist/prod/index.js";
