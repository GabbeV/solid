import {test,expect} from 'vitest';
import {action,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush,isPending,deep} from 'subject';
import {appendFileSync} from 'node:fs';
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
const tick=async()=>{for(let i=0;i<4;i++){await new Promise(r=>setTimeout(r,0));flush();}};
test('ambient versus action, with parent producer bypass ablation',async()=>{
 for(const disable of [false,true])for(const mode of ['ambient','action']){
  (globalThis as any).disableBypass=disable;console.log('CASE',disable,mode);
  let gate=deferred(),hold=deferred(),state,write,setId,dispose;const frames=[],values=[];
  createRoot(d=>{dispose=d;const [id,set]=createSignal(0);setId=set;
   [state,write]=createOptimisticStore(async()=>{const n=id();await gate.promise;return {object:{guessed:10+n,unguessed:20+n},scalar:30+n};},{object:{guessed:0,unguessed:0},scalar:0},{seedLoadingValue:true});
   createRenderEffect(()=>({ref:isPending(()=>state.object)}),x=>{frames.push(x)});
   createRenderEffect(()=>isPending(()=>deep(state.object)),()=>{});
   createRenderEffect(()=>state.object.guessed,x=>{values.push(x)});
  });flush();await tick();gate.resolve();await tick();gate=deferred();setId(1);flush();await tick();
  (globalThis as any).causeTrace=[];const guess=()=>write(s=>{s.object.guessed=99}); const done=mode==='ambient'?guess():action(function*(){guess();yield hold.promise;})();flush();await tick();
  const result={disable,mode,selected:frames.at(-1),values,frames,trace:(globalThis as any).causeTrace};console.log('RESULT',JSON.stringify(result));appendFileSync(process.env.RECEIPT!,JSON.stringify(result)+'\n');
  expect(values.at(-1)).toBe(99);
  expect(result.selected.ref).toBe(!disable&&mode==='ambient'?false:true);
  gate.resolve();await tick();hold.resolve();if(done)await done;await tick();dispose();flush();
 }
});