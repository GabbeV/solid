# Exact pending cause, 2026-11-12

Only scratch runtime copies changed. Source: experiment 502b337f2 (runtime same as 8c35af093). Next reference: /workspace/scratch/store-review-next-20261112 dfb18120a.

## Result

Experiment's ambient leaf-write clears parent-reference pending because its parent property input deliberately stops reading the producer, not because proxy identity itself proves availability. The bypass also runs for an open action. The open-action case conceals the resulting false boolean through ordinary context/frame selection.

Experiment exact path:

1. store.ts:1932 delegates the selected key's firewall to its slot (`ownsFirewall`, optimistic-static.ts:559-568).
2. A leaf selection invalidates ancestor inputs (`invalidateAncestors`, optimistic-static.ts:198-207).
3. Parent object input re-runs and hits optimistic-static.ts:162: `if (child && readDescendantOutputs(child)) return read(node)`. `readDescendantOutputs` at 361-373 only checks for descendant `activeOwner()`: it does not read the descendant output despite its name. Thus this branch skips `pullFamilyInput(t,key)` at 163 and drops the actual pending producer dependency.
4. Trace: parent input begins status1, producer remains status1, backing property node still has one pending source; after bypass, selected parent input/output statuses are0. This happens in BOTH ambient and action cases. Pending observation has committed true, staged false in both.
5. Ambient publishes false. During action, observation reads eventually execute coordination.ts:524-530 with ownPosition1, heldPosition0, and return committed (`true`), retaining a stale-reader obligation. Core readHeld/frameRead then serves committed via core.ts:2522/2555. This explains why the open-action control stays true without implying that the producer bypass did not occur. context-trace.jsonl contains the decisive position/value records.

Next exact path: store.ts:2165 always calls pullFamily(target) before selecting a leaf. pullFamily 1893-1912 refuses the optimistic stands bypass inside a verdict window, explicitly says isPending remains true while the flight is up, and reads the derive at 1937. Next therefore observes the still-pending producer for the object property itself.

## Decisive ablation

`decisive.test.ts` runs ambient/action with the single descendant bypass enabled/disabled in a scratch copy. It asserts parent false only for original ambient, true for the other three, AND published guessed value99 for all four. Thus restoring producer status is compatible with displaying the optimistic leaf in this reduced program. This is causal evidence, not a validated general runtime fix.

Run:

```sh
cd /workspace/scratch/pending-cause-20261112
SUBJECT=$PWD/runtime CASE=decisive.test.ts RECEIPT=$PWD/repeat.jsonl node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config vite.config.mjs
```

final.log: 1 test passed (four scenarios). final.jsonl includes publication frames, published values and instrumented traces. Earlier ablation/value/context receipts preserve increasing instrumentation. runtime/packages/signals is an isolated copy, tooling uses node_modules symlink. global disableBypass controls only branch162; all other additions only record state.

`parent-only.test.ts` puts the parent-reference pending query alone in its own render effect, with separate leaf-value and deep-pending effects. Same four outcomes: original ambient false, original open action true, ablated ambient/action true; leaf99 published in all four. parent-only-verified.log/jsonl pass. Thus the ambient/action distinction is not caused merely by combining the five probes in one effect. parent-only.log preserves a failed exploratory expectation that the action result would change; verified rerun uses the actual expected outcomes.

## Intent and limits

This was an intentional experiment implementation choice introduced by ec3ae1c98 (`Integrate parent-object selection and derived store input status`), not an established upstream contract. STORE-OVERNIGHT-DECISIONS.md, section Parent objects and derived input status, explicitly says a selected descendant keeps ancestor reference available and isPending(store.object) may be false while an unguessed child is pending; it calls this a 'choice for review, not a whole-object loading guarantee'. The constructor/action-dependent publication is not separately justified there.

Current shared local specification A9/A22/A23/A24 supports next's producer-wide new-question pending: the producer's change set is unknown; optimistic writes are verdict-inert and do not silence a new question. A22's settled proxy-level example applies to a known plain-store write set, not an unresolved derived authority. Therefore do not describe this experiment difference as an approved identity semantic. It is an explicit experimental divergence requiring review against the existing spec.

GitHub read-only connector retrieval: solidjs/solid#2844, github-2844.json. The maintainer comment 4911390393 described an older store-wide optimistic pending mask. Current SPEC marks that model superseded on 2026-07-13 by A24. It neither justifies this narrow reference-only behavior nor proves current maintainer intent. No exact contemporary GitHub ruling on this ambient/action distinction was found. No posting occurred.
