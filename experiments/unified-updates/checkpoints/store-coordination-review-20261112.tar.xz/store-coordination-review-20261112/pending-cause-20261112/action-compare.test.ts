import { appendFileSync } from 'node:fs';
import { test, expect } from 'vitest';
import { action, createOptimisticStore, createRenderEffect, createRoot, createSignal, deep, flush, isPending, latest } from 'subject';
const tick = async () => { for (let i = 0; i < 4; i++) { await new Promise(r => setTimeout(r, 0)); flush(); } };
const safe = (f:any) => { try { return f(); } catch { return 'NotReady'; } };
const deferred = () => { let resolve!: (x:any)=>void; const promise = new Promise<any>(r=>resolve=r); return {promise,resolve}; };
test('reference versus descendant and deep published pending', async () => {
 for (const phase of ['initial','updating']) for (const guess of ['none','leaf','whole','scalar']) {
  let gate = deferred(), hold = deferred(); const frames:any[] = [], values:any[]=[];
  let state:any, write:any, run:any, setId:any, dispose:any;
  createRoot(d => {
   dispose=d; const [id,set]=createSignal(0); setId=set;
   [state,write]=createOptimisticStore(async () => { const n=id(); await gate.promise; return {object:{guessed:10+n,unguessed:20+n},scalar:30+n}; },{object:{guessed:0,unguessed:0},scalar:0}, {seedLoadingValue:true});
   createRenderEffect(() => ({ref:isPending(()=>state.object),guessed:isPending(()=>state.object.guessed),unguessed:isPending(()=>state.object.unguessed),deep:isPending(()=>deep(state.object)),scalar:isPending(()=>state.scalar)}), x=>{frames.push(x)});
   createRenderEffect(()=>state.object.guessed,x=>{values.push(x)});
   run=action(function*(){write((s:any)=>{ if(guess==='leaf')s.object.guessed=99; if(guess==='whole')s.object={guessed:99,unguessed:88}; if(guess==='scalar')s.scalar=99; }); yield hold.promise; });
  });
  flush(); await tick();
  if(phase==='updating') {gate.resolve(null); await tick(); gate=deferred(); setId(1);flush();await tick();}
  const before=frames.at(-1), done=guess==='none'?undefined:run(); flush(); await tick();
  const selected=frames.at(-1); const direct={ref:isPending(()=>state.object),guessed:isPending(()=>state.object.guessed),unguessed:isPending(()=>state.object.unguessed),deep:isPending(()=>deep(state.object)),scalar:isPending(()=>state.scalar)};
  appendFileSync(process.env.RECEIPT!,JSON.stringify({phase,guess,before,selected,direct,publishedGuessed:values.at(-1),latestGuessed:safe(()=>latest(()=>state.object.guessed)),frames})+'\n');
  expect(selected).toEqual(direct);
  gate.resolve(null);await tick();hold.resolve(null);if(done)await done;await tick();dispose();flush();
 }
});
