# Latest upstream rerun: edeb5db09

Exact source revision: edeb5db09f86d1fd558567069cbba6f489a13cbe.
Detached worktree: /workspace/scratch/structural-entangle-next-edeb5db09.
Prior dfb worktree and receipts remain intact. Main runtime files unchanged.

Command: `python /workspace/scratch/structural-entangle-20261112/run-latest.py`
Result: exit 0; 36 prior recording probes and 36 latest recording probes; **zero changed JSON timeline objects**. Exact records: latest-edeb5db09.jsonl, latest-edeb5db09-diff.json, latest-edeb5db09.log. These are behavioral recording probes, not 36 desired-semantics assertions.

Thus all material findings survive the actual latest source: input-empty hole in experiment; next same-shape slot rederive joins; descendant rowfield rederive independence; no-reader/late-reader difference; chained outer keeping old rows while source input publishes; two direct index overrides producing a hole when structural support owner expires in experiment.

## #4814 distinction

Commit 38b6f850d705a078871712e6c7fc061930295d4b changes only whether another guess's keys are recorded as borrowed: borrowing remains allowed only when the current setter changes no key presence and leaves length unchanged. It introduces a separate `shape` boolean in notifyOptimisticWrites. This is narrower than the existing `structural` flag, which is also set for replacing an existing array slot. Source latest optimistic.ts 351-354, 359-361, 381-385, 417-420.

If a setter fills a hole or adds/removes an index, it changes shape even with unchanged length. Such guesses write the list slot and already entangle under the list-slot rule; #4814 stops borrowed-key fallthrough from subsequently splitting the survivor's length from its frame. Existing-index literal writes that preserve keys and length may still borrow, and their lender's primitive index can expire independently under #4793. This change does not coordinate arbitrary incoming truth with an active guess, nor detect holes from a later incoming shrink.

Additional authoritative regression executed against latest:
`node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config /workspace/scratch/structural-entangle-20261112/latest-upstream4793.config.mts`
CWD latest worktree packages/signals. Result: 1 file, 1 test passed (upstream optimistic-array-structural-guesses-4793.test.ts). Its exact case is seed[], B writes index1=2, A fills index0=1, B ends; list remains len2/[1,2] until both end. This is an assertion test, unlike our recording matrix. Output saved in latest-upstream4793.log.

## Recommendation impact

No reversal. Preserve #4814's distinction between actual key/length shape edits and ordinary existing-slot edits when defining guess-overlap ownership. Incoming-rederivation coordination is a separate policy. The conservative first trial (all rederivations with live direct array-slot/arrangement guesses join) remains simpler than support-minimal detection but deliberately delays same-shape input values. Do not claim #4814 already supplies that incoming rule. Do not broaden to nested row fields/store-family properties without an explicit decision.
