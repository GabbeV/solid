import {appendFileSync} from 'node:fs';
import {it} from 'vitest';
import {action,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush,refresh} from 'test-signals';
const turn=async()=>{await new Promise(r=>setTimeout(r,0));flush()};
const snap=(x:any):any=>Array.isArray(x)?Array.from(x,v=>v===undefined?'HOLE':snap(v)):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).map(k=>[k,snap(x[k])])):x;
const scenarios:any[]=[
 ['row-field-value',[{id:'a',value:1},{id:'b',value:2}],(d:any)=>{d[1].value=9},[{id:'a',value:3},{id:'b',value:2}]],
 ['row-slot-value',[{id:'a',value:1},{id:'b',value:2}],(d:any)=>{d[1]={id:'m',value:9}},[{id:'a',value:3},{id:'b',value:2}]],
 ['push-shrink',['A'],(d:any)=>d.push('M'),[]],
 ['index0-shrink',['A','B'],(d:any)=>{d[0]='M'},[]],
 ['index-shrink',['A','B'],(d:any)=>{d[1]='M'},[]],
 ['index-value',['A','B'],(d:any)=>{d[1]='M'},['X','B']],
 ['index-extend',['A','B'],(d:any)=>{d[1]='M'},['A','B','C']],
 ['object-delete',{x:1,y:2},(d:any)=>{d.x=9},{y:3}],
 ['object-value',{x:1,y:2},(d:any)=>{d.x=9},{x:1,y:3}],
 ['object-extra',{x:1,y:2},(d:any)=>{d.x=9},{x:1,y:2,z:3}],
 ['nested-delete',{child:{x:1,y:2},other:0},(d:any)=>{d.child.x=9},{other:1}],
 ['nested-replace',{child:{x:1,y:2},other:0},(d:any)=>{d.child.x=9},{child:{x:2,y:3},other:1}],
 ['nested-array-shrink',{child:['A','B'],other:0},(d:any)=>{d.child[1]='M'},{child:[],other:1}]
];
for(const [name,initial,edit,incoming] of scenarios)for(const order of ['guess-first','input-first'])it(name+' '+order,async()=>{
 const [input,setInput]=createSignal(initial);const [a,setA]=createSignal(false),[b,setB]=createSignal(false);
 const ga=Promise.withResolvers<void>(),gb=Promise.withResolvers<void>();const shown:any[]=[];const raw:any[]=[];const saved:any[]=[];const phases:any[]=[];
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimisticStore(()=>input(),initial);createRenderEffect(()=>snap(rows),v=>{shown.push(v)});createRenderEffect(()=>snap(input()),v=>{raw.push(v)});createRenderEffect(()=>[a(),b()],v=>{saved.push(v)});return [rows,guess,dispose] as const});
 let pa:any,pb:any;const sample=(at:string)=>phases.push({at,input:raw.at(-1),rows:shown.at(-1),saved:saved.at(-1)});
 try{flush();sample('initial');pa=action(function*(){guess(edit);setA(true);yield ga.promise})();flush();sample('guess');pb=action(function*(){setInput(incoming);setB(true);yield gb.promise})();flush();sample('input');if(order==='guess-first'){ga.resolve();await pa;await turn();sample('guess settled');gb.resolve();await pb}else{gb.resolve();await pb;await turn();sample('input settled');ga.resolve();await pa}await turn();sample('both settled');appendFileSync(process.env.RECEIPT!,JSON.stringify({name,order,phases})+'\n')}
 finally{ga.resolve();gb.resolve();await Promise.allSettled([pa,pb]);dispose();flush()}
});
for(const mode of ['full','index','none','late'])it('observation '+mode,async()=>{
 const [input,setInput]=createSignal(['A']);const gate=Promise.withResolvers<void>();const shown:any[]=[];const raw:any[]=[];const phases:any[]=[];
 let lateDispose:(()=>void)|undefined;
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimisticStore(()=>input(),['A']);if(mode==='full')createRenderEffect(()=>snap(rows),v=>{shown.push(v)});if(mode==='index')createRenderEffect(()=>rows[1],v=>{shown.push(v)});createRenderEffect(()=>snap(input()),v=>{raw.push(v)});return [rows,guess,dispose] as const});
 let p:any;const sample=(at:string)=>phases.push({at,input:raw.at(-1),output:shown.at(-1),direct:snap(rows)});
 try{flush();sample('initial');p=action(function*(){guess(d=>{d.push('M')});yield gate.promise})();flush();sample('guess');setInput([]);flush();sample('input');if(mode==='late'){createRoot(dispose=>{lateDispose=dispose;createRenderEffect(()=>snap(rows),v=>{shown.push(v)})});flush();sample('late reader')}gate.resolve();await p;await turn();sample('settled');appendFileSync(process.env.RECEIPT!,JSON.stringify({name:'observation',mode,phases})+'\n')}
 finally{gate.resolve();await Promise.allSettled([p]);if(typeof lateDispose!=='undefined')lateDispose();dispose();flush()}
});
for(const chained of [false,true])for(const incoming of [[],[{id:'a',value:2}]])it('keyed '+chained+' '+incoming.length,async()=>{
 const initial=[{id:'a',value:1}];const [input,setInput]=createSignal(initial);const gate=Promise.withResolvers<void>();const shown:any[]=[];const raw:any[]=[];const phases:any[]=[];
 const [rows,guess,dispose]=createRoot(dispose=>{const [inner]=createOptimisticStore(()=>input(),initial,{key:'id'});const [rows,guess]=chained?createOptimisticStore(()=>inner,initial,{key:'id'}):createOptimisticStore(()=>input(),initial,{key:'id'});createRenderEffect(()=>snap(rows),v=>{shown.push(v)});createRenderEffect(()=>snap(input()),v=>{raw.push(v)});return [rows,guess,dispose] as const});
 let p:any;const sample=(at:string)=>phases.push({at,input:raw.at(-1),rows:shown.at(-1)});
 try{flush();sample('initial');p=action(function*(){guess(d=>{d.push({id:'m',value:9})});yield gate.promise})();flush();sample('guess');setInput(incoming);flush();sample('input');gate.resolve();await p;await turn();sample('settled');appendFileSync(process.env.RECEIPT!,JSON.stringify({name:'keyed',chained,incoming,phases})+'\n')}
 finally{gate.resolve();await Promise.allSettled([p]);dispose();flush()}
});
it('topology support withdrawal',async()=>{
 const [input,setInput]=createSignal(['A','B']);const ga=Promise.withResolvers<void>(),gb=Promise.withResolvers<void>();const shown:any[]=[];const raw:any[]=[];const phases:any[]=[];
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimisticStore(()=>input(),['A','B']);createRenderEffect(()=>snap(rows),v=>{shown.push(v)});createRenderEffect(()=>snap(input()),v=>{raw.push(v)});return [rows,guess,dispose] as const});
 let pa:any,pb:any;const sample=(at:string)=>phases.push({at,input:raw.at(-1),rows:shown.at(-1)});
 try{flush();sample('initial');pa=action(function*(){guess(d=>{d[1]='M'});yield ga.promise})();flush();sample('guess index1');pb=action(function*(){guess(d=>{d[0]='N'});yield gb.promise})();flush();sample('guess index0');setInput([]);flush();sample('input');gb.resolve();await pb;await turn();sample('support guess settled');ga.resolve();await pa;await turn();sample('both settled');appendFileSync(process.env.RECEIPT!,JSON.stringify({name:'topology support withdrawal',phases})+'\n')}
 finally{ga.resolve();gb.resolve();await Promise.allSettled([pa,pb]);dispose();flush()}
});
it('refresh equal array',async()=>{
 const [input]=createSignal(['A']);const gate=Promise.withResolvers<void>();const shown:any[]=[];const phases:any[]=[];let calls=0;
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimisticStore(()=>{calls++;return input()},['A']);createRenderEffect(()=>snap(rows),v=>{shown.push(v)});return [rows,guess,dispose] as const});
 let p:any;const sample=(at:string)=>phases.push({at,calls,rows:shown.at(-1)});
 try{flush();sample('initial');p=action(function*(){guess(d=>{d.push('M')});yield gate.promise})();flush();sample('guess');refresh(rows);flush();await turn();sample('refresh');gate.resolve();await p;await turn();sample('settled');appendFileSync(process.env.RECEIPT!,JSON.stringify({name:'refresh equal array',phases})+'\n')}
 finally{gate.resolve();await Promise.allSettled([p]);dispose();flush()}
});
