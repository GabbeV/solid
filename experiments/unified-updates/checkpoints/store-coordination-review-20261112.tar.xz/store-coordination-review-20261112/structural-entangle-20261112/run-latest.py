import json,subprocess,pathlib,os
base=pathlib.Path(__file__).parent
repo='/workspace/scratch/structural-entangle-next-edeb5db09';label='latest-edeb5db09'
config=base/(label+'.config.mts');config.write_text('export default '+json.dumps({'define':{'__DEV__':'true','__OBSERVE__':'true','__TEST__':'true'},'resolve':{'alias':{'test-signals':repo+'/packages/signals/src/index.ts'}},'test':{'globals':True,'include':[str(base/'probe.test.ts')],'pool':'threads'}}))
receipt=base/(label+'.jsonl');receipt.write_text('')
with (base/(label+'.log')).open('w') as f:r=subprocess.run(['node','/workspace/layered-solid/node_modules/vitest/vitest.mjs','run','--config',str(config)],cwd=repo+'/packages/signals',env={**os.environ,'RECEIPT':str(receipt)},stdout=f,stderr=subprocess.STDOUT)
print(label,r.returncode)
a=[json.loads(l) for l in (base/'next.jsonl').read_text().splitlines()];b=[json.loads(l) for l in receipt.read_text().splitlines()]
# Vitest emits tests in definition order within this single file.
diffs=[{'before':x,'after':y} for x,y in zip(a,b) if x!=y]
(base/(label+'-diff.json')).write_text(json.dumps({'before_count':len(a),'after_count':len(b),'diffs':diffs},indent=2)+'\n');print(json.dumps({'before_count':len(a),'after_count':len(b),'changed_count':len(diffs)}))
for d in diffs:print(json.dumps(d))
