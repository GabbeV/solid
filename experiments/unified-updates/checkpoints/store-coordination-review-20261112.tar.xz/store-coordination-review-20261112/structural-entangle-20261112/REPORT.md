# Structural entanglement investigation

No runtime files edited. Next worktree dfb18120a; experiment current working source.
Run: `python /workspace/scratch/structural-entangle-20261112/run.py`
Result: next exit 0, experiment exit 0; 31 cases each. These are behavioral receipt probes, not assertions of desired semantics. JSONL records exact published effect callback frames (not speculative render bodies). `saved` is a separate ordinary signal per action; it establishes action-level joins. Both gate release orders tested in the 11-case matrix.

## Observed

- Direct array push M over [A], independent incoming []: next full/index subscribers hold input[A], rows[A,M]. Experiment publishes input[] and rows[hole,M].
- Next joins even when structure is unchanged: [A,B], guess index1=M, incoming [X,B]. Both actions' saved flags stay false after either action settles and become true only after both settle. Experiment permits input action first -> input[X,B], rows[X,M], saved[false,true].
- Array extension is likewise joined by next. Thus reproducing next wholesale is broader than structural-conflict-only coordination.
- Next object x=9 with incoming y-only change is independent. Input action first publishes new y and keeps guessed x. Root x deletion also independent and keeps guessed x; adding z stays independent but next enumeration can omit z while x guess exists. Nested child deletion can remove the whole guessed subtree; neither is general ancestor-preservation entanglement.
- Nested array shrink does join next, and creates a hole in experiment.
- Index0-only guess followed by input[] is dense [M] on experiment and independent; next joins. This distinguishes 'any incoming shape change' from 'composition needs structural support'.
- No output subscriber: next permits input[] and direct rows becomes [A], dropping unseen M; a late subscriber sees [A]. Full reader OR only rows[1] causes the hold. Untracked samples do not count as subscriptions. Experiment yields the hole under every mode.
- Explicit key:'id' direct array push behaves like primitive push: next holds input; experiment hole. Chained inner derived optimistic store + outer derived optimistic store behaves differently: outer pushM then input[] publishes input[] while outer keeps [A,M] on BOTH versions. A same-key A value change flows through and updates A under M on BOTH versions. Therefore next's direct-store hold is not a cross-boundary guarantee.
- Topology support withdrawal: initial [A,B], guess action A index1=M, independent guess B index0=N, input[]. Experiment first publishes []/[N,M], then B ends -> []/[hole,M], then A ends -> []/[]. Next joins and keeps input[A,B]/rows[N,M] through B's end, settling both together. Checking incoming topology once is insufficient.

## Source path in next

`packages/signals/src/store/optimistic.ts`:
- 340-347 treats any changed array slot as structural; 368+ creates arrangement g.
- ask 882-895 records family new-question stamp and requests a future hold, with refresh/same-action exceptions.
- stands 916-931 controls serving guesses through rederivation.
- park 936-942 merges each observed live guess's parent transaction into the parked update.
- laneNodeOf 1011-1017 requires an active subscriber generation when called with read=true.
`store/projection.ts:165` invokes ask when waking pending family readers.
`store/store.ts:490-495` park materializes staging then calls opt park.
This is reader/rederivation coordination, not a detector comparing old and incoming array length/key sets.

## Recommendation boundaries (proposal, not implemented)

Do not describe next's actual policy as the desired narrow rule. Preserve scalar input/output separation. For stores, choose an explicit intrinsic structural-dependency rule, applied before publication and independent of mounted readers. A conservative smallest implementation candidate: coordinate an incoming change of array topology with all still-live guesses on that array; leave same-topology primitive/value-only updates and ordinary object-key changes granular. Index-only guesses must be included because incoming changes can introduce the conflict later. This deliberately joins even safe index0+empty cases; a later optimization can prove narrower safety.

A more minimal semantic rule joins only when withdrawing truth/another guess would remove structural support needed to keep a surviving overlay coherent. Dense prefix support matters: index1 needs index0 to exist, index0 does not need old index1. This requires dependency registration between overlapping/disjoint owners whose structure supports each other, not merely comparing a landing once. Support withdrawal probe establishes the need. It is significantly more complex than a shape-change rule.

Nested object replacement requires an explicit choice: deleting an unguessed ancestor may discard a descendant guess (current observed behavior) or entangle because the descendant depends on that ancestor's existence. Do not infer the choice from array density or silently make any object x guess vouch for y/z. Same-key row content changes should remain leaf-level if accepted structural policy is about membership/order, rather than arbitrary row object identity. Chained boundaries need incoming structural provenance before an upstream commit; outer landing-only checks cannot retroactively hold already-published input. Async answers create the same hazard: if changing request input commits before answer topology is known, later answer-based conflict detection cannot promise that input remained held. Either reserve/coordinate at rederivation start for potentially structural output, or scope the guarantee to the landing transaction and acknowledge that earlier request input can already publish.

No candidate rule is claimed implemented or validated beyond observed current behavior.

## Final scope/cost comparison

Latest run: 36 recording cases per version, exit 0 each. Late observer root disposal fixed. Added observable distinction: `d[1].value=9` plus incoming other row-field change is independent on next and experiment; `d[1]={id:'m',value:9}` plus incoming other row-field change joins on next, stays independent in experiment. Explicit synchronous `refresh(rows)` with equal input reruns derive (calls 1->2), retains [A,M] on both, settles [A]; this does not by itself establish a refresh action join, only no loss of shown guess. Existing next ask explicitly exempts REACTIVE_REASK.

(a) Coordinate every rederivation of an array carrying direct slot/arrangement guesses: simpler than inspecting incoming topology, and the reasonable conservative first trial if delaying value-only array inputs is acceptable. Keep descendant row-field guesses granular: they do not put an arrangement edit on the parent array. Join the incoming update with ALL live direct array guess owners, not just whichever carrier a mounted reader happened to touch. This also avoids support-withdrawal holes after an input[] landing: incoming cannot publish until all active support owners finish. Do not extend automatically to every target in the store family: an unrelated child object guess should not delay another sibling's value update just because they share a derive.

(b) Structural-only coordination preserves independent value changes, but must compare length, index presence, membership/order under keyed reconciliation, and retain provenance for support across overlapping guesses and withdrawal. A simple 'length differs' check misses sparse key changes and equal-length reorder/replacement; a simple 'keys differ' check misses keyed membership changes. Comparing only raw row object reference wrongly makes routine new server objects structural even when keyed identity is stable. A support-minimal policy is substantially more machinery than (a).

Potential implementation experiment hook: keep ask/park transaction plumbing, but make array coordination intrinsic: mark affected live direct-array targets at rederivation invalidation and merge their owning transactions via laneNodeOf(target,false), not subscriber-filtered laneNodeOf(target,true). Preserve overlap joins and explicit refresh distinction. A blanket removal of the read filter is not a complete implementation: it joins object guesses too, only runs when ask/wake runs, and may miss lazy/unobserved derives or chained inner publication. Add eager structural guards/source-side dependencies while array edits exist if publication must be prevented even with zero output subscribers. A late-mount observer cannot retroactively unpublish input. First load with no prior committed shape/transaction is a separate seed-write policy and cannot be repaired by merging a nonexistent prior update. No implementation-size claim is made until these lifecycle paths have a working trial.

Recommendation: propose (a) as an explicit conservative array rule first, explain that it delays even same-shape array slot input changes, preserve nested row-field independence, and do not promise nested/chained support without provenance/eager invalidation work. Broader whole-family rederivation join is superficially simpler but semantically excessive and reverses the established separation for unrelated store properties. If the user requires same-shape array input independence too, use (b) and budget for ownership/support bookkeeping rather than presenting it as a small shape check.
