import json,subprocess,pathlib,os
base=pathlib.Path(__file__).parent
for label,repo in [('next','/workspace/scratch/store-review-next-20261112'),('experiment','/workspace/layered-solid')]:
 config=base/(label+'.config.mts');config.write_text('export default '+json.dumps({'define':{'__DEV__':'true','__OBSERVE__':'true','__TEST__':'true'},'resolve':{'alias':{'test-signals':repo+'/packages/signals/src/index.ts'}},'test':{'globals':True,'include':[str(base/'probe.test.ts')],'pool':'threads'}}))
 receipt=base/(label+'.jsonl');receipt.write_text('')
 with (base/(label+'.log')).open('w') as f:r=subprocess.run(['node','/workspace/layered-solid/node_modules/vitest/vitest.mjs','run','--config',str(config)],cwd=repo+'/packages/signals',env={**os.environ,'RECEIPT':str(receipt)},stdout=f,stderr=subprocess.STDOUT)
 print(label,r.returncode)
