import json,subprocess,pathlib,os
base=pathlib.Path(__file__).parent
repo='/workspace/scratch/structural-entangle-next-edeb5db09'
source=(base/'probe.test.ts').read_text(); source=source[:source.index("for(const waitFor")].replace("['baseline','join-render','join-input']","['baseline']")
probe=base/'latest-baseline.test.ts';probe.write_text(source)
for dev in [True,False]:
 name='next-edeb5db09'+('-dev' if dev else '-prod');src=repo+'/packages/signals/src/'
 config=base/(name+'.config.mts');config.write_text('export default '+json.dumps({'define':{'__DEV__':str(dev).lower(),'__OBSERVE__':'true','__TEST__':'true'},'resolve':{'alias':{'test-signals':src+'index.ts','test-types':src+'store/types.ts','test-scheduler':src+'core/scheduler.ts'}},'test':{'include':[str(probe)],'pool':'threads'}}))
 receipt=base/(name+'.jsonl');receipt.write_text('')
 with (base/(name+'.log')).open('w') as f:r=subprocess.run(['node','/workspace/layered-solid/node_modules/vitest/vitest.mjs','run','--config',str(config)],cwd=repo+'/packages/signals',env={**os.environ,'RECEIPT':str(receipt)},stdout=f,stderr=subprocess.STDOUT)
 rows=[json.loads(l) for l in receipt.read_text().splitlines()];(base/(name+'.json')).write_text(json.dumps(rows,indent=2));print(name,r.returncode,len(rows))
 for row in rows: print(row['seedLoadingValue'],row['order'],[(p['at'],p['shown'],p['calls'],bool(p.get('rejected'))) for p in row['phases']])
