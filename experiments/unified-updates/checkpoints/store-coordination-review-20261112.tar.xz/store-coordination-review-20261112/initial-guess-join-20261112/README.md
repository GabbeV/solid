# Initial guess / joined input probe — 2026-11-12

Experiment source HEAD: 502b337f2a2a1aa129a582076027a0010f8a4293.
Current next source HEAD: dfb18120a407f7b505bfd7cde25c745d8d965932.
No package source edits. This is an internal-API harness intervention, not an implemented public policy.

Run `python /workspace/scratch/initial-guess-join-20261112/run.py`.
Four source-alias runs, 14 cases each, all exit 0. These are receipt-producing probes; publication callbacks and phase snapshots are saved in each *.json; *.jsonl is the original record. Flags explicitly differ by __DEV__, keeping __OBSERVE__ and __TEST__ true. Next dev's before-first-load rejection is recorded, not bypassed.

The 12-case matrix crosses implicit loading / explicit seedLoadingValue, answer-first / action-first, and baseline / join-render / join-input. Every successful setter callback runs once; there is no callback replay. Action results return 23. `shown` records actual createRenderEffect publication callbacks, not imperative proxy snapshots.

## Exact interventions

At initial loading, the derive node has no transaction; the pending first render does. Consequently blindly calling txOf(derive) cannot identify the initial update. `join-render` merges the pending first render's transaction into the guessing action via joinFuture(txOf(initialRender)). That alone is insufficient: the guess can still show when the answer arrives, through optimistic output publication.

`join-input` additionally holds the actual derive node on that same pending update before joining it:

    holdNode(derive, txOf(initialRender));
    joinFuture(txOf(initialRender));
    guess(draft => { draft.push("M"); });

This joins and holds the actual input producer. It does not copy an array, claim unguessed properties, replay setters, or merely hide a render callback. It is deliberately performed before the setter. Capturing an arbitrary render node is harness scaffolding, not a recommendation for the runtime's discovery mechanism.

## Results

Default initial loading, successful calls (experiment dev/prod and next prod):

| Ordering/mode | Before answer | After answer while action open | After both settle |
|---|---|---|---|
| Baseline, answer-first, experiment | loading | [M,B] | [A,B] |
| Baseline, answer-first, next prod | loading | [M] | [A,B] |
| Join-render, answer-first, experiment | loading | values [M], length 1, keys [0,1] | [A,B] |
| Join-render, answer-first, next prod | loading | [M] | [A,B] |
| Join-input, answer-first, both | loading | loading | [A,B] |
| Any mode, action-first, both | loading through action end | [A,B] after answer | [A,B] |

In join-input, `shown` contains exactly one frame, [A,B], in both orders. Therefore the proposed joined-input lifetime can make the guess never displayed. It is not already guaranteed merely because the setter ran while initial loading. Next dev rejects every default-load guess before its callback with OPTIMISTIC_WRITE_BEFORE_LOAD, including the intervention; deciding to replace that guard remains a separate policy choice.

With seedLoadingValue:true, [] is an already published commit #0 and the push immediately publishes [M] on both engines. The initial render has no pending transaction, so the intervention deliberately does nothing. Experiment later publishes [M,B] while open; next keeps [M]. Action-first reverts [M] to [] before the eventual answer. The never-displayed initial rationale does not apply to this mode.

## Retirement and waits

The input answer is staged while the action stays open; ending the action first leaves the input pending. Once both are ready, ordinary guess retirement/correction removes the override and the first successful content frame publishes [A,B]. The probe does not add its own suppression or retirement algorithm. Relevant current code: experiment layers/optimistic.ts:180-201 checks ordinary readiness and retires each scope's layers; next core/guesses.ts:247-279 and core/lanes.ts:564-616 dissolve/correct the guess, preserving only shown frames and dropping never-shown queued runs.

Two additional cases use the same joined-input intervention. An action yielding the raw answer.promise completes and returns the raw [A,B] result, then [A,B] publishes. An action yielding a gate resolved only by the [A,B] render publication remains open after the raw answer: shown=loading and returned=false. An explicit escape gate ends the action and publication proceeds. This is the circular wait to avoid: commit waits for action return, action waits for its commit. Next dev only records the existing rejection in these cases.

Recommendation for review: the user's narrow initial unpublished structural case has a concrete feasible coordination approach, with first publication after the joined input/action lifetime. It needs deliberate runtime integration that identifies/holds the actual input update; simply merging output work is insufficient. Keep explicit seed commit #0 distinct, retain one-shot setter execution and raw action results, and do not generalize this result into an unapproved whole-array snapshot or automatic rebase rule.

## Latest next and #4810 follow-up

Latest upstream review HEAD is edeb5db09f86d1fd558567069cbba6f489a13cbe, including #4814 (38b6f850d) and #4810. `run-latest.py` reruns only the original baseline matrix against `/workspace/scratch/structural-entangle-next-edeb5db09`; all eight dev/prod cases exit 0 and preserve the dfb18120a timelines. See `next-edeb5db09-{dev,prod}.json` and logs. No fresh join trial was needed to establish that the changed upstream baseline still admits the same initial problem in production.

#4810's final change in `store/store.ts` catches NotReadyError while cloning a loading chained child's backing in `ensurePB`, warns in dev, and returns a throwaway `{}`. It does not install that throwaway as `target.pb`: the child keeps following its original inner store and the first answer. Other writes from the same setter still land. This is narrower than skipping a whole setter or discarding every optimistic edit written before first answer. The original optimistic root-store guard is unchanged, as the latest dev probe confirms. Commit history records that copying the seed had incorrectly detached the child and permanently supplied unguessed seed keys; dropping avoids that problem.

Discarding an unpublished initial optimistic write is a distinct, simpler candidate than joining when the desired policy is that the first real answer should appear immediately, even if the unrelated action remains open. Execute the setter once against its draft, discard its initial unpublished proposals rather than create their optimistic lifetime, preserve unrelated writes and the action's return, and let input publish normally. Alternatively, dropping those proposals atomically at first answer needs an explicit initial-answer supersession rule. Either approach avoids waiting for the rest of the action, and needs no callback replay or seed-backed vouching for unguessed keys. This does not follow automatically from #4810 and was not implemented in this investigation.

The review choice is therefore concrete: **discard** gives first input answer publication without waiting for the open action; **join input** waits for both the input and the action, then publishes the answer. Both can avoid displaying M in the implicit-initial case, but with different timing. A blanket statement that the guess was already guaranteed never visible is false under the current engines, and explicit seedLoadingValue remains outside this rationale because its guessed [M] is already visible. No new semantics were selected here.
