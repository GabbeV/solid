import { appendFileSync } from 'node:fs';
import { it } from 'vitest';
import { action,createOptimisticStore,createRenderEffect,createRoot,flush,getOwner } from 'test-signals';
import { $TARGET } from 'test-types';
import {joinFuture,txOf,resolveTx} from 'test-scheduler';
const turn=async()=>{await new Promise(r=>setTimeout(r,0));flush()};
const view=(v:string[])=>({values:Array.from(v,x=>x??'<hole>'),length:v.length,keys:Object.keys(v)});
for(const seedLoadingValue of [false,true])for(const order of ['answer-first','action-first'])for(const join of [false,true])it(`${seedLoadingValue} ${order} ${join}`,async()=>{
 const answer=Promise.withResolvers<string[]>(),end=Promise.withResolvers<void>();const shown:any[]=[],phases:any[]=[];let renderNode:any;let calls=0,rejected:any,result:any,returned=false;
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimisticStore(()=>answer.promise,[],{seedLoadingValue});createRenderEffect(()=>{renderNode=getOwner();return view(rows)},v=>{shown.push(v)});return[rows,guess,dispose]as const});
 const node=(rows as any)[$TARGET]._fam.node;
 const info=()=>({flags:node._statusFlags,held:!!node._x?._transaction,renderHeld:!!renderNode._x?._transaction,renderOpen:renderNode._x?._transaction?resolveTx(txOf(renderNode))._open:undefined,open:node._x?._transaction?resolveTx(txOf(node))._open:undefined});
 const sample=(at:string)=>phases.push({at,shown:shown.at(-1)??'loading',calls,rejected,returned,result,node:info()});
 let running:any;
 try{flush();sample('initial');running=action(function*(){if(join && renderNode._x?._transaction)joinFuture(txOf(renderNode));const v=guess(d=>{calls++;d.push('M')});result=v;yield end.promise;return 23})();running.then(()=>returned=true,e=>{rejected=e.message;returned=true});await turn();sample('guess');
 if(order==='answer-first'){answer.resolve(['A','B']);await turn();sample('answer');end.resolve();await Promise.allSettled([running]);await turn();sample('action ended')}else{end.resolve();await Promise.allSettled([running]);await turn();sample('action ended');answer.resolve(['A','B']);await turn();sample('answer')}
 appendFileSync(process.env.RECEIPT!,JSON.stringify({seedLoadingValue,order,join,phases,shown})+'\n');
 }finally{answer.resolve(['A','B']);end.resolve();await Promise.allSettled([running]);dispose();flush()}
});
