import { expect, it } from "vitest";
import {
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  createStore,
  flush,
  latest
} from "../src/index.js";

const settle = () => new Promise<void>(resolve => setTimeout(resolve, 0));

it.each([false, true])(
  "a first store proposal moves its values and structure together, then holds a replacement (async derive=%s)",
  async asyncDerive => {
    const first = Promise.withResolvers<number>();
    const lower = Promise.withResolvers<void>();
    const upper = Promise.withResolvers<number>();
    const states: string[] = [];
    const labels: number[] = [];
    const late: string[] = [];
    const app = createRoot(dispose => {
      const [id, setId] = createSignal(0);
      const record = createMemo(() => id() || first.promise);
      const slow = createMemo(() => {
        record();
        return lower.promise;
      });
      createRenderEffect(slow, () => {});
      const [store] = createStore<{ count: number; rows: number[]; ready?: boolean }>(
        draft => {
          const value = latest(record);
          draft.count = value;
          draft.rows = Array.from({ length: value }, (_, index) => index + 1);
          draft.ready = true;
          if (asyncDerive) return Promise.resolve();
        },
        { count: -1, rows: [] }
      );
      const label = createMemo(() => (store.count === 2 ? upper.promise : store.count));
      const read = () =>
        `${store.count}:${store.rows.length}:${store.rows.join(",")}:${"ready" in store}:${Object.keys(store).sort().join(",")}`;
      createRenderEffect(read, value => void states.push(value));
      createRenderEffect(label, value => void labels.push(value));
      return { dispose, setId, read };
    });
    const frame = (value: number) =>
      `${value}:${value}:${Array.from({ length: value }, (_, i) => i + 1).join(",")}:true:count,ready,rows`;
    let disposeLate = () => {};
    try {
      flush();
      expect(states).toEqual([]);
      first.resolve(1);
      await settle();
      expect(states).toEqual([frame(1)]);
      expect(labels).toEqual([1]);
      app.setId(2);
      flush();
      await settle();
      expect(states).toEqual([frame(1)]);
      expect(labels).toEqual([1]);
      disposeLate = createRoot(dispose => {
        createRenderEffect(app.read, value => void late.push(value));
        return dispose;
      });
      flush();
      expect(late.every(value => value === frame(1))).toBe(true);
      upper.resolve(2);
      await settle();
      expect(states).toEqual([frame(1), frame(2)]);
      expect(labels).toEqual([1, 2]);
      expect(late.at(-1)).toBe(frame(2));
      lower.resolve();
      await settle();
      expect(states).toEqual([frame(1), frame(2)]);
      expect(labels).toEqual([1, 2]);
    } finally {
      disposeLate();
      app.dispose();
    }
  }
);
