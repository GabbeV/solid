import {appendFileSync} from 'node:fs';
import {it} from 'vitest';
import {action,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush,deep} from '/workspace/scratch/next-array-audit-4de85c2b/packages/signals/src/index.ts';
const tick=async()=>{for(let i=0;i<4;i++){await new Promise(r=>setTimeout(r,0));flush()}};
const snap=(s:any)=>({length:s.length,keys:Object.keys(s),values:Array.from({length:s.length},(_,i)=>i in s?JSON.parse(JSON.stringify(s[i])):'HOLE')});
const cases:any[]=[
['same-index',[0,0],(d:any)=>{d[0]=1},(d:any)=>{d[0]=2}],
['distinct-existing',[0,0],(d:any)=>{d[0]=1},(d:any)=>{d[1]=2}],
['grow-separate',[],(d:any)=>{d[1]=1},(d:any)=>{d[3]=2}],
['fill-hole',[],(d:any)=>{d[1]=1},(d:any)=>{d[0]=2}],
['push',[],(d:any)=>{d.push(1)},(d:any)=>{d.push(2)}],
['truncate',[0,0,0],(d:any)=>{d.length=2},(d:any)=>{d.length=1}],
['delete-separate',[0,0,0],(d:any)=>{delete d[0]},(d:any)=>{delete d[1]}],
['delete-v-existing',[0,0,0],(d:any)=>{delete d[0]},(d:any)=>{d[1]=2}],
['existing-v-delete',[0,0,0],(d:any)=>{d[1]=1},(d:any)=>{delete d[0]}],
['read-other',[0,0],(d:any)=>{d[0]=1},(d:any)=>{d[1]=d[0]+1}],
['read-length-after-push',[0,0],(d:any)=>{d.push(1)},(d:any)=>{d[0]=d.length}],
['row-fields',[{x:0,y:0}],(d:any)=>{d[0].x=1},(d:any)=>{d[0].y=2}],
['row-slot-v-field',[{x:0,y:0}],(d:any)=>{d[0]={x:1,y:0}},(d:any)=>{d[0].y=2}],
['row-slot-read-changed',[{x:0,y:0}],(d:any)=>{d[0]={x:1,y:0}},(d:any)=>{d[0].y=d[0].x+1}],
['row-slot-read-unchanged',[{x:0,y:0}],(d:any)=>{d[0]={x:1,y:0}},(d:any)=>{d[0].y=d[0].y+2}],
];
for(const [name,initial,A,B] of cases)for(const first of ['A','B'])for(const reader of ['ordinary','deep'])it(`${name} ${first} ${reader}`,async()=>{
 const ga=Promise.withResolvers<void>(),gb=Promise.withResolvers<void>();let pa:any,pb:any;
 const phases:any[]=[];let renderedFlags:any;let renderedRows:any;
 const [s,set,a,b,sa,sb,dispose]=createRoot(dispose=>{const [s,set]=createOptimisticStore<any>(structuredClone(initial));const [a,sa]=createSignal(false),[b,sb]=createSignal(false);createRenderEffect(()=>reader==='deep'?(deep(s),snap(s)):snap(s),v=>{renderedRows=v});createRenderEffect(()=>[a(),b()],v=>{renderedFlags=v});return[s,set,a,b,sa,sb,dispose] as const});
 const sample=(at:string)=>phases.push({at,rows:snap(s),flags:[a(),b()],renderedFlags,renderedRows});
 try{flush();sample('initial');pa=action(function*(){set(A);sa(true);yield ga.promise})();await tick();pb=action(function*(){set(B);sb(true);yield gb.promise})();await tick();sample('both active');(first==='A'?ga:gb).resolve();await tick();sample(`${first} ended`);(first==='A'?gb:ga).resolve();await Promise.allSettled([pa,pb]);await tick();sample('both ended');appendFileSync('/workspace/scratch/next-array-rules-20261113/results.jsonl',JSON.stringify({name,first,reader,phases})+'\n')}finally{ga.resolve();gb.resolve();await Promise.allSettled([pa,pb]);dispose();flush()}
});
