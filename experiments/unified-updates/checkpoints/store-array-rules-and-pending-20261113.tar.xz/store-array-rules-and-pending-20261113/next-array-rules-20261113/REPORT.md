# Actual upstream next array setter audit, 2026-11-13

Pinned upstream `solidjs/solid` next: `4de85c2b86053b933c3a8268ac5e114e2f85f84e` (fetched explicitly from upstream; origin here is GabbeV fork).
Isolated source: `/workspace/scratch/next-array-audit-4de85c2b`. No runtime edits.

`probe.test.ts`, `config.mts`, `results.jsonl`, `run.log`: 15 two-action cases × both finish orders × ordinary full-array reader or tracked deep+ordinary reader = 60 recording probes. Each action also writes its own ordinary saved flag before yielding. A full join means neither saved flag publishes when only one action ends. Merely retaining both guessed values is not evidence of a full join. These are behavioral receipts, not desired-semantics assertions. Final run exit 0, 60 completed; direct flags equal separately rendered flags throughout. Source/test source pointers below use this isolated tree.

## Rules observed with ordinary tracked array reader

| A then B | Full action join? | First action to finish |
|---|---|---|
| Both replace same existing primitive index | Yes | Latest guess and both flags held |
| Replace distinct existing primitive indices | No | Its own guess expires and its flag publishes |
| Both grow array at different new indices, changing length | Yes | Both guesses and flags held (length overlap) |
| Both push | Yes | Both guesses and flags held (length overlap/read) |
| Both explicitly truncate length | Yes | Both guesses and flags held (length overlap) |
| A grows `[]` with index1; B fills hole index0, unchanged length | **No** | A first: B retains `[B,A]` although A's saved flag publishes. B first: direct array becomes hole/index1=A |
| Delete distinct existing indices, unchanged length | **No** | A first: B retains both holes although A's saved flag publishes. B first: direct array retains only A's hole |
| Delete index0 then replace index1 | No | A first: direct values `[0,B,0]` but keys omit `0` (presence/value disagreement); B first: A's hole remains |
| Replace index1 then delete index0 | No | A first: B retains A's guessed index1 after A's saved flag publishes; B first: direct array retains only A's value |
| B computes distinct index from A's guessed primitive | Yes | Read-derived guess joins A |
| B computes existing index from length changed by A's push | Yes | Explicit primitive length read joins |
| Two fields of same existing row (`x`, `y`) | No | Independent fields expire independently |
| A replaces row slot; B writes literal descendant `y` | **No** | If A ends first, B's still-live descendant guess disappears with replaced row; its saved flag has not published |
| A replaces row slot; B computes `y` from changed descendant `x` | Yes | Latest #4820 tracks dependency through replacement |
| A replaces row slot; B computes `y` from unchanged descendant `y` | No | Unchanged primitive read does not join; B's edit disappears if A ends first |

## deep observer materially changes coordination

A preexisting tracked `deep(s)` reader causes full action joins for distinct existing indices, hole fill, distinct deletes, delete/existing-slot mixes, and two distinct fields in the same existing row. It did not join row-slot replacement with a literal descendant edit, or unchanged-descendant-read case. This is observed behavior; whether this is the desired coordination boundary is a separate semantic decision. In source each write guesses common deep witness `t.dk` if allocated (`optimistic.ts:474`). No blanket claim about all descendants or unrelated branches follows.

## Additional read/display discrepancies requiring review

After B ends first, ordinary reader's latest rendered snapshot differs from direct reads at the same flushed phase:

* hole fill: rendered `[]`; direct length2, hole0/index1=A;
* delete distinct: rendered original dense array; direct hole0;
* existing-v-delete: rendered original dense array; direct A's index1 value.

All three are saved in `results.jsonl` via both `rows` and `renderedRows`; ordinary rendered saved flags match direct flags. These are read/display discrepancies, not established on-screen tearing: outside imperative reads may have an authorized boundary. A second ordinary binding would be needed to establish simultaneous displayed disagreement. Disappearance of the descendant edit on row removal likewise needs review of the intended removal rule; the receipts establish behavior, not a semantic ruling.

## Source conclusions and limits

`optimistic.ts:227-240` chooses carriers by actual changed/deleted key overlap, including `length` when changed. `:350-390` builds those key sets. All changed array slots mark `structural`, but only added/deleted keys set `shape`. `:414` suppresses borrowed keys for key/length shape edits. `:428` records arrangement for all structural array writes. Thus #4814's “structural guesses entangle” comment is stronger than these full-action receipts: hole fills and distinct deletions have no shared changed key, and snapshot retention alone is not a full join. Upstream regression `tests/optimistic-array-structural-guesses-4793.test.ts:26-61` tests A-first retained list and final expiration only; no ordinary sibling flags and no opposite settlement order.

`optimistic.ts:855-884` is latest #4820: reads of changed primitives through placed children, added/deleted-key presence, and changed key enumeration record foreign guess dependencies; unchanged fields/key sets do not. Same-tick unflushed guesses are handled separately (`guessCarrier:239`); these probes deliberately flush between action starts. No assertion of read-derived coordination without a subsequent guessed write follows.

Ordinary full-array iteration is not deep. Tracked deep changes the tested boundary. This matrix uses a plain nonderived optimistic store, no incoming rederivation and no chained outer store. Prior incoming/reader/chained receipts under `/workspace/scratch/structural-entangle-20261112` were pinned to edeb5db09; do not silently relabel them latest or generalize this setter-only matrix to chained/incoming behavior.

## Guard cases: one structural edit does not join every live index guess

`guards.test.ts`, `guards.jsonl`, `guards.log`: six additional ordinary-reader probes, both finish orders, rendered saved flags checked.

| Seed `[A,B]`, first guess A, then guess B | Full join? |
|---|---|
| A writes index0=M; B truncates length=1 (keeps index0) | No |
| A writes index1=M; B truncates length=1 (deletes index1) | Yes, common written/deleted index1 |
| A writes index0=M; B grows index2=N | No |

In both nonjoining cases, if A ends first B's frame retains M while A's saved flag publishes. If B ends first the latest ordinary rendered row snapshot is the original `[A,B]`, whereas direct reads still expose A's M; this remains a read/display discrepancy, not a proved simultaneous display tear. Both saved-flag observers publish independently. “Truncation joins” must therefore be scoped to overlapping index deletion or shared length writes, not any structural operation meeting any live index guess.
