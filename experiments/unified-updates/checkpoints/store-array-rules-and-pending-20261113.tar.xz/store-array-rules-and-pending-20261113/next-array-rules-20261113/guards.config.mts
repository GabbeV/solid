export default {define:{__DEV__:'true',__OBSERVE__:'true',__TEST__:'true'},test:{globals:true,include:['/workspace/scratch/next-array-rules-20261113/guards.test.ts'],pool:'threads'}}
