# Initial unpublished writes: discard and entangle — scoped plan

Source reviewed: `/workspace/layered-solid`, HEAD `2db2dfd13` (realcore). No package source edits by this investigation. Other agents' working tree edits remain untouched.

## Ruled semantics

The user's definitive ruling is: **“set before initial load cases should discard but entangle to be consistent.”** Discarding the unpublished proposal must not erase the write's coordination with its producer. While the writing action remains open, an arriving first input answer must not become visible through that input, including a reader mounting after the answer arrives. No proposal value needs to survive, become an optimistic override, or populate previously unknown keys. Existing observation rules continue to govern whether an unfinished, unobserved input holds other work after the action body finishes.

`seedLoadingValue: true` is distinct: the seed is commit #0 by declaration (`store/types.ts:73`); initial writes can already be displayed. It must retain ordinary optimistic behavior, not enter this initial-discard path.

## Feasible minimal coordination seam

A cold internal operation, tentatively `entangleInitialStoreWrite(producer)`, should perform the **ownership part** of a write without supplying a value:

1. If the actual producer is already held, join its live transaction before transferring/listing it. This preserves any earlier writer/producer ownership.
2. Use the current setter/action flush transaction; if absent, `joinFuture(null)` supplies an ordinary update. Resolve merged pointers.
3. `holdNode(producer, currentUpdate)`. Do not call `setSignal(producer, seed)` or propose an optimistic slot value. Do not alter the producer's pending/uninitialized status.

This is the same coordination intent as `core/core.ts:2893` (a write joins the old hold before its equality gate), extended to a discarded write whose producer is not yet held. `scheduler.ts:545` supplies/join updates; `scheduler.ts:769-799` holds/lists nodes and marks pending updates. The producer's existing landing machinery then stages its real first answer under that ownership: `store/store.ts:2049` (`holdWithDerive`) and `store/projection.ts:304-346`.

**Initial mount discovery need not find an arbitrary render transaction.** The producer has no `_transaction` on initial load, while the initial render can have one. A new bounded realcore probe instead holds the producer directly in the current action transaction, without joining the render. Existing answer propagation joins the render when necessary. This avoids a subscriber walk and does not depend on a specific render being mounted at write time.

An internal ordinary truth-slot “set without value” API is a reasonable implementation shape for this helper. Existing `slot.propose(value)` is not that API: it queues a visible selection and action guess (`layers/optimistic.ts:649`, `:749`); `setSignal(node, node._value)` is also not suitable for an uninitialized node, because the uninitialized gate treats it as a real staged value (`core/core.ts:2904`). `bindScope`/`pendingScope` should not be added merely to keep an unobserved initial flight alive; that would broaden existing observedness semantics.

## Two entry paths, one coordination operation

**Ordinary outer store setter writing through a chained loading child (#4810).** The trigger is the clone inside `ensurePB` (`store/store.ts:749-780`), which reads a live chained backing. Upstream #4810 catches `NotReadyError` at that clone and returns a throwaway `{}` without installing `target.pb` (`/workspace/scratch/structural-entangle-next-edeb5db09/packages/signals/src/store/store.ts:727-737`). Its discard alone loses write ownership. At that trigger, identify the actual unresolved inner family's producer (follow the chained target, rather than taking the outer family's node), invoke the coordination operation, and discard only this child's proposed mutation. Do not detach the child from its inner store. Preserve sibling writes and the setter's ordinary return/throw behavior.

The catch must distinguish synchronous `ContextRetry` (a subclass of `NotReadyError`) from genuine initial pending. Retrying calculations are not unpublished write proposals. It must also distinguish initial uninitialized input from later pending/refetch; the ruling does not discard later writes. `NotReadyError.source` identifies a pending source but is not always the family producer whose continuation writes the store; resolve the target's actual producer deliberately.

**Initially loading optimistic root store.** Realcore dispatches to `createStaticOptimisticStore` (`store/optimistic.ts:903`, `store/optimistic-static.ts:815-830`). Its draft composes/clones the seed (`optimistic-static.ts:620-626`) and its `writes` path creates value/presence/shape/array proposals (`:657` onward). It does not necessarily throw while cloning, so an `ensurePB` catch alone cannot cover it. Detect the uninitialized family in the optimistic draft/notification adapter, keep the callback's transient draft execution, coordinate the producer, and drop those initial proposals before `proposeOptimisticSlots`. Restore any preexisting staged backing and clear temporary array/draft bookkeeping. The legacy dev guard (`optimistic.ts:915`) rejects before invoking the callback, but realcore bypasses that guard; do not accidentally reintroduce divergent dev/prod behavior.

Shared store setter notification is `store/store.ts:1207`, with the outermost target list at `:2698-2740`. A narrow discard marker/result can route that one target around publication while still allowing the outermost setter to notify its other targets. Do not turn a failure to clone one child into skipping the whole callback or setter.

## Bounded probes and receipts

`probe.test.ts` is an internal-API harness intervention, not a package implementation or assertion suite. It invokes a transient `[]` mutation manually for the unseeded discarded branch to isolate coordination; it does not prove real draft interception. It tests real producer landing/publication on realcore. Run the adjacent dev/prod configs with Vitest and `RECEIPT=<jsonl path>`.

`expanded-prod.jsonl` / `expanded-dev.jsonl` and logs contain 11 cases each, exit 0:

- Initial render, implicit initial seed: producer held directly in action versus joining the initial render as a control; both answer-first and action-first. Exactly one published frame `[A,B]`, no `[M]`; answer-first stays loading until action end.
- Explicit commit #0 control: ordinary setter publishes `[M]`, then ordinary corrections. No discard intervention in this branch.
- An unrelated visible sibling and action-first: with no consumer of the initial input, sibling may publish when the action ends even while input remains loading. With an ordinary pending render consumer, sibling waits through the answer. These observations follow existing runtime rules; they are not a request for unconditional input lifetime retention.
- **No initial consumer, answer first, late mount while action open:** the first answer stays held; the late render remains loading; only action completion publishes `[A,B]`. This directly covers missing `_transaction` on initial mount and the later-observer case without render-transaction discovery.

Earlier `prod.jsonl` / `dev.jsonl` are the initial eight-case matrix before sibling/late-mount expansion. `sibling.log` records a discarded harness revision whose render callback accidentally returned `Array.push`'s number as cleanup; that harness bug is corrected in the expanded runs, whose logs are clean.

## Implementation order / necessary checks

1. Add the single non-value coordination helper and test initial render plus late mount on actual setters.
2. Route ordinary chained-child discard through it; cover two loading children in one setter and sibling successful writes. Repeated calls join/resolve existing transactions, not overwrite their ownership. Multiple affected children are not a semantic blocker.
3. Route the realcore optimistic root's initial proposal drop through the same helper, including array push/replacement and nested writes. Ensure no initial value/presence/shape/length proposals escape and all transient state restores.
4. Check dev/prod, both answer/action orders, action failure, first-answer rejection/disposal, direct setter without action, and explicit commit #0 control. For direct setter, create/join ordinary work even if no action exists; do not invent an open action or require an unobserved producer to block indefinitely.

The remaining implementation question is **where each real setter can identify an initial unpublished target while preserving its callback execution and transient draft state**, not whether coordination itself is possible. In particular, a chained array operation that must read unresolved `length` before any mutation may throw before `ensurePB`; the catch-only #4810 path does not prove support for such reads. Do not fabricate data to make arbitrary callbacks executable, replay the callback, snapshot a whole array as authority, or broaden this ruling to later pending writes. Treat any uncovered read-before-write case as an explicit scope/test finding when implementing.
