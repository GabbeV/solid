import { appendFileSync } from 'node:fs';
import { it } from 'vitest';
import { action,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush,getOwner } from 'test-signals';
import { $TARGET } from 'test-types';
import {joinFuture,txOf,resolveTx,holdNode,flushTransaction} from 'test-scheduler';
const turn=async()=>{await new Promise(r=>setTimeout(r,0));flush()};
const view=(v:string[])=>({values:Array.from(v,x=>x??'<hole>'),length:v.length,keys:Object.keys(v)});
for(const seedLoadingValue of [false,true])for(const order of ['answer-first','action-first'])for(const mode of ['discard-current','discard-render'])it(`${seedLoadingValue} ${order} ${mode}`,async()=>{
 const answer=Promise.withResolvers<string[]>(),end=Promise.withResolvers<void>();const shown:any[]=[],phases:any[]=[];let renderNode:any;let calls=0,rejected:any,result:any,returned=false;
 const [rows,guess,dispose]=createRoot(dispose=>{const [rows,guess]=createOptimisticStore(()=>answer.promise,[],{seedLoadingValue});createRenderEffect(()=>{renderNode=getOwner();return view(rows)},v=>{shown.push(v)});return[rows,guess,dispose]as const});
 const node=(rows as any)[$TARGET]._fam.node;
 const info=()=>({flags:node._statusFlags,held:!!node._x?._transaction,renderHeld:!!renderNode._x?._transaction,renderOpen:renderNode._x?._transaction?resolveTx(txOf(renderNode))._open:undefined,open:node._x?._transaction?resolveTx(txOf(node))._open:undefined});
 const sample=(at:string)=>phases.push({at,shown:shown.at(-1)??'loading',calls,rejected,returned,result,node:info()});
 let running:any;
 try{flush();sample('initial');running=action(function*(){let v;if(!seedLoadingValue){if(mode==='discard-render' && renderNode._x?._transaction)joinFuture(txOf(renderNode));holdNode(node,resolveTx(flushTransaction!));const d:string[]=[];calls++;d.push('M')}else v=guess(d=>{calls++;d.push('M')});result=v;yield end.promise;return 23})();running.then(v=>{returned=true;result=v},e=>{rejected=e.message;returned=true});await turn();sample('guess');
 if(order==='answer-first'){answer.resolve(['A','B']);await turn();sample('answer');end.resolve();await Promise.allSettled([running]);await turn();sample('action ended')}else{end.resolve();await Promise.allSettled([running]);await turn();sample('action ended');answer.resolve(['A','B']);await turn();sample('answer')}
 appendFileSync(process.env.RECEIPT!,JSON.stringify({seedLoadingValue,order,mode,phases,shown})+'\n');
 }finally{answer.resolve(['A','B']);end.resolve();await Promise.allSettled([running]);dispose();flush()}
});

for(const observed of [false,true])it('write hold with sibling; observed='+observed,async()=>{
 const answer=Promise.withResolvers<string[]>(),end=Promise.withResolvers<void>();const shown:any[]=[],phases:any[]=[];let returned=false;
 const [rows,sibling,setSibling,dispose]=createRoot(dispose=>{
  const [rows]=createOptimisticStore(()=>answer.promise,[]);const [sibling,setSibling]=createSignal(0);
  createRenderEffect(()=>sibling(),value=>{shown.push(value)});
  if(observed)createRenderEffect(()=>view(rows),()=>{});
  return [rows,sibling,setSibling,dispose]as const;
 });
 const node=(rows as any)[$TARGET]._fam.node;const sample=(at:string)=>phases.push({at,shown:shown.at(-1),returned,held:!!node._x?._transaction});
 let running:any;
 try{flush();sample('initial');running=action(function*(){holdNode(node,resolveTx(flushTransaction!));setSibling(1);yield end.promise;return 23})();running.then(()=>returned=true);await turn();sample('write');end.resolve();await running;await turn();sample('action ended');answer.resolve(['A','B']);await turn();sample('answer');appendFileSync(process.env.RECEIPT!,JSON.stringify({case:'sibling',observed,phases,shown})+'\n')}
 finally{answer.resolve(['A','B']);end.resolve();await Promise.allSettled([running]);dispose();flush()}
});

it('answer first with no initial observer, mount while action open',async()=>{
 const answer=Promise.withResolvers<string[]>(),end=Promise.withResolvers<void>();const shown:any[]=[],phases:any[]=[];let returned=false;
 const [rows,dispose]=createRoot(dispose=>{const [rows]=createOptimisticStore(()=>answer.promise,[]);return [rows,dispose]as const});
 const node=(rows as any)[$TARGET]._fam.node;let unmount:any;const sample=(at:string)=>phases.push({at,shown:shown.at(-1)??'loading',returned,held:!!node._x?._transaction});let running:any;
 try{flush();sample('initial');running=action(function*(){holdNode(node,resolveTx(flushTransaction!));yield end.promise;return 23})();running.then(()=>returned=true);await turn();sample('write');answer.resolve(['A','B']);await turn();sample('answer');unmount=createRoot(dispose=>{createRenderEffect(()=>view(rows),value=>{shown.push(value)});return dispose});flush();sample('late mount');end.resolve();await running;await turn();sample('action ended');appendFileSync(process.env.RECEIPT!,JSON.stringify({case:'late-mount',phases,shown})+'\n')}
 finally{answer.resolve(['A','B']);end.resolve();await Promise.allSettled([running]);unmount?.();dispose();flush()}
});
