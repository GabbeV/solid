# Pending derived parent fix — 2026-11-13

Source base: 2db2dfd13 in /workspace/layered-solid. No commit by the implementation agent.

The accepted minimal change removes the descendant-selection producer bypass from optimistic-static.ts, plus its unused helper/import. Parent selected inputs now retain their producer dependency. Normal optimistic leaf display remains available.

New regression file: packages/signals/tests/unified-store-pending-derived-parent.test.ts (three tests):
- Ambient leaf guess while new async producer question is unresolved: guessed99 displays; independent reference and deep pending queries stay true.
- Open-action version: same expectations. Producer answer clears pending, updates unguessed sibling, action completion restores answered leaf11.
- Known plain-store held sibling write plus held optimistic leaf guess: guessed99 displays, unchanged parent reference stays available, deep query stays pending until settlement.

command.sh contains the exact final affected-suite invocation. final.log transcribes the captured tool output, without rerunning the command. All 13 suites / 66 tests passed; git diff --check was also clean.

Earlier test-construction corrections: effect callbacks initially returned Array.push results, rejected as invalid cleanup values; corrected to return undefined. An exploratory plain control used an ambient guess over an already available plain input, so the guess immediately retired and the observed value stayed10. The final control uses a held action to retain the guess. No existing consistency assertions were modified.

No full-suite or performance result is claimed by this receipt. No source other than optimistic-static.ts and the new regression file was edited by the implementation agent.
