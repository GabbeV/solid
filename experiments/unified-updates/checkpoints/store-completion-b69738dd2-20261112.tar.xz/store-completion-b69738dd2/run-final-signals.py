import hashlib,json,pathlib,subprocess,sys
repo=pathlib.Path('/workspace/layered-solid');base=pathlib.Path(sys.argv[1]);base.mkdir(parents=True,exist_ok=False)
def hashes(folder):
 return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo/folder).rglob('*')) if p.is_file()}
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True),'sourceHashes':hashes('packages/signals/src'),'artifactHashes':hashes('packages/signals/dist')}
cmd=['node','--expose-gc',str(repo/'node_modules/vitest/vitest.mjs'),'run','--reporter=json','--outputFile='+str(base/'signals.json')]
meta['command']=cmd;meta['cwd']=str(repo/'packages/signals')
(base/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
with (base/'signals.log').open('w') as log:result=subprocess.run(cmd,cwd=meta['cwd'],stdout=log,stderr=subprocess.STDOUT)
d=json.loads((base/'signals.json').read_text());u=json.loads(pathlib.Path('/workspace/scratch/store-full-integration/current-until-map.json').read_text())['byFile'];fail=[];skip=[]
for f in d['testResults']:
 fn=f['name'].split('/tests/')[-1]
 for t in f['assertionResults']:
  if t['status']=='failed':fail.append({'file':fn,'fullName':t['fullName'],'untilDependent':bool(u.get(fn,{}).get(t['fullName'],{}).get('untilDependent')),'messages':t['failureMessages']})
  elif t['status'] not in ('passed',):skip.append({'file':fn,'fullName':t['fullName'],'status':t['status']})
summary={k:d[k] for k in ('numTotalTests','numPassedTests','numFailedTests','numPendingTests')}
summary.update(exitCode=result.returncode,untilDependent=sum(x['untilDependent'] for x in fail),nonUntilFailures=sum(not x['untilDependent'] for x in fail),sourceUnchanged=meta['sourceHashes']==hashes('packages/signals/src'),artifactsUnchanged=meta['artifactHashes']==hashes('packages/signals/dist'))
for name,data in [('summary',summary),('failures',fail),('skips',skip)]: (base/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(summary,indent=2))
for x in fail:
 if not x['untilDependent']: print(x['file'],x['fullName'],x['messages'][0][:600])
