import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
repo=Path('/workspace/layered-solid')
out=Path('/workspace/scratch/store-full-integration/supplementary-final-b69738dd2')
out.mkdir(exist_ok=False)
compiler='/workspace/scratch/pending-repro-rc21/node_modules/@solidjs/compiler-linux-x64-gnu/compiler.linux-x64-gnu.node'
env=dict(os.environ,SOLID_COMPILER_NATIVE=compiler)
def hashes():
 return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['signals','solid','web','h','html','universal','element'] for p in sorted((repo/'packages'/d/'dist').rglob('*')) if p.is_file()}
def save(name,obj): (out/name).write_text(json.dumps(obj,indent=2)+'\n')
before=hashes()
save('artifact-hashes-before.json',before)
save('provenance.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'started':datetime.now(timezone.utc).isoformat(),'nativeCompiler':compiler,'compilerSHA256':hashlib.sha256(Path(compiler).read_bytes()).hexdigest()})
runs=[]
for package,config,label in [('solid','tsconfig.test.json','solid-types'),('solid','tsconfig.no-dom.json','solid-types-no-dom'),('web','tsconfig.test.json','web-types'),('web','tsconfig.test.augment.json','web-types-augment')]:
 runs.append((label,repo/'packages'/package,['node',str(repo/'node_modules/typescript/bin/tsc'),'--project',config]))
runs.append(('imports',repo/'packages/test-integration',['node','test-imports.mjs']))
for package in ['diagnostics','h','html','universal','element']:
 runs.append((package,repo/'packages'/package,['node',str(repo/'node_modules/vitest/vitest.mjs'),'run','--reporter=json','--outputFile='+str(out/(package+'.json'))]))
results={}
save('commands.json',[{'name':n,'cwd':str(c),'command':cmd,'env':{'SOLID_COMPILER_NATIVE':compiler}} for n,c,cmd in runs])
for label,cwd,cmd in runs:
 print('Running '+label,flush=True)
 with (out/(label+'.log')).open('w') as f: rc=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 counts={'exitCode':rc}
 receipt=out/(label+'.json')
 if receipt.exists():
  data=json.loads(receipt.read_text())
  counts.update({k:data.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']})
  counts['suiteLoadFailures']=sum(1 for s in data.get('testResults',[]) if s.get('status')=='failed' and not s.get('assertionResults'))
 results[label]=counts
 save('summary.json',results)
 print(label,counts,flush=True)
after=hashes()
save('artifact-hashes-after.json',after)
save('artifact-drift.json',{k:{'before':before.get(k),'after':after.get(k)} for k in set(before)|set(after) if before.get(k)!=after.get(k)})
save('MANIFEST.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='MANIFEST.json'})
raise SystemExit(any(v['exitCode'] for v in results.values()) or before!=after)
