import json,pathlib,re,collections,hashlib
base=pathlib.Path('/workspace/scratch/store-full-integration');root=base/'frozen-1e1b1e07a/packages/signals';receipt=base/'frozen-1e1b1e07a-built-full.json';d=json.load(open(receipt))
all_until={
'create-deferred-3710.test.ts':[(448,'until scalar waiter'),(483,'parameterized direct/derived action waiter'),(954,'unchanged derived waiter'),(983,'store length waiter')],
'create-deferred.test.ts':[(347,'until over deferred derivation')],
'deferred-protocol-error-flight.test.ts':[(59,'waiter=until branch; refresh sibling cases remain included'),(121,'NotReady iterator waiter')],
'deferred-sync-error-flight.test.ts':[(39,'waiter=until branch; refresh sibling cases remain included')],
'direct-commit-readers-posture.test.ts':[(135,'action authoritative waiter'),(159,'mainline authoritative waiter'),(204,'foreign hold authoritative waiter')],
'optimistic-guess-over-held-slot.test.ts':[(64,'shared setup action waiter')],
'optimistic-keyed-fold.test.ts':[(93,'push helper action waits for server echo; both overlapping-push tests call it'),(206,'external until keyed echo waiters'),(254,'unpublished keyed guess waiter')],
'optimistic-live-echo-3898.test.ts':[(43,'echo waiter'),(81,'mainline timeout waiter'),(140,'keyed echo waiter'),(172,'scalar echo waiter')],
'optimistic-reorder-effect-loop.test.ts':[(45,'shared scenario action waits for applied echo')],
'until-entanglement.test.ts':[(62,'action confirmation wait'),(118,'last-yield wait'),(184,'two-action confirmation waits'),(251,'cancellation wait'),(306,'store confirmation wait'),(345,'held foreign waiter')],
'until-memo-confirmation-3943.test.ts':[(33,'parameterized confirmation waiter'),(88,'reguess confirmation'),(111,'two guesses'),(138,'mixed derivation'),(169,'independent guess'),(196,'store edits'),(232,'equal row confirmation'),(260,'unconfirmed guess')],
'until.test.ts':[(44,'until primitive test; each failed test exercises until directly or inside action')],
'watch-error-outcomes.test.ts':[(54,'kind=until branch; resolve/refresh cases remain included')],
'store/derived-latest-confirmed-key.test.ts':[(71,'shared action waits for keyed echo')],
'store/fold-3164.test.ts':[(93,'store path requires until to keep session action live'),(166,'signal path waits on authenticated truth')],
}
rows=[]
for suite in d['testResults']:
 f=suite['name'].split('/tests/')[-1];source=(root/'tests'/f).read_text()
 for a in suite['assertionResults']:
  if a['status']!='failed':continue
  name=a['fullName'];msg='\n'.join(a['failureMessages']);dep=False;ev=[]
  if f in all_until:dep=True;ev=[{'path':'tests/'+f,'line':l,'reason':why} for l,why in all_until[f]]
  elif f=='held-truth-lane-only.test.ts':
   if '(until()-stolen carrier)' in name:dep=True;ev=[{'path':'tests/'+f,'line':93,'reason':'test calls buildSteal; its action calls until, so deferred throw aborts hold'}]
   elif "GabbeV's session fold" in name:dep=True;ev=[{'path':'tests/'+f,'line':603,'reason':'session action calls until; deferred throw reverts signingIn before assertion'}]
  elif f.startswith('visibility-oracle'):
   if 'authoritative →' in name:dep=True;ev=[{'path':'tests/visibility-oracle.harness.ts','line':180,'reason':'authoritative reader implementation invokes until, even when test file does not'}]
   elif 'held truth (a foreign primitive' in name:dep=True;ev=[{'path':'tests/visibility-oracle.states.ts','line':572,'reason':'state builder uses until to steal landing into action; all reader cells require that setup'}]
  elif f=='store/createOptimisticStore.test.ts':
   if 'holds overlapping keyed adds across' in name:dep=True;ev=[{'path':'tests/'+f,'line':3569,'reason':'add action calls until before failing optimistic publication assertion'}]
   elif "an edit's values outlive its own echo" in name:dep=True;ev=[{'path':'tests/'+f,'line':3650,'reason':'edit action calls until before failing pending-flag assertion'}]
   elif 'reporter shape: optimistic push' in name:dep=True;ev=[{'path':'tests/'+f,'line':4114,'reason':'reporter action uses until'}]
  # Only first failing assertions are categorized; later assertions remain unexecuted.
  diagnostic=None
  if f=='held-truth-lane-only.test.ts' and 'precondition:' in name:diagnostic='legacy engine representation: CONFIG_HELD and _pendingValue/_value; also until-dependent'
  elif f=='store/enumerator-presence-nodes.test.ts' and 'through the key-set node alone' in name:diagnostic='internal selected presence-node subscriber count; preceding observed key-set publication already passed'
  elif f=='attribution-optimistic-revert.test.ts':diagnostic='public attribution event metadata/source naming, not display value; keep included'
  elif 'OPTIMISTIC_WRITE_BEFORE_LOAD' in name:diagnostic='public dev validation/error contract, not merely legacy representation; keep included'
  category='until-dependent' if dep else 'build-artifact' if f=='dist-artifacts.test.ts' else 'internal-diagnostic' if diagnostic and f=='store/enumerator-presence-nodes.test.ts' else 'attribution-contract' if f=='attribution-optimistic-revert.test.ts' else 'observable-or-public-contract'
  loc=re.findall(r'/tests/([^:]+):(\d+):(\d+)',msg)
  if not ev:ev=[{'path':'tests/'+f,'reason':'No until call in test file or runtime helper imports; oracle non-authoritative reader/state inspected separately.'}]
  rows.append({'file':f,'name':name,'category':category,'untilDependent':dep,'untilEvidence':ev if dep else [],'nonUntilReview':None if dep else ev,'diagnostic':diagnostic,'assertion':msg.splitlines()[0] if msg else '', 'firstTestStack':{'path':'tests/'+loc[0][0],'line':int(loc[0][1])} if loc else None})
byfile=collections.defaultdict(list)
for x in rows:byfile[x['file']].append(x)
files=[{'file':f,'failed':len(rs),'untilDependentFailures':sum(x['untilDependent'] for x in rs),'otherFailures':sum(not x['untilDependent'] for x in rs),'allFailedTestsUntilDependent':all(x['untilDependent'] for x in rs)} for f,rs in byfile.items()]
summary={'receipt':str(receipt),'receiptSha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'counts':{k:d[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']},'failureCategories':dict(collections.Counter(r['category'] for r in rows)),'untilDependentFailures':sum(x['untilDependent'] for x in rows),'remainingNonUntilFailures':sum(not x['untilDependent'] for x in rows),'files':files,'notes':['No whole-file exclusion applied. Counts classify every failed test identity individually.','All-failed-tests-until-dependent does not imply all tests in that file depend on until; passing sibling cases must remain in denominator.','Until-dependent cases can still reveal additional bugs after until support/migration; this inventory does not assert they otherwise pass.','Internal diagnostic and attribution failures remain included in the non-until failure denominator.','2 skipped cases retained separately; one build-artifact E2BIG failure remains visible.']}
json.dump(rows,open(base/'frozen-until-classification.json','w'),indent=2);json.dump(summary,open(base/'frozen-until-summary.json','w'),indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ['files','notes']},indent=2))
print('Mixed failed files:',[(x['file'],x['untilDependentFailures'],x['otherFailures']) for x in files if x['untilDependentFailures'] and x['otherFailures']])
