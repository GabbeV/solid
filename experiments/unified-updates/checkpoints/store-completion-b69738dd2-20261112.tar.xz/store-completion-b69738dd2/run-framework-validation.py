#!/usr/bin/env python3
"""Run official framework suites against already-built artifacts; never build/install/edit source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
from datetime import datetime, timezone

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("output", type=Path, help="Fresh receipt directory")
parser.add_argument("--repo", type=Path, default=Path("/workspace/layered-solid"))
parser.add_argument("--compiler", type=Path, default=Path("/workspace/scratch/pending-repro-rc21/node_modules/@solidjs/compiler-linux-x64-gnu/compiler.linux-x64-gnu.node"))
parser.add_argument("--prepare-only", action="store_true", help="Write configs, hashes and planned commands without running tests")
parser.add_argument("--official-server", action="store_true", help="Use official raw server resolution instead of the qualified current-dist shared signals bus")
args = parser.parse_args()
repo, out, compiler = args.repo.resolve(), args.output.resolve(), args.compiler.resolve()
if out.exists() and any(out.iterdir()):
    parser.error("Output must be a new or empty directory; preserve prior receipts.")
if not compiler.is_file():
    parser.error("Existing native compiler binary is missing; no installation is attempted.")
for required in ["packages/signals/dist/dev.js", "packages/signals/dist/dev.attribution.js", "packages/solid/dist/solid.dev.js", "packages/web/dist/web.dev.js"]:
    if not (repo / required).is_file():
        parser.error(f"Required built artifact missing: {required}; build separately before running.")
out.mkdir(parents=True, exist_ok=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def hashes():
    result = {}
    for folder in ["packages/signals/dist", "packages/solid/dist", "packages/web/dist", "packages/web/frames/dist", "packages/web/serialization/dist", "packages/web/server-functions/dist"]:
        parent = repo / folder
        if parent.is_dir():
            for path in sorted(parent.rglob("*")):
                if path.is_file():
                    result[str(path.relative_to(repo))] = digest(path)
    return result

def save(name, data):
    (out / name).write_text(json.dumps(data, indent=2) + "\n")

def source_hashes():
    result = {}
    for folder in ["packages/signals/src", "packages/solid/src", "packages/web/src"]:
        for path in sorted((repo / folder).rglob("*")):
            if path.is_file():
                result[str(path.relative_to(repo))] = digest(path)
    return result

before = hashes()
save("tested-artifact-hashes.json", before)
save("provenance-before.json", {
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
    "status": subprocess.check_output(["git", "status", "--short"], cwd=repo, text=True),
    "sourceHashes": source_hashes(),
    "compiler": {"path": str(compiler), "sha256": digest(compiler)},
    "diagnosticsSignalsResolution": str((repo / "packages/diagnostics/node_modules/@solidjs/signals").resolve()),
    "node": subprocess.check_output(["node", "--version"], text=True).strip(),
    "startedUTC": datetime.now(timezone.utc).isoformat(),
})
# Config wrappers alter module resolution/setup only. They provide no mocks,
# transform changes, test fixtures, source patches, or expectation changes.
server_config = out / "server-shared-signals.config.mjs"
server_config.write_text(
    f"import base from {json.dumps(str(repo / 'packages/web/vite.config.server.mjs'))};\n"
    "export default {...base,resolve:{...base.resolve,alias:{\n"
    f" '@solidjs/signals/attribution':{json.dumps(str(repo / 'packages/signals/dist/dev.attribution.js'))},\n"
    f" '@solidjs/signals':{json.dumps(str(repo / 'packages/signals/dist/dev.js'))},\n"
    " ...base.resolve.alias\n"
    "}},test:{...base.test,server:{deps:{inline:[/solid-js/,/@solidjs[+/]web/],external:[/\\/packages\\/signals\\/dist\\//]}}}};\n"
)
hydrate_config = out / "hydrate-local-setup.config.mjs"
hydrate_config.write_text(
    f"import base from {json.dumps(str(repo / 'packages/web/vite.config.hydrate.mjs'))};\n"
    "export default {...base,test:{...base.test,setupFiles:["
    + json.dumps(str(repo / "packages/web/test/setup-jest-dom.ts"))
    + ",...base.test.setupFiles]}};\n"
)
suites = [
    ("solid", "solid", repo / "packages/solid/vite.config.mjs"),
    ("web-client", "web", repo / "packages/web/vite.config.mjs"),
    ("web-server", "web", repo / "packages/web/vite.config.server.mjs" if args.official_server else server_config),
    ("web-hydrate", "web", hydrate_config),
]
env = os.environ.copy()
env["SOLID_COMPILER_NATIVE"] = str(compiler)
summary = {"prepareOnly": args.prepare_only, "serverResolution": "official raw" if args.official_server else "qualified current-dist shared signals bus", "runs": {}}
commands = []
for label, package, config in suites:
    command = ["node", str(repo / "node_modules/vitest/vitest.mjs"), "run", "--config", str(config), "--reporter=json", f"--outputFile={out / (label + '.json')}"]
    commands.append({"suite": label, "cwd": str(repo / "packages" / package), "command": shlex.join(command), "env": {"SOLID_COMPILER_NATIVE": str(compiler)}})
    save("commands.json", commands)
    if args.prepare_only:
        print(f"Prepared {label}", flush=True)
        continue
    print(f"Running {label} ...", flush=True)
    with (out / f"{label}.log").open("w") as log:
        completed = subprocess.run(command, cwd=repo / "packages" / package, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt = out / f"{label}.json"
    counts = {"exitCode": completed.returncode}
    if receipt.is_file():
        data = json.loads(receipt.read_text())
        counts.update({key: data.get(key) for key in ["numTotalTests", "numPassedTests", "numFailedTests", "numPendingTests"]})
        counts["suiteLoadFailures"] = sum(1 for suite in data.get("testResults", []) if suite.get("status") == "failed" and not suite.get("assertionResults"))
        failures = [{"file": suite["name"], "name": assertion["fullName"], "failures": assertion.get("failureMessages", [])} for suite in data.get("testResults", []) for assertion in suite.get("assertionResults", []) if assertion["status"] == "failed"]
        save(f"{label}-failures.json", failures)
    summary["runs"][label] = counts
    save("framework-summary.json", summary)
    print(label, counts, flush=True)
after = hashes()
summary["artifactDrift"] = {path: {"before": value, "after": after.get(path)} for path, value in before.items() if after.get(path) != value}
summary["newArtifactsDuringRun"] = sorted(set(after) - set(before))
save("framework-summary.json", summary)
save("provenance-finish.json", {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(), "sourceHashes": source_hashes(), "finishedUTC": datetime.now(timezone.utc).isoformat()})
save("MANIFEST.json", {"files": {p.name: {"bytes": p.stat().st_size, "sha256": digest(p)} for p in sorted(out.iterdir()) if p.is_file() and p.name != "MANIFEST.json"}})
failed = any(run.get("exitCode") for run in summary["runs"].values()) or bool(summary["artifactDrift"] or summary["newArtifactsDuringRun"])
sys.exit(1 if failed else 0)
