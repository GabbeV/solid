# Chained native-method correction receipt

Integrated source commit: b69738dd2 (root integration).

The patch artifact `chained-native-method-probe.patch` was regenerated directly with:

    git show b69738dd2 --format= -- packages/signals/src/store/store.ts

It now contains exactly the three intended native-method hunks. It does not revert the quiet producer-link correction. Committed store.ts SHA256:

    62042f75c7ac37433de3e03e847db5a3f94169443109775dfab67e7caa4994b6

Final selected-parent-body guard verification: `chain-native-selected-body-final.json`, 42 total / 42 passed / 0 failed. Command ran from `/workspace/scratch/nested-store-completion/packages/signals`:

    ../../node_modules/.bin/vitest run tests/store/store-in-store-tracking.test.ts tests/unified-chained-native-method.test.ts tests/unified-store-parent-reclamation.test.ts tests/unified-cold-store-companion.test.ts tests/unified-optimistic-accessors.test.ts --reporter=json --outputFile=/workspace/scratch/chain-native-selected-body-final.json

Earlier broad verification before the final selected-body guard: `chain-native-proxy-only-broad.json`, 959/959. Do not describe this as a full-suite check of the final integrated source. Source-only tsc completed successfully; log `chain-native-final-source-types.log`.

Main and next bcef1041 each pass the same initial three controls (`chain-native-own-controls-baseline.json`, `chain-native-own-controls-next-bcef.json`): prototype method lookup stays untracked for a later own field; once an own method is actually read it remains reactive; an already tracked own getter preserves the outer selected receiver and evaluates once per direct read. Six own-data/getter/custom-prototype publication controls pass on the pre-fix main baseline (`chain-native-six-controls-baseline.json`).

The final clean test source is `/workspace/scratch/nested-store-completion/packages/signals/tests/unified-chained-native-method.test.ts` (nine controls). The final extra cold retained-parent getter control exposed the need for the selected-body guard; the unguarded candidate returned [0] instead of the outer selected [7]. The guard reuses ordinary descriptor selection whenever a parent body supplies the metadata.

Root is running the authoritative frozen-source and framework suites. No further implementation or broad worker run is pending here.
