import base from "/workspace/layered-solid/packages/web/vite.config.server.mjs";
export default {...base,resolve:{...base.resolve,alias:{
 '@solidjs/signals/attribution':"/workspace/layered-solid/packages/signals/dist/dev.attribution.js",
 '@solidjs/signals':"/workspace/layered-solid/packages/signals/dist/dev.js",
 ...base.resolve.alias
}},test:{...base.test,server:{deps:{inline:[/solid-js/,/@solidjs[+/]web/],external:[/\/packages\/signals\/dist\//]}}}};
