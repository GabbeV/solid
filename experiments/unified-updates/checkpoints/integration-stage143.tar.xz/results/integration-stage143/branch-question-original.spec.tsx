/** @jsxImportSource @solidjs/web */
import { appendFileSync } from "node:fs";
import { expect, test } from "vitest";
import { Loading, createMemo, createSignal, flush, latest } from "solid-js";
import { render } from "../src/index.js";

const settle = async () => {
  await new Promise(resolve => setTimeout(resolve, 0));
  flush();
};

for (const header of [false, true])
  test(`leaving the latest branch (filter header=${header})`, async () => {
    const first = Promise.withResolvers<number[]>();
    const second = Promise.withResolvers<number[]>();
    const host = document.createElement("main");
    document.body.append(host);
    let setFilter!: (value: string) => void;
    let filter!: () => string;
    const dispose = render(() => {
      [filter, setFilter] = createSignal("open");
      const list = createMemo(() => filter() === "open" ? first.promise : second.promise);
      const count = createMemo(() => filter() === "open" ? latest(() => list().length) : -1);
      return <>
        {header && <header>{filter()}</header>}
        <span>{count()}</span>
        <Loading fallback="first load">
          <Loading on={filter()} fallback={<>loading {filter()}</>}>
            <b>{list().join(",")}</b>
          </Loading>
        </Loading>
      </>;
    }, host);
    const frames: unknown[] = [];
    const sample = () => frames.push({ filter: filter(), dom: host.innerHTML });
    try {
      flush();
      first.resolve([1, 2, 3]);
      await settle();
      expect(host.querySelector("span")?.textContent).toBe("3");
      sample();
      setFilter("closed");
      flush();
      await settle();
      sample();
      second.resolve([9]);
      await settle();
      sample();
      expect(host.querySelector("span")?.textContent).toBe("-1");
      expect(host.querySelector("b")?.textContent).toBe("9");
      appendFileSync(process.env.BRANCH_REPORT!, JSON.stringify({ header, frames }) + "\n");
    } finally {
      dispose();
      host.remove();
    }
  });
