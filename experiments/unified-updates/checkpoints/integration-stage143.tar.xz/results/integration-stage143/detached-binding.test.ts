/** @vitest-environment jsdom */
import { expect, it } from "vitest";
import {
  action,
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  latest,
  onCleanup
} from "../src/index.js";

for (const observation of ["none", "inline", "memo"] as const)
  for (const schedule of [false, true])
    it(`initializes a detached held binding without publishing its tree (${observation}, scheduled=${schedule})`, async () => {
      const end = Promise.withResolvers<void>();
      const host = document.createElement("main");
      document.body.append(host);
      const initialized: { value: string; attached: boolean }[] = [];
      const cleaned: number[] = [];
      let proposed!: HTMLElement;
      const app = createRoot(dispose => {
        const [value, setValue] = createSignal(0);
        const selected =
          observation === "memo" ? createMemo(() => latest(value)) : () => latest(value);
        const tree = createMemo(() => {
          const version = value();
          const element = document.createElement("span");
          if (version) proposed = element;
          onCleanup(() => cleaned.push(version));
          createRenderEffect(
            () => (observation === "none" ? `${value()}` : `${value()}/${selected()}`),
            text => {
              element.textContent = text;
              initialized.push({ value: text, attached: element.isConnected });
            },
            { schedule }
          );
          return element;
        });
        createRenderEffect(tree, element => host.replaceChildren(element), { schedule: true });
        const run = action(function* () {
          setValue(1);
          yield end.promise;
        });
        return { dispose, run };
      });
      let running: Promise<unknown> | undefined;
      try {
        flush();
        const original = host.firstChild;
        const oldText = observation === "none" ? "0" : "0/0";
        const newText = observation === "none" ? "1" : "1/1";
        expect(host.textContent).toBe(oldText);
        running = app.run();
        flush();
        expect(proposed.isConnected).toBe(false);
        expect(proposed.textContent).toBe(schedule ? "" : newText);
        expect(initialized.filter(entry => entry.value === newText)).toEqual(
          schedule ? [] : [{ value: newText, attached: false }]
        );
        expect(host.firstChild).toBe(original);
        expect(host.textContent).toBe(observation === "none" ? "0" : "0/1");
        expect(cleaned).toEqual([]);
        end.resolve();
        await running;
        await new Promise(resolve => setTimeout(resolve, 0));
        flush();
        expect(host.firstChild).toBe(proposed);
        expect(host.textContent).toBe(newText);
        expect(cleaned).toEqual([0]);
        expect(initialized.filter(entry => entry.value === newText)).toHaveLength(1);
      } finally {
        end.resolve();
        await running;
        app.dispose();
        host.remove();
        flush();
      }
      expect(cleaned).toEqual([0, 1]);
    });
