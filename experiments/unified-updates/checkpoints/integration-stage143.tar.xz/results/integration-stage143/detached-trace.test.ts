/** @vitest-environment jsdom */
import { expect, it } from "vitest";
import {
  action,
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  latest,
  onCleanup
} from "../src/index.js";

for (const observation of ["none", "inline", "memo"] as const)
  for (const schedule of [false, true])
    it(`initializes a detached held binding without publishing its tree (${observation}, scheduled=${schedule})`, async () => {
      const end = Promise.withResolvers<void>();
      const host = document.createElement("main");
      document.body.append(host);
      const initialized: { value: string; attached: boolean }[] = [];
      const cleaned: number[] = [];
      let proposed!: HTMLElement;
      const app = createRoot(dispose => {
        const [value, setValue] = createSignal(0);
        const selected =
          observation === "memo" ? createMemo(() => latest(value)) : () => latest(value);
        const tree = createMemo(() => {
          const version = value();
          const element = document.createElement("span");
          if (version) proposed = element;
          onCleanup(() => cleaned.push(version));
          createRenderEffect(
            () => (observation === "none" ? `${value()}` : `${value()}/${selected()}`),
            text => {
              element.textContent = text;
              initialized.push({ value: text, attached: element.isConnected });
            },
            { schedule }
          );
          return element;
        });
        createRenderEffect(tree, element => host.replaceChildren(element), { schedule: true });
        const run = action(function* () {
          setValue(1);
          yield end.promise;
        });
        return { dispose, run };
      });
      let running: Promise<unknown> | undefined;
      try {
        flush();
        const original = host.firstChild;
        const oldText = observation === "none" ? "0" : "0/0";
        const newText = observation === "none" ? "1" : "1/1";
        expect.soft(host.textContent).toBe(oldText);
        running = app.run();
        flush();
        console.log(observation, schedule, "held", host.textContent, proposed.textContent, initialized);
        expect.soft(proposed.isConnected).toBe(false);
        expect.soft(proposed.textContent).toBe(schedule ? "" : newText);
        expect.soft(initialized.filter(entry => entry.value === newText)).toEqual(
          schedule ? [] : [{ value: newText, attached: false }]
        );
        expect.soft(host.firstChild).toBe(original);
        expect.soft(host.textContent).toBe(observation === "none" ? "0" : "0/1");
        expect.soft(cleaned).toEqual([]);
        end.resolve();
        await running;
        await new Promise(resolve => setTimeout(resolve, 0));
        flush();
        console.log(observation, schedule, "landed", host.textContent, initialized);
        expect.soft(host.firstChild).toBe(proposed);
        expect.soft(host.textContent).toBe(newText);
        expect.soft(cleaned).toEqual([0]);
        expect.soft(initialized.filter(entry => entry.value === newText)).toHaveLength(1);
      } finally {
        end.resolve();
        await running;
        app.dispose();
        host.remove();
        flush();
      }
      expect.soft(cleaned).toEqual([0, 1]);
    });
