export default { test: { globals: true, environment: "jsdom", pool: "threads", include: ["test/runtime/serializer.spec.js"] } };
