import {it,expect} from 'vitest';
import {createRoot,createStore,flush} from '../src/index.js';
it('plain store setter writes the shared source',()=>{
 const app=createRoot(dispose=>{
  const [person]=createStore({name:'Alice'});
  const [list,setList]=createStore({people:[person]});
  return {person,list,setList,dispose};
 });
 try {flush();expect(app.list.people[0]).toBe(app.person);app.setList(s=>{s.people[0].name='Bob';});flush();expect(app.person.name).toBe('Bob');expect(app.list.people[0]).toBe(app.person);}
 finally {app.dispose();flush();}
});
