Source-local affects implementation checkpoint, 2026-11-16.
See retained.patch and new test copy for retained source changes against BASE_SHA.
Full.json is an intermediate run, full-final.json is before removing the rejected
plain ancestry guard; final targeted checks pass rule index and source-local
cases except the new plain shared-child semantic question (now named question).
The full-final runtime failures otherwise match135 until exactly. Three index
failures were repaired by regeneration. Build-final and types-retained reflect
the retained source. Framework tests used the rebuilt code before removing the
plain-only ancestry guard; none of six failing web tests invokes affects.
Framework failures are not yet triaged; do not label them intentional or fixed.

Rejected ancestry rule in affects.walk: exclude a plain target if walking its
.u chain does not reach the declaration target. Independent probe found same raw
child in a and b reports captured pending true if a.child materialized first,
false if b.child materialized first, after affects(a). That guard is fully removed.
Do not use path-copy parent metadata as semantic source provenance.

Plain-shared-write.test.ts passes on retained source and next221b5f99f: plain
list.people[0]===person, and setList(d=>d.people[0].name='Bob') updates person.
This motivates asking whether existing plain-store mark sharing should remain,
rather than assuming a derived-wrapper rule changes plain aliases too.
