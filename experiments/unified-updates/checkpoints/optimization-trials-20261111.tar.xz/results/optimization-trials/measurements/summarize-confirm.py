import json, pathlib, statistics

p=pathlib.Path(__file__).parent
labels=['next','entry','attempt']
data={}
for label in labels:
    data[label]=[]
    for i in range(1,6):
        f=p/f'confirm{i}-{label}.json'
        if f.exists():
            data[label].append({b['name']:b for file in json.loads(f.read_text())['files'] for g in file['groups'] for b in g['benchmarks']})
records=[]
for name in data['next'][0]:
    record={'case':name, 'variants':{}}
    for label in labels:
        runs=data[label]
        means=[r[name]['mean'] for r in runs]
        pairs=[r[name]['mean']/data['next'][i][name]['mean'] for i,r in enumerate(runs) if i<len(data['next'])]
        if not means: continue
        record['variants'][label]={
            'runs':len(means), 'medianMeanMs':statistics.median(means),
            'minMeanMs':min(means),'maxMeanMs':max(means),
            'pairedRatiosToNext':pairs,
            'medianPairedRatioToNext':statistics.median(pairs) if pairs else None,
            'rmes':[r[name]['rme'] for r in runs],
            'sampleCounts':[r[name]['sampleCount'] for r in runs],
        }
    records.append(record)
(p/'confirm-summary.json').write_text(json.dumps(records,indent=2))
for r in records:
    print(r['case'])
    for label in labels[1:]:
        v=r['variants'].get(label)
        if v and v['pairedRatiosToNext']:
            print(' ',label, f"{v['medianPairedRatioToNext']:.3f}x next",f"range {min(v['pairedRatiosToNext']):.3f}–{max(v['pairedRatiosToNext']):.3f}")
