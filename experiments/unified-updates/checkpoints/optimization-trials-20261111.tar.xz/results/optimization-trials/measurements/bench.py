import json, os, pathlib, platform, subprocess, sys, time

out = pathlib.Path(__file__).parent
roots = json.loads((out/'roots.json').read_text())
env = dict(os.environ, SIGNALS_BENCH='dist', SIGNALS_TIER='prod')
env.pop('FILTER', None)
env.pop('SIGNALS_TEST_DEFINE', None)
series = sys.argv[1]
labels = sys.argv[2:] or list(roots)
for label in labels:
    prefix = out / (series + '-' + label)
    cmd = ['node', '/workspace/layered-solid/node_modules/vitest/vitest.mjs', 'bench', '--run',
           'tests/core/reactivity.bench.ts', 'tests/core/creation.bench.ts',
           'tests/core/settled.bench.ts', 'tests/core/optimism.bench.ts',
           '--maxWorkers=1', '--outputJson=' + str(prefix) + '.json']
    metadata = {'cmd': cmd, 'root': roots[label], 'start': time.time(), 'platform': platform.platform(), 'loadBefore': os.getloadavg()}
    print(series, label, 'start', flush=True)
    with pathlib.Path(str(prefix)+'.log').open('w') as log:
        result = subprocess.run(cmd, cwd=roots[label]+'/packages/signals', env=env, stdout=log, stderr=subprocess.STDOUT)
    metadata.update(end=time.time(), exit=result.returncode, loadAfter=os.getloadavg())
    pathlib.Path(str(prefix)+'.meta.json').write_text(json.dumps(metadata, indent=2))
    print(series, label, result.returncode, round(metadata['end']-metadata['start'], 2), 'seconds', flush=True)
    if result.returncode:
        print(pathlib.Path(str(prefix)+'.log').read_text()[-8000:], flush=True)
        sys.exit(result.returncode)
    report = json.loads(pathlib.Path(str(prefix)+'.json').read_text())
    missing = [g['fullName'] + ':' + b['name'] for f in report['files'] for g in f['groups'] for b in g['benchmarks'] if not b.get('sampleCount') or not b.get('mean')]
    if missing:
        raise RuntimeError('Unmeasured benchmark cases: ' + repr(missing))
