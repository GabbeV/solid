#!/usr/bin/env python3
"""Read-only CPU-profile attribution. Run: python profiles/analyze.py > analysis.json.
Counts are samples, not timings/allocations or per-operation costs.
Recognize the fixture wrapper under tinybench loop when V8 omits/inlines run.
Body attribution includes warmup: truncated async stacks prevent a clean split. Inclusive
counts count a function once per sample, even with recursive stack occurrences.
"""
import collections, json
from pathlib import Path
BASE = Path(__file__).resolve().parent

def analyze(path):
    p = json.loads(path.read_text())
    nodes = {n['id']: n for n in p['nodes']}
    parent = {child: n['id'] for n in p['nodes'] for child in n.get('children', [])}
    def stack(n):
        result = []
        while n in nodes:
            result.append(nodes[n]['callFrame'])
            if n not in parent: break
            n = parent[n]
        return result
    def fixture(f):
        return f['functionName'] == 'run' and f['url'].endswith('/tests/core/optimism.bench.ts')
    def key(f):
        url = f['url']
        return (url.split('/dist/prod/')[-1] if '/dist/prod/' in url else url.rsplit('/', 1)[-1]) + ':' + (f['functionName'] or '<anonymous>')
    budgets = collections.Counter()
    self_count, inclusive, modules = collections.Counter(), collections.Counter(), collections.Counter()
    fixture_count = 0
    for sample in p.get('samples', []):
        frames = stack(sample)
        leaf = frames[0]
        names = {f['functionName'] for f in frames}
        if leaf['functionName'] == '(garbage collector)': bucket = 'gc_unassigned'
        elif leaf['functionName'] == '(idle)': bucket = 'idle'
        elif any(fixture(f) for f in frames) or (any(f['url'].endswith('/tests/core/optimism.bench.ts') for f in frames) and any(f['functionName'] == 'loop' and 'tinybench' in f['url'] for f in frames)):
            if any(f['functionName'] == 'setup' and f['url'].endswith('/optimism.bench.ts') for f in frames): bucket = 'fixture_preflight'
            else: bucket = 'fixture_body_warmup_or_measurement'
        elif any('/packages/signals/dist/prod/' in f['url'] for f in frames): bucket = 'other_runtime_setup_teardown'
        else: bucket = 'startup_harness_other'
        budgets[bucket] += 1
        if bucket != 'fixture_body_warmup_or_measurement': continue
        fixture_count += 1
        runtime = [f for f in frames if '/packages/signals/dist/prod/' in f['url']]
        if '/packages/signals/dist/prod/' in leaf['url']:
            self_count[key(leaf)] += 1
            modules[leaf['url'].split('/dist/prod/')[-1]] += 1
        else: self_count['[fixture or harness leaf]'] += 1
        for k in set(key(f) for f in runtime): inclusive[k] += 1
    union = set(self_count) | set(inclusive)
    rows = [{'function': k, 'self': self_count[k], 'inclusive': inclusive[k],
             'self_pct': round(100*self_count[k]/fixture_count, 1) if fixture_count else 0,
             'inclusive_pct': round(100*inclusive[k]/fixture_count, 1) if fixture_count else 0}
            for k in sorted(union, key=lambda k: (-self_count[k], -inclusive[k], k))]
    return {'profile':path.name, 'samples':len(p.get('samples',[])),
            'profile_duration_s':(p['endTime']-p['startTime'])/1e6,
            'fixture_body_samples':fixture_count,'budgets':dict(budgets),
            'runtime_module_self':dict(modules.most_common()),'functions':rows}

result = {}
for label in ['next','cold']:
    profiles = [analyze(p) for p in sorted((BASE/label).glob('*.cpuprofile'))]
    result[label] = {'worker':max(profiles, key=lambda p:p['fixture_body_samples']),
                     'other_processes':[p for p in profiles if not p['fixture_body_samples']]}
print(json.dumps(result, indent=2))
