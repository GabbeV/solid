Workers are PID **46130 next** and **46170 cold**; launcher PIDs 46105/46143 have
no fixture-body samples and spend most samples idle/importing. Analysis script:
`python /workspace/scratch/unified-opt-results/profiles/analyze.py > analysis.json`.

The worker stacks identify **2,117 next / 1,934 cold fixture-body samples**.
Recognition includes the native Tinybench-loop fixture wrapper because V8 omits
or inlines fixture.run on many stacks; requiring its literal frame alone would
misclassify 708/1,420 samples. Body attribution includes warmup: truncated async
stacks prevent reliable warmup/measurement separation. Setup/preflight is excluded.

Self / inclusive percentages below use each worker's fixture-body denominator.
Inclusive rows overlap; they must not be added.

| Function | Next self / incl. | Cold self / incl. |
|---|---:|---:|
| scheduler settle | 19.5 / 60.3% | 15.5 / 69.6% |
| core recompute (outer) | 15.4 / 20.9% | 0.1 / 18.6% |
| core recomputeBody | — | 6.2 / 12.3% |
| laneSeams | 5.9 / 25.0% | 2.0 / 2.0% |
| settleLayers | — | 0.1 / 34.2% |
| optimistic proposal-apply hook (`jt`) | — | 9.0 / 29.0% |
| stageLayer | — | 2.3 / 15.5% |
| recomputeInUpdate | — | 3.8 / 17.2% |
| adoptOutput | — | 4.7 / 5.5% |
| settleObservations | — | 5.3 / 5.3% |

Other worker budgets (next/cold): startup/harness/other 468/372; runtime
setup/teardown 11/17; preflight 2/8; idle 59/70; **GC 83/114 unassigned**.
GC stacks do not identify which operation caused collection; these are not
allocation measurements.

Two grounded hypotheses:

1. Investigate proposal selection/position/application and subsequent adoption:
   cold's `jt` iterates proposals three times (select, position, apply); its
   descendants include stageLayer (15.5% inclusive), adoptOutput (4.7% self), and
   layerPosition (3.7% self). Establish which lifecycle obligations repeat before
   considering consolidation. These samples support examining this broader path.
2. Investigate no-work observation settlement during scalar guesses:
   settleObservations consumes 5.3% self even though this fixture requests no
   latest/pending observations. Verify whether it performs required publication
   duties before proposing a guarded skip.

Repeated scope/hook assignments are not separately resolved hotspots. Scope
work may be inlined into recomputeInUpdate; samples cannot isolate those
assignments. Larger proposal/publication work is clearly visible, so source
assignment counts alone do not justify prioritizing it.

Limits: one short 500µs profile per runtime, different completed operation counts,
JIT/inlining and async-stack effects, shared-sample uncertainty, preserved-module
Node execution. Percentages show composition, not absolute slowdown or speedup;
accepted unprofiled timing remains separate. No builds or additional runs performed.
