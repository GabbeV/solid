import { mergeConfig } from "/workspace/layered-solid/node_modules/vitest/dist/config.js";
import config from "/workspace/scratch/unified-opt-cold-reset/packages/signals/vite.config.ts";
export default mergeConfig(config({mode:"test",command:"serve"} as any), {
  resolve: {alias: [{find: /^(?:\.\.\/)+src\/index\.js$/, replacement: "/workspace/scratch/unified-opt-cold-reset/packages/signals/dist/prod/index.js"}]},
  test: {server: {deps: {external: [/\/dist\//]}}}
});
