import hashlib, json, os, pathlib, platform, subprocess, time

out = pathlib.Path(__file__).parent
roots = json.loads((out/'roots.json').read_text())
env = dict(os.environ, SIGNALS_BENCH='dist', SIGNALS_TIER='prod')
env.pop('FILTER', None)
env.pop('SIGNALS_TEST_DEFINE', None)
files = ['reactivity', 'creation', 'settled', 'optimism']
labels = ['next', 'entry', 'attempt', 'scheduler', 'next-scheduler']
manifest = {'platform': platform.platform(), 'node': subprocess.check_output(['node','--version'],text=True).strip(), 'fixtures': {f: hashlib.sha256((pathlib.Path(roots['entry'])/'packages/signals/tests/core'/(f+'.bench.ts')).read_bytes()).hexdigest() for f in files}}
(out/'repeat-manifest.json').write_text(json.dumps(manifest,indent=2))
for round_index in range(1, 6):
    order = labels if round_index % 2 else labels[::-1]
    for label in order:
        start = time.time()
        combined = {'files': []}
        print('round',round_index,label,'start',flush=True)
        for fixture in files:
            prefix = out / f'round{round_index}-{label}-{fixture}'
            cmd = ['node', '/workspace/layered-solid/node_modules/vitest/vitest.mjs', 'bench', '--run',
                   f'tests/core/{fixture}.bench.ts', '--maxWorkers=1', '--outputJson='+str(prefix)+'.json']
            metadata = {'cmd': cmd, 'root': roots[label], 'start': time.time(), 'loadBefore': os.getloadavg()}
            with pathlib.Path(str(prefix)+'.log').open('w') as log:
                result = subprocess.run(cmd, cwd=roots[label]+'/packages/signals', env=env, stdout=log, stderr=subprocess.STDOUT)
            metadata.update(end=time.time(), exit=result.returncode, loadAfter=os.getloadavg())
            pathlib.Path(str(prefix)+'.meta.json').write_text(json.dumps(metadata,indent=2))
            if result.returncode:
                raise RuntimeError(f'{prefix}: exit {result.returncode}; inspect log')
            report=json.loads(pathlib.Path(str(prefix)+'.json').read_text())
            missing=[g['fullName']+':'+b['name'] for f in report['files'] for g in f['groups'] for b in g['benchmarks'] if not b.get('sampleCount') or not b.get('mean')]
            if missing:
                raise RuntimeError('Unmeasured cases: '+repr(missing))
            combined['files'].extend(report['files'])
        (out/f'round{round_index}-{label}.json').write_text(json.dumps(combined))
        print('round',round_index,label,'done',round(time.time()-start,2),'seconds',flush=True)
