import hashlib, json, os, pathlib, shutil, subprocess, sys, time

out = pathlib.Path(__file__).parent
roots = {
    'next': '/workspace/layered-next-4fe75321',
    'entry': '/workspace/layered-solid',
    'attempt': '/workspace/scratch/unified-opt-attempt-loop',
    'journal': '/workspace/scratch/unified-opt-journal',
    'scheduler': '/workspace/scratch/unified-opt-scheduler',
    'next-scheduler': '/workspace/scratch/unified-opt-scheduler-next',
    'cold': '/workspace/scratch/unified-opt-cold-reset',
    'final': '/workspace/layered-solid',
}
commands = [
    ['node', '/workspace/layered-solid/packages/signals/node_modules/rollup/dist/bin/rollup', '-c'],
    ['node', 'scripts/mangle-props.mjs', 'dist/prod', 'dist/observe'],
    ['node', 'scripts/check-pure.mjs', 'dist/prod'],
    ['node', 'scripts/check-pure.mjs', 'dist/observe'],
    ['node', '/workspace/layered-solid/node_modules/typescript/bin/tsc', '-p', 'tsconfig.build.json'],
]
fixture_root = pathlib.Path('/workspace/scratch/unified-opt-benchmarks/packages/signals/tests/core')
env = dict(os.environ)
env.pop('SIGNALS_TEST_DEFINE', None)
for label, root in roots.items():
    if len(sys.argv)>1 and label not in sys.argv[1:]:
        continue
    root = pathlib.Path(root)
    for name in ['settled.bench.ts', 'optimism.bench.ts']:
        shutil.copy2(fixture_root / name, root / 'packages/signals/tests/core' / name)
    package = root / 'packages/signals'
    metadata = {'root': str(root), 'commands': commands, 'start': time.time()}
    for key, args in [('head', ['rev-parse', 'HEAD']), ('status', ['status', '--short']), ('patch', ['diff'])]:
        metadata[key] = subprocess.check_output(['git', *args], cwd=root, text=True)
    with (out / (label + '-build.log')).open('w') as log:
        for cmd in commands:
            print(label, ' '.join(cmd), flush=True)
            subprocess.run(cmd, cwd=package, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    metadata['end'] = time.time()
    metadata['artifacts'] = {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((package/'dist/prod').rglob('*.js'))}
    (out / (label + '-build.json')).write_text(json.dumps(metadata, indent=2))
(out / 'roots.json').write_text(json.dumps(roots, indent=2))
