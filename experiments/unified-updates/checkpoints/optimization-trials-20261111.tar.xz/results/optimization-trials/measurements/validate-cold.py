import json, os, pathlib, subprocess, time
out=pathlib.Path(__file__).parent
root=pathlib.Path('/workspace/scratch/unified-opt-cold-reset')
env=dict(os.environ)
for name in ['SIGNALS_TEST_DEFINE','SIGNALS_BENCH','SIGNALS_TIER','FILTER']:
    env.pop(name,None)
cmd=['node','/workspace/layered-solid/node_modules/vitest/vitest.mjs','run','--maxWorkers=2','--reporter=json','--outputFile='+str(out/'cold-full.json')]
with (out/'cold-full.log').open('w') as log:
    start=time.time()
    result=subprocess.run(cmd,cwd=root/'packages/signals',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'cold-full-command.json').write_text(json.dumps({'cmd':cmd,'cwd':str(root/'packages/signals'),'start':start,'end':time.time(),'exit':result.returncode},indent=2))
before=json.loads(pathlib.Path('/workspace/scratch/correctness-review/final/signals-retained.json').read_text())
after=json.loads((out/'cold-full.json').read_text())
def failures(report):
    return {f['name'].split('/packages/signals/')[-1]+' :: '+a['fullName'] for f in report['testResults'] for a in f['assertionResults'] if a['status']=='failed'}
old,new=failures(before),failures(after)
comparison={'before':{k:v for k,v in before.items() if k.startswith('num')},'after':{k:v for k,v in after.items() if k.startswith('num')},'addedFailures':sorted(new-old),'removedFailures':sorted(old-new)}
(out/'cold-full-comparison.json').write_text(json.dumps(comparison,indent=2))
print(json.dumps(comparison,indent=2))
