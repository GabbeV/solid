import { bundle, moduleOf } from '/workspace/layered-solid/scripts/size/bundle.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import { relative } from 'node:path';
const roots = JSON.parse(readFileSync(new URL('./roots.json', import.meta.url)));
const records = [];
for (const [name, root] of Object.entries(roots)) {
  for (const [scenario, bindings] of [
    ['core', 'createSignal, createMemo, createEffect, createRoot, flush'],
    ['optimism', 'createSignal, createMemo, createRenderEffect, createRoot, createOptimistic, action, flush'],
    ['observed optimism', 'createSignal, createMemo, createRenderEffect, createRoot, createOptimistic, action, isPending, latest, flush']
  ]) {
    const measured = await bundle({ name: scenario, path: relative('/workspace/layered-solid/scripts/size', root + '/packages/signals/dist/prod/index.js'), import: '{ ' + bindings + ' }', limit: '0 B' });
    records.push({ ...measured, name, scenario, modules: measured.modules.map(m => ({ ...m, module: moduleOf(m.id) })) });
    console.log(name, scenario, measured.min, measured.br);
  }
}
writeFileSync(new URL('./size.json', import.meta.url), JSON.stringify(records, null, 2));
