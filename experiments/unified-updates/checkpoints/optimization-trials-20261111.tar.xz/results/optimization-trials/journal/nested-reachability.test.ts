import { expect, it } from "vitest";
import { action, createMemo, createRenderEffect, createRoot, createSignal, flush } from "../src/index.js";
import { $REFRESH } from "../src/core/constants.js";
import { committedDependencies } from "../src/layers/committed-dependencies.js";

it("retains ordered frames while a parent branch first refreshes an initialized child", async () => {
  const end = Promise.withResolvers<void>();
  const [outer, setOuter] = createSignal(false);
  const [inner, setInner] = createSignal(false);
  const [oldInput] = createSignal(1), [newInput] = createSignal(2);
  const [oldChild] = createSignal(10), [newChild] = createSignal(20);
  let child!: () => number, parent!: () => number, dispose!: () => void, shown = 0;
  createRoot(d => {
    dispose = d;
    child = createMemo(() => inner() ? newChild() : oldChild());
    expect(child()).toBe(10);
    parent = createMemo(() => outer() ? newInput() + child() : oldInput());
    createRenderEffect(parent, value => { shown = value; });
  });
  const node = (f: () => unknown) => (f as any)[$REFRESH];
  const before = [...committedDependencies(node(child))];
  const running = action(function* () {
    setOuter(true);
    setInner(true);
    yield end.promise;
  })();
  flush();
  expect(shown).toBe(1);
  expect([...committedDependencies(node(child))]).toEqual(before);
  end.resolve();
  await running;
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(shown).toBe(22);
  expect([...committedDependencies(node(child))]).toEqual([node(inner), node(newChild)]);
  dispose();
  flush();
});
