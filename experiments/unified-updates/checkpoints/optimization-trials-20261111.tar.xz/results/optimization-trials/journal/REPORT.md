Partition trial: bounded implementation and real-hook reachability

Source: detached f5e7a5ce075f219832d53b81f767a26750e87597 (includes runtime correctness checkpoint d49bcd3f6). Worktree: /workspace/scratch/unified-opt-journal. Only modified tracked file: packages/signals/src/layers/committed-dependencies.ts. Clean candidate SHA-256: 9801974e823dd510ce0f3eacaf4ae84b272fc337c31aec210e8e429e7309a37d. Patch: candidate.patch. No builds, performance timings, commits or pushes.

The implementation partitions the current node's journal entries into a suffix, filters graph links against that suffix, clears its strong references, and shortens count. It preserves dependency-list order, count==0 gate, saved/uninitialized gates, error-prefix path, and commit/clear helper. Bound O(J + D*I), no Set/cache/node fields. Diff: +19/-13 lines.

Commands used (cwd worktree/packages/signals), with existing node_modules symlinks and no dependency installation:

    node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/unified-committed-dependencies.test.ts tests/unified-context-retry-error.test.ts tests/unified-owned-render-context.test.ts tests/unified-retained-publication.test.ts tests/unified-pending-error-observation.test.ts tests/unified-owner-context-retry.test.ts --maxWorkers=1 --reporter=json --outputFile=/workspace/scratch/journal-receipts/focused.json

Same command with scratch instrumentation -> instrumented-focused.json. Then:

    node /workspace/layered-solid/node_modules/vitest/vitest.mjs run 'tests/unified-' --maxWorkers=1 --reporter=json --outputFile=/workspace/scratch/journal-receipts/instrumented-unified.json
    node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/unified-journal-reachability.test.ts --maxWorkers=1 --reporter=json --outputFile=/workspace/scratch/journal-receipts/instrumented-nested.json

Results: clean focused 119/119 tests (6 files); instrumented focused 119/119; instrumented unified 885/885 (103 files); compact nested control 1/1. git diff --check passes. Broader suite includes focused selection and is not additive coverage.

Scratch instrumentation (instrumented.ts) records actual hook J/I/D, tests original whole-journal membership count and candidate suffix membership count on the same actual pre-partition hook state, compares candidate ordered snapshots against old filtering, asserts null journal tail at hook entry and no surviving own entries after park. Probes are operation counts, not timing, and candidate journal history may differ from the unmodified algorithm's journal ordering. Instrumentation is removed from worktree; clean candidate retained as candidate.ts. Scratch nested test copied out then removed from worktree.

counts.json / hooks-*.jsonl hold full receipts. Focused: 1,636 parks, 149 foreign-journal parks, 168 snapshot-eligible parks, zero eligible J>I; membership comparisons 379 -> 379. Existing error recovery genuinely produced D=2 with validated prefix=1. Unified: 27,267 parks, 1,291 foreign-journal parks, 308 eligible parks, zero eligible J>I; comparisons 914 -> 914; 45 error commits with trailing recovery links. All ordered-frame/tail invariants passed.

Compact normal nested memo example: parent switches from a scalar branch into a branch reading a new scalar and an already initialized lazy child; child switches its own scalar branch in the held action. Child real park has J=3/I=1/D=3 and membership probes 9 -> 3; parent has J=2/I=2/D=4 and probes 7 -> 7. The test asserts old committed child dependency order while held and new ordered frame after publication. This proves useful state is reachable; it does not establish representative frequency or speed. No larger workload was created.

Tradeoff: isInserted now accepts start=0, adding parameter/default initialization and a dynamic start to general committedDependencies/layerPosition membership calls too. Production bundling/JIT may eliminate some overhead, but no such claim is verified. Partition also writes two journal slots per own entry instead of merely removing it, and scans all J entries before eligibility handling. Existing suites show no membership savings. Current evidence supports correctness of this bounded candidate and reachability of its target, but does not justify adoption as a practical performance optimization without primary size/benchmark results. No semantic decisions were changed.
