# Attempt loop trial

Entry: `f5e7a5ce075f219832d53b81f767a26750e87597` (detached).
Worktree: `/workspace/scratch/unified-opt-attempt-loop`.
Only tracked change: `packages/signals/src/layers/coordination.ts` (31 insertions, 58 deletions).
Patch: `attempt-loop.patch`.

Deleted retryCalculation and the duplicated invocation/check/normalize/catch body. computeLayer now executes that body inline in one loop, returning before reset on successful attempts. Reset retains its original order and runs only between attempts. Initial setup and the outer acceptance finally are unchanged; original previousPosition remains fixed. No guards, transfer/publication logic, fields, caches, or tests changed.

Validation: 17 files, 284 tests passed, zero failed/skipped; process exit 0. Includes the six report selections plus creator delayed/async/caught retry controls, previous-input, effect-error-retry, and owned context/lifetime/migration/proposal/removal/render/repeat coverage. Exact executable command and parsed totals are in summary.json; full Vitest JSON is focused.json. git diff --check exits 0.

Falsifying cases: none observed. No new tests required: existing 72 owner-context cases and 20 catch/error-category cases cover the identified boundary risks. Existing counts/assertions were retained.

Unresolved: no production size, mangling, JIT, or throughput measurement; loop backedge could affect first-attempt performance. No full-suite claim. No suspected unrelated bug pursued. No builds, benchmarks, installs, commits, or pushes.
