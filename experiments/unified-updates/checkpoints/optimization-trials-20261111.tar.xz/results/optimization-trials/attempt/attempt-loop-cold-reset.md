# Alternative: outline retry-only reset

Patch: `attempt-loop-cold-reset.patch`, against entry `f5e7a5ce075f219832d53b81f767a26750e87597`.
Only path: `packages/signals/src/layers/coordination.ts`; 35 insertions, 52 deletions.
Neither the active trial worktree nor main runtime was edited. No worktree creation, tests, builds, profiling, or timing.

The patch replaces retryCalculation with resetCalculation, leaving one inline invocation/owner-retry/normalization/catch loop in computeLayer. A successful first attempt returns before any reset helper call. The helper consumes the discarded result rejection, chooses committed previous history when the original previousPosition differs, invalidates the flight, releases flight teardown, disposes tentative children, resets dependencies/discovery and retryEvaluation, then returns the selected previous argument. The caller clears result and the dev thrown-read marker, in their original relative order, before the next invocation.

The helper call is outside the attempt catch but inside the unchanged outer acceptance finally. Therefore reset failures still propagate without being mistaken for calculation failures. Pending ancestor retry detection, its rejection sink, receiveOwnerRetry, and ordinary-error acceptance remain unchanged. No helper allocation, field, cache, transfer/publication change, or guard deletion is introduced. The original previousPosition remains fixed across all attempts.

This is an untested shape alternative, not a performance claim. V8 or the production minifier may inline the reset helper; the loop backedge remains. Production bytes and both successful-attempt and retry-heavy throughput require separate evaluation before adoption.
