# Separate upstream scheduler fast path trial

Candidate remains uncommitted and isolated. No main checkout or pinned next checkout was modified. No dependency installation, build, timing, commit, or push ran.

- Solid worktree `/workspace/scratch/unified-opt-scheduler`: f5e7a5ce0.
- Historical next worktree `/workspace/scratch/unified-opt-scheduler-next`: 4fe75321d.
- Current next worktree `/workspace/scratch/unified-opt-scheduler-next-current`: bcef1041c.

## Plan before implementation

Compute a local landing-scope flag only after before-commit preparation, commit/trim cleanup, and lane seam processing. Keep own queues when there is no joined transaction, no transaction to judge, and no lane callback work. Skip only landing queue allocation/order/traversal and final composition. Preserve all later hooks, callback phases, and cleanup timing. Apply equivalent bounded patches to both next pins, then run direct single-worker focused Vitest with new trigger controls. No builds/timings/commits until primary scheduling.

## Exact change and applicability

Each runtime patch adds the same `composeQueues` boolean in GlobalQueue.settle after heldTrims cleanup and laneSeamsHook. It checks `t !== null || transactions.length !== 0 || !!(lanes && (lanes[0].length || lanes[1].length))`. True preserves the old landing machinery and two-slot composition verbatim. False restores `this._queues = own`, skipping the empty machinery. Solid invokes layerOrder unconditionally after queue selection, preserving its original per-seam execution and private orderPublication reset. Empty lane seam queues are therefore safe; nonempty lane callback work still composes.

Historical next's corresponding original blocks start at scheduler.ts:1109 (fresh `[[], []]` + transaction landing traversal) and :1146 (callback recomposition). Current next's corresponding original blocks start at :1146 and :1183. Both pins have precisely the same general opportunity as solid. Their transaction traversal uses blocked(u), while solid uses layerOrder/readyToPublish and a repeated landing loop. No changes were made to these nonempty paths.

The general avoided allocation/composition is upstream-applicable and must receive no experiment-specific credit. Only avoiding solid's repeated empty landing loop is specific; layerOrder dispatch is preserved. No byte or throughput improvement is claimed; a new branch may grow output or cost more on nonempty paths.

## Invariants and critical review

- Preparation reaches its existing fixed point. The guard is not computed at flush entry.
- commitPendingNodes and heldTrims cleanup occur before the guard; cleanup-created transactions take the slow path.
- laneSeamsHook still executes before judging the scope; nonempty lane work takes the slow path.
- storeCommitHook, releaseAmbientMarksHook, attribution hooks, zombie drain, boundarySeamHook, and layerSeam keep their original relative order and continue executing.
- Own render callbacks precede own user callbacks. Slow-path lane/own/landing ordering is unchanged.
- A callback that opens an action after this seam does not invalidate the local flag: it only records whether this seam needed landing queues.
- No node fields, caches, imports, transaction registries, cleanup timing, or observation readiness changes.
- On the false path, hooks between landing and composition enqueue directly onto own queues. For each phase i, call the original own queue O_i and all callbacks enqueued by store/ambient hooks H_i in enqueue order. The old path allocated an empty L_i; hooks filled L_i with H_i; nonparked/no-lane composition produced O_i.concat(H_i). The new path appends H_i directly to O_i. Their callback sequences are identical. No callbacks are run between these hooks and composition; reentrant flush is guarded by _running. A new control injects actual public scheduled render/user effect creation from both seam hooks and checks every callback exactly once, with originals delegated and hooks restored.
- Critical follow-up removed the earlier candidate's skipped empty layerOrder call. It now runs unconditionally, preserving hook lifetime exactly. There is no layerAfterCommit binding at any of the three pinned sources.
- This remains a candidate, not a landing recommendation without primary-controlled size and throughput evidence.

## Tests and receipts

Use `node ../../node_modules/vitest/vitest.mjs run <files> --maxWorkers=1 --reporter=json --outputFile=<receipt>` from each worktree's packages/signals directory. Root and package node_modules reuse `/workspace/layered-solid` dependencies through symlinks. All runs use source, dev tier; there are no production/build results.

1. `scheduler-solid-focused.json`: 61/61. Files: unified-coordination, unified-lifetime-retention, unified-experiment, unified-equality-publication, unified-fresh-mount, cleanup-write-during-landing-4089, settle-folds-queued-writes, async-cleanup-timing, unified-render-scheduling (all `.test.ts`). This includes held DOM attachment controls.
2. `scheduler-solid-controls-idle-prep.json`: 14/14. Files: scheduler-empty-landings, scheduler-empty-landings-idle, unified-owned-removal-preparation.
3. `scheduler-solid-controls-final.json`: 7/7. Files: scheduler-empty-landings, scheduler-empty-landings-idle, scheduler-empty-preparation. New controls assert exact callback order when replacement cleanup writes synchronously, cleanup opens an action, and scheduled render callback opens an action after the seam. Cleanup cases assert old and replacement frames each clean exactly once. Idle variant imports layers/layer. Explicit preparation control installs a one-shot internal before-commit hook which opens an action; all runs stay held until release.
4. `scheduler-solid-controls-baseline.json`: same 7/7 against unmodified f5e7a5ce0 scheduler in the isolated worktree. The source was restored to the patch in a Python try/finally. This establishes that new expected behavior agrees with the baseline.
5. `scheduler-next-focused.json` and `scheduler-next-current-focused.json`: 13/13 each. Files: scheduler-empty-landings, cleanup-write-during-landing-4089, settle-folds-queued-writes, async-cleanup-timing, scheduler-livelock.
6. `scheduler-next-lanes.json` and `scheduler-next-current-lanes.json`: 45/45 each. Files: scheduler-empty-landings (final cleanup assertions), lane-frame-effect-owner-4137, lane-frame-deferred-run-3662, lane-frame-held-lane-3662, async-lane-landing-equals-order, loading-on-frame-following-3540, ispending-in-boundary-on-3528.

All filenames above receive `.test.ts` in the command. summary.json contains machine-readable totals; the raw Vitest JSON receipts are retained here. `scheduler-solid-controls.json` is an earlier 3/3 control run superseded by final 7/7; it is not additional coverage.

## Artifacts

`solid-runtime.patch`, `next-runtime.patch`, and `next-current-runtime.patch` are exact patches for their pinned bases. Corresponding `*-tests.patch` add the controls. The solid patch adds nine executed cases across three files; next adds the four public controls. Patches are review artifacts, not commits. Runtime diff is +45/-38 lines in solid (mostly indentation) and +30/-23 lines in each next pin.

Primary must decide whether to land separately and schedule measurements against unmodified next; no experiment-specific ratio improvement is established by this trial.

## Critical follow-up receipts

The final solid runtime preserves layerOrder on every seam. `scheduler-solid-controls-hook-final.json` passes 9/9, including the four controls with and without the idle layer import plus explicit preparation. `scheduler-next-controls-hook-final.json` and `scheduler-next-current-controls-hook-final.json` each pass 4/4. Identical controls against each unmodified pinned scheduler pass in corresponding `*-controls-hook-baseline.json` receipts. Each baseline source replacement was confined to the candidate worktree and restored in try/finally.

The fourth common control delegates existing store/ambient hooks then creates scheduled render and user effects from those hooks. The exact log is own-render:1, store-render, ambient-render, own-user:1, store-user, ambient-user on all candidates and baselines. No callback disappears or repeats. These hook injection tests use public effect APIs, with internal hook wrapping solely to place creation precisely between landing and composition.

The first version of this test put the scheduler import ahead of index, exposing circular module initialization before any test ran. Corrected import order matches existing tests; this was a test setup failure, not evidence of an existing runtime bug or an accepted failing optimization. Final raw receipts contain successful runs.

After restoring unconditional layerOrder, `scheduler-solid-hook-revision-focused.json` passes 25/25 across unified-coordination, unified-equality-publication, and unified-owned-removal-preparation (direct Vitest, maxWorkers=1).
