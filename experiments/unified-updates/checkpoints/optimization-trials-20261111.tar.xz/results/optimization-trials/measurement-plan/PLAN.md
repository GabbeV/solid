# Reproducible optimization measurement plan

Read-only preparation against experiment entry f5e7a5ce0. No builds, runtime edits,
tests, or timings performed by this agent. Root owns serialized execution.

## Comparators and attribution

Primary baseline: unmodified next 4fe75321d61f9e4f1e1c63edc2087d099a36e9e1,
existing /workspace/layered-next-4fe75321. This is the experiment's fork anchor
and all stage182 scalar-size receipts use it. Keep it fixed to distinguish each
candidate from accumulated experiment overhead. Verify `git status --short` and
record `git rev-parse HEAD` plus candidate patch SHA before each build.

Latest inspected upstream bcef1041cb50bf648da5641693b5ebdea1fc5dc2 at
/workspace/scratch/solid-pr4717-review is a SECOND independent comparator; mixing
it into the primary series would introduce upstream changes. If reporting current
upstream, rebuild it identically and publish a separately labelled board.

Test one candidate at a time: retained experiment, inline attempt-loop,
insertion-journal partition, empty scheduler. Every headline ratio uses unmodified
next. Also show candidate/retained-experiment as attribution, not the sole claim.
The empty scheduler path is upstream-applicable; additionally apply equivalent
patch to a separate next worktree and show next-patched/next-unmodified. Any common
win is an upstream win, not proof of closing experiment-specific overhead.

## Build/config/dependency checks

Existing real dependencies resolve through /workspace/pr3886/next: Vitest 4.1.6,
Rollup 4.59.0, esbuild 0.27.7, TypeScript 6.0.3. Package node_modules is symlinked;
root node_modules contains individual symlinks. Do not install, pnpm, npx, or use
.bin wrappers. Exact binaries below exist. New worktrees do NOT acquire these
ignored links automatically; reproduce links carefully, never move/delete the
shared dependency directories. Scalar signals timing doesn't use seroval, but root
seroval is separately linked to /workspace/scratch/solid-seroval-1.7.

For each root R, in R/packages/signals, serially:

```bash
node /workspace/layered-solid/packages/signals/node_modules/rollup/dist/bin/rollup -c
node scripts/mangle-props.mjs dist/prod dist/observe
node scripts/check-pure.mjs dist/prod
node scripts/check-pure.mjs dist/observe
node /workspace/layered-solid/node_modules/typescript/bin/tsc -p tsconfig.build.json
```

Unset SIGNALS_TEST_DEFINE (shipped dist must have __TEST__ false). Build completes
only after the shared per-tree property-mangle pass and purity checks. mangle uses
one cache/domain, compress:false and reserves _name, _loc, _parent. Never run tests
or bundle consumers between rollup and mangling: stage182 had a real packaging
failure from that mistake. Fresh worktree checkout changes source mtimes, requiring
rebuild. Record Node version, binary versions, src git tree/patch, full artifact
hashes (all dist/prod JS), config/script hashes, and command/env in receipt.

The main and 4fe75321 configs and core bench fixtures currently have no diff.
SIGNALS_BENCH=dist SIGNALS_TIER=prod selects built prod, refuses missing/stale entry,
sets __TEST__ false and externalizes dist so Vite doesn't turn its imports into
namespace loads. Source benchmarks are diagnostic only. This is a preserved-module
Node view; supplemental esbuild consumer bundles below provide scope-hoisted view.

IMPORTANT: old `build.mjs --scalar` references absent scalarConfig. Old
`measure-sync.mjs` hardcodes /workspace/layered-baseline and candidate dist/scalar.
`measure.mjs --scalar` also picks dist/scalar. Do not run these unchanged or label
old preintegration receipts as current benchmarks.

## Smallest real repository benchmark board

From EACH R/packages/signals, run the identical command, replacing output label:

```bash
SIGNALS_BENCH=dist SIGNALS_TIER=prod node /workspace/layered-solid/node_modules/vitest/vitest.mjs bench --run tests/core/reactivity.bench.ts tests/core/creation.bench.ts --outputJson=/workspace/scratch/unified-opt-measurement/LABEL-core.json
```

Retain every case: signal/memo/owner/render-effect/store creation and teardown,
one-to-one writes, batched fanout, diamond, equality bailout. Pair alternating
next/candidate processes, at least 5 process pairs; a single Vitest result is not
evidence of a win. Vitest JSON has files[].groups[].benchmarks[] with name, mean,
hz, rme, samples; inspect schema rather than assuming test-reporter JSON.

Semantic limit: core `propagation:diamond` and `updateSignals:update1to1000` perform
2000 writes within ONE flush. Their names do not mean 2000 propagated updates.
They omit settled read costs and chain-per-flush. Per user preference, extend the
existing native Vitest bench file conventionally if those workloads are required;
do not resurrect the custom experiments/* measurement engine or workers.

## Missing native cases: smallest conventional additions

Search of all packages/signals/tests/**/*.bench.ts found NO createOptimistic,
action, active-layer, retry, or async-optimism benches. Existing experiment workers
are historical fixture references only, not proposed execution commands. Therefore
an honest first board can report existing ordinary cases immediately, but cannot
claim active optimism was measured until native cases are added.

Propose additions to tests/core/reactivity.bench.ts using its existing bench,
FILTER and cleanup conventions, with identical fixture files copied into every
comparison worktree (record hash; harness-only change does not modify runtime):

- settled:signalRead and settled:memoRead: fixed 10,000-access batch, retain sink,
  final expected value assertion outside timed body.
- settled:writeFlush, settled:chain20, settled:diamond, settled:fanout250:
  precreate graph and consumer; 20 repetitions per bench body of
  `flush(() => setSource(++value))`, one propagation per repetition. Assert final
  consumer value and dispose outside body. Keep old batched cases intact.
- optimism:activeSingle/direct and callback; optimism:activeChain16;
  optimism:activeFanout128; optimism:independent16: create real createOptimistic
  nodes and open generator action(s) held on deferred Promise(s) in beforeAll,
  then each timed body performs 20 `flush(() => guess(++value))` updates. Assert
  publication values after benchmark and resolve/await actions, flush and dispose
  in afterAll. Independent16 rotates writes among genuinely independent actions.
- optimism:importedIdle: same ordinary per-flush write graph with an inactive
  createOptimistic alive. Distinguish this from ordinary-only import surface.

Use public API createOptimistic, action, createMemo, createRenderEffect,
createRoot, createSignal, flush. Put async setup/teardown in native Vitest
beforeAll/afterAll, not asynchronous top-level describe. All roots must execute
identical setup and assertions before ratios are accepted. Do not measure fixture
construction inside active update bodies. Existing creation.bench.ts covers it.

Native benchmark static imports retain optimism in that bench module. For a true
ordinary-only import surface, put the active set in a separate conventional native
`tests/core/optimism.bench.ts` file instead; preferred over contaminating ordinary
reactivity.bench.ts. This remains the repo's Vitest harness, not a new engine.
If approved additions are made, expand the same command with
`tests/core/optimism.bench.ts`; no separate runner is needed.

Vitest JSON parsing (outside all timing windows):

```js
const result=JSON.parse(readFileSync(path,'utf8'));
for (const file of result.files)
 for (const group of file.groups)
  for (const bench of group.benchmarks)
   console.log(file.filepath, bench.name, bench.mean, bench.hz, bench.rme);
```

Confirm actual fields on first receipt (Vitest benchmark output is distinct from
JSON test reporter output). Compare matching names/fixtures. Use mean duration
candidate/next (lower wins), or hz next/candidate with equivalent interpretation;
never invert halfway through a board. Retain raw samples/spread and process pairs.

## Retry/journal validation gap (separate from timing)

Active update workers mostly change an already-established override; they do NOT
force context migration, retries crossing Promise/async/generator bodies, or
proposal journal adoption with created/disposed children. Therefore they cannot
establish safety or time retry-loop/journal partition costs directly. Existing
public-API regression selections are preferable to inventing a timing fixture.
Inspect unified-coordination, unified-experiment, unified-reversal, lifetime and
fresh-mount suites for agent-specific controls. Pin exact callback/request/cleanup
logs: one normal calculation; one higher-context creator retry; transfer of an
async proposal without duplicate request; interleaved holder insertion/removal;
then rerun with reversed peer order and a disposed owner. Record counts/traces as
correctness evidence only, never a performance claim.

For empty scheduler also require cleanup/preparation opening an action, preexisting
unrelated action, synchronous cleanup write, and scheduled callback opening an
action after seam; assert attached publication and render/user callback ordering,
with no optional import and imported-idle. Stage182 Show DOM attachment controls
are retained. Tests importing internal source cannot be blindly aliased to mangled
prod: mixing runtimes/private properties invalidated a historical run.

## Runtime budget and receipts

No modern throughput duration receipt found; do not promise a measured duration.
Historical stage182 signals-build.log reports Rollup dev 4.4s, prod 2.7s, observe
2.7s (~10s before postpasses/types). Documentation's older sub-5s bench claim is
not a current recorded duration for Vitest 4.1.6. There is no honest measured
current native-board duration available from inspected receipts; time the first
pair, then budget 5 pairs from that observation. New active cases must likewise
have measured first-pair duration before estimating a full board.

Run exclusive: no parallel builds, tests, profilers, or timing agents. Capture
process load before/after, Node/CPU/OS, start/end wall times. Persist JSON per
process. Do not compare historical machine timings to new ones or derive speed
from removed branches, allocations, operation counts, or bundle attribution.

## Verified native lifecycle correction (supersedes proposed suite hooks above)

Installed Vitest 4.1.6 `dist/chunks/test.DNmyFkvJ.js:4177` native
runBenchmarkSuite does not call beforeAll/afterAll hooks. This affects top-level
and nested hooks alike; describe nesting and CodSpeed are not the root cause.
Missing setup caused undefined accessor/setter errors in Tinybench warmup.
Tinybench 2.9.0 defaults throws:false, saves warmup error, then returns early from
run without complete event; Vitest leaves placeholder benchmark JSON and exits0.

Fixed owned fixtures register top-level bench calls with native Tinybench
options.setup/options.teardown and throws:true. setup is awaited; teardown is
NOT awaited by Tinybench 2.9, so teardown is strictly synchronous. Active awaited
setup runs full lifecycle preflight from the exact same factory (held guesses,
microtask persistence, correction to completed source, exactly one cleanup), then
creates timing fixture. Timing teardown checks held values, disposes root and
releases action synchronously. Next fixture awaits previous released action before
opening another. No fire-and-forget validation or assertion callbacks. Measured
final correction is not claimed awaited; full correction belongs to preflight.

One exclusive smoke process per root, no builds, exit0 on next and entry:

```
SIGNALS_BENCH=dist SIGNALS_TIER=prod node /workspace/layered-solid/node_modules/vitest/vitest.mjs bench --run tests/core/settled.bench.ts tests/core/optimism.bench.ts --maxWorkers=1 --outputJson=/workspace/scratch/unified-opt-measurement/fixed-LABEL.json
```

Run cwd is ROOT/packages/signals. Both JSON receipts have all 11 finite means,
minimum sampleCount 249 (next) / 140 (entry). This validates harness execution and
fixture assertions, not performance improvement. Raw `samples` is intentionally
stripped by default config: require finite mean AND sampleCount>0. To retain raw
samples requires benchmark.includeSamples in configuration; installed CLI rejects
--benchmark.includeSamples (one initial attempt failed before running).
