import { expect, it } from "vitest";
import { createSignal, createRoot, createMemo, createRenderEffect, flush } from "../src/index.js";
it("ordinary initialized source with newly mounted async consequence", async () => {
  const [source] = createSignal(1), [tick, setTick] = createSignal(0);
  const end = Promise.withResolvers<void>();
  let preview: number | undefined, doubled: number | undefined, late: number | undefined;
  let output!: () => number;
  const dispose = createRoot(dispose => {
    output = createMemo(source);
    const twice = createMemo(() => {const value = output()*2; return end.promise.then(()=>value);});
    createRenderEffect(() => {tick(); return output();}, value=>{preview=value;}, {schedule:true});
    createRenderEffect(twice, value=>{doubled=value;}, {schedule:true});
    return dispose;
  });
  flush(); expect([preview,doubled]).toEqual([undefined,undefined]);
  setTick(1);
  const disposeLate = createRoot(dispose => {createRenderEffect(output,value=>{late=value;},{schedule:true});return dispose;});
  flush(); expect([preview,doubled,late]).toEqual([1,undefined,1]);
  end.resolve(); await new Promise(r=>setTimeout(r,0));flush();
  expect([preview,doubled,late]).toEqual([1,2,1]);
  disposeLate();dispose();
});
