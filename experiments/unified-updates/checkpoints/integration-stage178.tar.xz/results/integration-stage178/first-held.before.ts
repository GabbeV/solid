import { expect, it } from "vitest";
import {
  action,
  createMemo,
  createRenderEffect,
  createRoot,
  createSignal,
  flush,
  latest
} from "../src/index.js";

const turn = async () => {
  await new Promise<void>(resolve => setTimeout(resolve, 0));
  flush();
};

for (const asyncInput of [false, true])
  for (const wrapped of [false, true])
    it(`latest exposes a ready first held value (async input=${asyncInput}, wrapped=${wrapped})`, async () => {
      const end = Promise.withResolvers<void>();
      const answer = Promise.withResolvers<void>();
      const [source, setSource] = createSignal(0);
      let inputShown = 0;
      let preview: number | undefined;
      let doubled: number | undefined;
      const dispose = createRoot(dispose => {
        createRenderEffect(source, value => {
          inputShown = value;
        });
        return dispose;
      });
      flush();
      const running = action(function* () {
        setSource(1);
        yield end.promise;
      })();
      flush();
      const disposeLate = createRoot(dispose => {
        const born = createMemo(() => {
          const value = source();
          return asyncInput ? answer.promise.then(() => value) : value;
        });
        const output = wrapped ? createMemo(() => latest(born)) : () => latest(born);
        const twice = createMemo(() => output() * 2);
        createRenderEffect(
          output,
          value => {
            preview = value;
          },
          { schedule: true }
        );
        createRenderEffect(
          twice,
          value => {
            doubled = value;
          },
          { schedule: true }
        );
        return dispose;
      });
      try {
        flush();
        if (asyncInput) {
          expect([inputShown, preview, doubled]).toEqual([0, undefined, undefined]);
          answer.resolve();
          await turn();
        }
        expect([inputShown, preview, doubled]).toEqual([0, 1, 2]);
        end.resolve();
        await running;
        await turn();
        expect([inputShown, preview, doubled]).toEqual([1, 1, 2]);
      } finally {
        disposeLate();
        dispose();
        answer.resolve();
        end.resolve();
        await running;
        await turn();
      }
    });
