import { pathToFileURL } from 'node:url';
const { createSignal, createMemo, createRenderEffect, createRoot, action, flush, latest } = await import(pathToFileURL(process.argv[2]));
const done = Promise.withResolvers();
const seen = [];
const [x, setX] = createSignal(0);
const dispose = createRoot(dispose => {
  createRenderEffect(x, x => { seen.push(['x', x]); });
  return dispose;
});
flush();
const running = action(function* () { setX(1); yield done.promise; })();
flush();
const disposeLate = createRoot(dispose => {
  const born = createMemo(x);
  createRenderEffect(() => latest(born), value => { seen.push(['latest born', value]); });
  return dispose;
});
flush();
console.log('held', JSON.stringify(seen));
done.resolve(); await running;
await new Promise(resolve => setTimeout(resolve, 0)); flush();
console.log('released', JSON.stringify(seen));
disposeLate(); dispose();
