import { bundle, moduleOf, scenarios } from '../../../../scripts/size/bundle.mjs';
import { writeFileSync } from 'node:fs';
import { relative } from 'node:path';
import { fileURLToPath } from 'node:url';
const roots = { next: '/workspace/layered-next-4fe75321', experiment: '/workspace/layered-solid' };
const records = [];
for (const [name, root] of Object.entries(roots)) {
  for (const [scenario, bindings] of [
    ['core', 'createSignal, createMemo, createEffect, createRoot, flush'],
    ['optimism', 'createSignal, createMemo, createRenderEffect, createRoot, createOptimistic, action, flush'],
    ['observed optimism', 'createSignal, createMemo, createRenderEffect, createRoot, createOptimistic, action, isPending, latest, flush']
  ]) {
    const measured = await bundle({name: scenario, path: relative('/workspace/layered-solid/scripts/size', root + '/packages/signals/dist/prod/index.js'), import: '{ ' + bindings + ' }', limit: '0 B'});
    records.push({...measured, name, scenario, modules: measured.modules.map(m=>({...m, module: moduleOf(m.id)}))});
  }
}
writeFileSync(fileURLToPath(new URL('./size-scalar.json', import.meta.url)), JSON.stringify(records,null,2));
for (const r of records) console.log(r.name,r.scenario,r.min,r.br);
