import { mergeConfig } from "vitest/config";
import config from "./vite.config.ts";
export default mergeConfig(config({mode:"test", command:"serve"} as any), {
  resolve: {alias: [{find: /\.\.\/src\/index\.js$/, replacement: process.env.TRACE_DIST!}]},
  test: {server: {deps: {external: [/\/dist\//]}}}
});
