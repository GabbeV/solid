import {it,expect} from 'vitest';
import {action,createMemo,createOptimistic,createOptimisticStore,createRenderEffect,createRoot,flush,isPending} from '/workspace/scratch/solid-pr4717-review/packages/signals/src/index.ts';
const turn=()=>new Promise(r=>setTimeout(r,0));
for(const kind of ['scalar','store'] as const)it(kind+' exact 4c timeline',async()=>{
 const answers:(()=>void)[]=[];let calls=0;const fetch=(v:number)=>{calls++;return new Promise<number>(r=>answers.push(()=>r(v*2)))};const resolve=()=>{for(const r of answers.splice(0))r()};
 let read:()=>number,write:()=>void;if(kind==='scalar'){const [a,b]=createOptimistic(10);read=a;write=()=>b(15)}else{const [a,b]=createOptimisticStore({data:10});read=()=>a.data;write=()=>b(d=>{d.data=15})}
 let derived!:()=>number;const dispose=createRoot(d=>{derived=createMemo(()=>fetch(read()));createRenderEffect(derived,()=>{});return d});
 const gate=Promise.withResolvers<void>();let running;
 const trace=(phase:string)=>{let callback:number|undefined;const pending=isPending(()=>{callback=read();return callback});const row={phase,value:read(),callback,pending,derived:derived(),derivedPending:isPending(derived),calls};console.log(JSON.stringify({kind,...row}));return row};
 try{flush();resolve();await turn();flush();trace('initial');running=action(function*(){write();yield gate.promise})();flush();trace('guess held');resolve();await turn();flush();trace('guess published action open');gate.resolve();await running;await turn();flush();trace('correction held');resolve();await turn();flush();trace('done');}
 finally{resolve();gate.resolve();await running;await turn();dispose();flush()}
});
