import {it,expect} from 'vitest';
import {createStore,flush} from '/workspace/layered-solid/packages/signals/src/index.ts';
for(const key of ['toString','constructor'])it('ordinary delete '+key,()=>{
 const custom=()=>123;const input=Object.defineProperty({},key,{value:custom,enumerable:true,configurable:true,writable:true});const [s,set]=createStore(input);
 set(d=>{delete (d as any)[key]});flush();console.log('ordinary delete',key,(s as any)[key],key in s,Object.getOwnPropertyDescriptor(s,key));expect((s as any)[key]).toBe(Reflect.get(Object.prototype,key,{}));expect(Object.hasOwn(s,key)).toBe(false);
});
it('ordinary add toString undefined',()=>{const [s,set]=createStore({});set(d=>{(d as any).toString=undefined});flush();expect((s as any).toString).toBeUndefined();expect(Object.hasOwn(s,'toString')).toBe(true)});
