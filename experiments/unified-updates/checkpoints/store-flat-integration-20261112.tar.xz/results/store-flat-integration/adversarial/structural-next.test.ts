import {it,expect} from 'vitest';
import {action,createOptimisticStore,createRenderEffect,createRoot,flush} from '/workspace/scratch/solid-pr4717-review/packages/signals/src/index.ts';
const turn=()=>new Promise(r=>setTimeout(r,0));
for(const key of ['toString','constructor','__proto__'])it('delete own '+key+' reveals inherited value',async()=>{
 const custom=()=>123;const input=Object.defineProperty({},key,{value:custom,enumerable:true,configurable:true,writable:true});const [s,set]=createOptimisticStore(input);const gate=Promise.withResolvers<void>();let observed:any;
 const d=createRoot(d=>{createRenderEffect(()=>[(s as any)[key],key in s,Object.keys(s).includes(key)],v=>{observed=v});return d});let running;
 try{flush();expect((s as any)[key]).toBe(custom);running=action(function*(){set(x=>{delete (x as any)[key]});yield gate.promise})();flush();console.log(key,observed,(s as any)[key],key in s,Object.getOwnPropertyDescriptor(s,key));expect((s as any)[key]).toBe(Reflect.get(Object.prototype,key,{}));expect(observed[0]).toBe(Reflect.get(Object.prototype,key,{}));expect(key in s).toBe(true);expect(Object.getOwnPropertyDescriptor(s,key)).toBeUndefined();}
 finally{gate.resolve();await running;await turn();d();flush()}
});
for(const initial of [false,true])it('undefined presence '+initial,async()=>{
 const [s,set]=createOptimisticStore(initial?{x:undefined}:{});const gate=Promise.withResolvers<void>();let running;
 try{flush();running=action(function*(){set(x=>{if(initial)delete (x as any).x;else (x as any).x=undefined});yield gate.promise})();flush();expect('x' in s).toBe(!initial);expect(Object.hasOwn(s,'x')).toBe(!initial);expect(Object.keys(s)).toEqual(initial?[]:['x']);expect((s as any).x).toBeUndefined();}
 finally{gate.resolve();await running;await turn();flush();expect('x' in s).toBe(initial)}
});
for(const key of ['toString','constructor','__proto__'])it('add own undefined '+key+' shadows inherited value',async()=>{
 const [s,set]=createOptimisticStore({});const gate=Promise.withResolvers<void>();let running;
 try{flush();running=action(function*(){set(x=>{Object.defineProperty(x,key,{value:undefined,enumerable:true,configurable:true,writable:true})});yield gate.promise})();flush();console.log('add undefined',key,(s as any)[key],Object.getOwnPropertyDescriptor(s,key));expect(Object.hasOwn(s,key)).toBe(true);expect(Object.keys(s)).toContain(key);expect((s as any)[key]).toBeUndefined();expect(Object.getOwnPropertyDescriptor(s,key)!.value).toBeUndefined();}
 finally{gate.resolve();await running;await turn();flush()}
});
