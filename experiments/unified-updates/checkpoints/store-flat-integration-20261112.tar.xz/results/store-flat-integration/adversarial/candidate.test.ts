import {expect,it} from 'vitest';
import {action,createMemo,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush} from '/workspace/scratch/unified-store-groups/packages/signals/src/index.ts';
const turn=()=>new Promise(r=>setTimeout(r,0));
for(const mode of ['keys','reflect','descriptors'] as const) it(mode+' unrelated rerun is not held by pending values',async()=>{
 const end=Promise.withResolvers<void>(), answer=Promise.withResolvers<number>();
 const [s,set]=createOptimisticStore({a:0,b:0}); const [tick,setTick]=createSignal(0); const shown:number[]=[];
 const dispose=createRoot(dispose=>{
  const derived=createMemo(()=>s.a?answer.promise:0); createRenderEffect(derived,()=>{});
  createRenderEffect(()=>{const t=tick();if(mode==='keys')Object.keys(s);else if(mode==='reflect')Reflect.ownKeys(s);else Object.getOwnPropertyDescriptors(s);return t;},v=>{shown.push(v)}); return dispose;
 });
 let running;
 try {flush(); running=action(function*(){set(d=>{d.a=1});yield end.promise;})();flush();setTick(1);flush();expect(shown.at(-1)).toBe(1);}
 finally{answer.resolve(1);end.resolve();await running;await turn();dispose();flush();}
});
it('same-value setter keeps its own action lifetime',async()=>{
 const ea=Promise.withResolvers<void>(),eb=Promise.withResolvers<void>();const [s,set]=createOptimisticStore({a:0});
 const dispose=createRoot(dispose=>{createRenderEffect(()=>s.a,()=>{});return dispose});let a,b;
 try{flush();a=action(function*(){set(d=>{d.a=1});yield ea.promise;})();flush();b=action(function*(){set(d=>{d.a=1});yield eb.promise;})();flush();ea.resolve();await a;await turn();flush();expect(s.a).toBe(1);eb.resolve();await b;await turn();flush();expect(s.a).toBe(0);}
 finally{ea.resolve();eb.resolve();await Promise.all([a,b]);await turn();dispose();flush();}
});
for(const mode of ['none','keys','reflect','descriptors'] as const)it(mode+' pending consequence does not block unrelated value publication',async()=>{
 const ea=Promise.withResolvers<void>(),va=Promise.withResolvers<number>(),vk=Promise.withResolvers<number>();const [s,set]=createOptimisticStore({a:0,b:0});const [tick,setTick]=createSignal(0);let shown=-1;
 const dispose=createRoot(dispose=>{
  const da=createMemo(()=>s.a?va.promise:0);createRenderEffect(da,()=>{});createRenderEffect(()=>s.a,v=>{shown=v});
  const dk=createMemo(()=>{const t=tick();if(mode==='keys')Object.keys(s);else if(mode==='reflect')Reflect.ownKeys(s);else if(mode==='descriptors') Object.getOwnPropertyDescriptors(s);return t?vk.promise:0});createRenderEffect(dk,()=>{});return dispose;
 });let running;
 try{flush();running=action(function*(){set(d=>{d.a=1});yield ea.promise;})();flush();setTick(1);flush();va.resolve(10);await turn();flush();expect(shown).toBe(1);}
 finally{ea.resolve();va.resolve(10);vk.resolve(1);await running;await turn();dispose();flush();}
});
it('disposing only suspended reader releases grouped publication',async()=>{
 const e=Promise.withResolvers<void>(),v=Promise.withResolvers<number>();const [s,set]=createOptimisticStore({a:0,b:0});const shown=[-1,-1];
 const d=createRoot(d=>{createRenderEffect(()=>s.a,x=>{shown[0]=x});createRenderEffect(()=>s.b,x=>{shown[1]=x});return d});
 const blocker=createRoot(d=>{const x=createMemo(()=>s.a?v.promise:0);createRenderEffect(x,()=>{});return d});let running;
 try{flush();running=action(function*(){set(d=>{d.a=1;d.b=1});yield e.promise;})();flush();expect(shown).toEqual([0,0]);blocker();flush();expect(shown).toEqual([1,1]);}
 finally{e.resolve();v.resolve(10);await running;await turn();blocker();d();flush();}
});
it('one setter retirement holds all corrected outputs through async correction',async()=>{
 const e=Promise.withResolvers<void>(),v=Promise.withResolvers<number>();const [s,set]=createOptimisticStore({a:0,b:0});let correction=false;const shown=[-1,-1,-1];
 const d=createRoot(d=>{const x=createMemo(()=>s.a===0&&correction?v.promise:s.a*10);createRenderEffect(()=>s.a,x=>{shown[0]=x});createRenderEffect(()=>s.b,x=>{shown[1]=x});createRenderEffect(x,x=>{shown[2]=x});return d});let running;
 try{flush();running=action(function*(){set(d=>{d.a=1;d.b=1});yield e.promise;})();flush();expect(shown).toEqual([1,1,10]);correction=true;e.resolve();await running;await turn();flush();expect(shown).toEqual([1,1,10]);v.resolve(0);await turn();flush();expect(shown).toEqual([0,0,0]);}
 finally{e.resolve();v.resolve(0);await running;await turn();d();flush();}
});
