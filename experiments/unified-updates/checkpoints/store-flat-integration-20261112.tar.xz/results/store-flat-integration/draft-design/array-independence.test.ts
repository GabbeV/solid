import { expect, test } from 'vitest';
import { action, createOptimisticStore, createRenderEffect, createRoot, createSignal, deep, flush } from 'probe-runtime';
const turn = async () => {await new Promise<void>(resolve => setTimeout(resolve, 0)); flush();};
for (const reader of ['indices', 'keys', 'iteration', 'deep']) {
  test(`disjoint existing array indices, ${reader}`, async () => {
    const gateA = Promise.withResolvers<void>(), gateB = Promise.withResolvers<void>();
    const [s, set] = createOptimisticStore([0, 0]);
    const [truthA, setTruthA] = createSignal(0), [truthB, setTruthB] = createSignal(0);
    const shown = {a: -1, b: -1, truthA: -1, truthB: -1};
    let extra: unknown;
    const dispose = createRoot(dispose => {
      createRenderEffect(() => s[0], v => {shown.a = v});
      createRenderEffect(() => s[1], v => {shown.b = v});
      createRenderEffect(truthA, v => {shown.truthA = v});
      createRenderEffect(truthB, v => {shown.truthB = v});
      if (reader === 'keys') createRenderEffect(() => Object.keys(s), v => {extra = v});
      if (reader === 'iteration') createRenderEffect(() => [...s], v => {extra = v});
      if (reader === 'deep') createRenderEffect(() => {const d = deep(s); return [d[0], d[1]]}, v => {extra = v});
      return dispose;
    });
    const timeline: unknown[] = [];
    const record = (phase: string) => {timeline.push({phase, ...shown, extra})};
    try {
      flush(); record('initial');
      const a = action(function* () {setTruthA(1); set(d => {d[0] = 1}); yield gateA.promise;})();
      flush(); await turn(); record('A guessing');
      const b = action(function* () {setTruthB(2); set(d => {d[1] = 2}); yield gateB.promise;})();
      flush(); await turn(); record('A and B guessing');
      expect([shown.a, shown.b]).toEqual([1, 2]);
      gateA.resolve(); await a; await turn(); record('A completed, B open');
      gateB.resolve(); await b; await turn(); record('both completed');
      expect([shown.a, shown.b, shown.truthA, shown.truthB]).toEqual([0, 0, 1, 2]);
      console.log(JSON.stringify({reader, timeline}));
    } finally {gateA.resolve(); gateB.resolve(); dispose(); flush();}
  });
}
