# Reuse the store draft engine before expanding shapes

Read-only architecture review, 2026-11-12. No runtime code changed.

## Recommended wiring

1. Keep `createProjectionInternal(null, seed, options, true)` as the constructor. Replace the isolated plain-object setter with a thin wrapper around existing `storeSetter(store, callback)`. This restores actual draft proxy traps, constructor/pollution rules, external-read tracking, write guards, native array methods and existing wrapping/identity caches. Do not implement another recursive draft proxy.
2. Generalize the current companion record lazily per StoreTarget, not recursively at constructor time. `read`, `view`, `draft`, `writes`, `has`, `descriptor` and `deep` can ensure a target's record on demand. Children already share the family through `wrap`; use existing getNode/getHasNode/getContainerNode truth inputs and source-owned scalar companions. Preserve raw child identity and `$OWNER`/lookupTarget semantics. Never deep-copy child values.
3. Implement `OptHooks.draft` using existing `cloneRaw` over the selected *writer* view, with `writerValue()` including unflushed proposals. Save any displaced incoming staging plus its associated flags; restore it when writes are translated. The minimum correctness implementation reuses the existing optimisticDraft strategy. Preserve/restore `pb`, overlay/deletion state and written metadata rather than allowing draft state to corrupt incoming truth. Keep unsupported derived/chained inputs rejected for this first refactor.
4. Translate only the optimistic user arm of `notifyWrites` into scalar proposals. Capture existing `t.wk` before that arm currently clears it, and pass a nullable written-key bound into `OptHooks.writes`; expose the existing WK_ALL-as-full-scan meaning without duplicating mutation recording. Deletions and array-length truncation need their existing metadata. Read old descriptor/value from the saved writer frame, new descriptor/value from the actual draft; use store identity comparisons, not raw recursive content equality. Existing normal `notifyWrites` remains the source for value/presence/container classification; share small comparison helpers rather than copying its entire pipeline.
5. Add a narrowly scoped collector around the existing proposal-group machinery, e.g. `withOptimisticSlotBatch(() => storeSetter(...))`. Existing `proposeOptimisticSlots` should still propose immediately, but append their existing layer identities to the current writer group; finalize that group in `finally` at the outermost wrapper exit. This covers every touched target and the current post-notification returned replacement without a new scheduler or recorder. Immediate proposal submission matters: a returned replacement must see earlier writes via writerValue, including resetting a provisional mutation back to its original value. Deferring all proposal submission until after replacement diff would lose that reset. Nested wrappers must reuse the outer publication collector while retaining normal draft-scope behavior.
6. Continue composing structural frames from selected per-property outputs for plain records. Enumerators subscribe only to selected structure. Standalone descriptors keep next's presence-only subscription contract. Deep walks selected child identities through the existing store walker and reads their companions; it never proposes a synthetic deep source, per the user's independence ruling.

No new store graph or scheduler is required. Same-setter cross-target publication uses the already accepted scalar proposal grouping.

## Cost caveat

The old optimisticDraft in both entry and bcef already clones the selected writer backing. Merely routing through storeSetter does not make first draft creation O(written). Passing existing `wk` makes diff/notification bounded; cloneRaw can still cost O(width). A real overlay optimization should factor the existing normal ensurePB allocator to accept a selected writer base. Existing overlay materialization/deletion helpers assume `t.v` is that base; they cannot simply be reused over another prototype without auditing and parameterizing those assumptions. Avoid claiming an O(written) setter until that work is complete. This is a follow-up optimization inside the existing allocator, not justification for keeping an isolated full-copy setter.

## Established behavior and remaining blockers

- Parent approved restoring ordinary/next pre-throw semantics: storeSetter emits synchronous writes in `finally` even if the callback throws. The flat milestone's isolated validation rollback was not a general semantic ruling. Keep validation of still-unsupported surfaces concrete, but do not globally make valid store writes transactional rollback.
- Existing traps supply inherited constructor suppression inside drafts, ignored `__proto__` mutation, getters with proxy receiver and descriptor handling. Do not port the flat raw-object draft's different behavior.
- Entry's returned optimistic replacement is diffed after mutation notification; bcef moves replacement into the draft using keyed reconcile (S-59/#4724). Do not import that keyed policy in the initial nested-record refactor. The publication wrapper can safely span the current two phases without choosing replacement identity semantics now.
- Accessor changes must use the existing descriptor/accessor metadata and FORCE wake behavior; value companions alone do not model getter evaluation. They can remain an explicit temporary unsupported surface while the common draft pipeline is established.
- Primitive arrays have a real next-version policy distinction below. Resolve it before choosing a shared guessed-container strategy. Nested records can proceed independently.

## Matched disjoint existing array-index comparison

`array-independence.test.ts` runs four reader variants: separate index bindings, plus optional Object.keys, iteration, or deep. Two separate events guess `s[0] = 1` and `s[1] = 2`, with a real timer turn after each flush. Each action also writes its own ordinary signal, so output retention and action transaction entanglement can be distinguished. No latest/untracked diagnostics, until, snapshots or manual microtask drains.

All four variants pass on both next `4fe75321d` and `bcef1041c`. The tests assert initial/published guesses and final retirement; intermediate observations are recorded without asserting an unestablished common policy.

After A completes while B remains open:

| Revision | Readers | Visible array | Ordinary A signal |
| --- | --- | --- | --- |
| 4fe | indices / keys / iteration / deep | `[1, 2]` | `0` (held) |
| bcef | indices / keys / iteration | `[1, 2]` | `1` (published) |
| bcef | deep | `[1, 2]` | `0` (held) |

After both complete, all variants show array `[0, 0]` and ordinary signals `[1, 2]`.

Source explanation: 4fe writes each array arrangement to the same guessed container, merging its action transactions even without a deep reader. Bcef owns separate carriers for disjoint changed keys; array `g` makes later arrangement frames cover index/length reads, retaining A's displayed element in B's arrangement after A's own action completed. The synthetic deep witness still merges bcef's underlying transactions when deep is present. The user's deep ruling removes that last cause, but does not itself decide array arrangement inheritance.

A single shared scalar container output would reproduce 4fe's underlying action entanglement and differ from bcef's non-deep action lifetime. Independent per-index selection alone would show `[0, 2]` after A, differing from both revisions' visible array. Thus arrays need an explicit structural arrangement policy; it cannot be presented as a mechanical extension of flat-record slots.

Receipts: `next4fe.log`, `nextbcef.log`, with `probe.config.mts`. Reproduce from `/workspace/layered-solid` using the config's original scratch path (or update include after relocating):

```
PROBE_RUNTIME=/workspace/layered-next-4fe75321/packages/signals/src/index.ts node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config /workspace/scratch/store-draft-design/probe.config.mts --silent=false --reporter=verbose
PROBE_RUNTIME=/workspace/scratch/solid-pr4717-review/packages/signals/src/index.ts node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config /workspace/scratch/store-draft-design/probe.config.mts --silent=false --reporter=verbose
```
