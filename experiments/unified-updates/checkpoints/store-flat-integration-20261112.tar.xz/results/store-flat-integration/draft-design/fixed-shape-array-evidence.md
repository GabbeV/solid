# Fixed-shape primitive array evidence

Narrow source/docs/test review of next `bcef1041c`; no implementation changes.

## Explicit contract evidence

I found **no explicit test or ruling requiring a whole-array arrangement snapshot for two fixed-shape primitive edits** (`[0,0]`, A changes index 0, B changes index 1). The matched runtime probe demonstrates current behavior, not intended policy.

The strongest explicit text points toward per-index ownership:

- `packages/signals/docs/RULES-DERIVED.md:219`, D-33: “a top-level `d[i] = x`, or a returned top-level array, is one write per index that differs ... the list itself is the slot only when its keys or length changed”. It attributes the point-of-write ruling to 2026-11-08, #4724, S-59. This is repository ruling text; this narrow review did not recover a direct Ryan comment, so do not represent it as a newly verified quotation from Ryan.
- `packages/web/test/optimistic-store-guess-point-of-write-4724.spec.tsx:5` states a rewritten top-level array with unchanged keys/length is one write per changed index, “never a guess on the list”. The executable pin is a **keyed derived object-row list with refresh and error forwarding**, comparing nested field mutation and a whole-array rewrite. It does not directly test independent retirement of fixed-shape primitive indices.
- `packages/signals/docs/SCENARIOS.md:1630`, S-59, records that keyed scenario and explicitly rejects escalating one changed row to a shared list guess. At line 1639: carried rows are not writes, so the two guesses share no slot. Again, its visible witness is refresh/error behavior, not the primitive index retirement case.
- `packages/web/test/optimistic-store-return-guess-4737.spec.tsx:5` repeats per-index wording for returned arrays. Its cases also concern keyed derived lists, field-versus-return equivalence and refresh/error behavior.
- `packages/signals/docs/rules-mining/core-store.md:68`, R15, requires uniform structural **invalidation** for array update idioms. It does not state that notification overlap transfers optimistic ownership or preserves another action's expired value.

Therefore D-33 supports independent ownership in the primitive shape, and current bcef already reflects that in the ordinary-signal witness (without deep). The separate question is whether copying A's value into B's arrangement should continue its **visible retention** after A ends. No direct fixed-shape primitive pin for that extra retention was found.

## Exact bcef cause of retaining A in B's displayed frame

All source references below are `packages/signals/src/store/optimistic.ts` on bcef:

1. `writerBacking` (169–173) calls `guessView(..., true)`. `guessView` (186–194) returns the newest live/pending guessed **whole frame**. `optimisticDraft` (210–212) clones that frame. Thus B starts from `[1,0]`, and B's draft becomes `[1,2]` even though B changes only index 1.
2. `notifyOptimisticWrites` (337–345) records only changed key `1`, but **any changed array element** also sets `structural = true`; unchanged length and membership do not prevent this.
3. `guessCarrier` (219–234) selects distinct carriers when changed-key sets do not overlap and no unflushed guess is shared. This accounts for independent underlying action transactions in the non-deep bcef probe.
4. `structural && isArr` (366–367) builds a full rows frame; `g.g = rows` at 399 enables arrangement coverage. `optimisticWrite(g, () => pb)` at 411 stores the whole B frame `[1,2]`.
5. `guessFor` (127–137) scans newest-first. Besides actual changed/deleted keys, its read arm (133–135) accepts **every numeric index and length** whenever `g.g !== undefined`. B's carrier therefore answers index 0 even though `g.wk` contains only index 1.
6. Hook `read` (799–806) reads that carrier's frame and returns `carrierValue(frame, key)`. After A's own action/carrier retires, B's surviving full frame still serves `1` at index 0.

This mechanism also supports meaningful arrangements, reorder, length changes and keyed rebasing. Its broad “any array element changed” activation is what extends that behavior to the fixed-shape primitive case. Source comments describing list entry and rebase explain the mechanism; they are not an explicit fixed-shape primitive retention ruling.
