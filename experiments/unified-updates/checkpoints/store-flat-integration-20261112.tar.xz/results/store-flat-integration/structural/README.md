# Flat structural optimistic-store candidate

Candidate: `/workspace/scratch/unified-store-groups`, based on original dirty grouped static slice over `743bfbd11`. Runtime source frozen after 19 candidate tests passed. No commits, pushes, installs or benchmarks. Main runtime untouched.

`delta.patch` is the exact delta against the original grouped candidate (starting source copies were saved before edits under `/tmp/store-structure-base`). Complete changed source/test files are in `source/`. The parent may already have formatted its copy of optimistic-static.ts, so use the complete source for that file if exact patch context differs. Do not replace unrelated parent tests.

The extension uses existing store-owned value, presence and container inputs with scalar optimistic output companions. Changed outputs from one setter share `proposeOptimisticSlots`; key-set/order/enumerability changes write the container, existing-value-only writes do not. Enumeration composes selected property outputs over selected structure, so container backing values cannot leak stale guesses. Deep only reads selected outputs and never writes a shared guessed witness.

Hook sites: optional `OptHooks.node` reports selected subscription identity for `observerHoldsContainer`; existing `read` routes tracked presence, descriptor presence, enumeration and `$TRACK` reads. Standalone descriptor tracking remains presence-only. Descriptor values and flags are selected correctly when evaluated.

Supported slice: flat plain mutable data records, additions/deletions including present-undefined, key order including integers/symbols, null prototypes, non-enumerable mutable data properties. Accessors, immutable descriptors, nested values, arrays, derived/chained inputs, shallow options, reconciliation and later integration surfaces remain explicitly unsupported.

## Validation

From `/workspace/scratch/unified-store-groups/packages/signals`:

```
node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/unified-optimistic-store-structure.test.ts tests/unified-optimistic-static-store.test.ts tests/unified-optimistic-store-writer-group.test.ts tests/unified-optimistic-api.test.ts tests/unified-optimistic-pending.test.ts tests/unified-optimistic-cancellation.test.ts tests/store/enumerator-presence-nodes.test.ts
```

Initial frozen run: 67 passed, one failed internal raw-input subscriber-count expectation. Runtime behavior passed. `targeted-tests.txt` retains that original receipt.

`enumerator-test-migration.patch` adapts that existing test's internal counts to selected outputs; it preserves zero presence readers and one container reader, accounting for the required scalar input-companion subscription. With that migration: **68 passed / 7 files**, captured in `targeted-with-migrated-internal-counts.txt`.

Additional unchanged upstream flat controls:

```
node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/optimistic-store-layer-scope.test.ts -t 'first-settling action|same-key writes entangle|delete under a concurrent|ambient write reverts'
node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/optimistic-undefined-override.test.ts -t '4:|5:'
```

Results: 4 passed / 1 excluded nested test; 2 passed / 4 excluded scalar/array tests.

```
node /workspace/layered-solid/node_modules/typescript/bin/tsc -p tsconfig.build.json --noEmit --emitDeclarationOnly false --pretty false
```

Source-only TypeScript passes (empty `source-typecheck.txt`, exit 0). Full package tsc was also attempted; it reports numerous existing test typing/missing dist errors and is not claimed passing. Two local source errors exposed during that run were corrected before freezing; source-only check rerun clean. `git diff --check` passes.
