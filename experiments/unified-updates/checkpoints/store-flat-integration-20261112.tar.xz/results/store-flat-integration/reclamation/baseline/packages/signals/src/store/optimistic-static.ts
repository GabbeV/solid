/** Interim shared-engine slice: flat plain records with per-property cuts.
 * Truth slots stay store-owned; only their selected outputs accept guesses. */
import { read, untrack, writeHook } from "../core/core.js";
import type { Signal } from "../core/types.js";
import { createOptimisticSlot, proposeOptimisticSlots } from "../layers/optimistic.js";
import { getNode, getHasNode, getContainerNode, devGuardStoreSetterWrite, devGuardStoreSetterResult } from "./store.js";
import { createProjectionInternal } from "./projection.js";
import type { OptHooks } from "./hooks.js";
import type { StoreTarget } from "./target.js";
import { $TARGET, isWrappable } from "./types.js";
import { $OWNER } from "./target.js";

type Slot = ReturnType<typeof createOptimisticSlot>;
type RecordSlots = {
  slots: Map<PropertyKey, Slot>;
  presence: Map<PropertyKey, Slot>;
  nodes: Map<Signal<any>, Slot>;
  container: Slot;
  prototype: object | null;
};
const records = new WeakMap<StoreTarget, RecordSlots>();
const unsupported = () => new Error(
  "Shared-engine optimistic stores currently support only flat plain records with mutable data properties; derived, nested, array, accessor and immutable descriptor changes are not integrated yet."
);

function validate(value: any, expected?: RecordSlots): PropertyKey[] {
  if (!value || typeof value !== "object" || value[$TARGET] || Array.isArray(value))
    throw unsupported();
  const prototype = Object.getPrototypeOf(value);
  if ((prototype !== Object.prototype && prototype !== null) ||
      (expected && prototype !== expected.prototype)) throw unsupported();
  const keys = Reflect.ownKeys(value).filter(key => key !== $OWNER);
  for (const key of keys) {
    const d = Object.getOwnPropertyDescriptor(value, key)!;
    if (!("value" in d) || !d.writable || !d.configurable || isWrappable(d.value))
      throw unsupported();
  }
  return keys;
}

function slotFor(t: StoreTarget, key: PropertyKey, presence = false): Slot {
  const record = records.get(t)!;
  const slots = presence ? record.presence : record.slots;
  let slot = slots.get(key);
  if (!slot) {
    const node = presence ? getHasNode(t, key) : getNode(t, key);
    slots.set(key, slot = createOptimisticSlot(node));
    record.nodes.set(node, slot);
  }
  return slot;
}

function selectedNode(t: StoreTarget, node: Signal<any>): Signal<any> {
  const record = records.get(t);
  if (!record) return node;
  let slot = record.nodes.get(node);
  if (!slot) {
    const key = (node as any)._key;
    slot = slotFor(t, key, t.h?.[key as any] === node);
  }
  return slot.output;
}

function compose(t: StoreTarget, shape: Record<PropertyKey, any>, writer = false) {
  const record = records.get(t)!;
  const out = Object.create(record.prototype);
  for (const key of Reflect.ownKeys(shape)) {
    if (key === $OWNER) continue;
    const descriptor = Object.getOwnPropertyDescriptor(shape, key)!;
    const slot = slotFor(t, key);
    Object.defineProperty(out, key, {
      ...descriptor, value: writer ? slot.writerValue() : read(slot.output)
    });
  }
  return out;
}

function selectedView(t: StoreTarget, source: Record<PropertyKey, any>) {
  const record = records.get(t);
  if (!record) return source;
  // Enumeration depends on structure alone. Suppress leaf subscriptions while
  // retaining the active calculation's selection context.
  return untrack(() => compose(t, read(record.container.output) as Record<PropertyKey, any>));
}

export const staticOptimisticHooks: OptHooks = {
  node: selectedNode,
  read: (t, node) => read(selectedNode(t, node)),
  // Reading outputs discovers coherent publication, without writing a shared
  // guessed deep witness and merging disjoint action lifetimes.
  deep: t => { for (const slot of records.get(t)?.slots.values() ?? []) read(slot.output); },
  view: selectedView,
  descriptor: (t, key) => untrack(() => {
    const record = records.get(t);
    if (!record) return undefined;
    const shape = read(record.container.output);
    const descriptor = Object.getOwnPropertyDescriptor(shape, key);
    return descriptor ? {...descriptor, value: read(slotFor(t, key).output)} : null;
  }),
  has: (t, key) => records.has(t) ? !!read(slotFor(t, key, true).output) : undefined,
  draft: () => { throw unsupported(); },
  writes: () => { throw unsupported(); },
  reconcile: () => { throw unsupported(); },
  arrangement: () => false,
  pair: () => {}, sweep: () => {}, ask: () => {}, park: () => {}, stands: () => false
};

export function createStaticOptimisticStore(first: any, second?: any, third?: any) {
  if (typeof first === "function" || third !== undefined || second?.shallow) throw unsupported();
  const keys = validate(first);
  const store = createProjectionInternal(null, first, second, true);
  const target: StoreTarget = (store as any)[$TARGET];
  const containerNode = getContainerNode(target);
  const container = createOptimisticSlot(containerNode);
  const record: RecordSlots = {
    slots: new Map(), presence: new Map(), nodes: new Map([[containerNode, container]]),
    container, prototype: Object.getPrototypeOf(first)
  };
  records.set(target, record);
  for (const key of keys) slotFor(target, key);
  const set = (fn: (draft: any) => any) => {
    if (writeHook !== null) writeHook(store as object);
    if (__DEV__) devGuardStoreSetterWrite();
    // Validate an isolated writer view before submitting any proposal.
    const previous = untrack(() => compose(target, container.writerValue(), true));
    const draft = Object.create(record.prototype, Object.getOwnPropertyDescriptors(previous));
    const result = fn(draft);
    if (__DEV__) devGuardStoreSetterResult(result);
    const next = result === undefined ? draft : result;
    const nextKeys = validate(next, record);
    const oldKeys = Reflect.ownKeys(previous);
    const allKeys = new Set([...oldKeys, ...nextKeys]);
    const entries: [Slot, unknown][] = [];
    let structure = oldKeys.length !== nextKeys.length || oldKeys.some((key, i) => key !== nextKeys[i]);
    for (const key of allKeys) {
      const old = Object.getOwnPropertyDescriptor(previous, key);
      const neu = Object.getOwnPropertyDescriptor(next, key);
      if (!Object.is(old?.value, neu?.value)) entries.push([slotFor(target, key), neu?.value]);
      // Missing and present-undefined are distinct structural states.
      if (!!old !== !!neu) {
        const presence = slotFor(target, key, true);
        const present = neu !== undefined || key in Object.create(record.prototype);
        if (presence.writerValue() !== present) entries.push([presence, present]);
      }
      if (old?.enumerable !== neu?.enumerable) structure = true;
    }
    if (structure) {
      // Clone the validated structure: later mutations of a returned object
      // must not mutate an already submitted proposal.
      entries.push([container, Object.create(record.prototype, Object.getOwnPropertyDescriptors(next))]);
    }
    proposeOptimisticSlots(entries);
  };
  return [store, set] as const;
}
