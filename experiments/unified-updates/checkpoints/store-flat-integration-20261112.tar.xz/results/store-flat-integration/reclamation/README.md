# Lazy optimistic-store companion reclamation

Worktree `/workspace/scratch/store-reclamation`, based on e988d156e plus frozen structural candidate overlay. Main runtime and original structural scratch untouched.

Integrate ONLY source/packages/signals/src/layers/optimistic.ts, source/packages/signals/src/store/optimistic-static.ts, and new source/packages/signals/tests/unified-optimistic-store-reclamation.test.ts. Other structural source/tests are parent-owned. The complete static source includes the parent's inherited-value comparison fix. delta.patch compares these runtime files against the original frozen structural overlay; baseline/ retains exact starting files. Use complete source if parent formatting/overlapping fix prevents patch application.

Companions are allocated by tracked reads or changed proposals, survive creator disposal independently, and are never allocated by inactive untracked reads, descriptor/enumeration views, or unchanged setters. Selected-node identity introspection does not allocate. Deep tracked reads explicitly materialize all current selected leaf subscriptions.

Last-subscriber removal adds a companion to a small candidate map and schedules the ordinary flush. Initial allocation adds a candidate too, covering setter-before-reader. optHooks.sweep retries only candidates; observed outputs leave the candidate map immediately. tryRelease refuses subscribers, active scopes/proposals/overrides, input or output holds/stagings/pending status, or queued/in-progress output work. On successful ordinary disposal, graph clearDeps releases the truth node via its existing slot hook; store maps then forget the companion. No core ordinary hot paths or alternative scheduler changed.

Validation: 78 tests / 9 files pass, including all parent inherited-shadow tests after their Object.keys preparation correction, migrated enumerator subscription-count assertion, and five new lifecycle regressions. Existing posture-store-parity S7 unchanged: 5 passed / 45 unrelated excluded. Source-only tsc and git diff --check pass. No installs or benchmarks.

The lifecycle suite covers 20 repeated cycles through value/presence/container release and later writes, creator/reader disposal, an unobserved active guess, late readers, held corrections, setter before first reader, and deep-only subscribers before any guesses with repeated new-key additions.
