import json,pathlib,collections,tarfile,hashlib
p=pathlib.Path('/workspace/scratch/store-integration-resume')
b=json.load(open('/workspace/scratch/unified-opt-results/cold-full.json')); s=json.load(open(p/'static-full.json')); n=json.load(open(p/'structure-full.json'))
def ix(x):return {(r['name'].split('/tests/')[-1],a['fullName']):a for r in x['testResults'] for a in r['assertionResults']}
bi,si,ni=ix(b),ix(s),ix(n)
oldclasses={(x['file'],x['name']):x['category'] for x in json.load(open(p/'static-classification.json'))}
rows=[]
for k,a in ni.items():
 if a['status']!='failed':continue
 msg='\n'.join(a.get('failureMessages',[])); old=oldclasses.get(k,'')
 cat='unsupported-store-explicit-guard' if 'optimistic stores currently support only' in msg else 'until-explicit-guard' if 'until is deferred' in msg else 'until-preexisting-indirect' if old=='until-preexisting-indirect' else 'documentation-index' if k[0]=='rules-index.test.ts' else 'needs-review'
 rows.append({'file':k[0],'name':k[1],'category':cat,'coldStatus':bi.get(k,{}).get('status','absent'),'staticStatus':si.get(k,{}).get('status','absent'),'staticCategory':old,'assertion':msg.splitlines()[0] if msg else '', 'message':msg})
def compare(old):return {'previouslyFailedNowPass':sum(a['status']=='passed' and old.get(k,{}).get('status')=='failed' for k,a in ni.items()),'previouslyPassedNowFail':sum(a['status']=='failed' and old.get(k,{}).get('status')=='passed' for k,a in ni.items()),'newTests':len(ni.keys()-old.keys()),'missingTests':len(old.keys()-ni.keys())}
def counts(x):return {k:x[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
summary={'cold':counts(b),'static':counts(s),'current':counts(n),'versusCold':compare(bi),'versusStatic':compare(si),'categories':dict(collections.Counter(r['category'] for r in rows))}
with tarfile.open(p/'structure-run-sources.tar') as t:summary['sourceSnapshotUnchangedAtFinish']=all(hashlib.sha256(t.extractfile(m).read()).digest()==hashlib.sha256((pathlib.Path('/workspace/layered-solid')/m.name).read_bytes()).digest() for m in t.getmembers() if m.isfile())
json.dump(rows,open(p/'structure-classification.json','w'),indent=2); json.dump(summary,open(p/'structure-summary.json','w'),indent=2)
print(json.dumps(summary,indent=2))
for r in rows:
 if r['category']=='needs-review':print(json.dumps(r,ensure_ascii=False))
