import config from './vite.config.mjs';
export default {
  ...config,
  cacheDir: '/tmp/solid-next-context175',
  test: { ...config.test, setupFiles: ['./test/setup-jest-dom.context-probe.ts'] }
};
