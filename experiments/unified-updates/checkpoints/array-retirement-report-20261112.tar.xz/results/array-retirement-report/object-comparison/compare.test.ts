import { test, expect } from 'vitest';
import { writeFileSync } from 'node:fs';
import { action, createOptimisticStore, createRenderEffect, createRoot, createSignal, flush } from 'probe-runtime';
const results: unknown[] = [];
const turn = async () => { await new Promise<void>(r => setTimeout(r, 0)); flush(); };
for (const shape of ['object', 'numeric object', 'array']) {
 test(shape, async () => {
  const initial = shape === 'array' ? [0,0] : shape === 'object' ? {a:0,b:0} : {0:0,1:0};
  const [ka,kb] = shape === 'object' ? ['a','b'] : ['0','1'];
  const [items, guess] = createOptimisticStore(initial);
  const [savedB, setSavedB] = createSignal(false);
  const endA = Promise.withResolvers<void>(), endB = Promise.withResolvers<void>();
  let shown: unknown, saved = false;
  const timeline: unknown[] = [];
  const dispose = createRoot(dispose => {
   createRenderEffect(() => [items[ka],items[kb]], value => {shown=value});
   createRenderEffect(savedB, value => {saved=value});
   return dispose;
  });
  const note = (phase:string) => timeline.push({phase,shown,savedB:saved});
  let a: Promise<unknown> | undefined, b: Promise<unknown> | undefined;
  try {
   flush(); note('initial');
   b=action(function*(){guess(d=>{d[kb]=2});setSavedB(true);yield endB.promise;})();
   flush();note('B live');
   a=action(function*(){guess(d=>{d[ka]=1});yield endA.promise;})();
   flush();note('both live');
   endB.resolve();await b;await turn();note('B finished, A live');
   endA.resolve();await a;await turn();note('both finished');
   expect(shown).toEqual([0,0]);
   results.push({shape,timeline});
   writeFileSync(process.env.PROBE_OUTPUT!,JSON.stringify(results,null,2));
  } finally {endA.resolve();endB.resolve();await Promise.all([a,b]);dispose();flush();}
 });
}
