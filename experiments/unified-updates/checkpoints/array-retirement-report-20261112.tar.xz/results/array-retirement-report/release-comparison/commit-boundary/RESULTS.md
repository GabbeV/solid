# Exact PR #4729 boundary probe

Both exact git-archived source runtimes passed the existing source-only probe (3 tests each). No installation or runtime edits. Vitest 4.1.6, existing /workspace/layered-solid/node_modules, existing probe config. Raw results: before.json, after.json; logs: before.log, after.log; exact commit metadata: metadata.json.

| Source | Initial shapes | After B generator finishes and `await b` resolves, while A remains open |
| --- | --- | --- |
| Parent b2cb0c7e8d4dbf64eac5dd4df9aff309d9f165a3 | [], [0], [0,0] | All: length 2, keys [0,1], a=1, b=2; ordinary savedB=false |
| PR c98168082e5fcb37833256733ceee5d2291791ea | [], [0], [0,0] | All: length 2, keys [0,1], a=1, b=2; ordinary savedB=true |

The ordinary signal is set inside B's generator before its yield and rendered by a separate scheduled effect. At both commits it stays false during B-live/A-and-B-live. On the parent it stays false after B finishes, then becomes true when A finishes. On PR #4729 it becomes true when B finishes, while A is still open. Array values remain identical on both sides at that point. Both restore the initial array shape after both finish.

This directly dates the transaction-lifetime change in this probe to PR #4729, while establishing no change in this probe's visible array outcome across that boundary.

Action promise semantics are unchanged: core/action.ts has zero diff across the boundary. Its done() decrements resolveTx(t)._open, calls schedule(), and resolves the action promise immediately; that promise does not wait for the merged transaction to commit. Thus `await b` alone cannot distinguish B's transaction remaining entangled with A from B committing independently. A bFinished flag written only after `await b` (as in the original hosted reproduction) cannot distinguish them either. The ordinary savedB write inside B does distinguish them.

Source mechanism corroboration: parent's store/optimistic.ts:639-648 park hook explicitly merges each observed guess's action into the flush transaction. PR replaces this machinery with per-target, per-lane guess carriers. The empirical signal result above, rather than blame alone, establishes this exact boundary.
