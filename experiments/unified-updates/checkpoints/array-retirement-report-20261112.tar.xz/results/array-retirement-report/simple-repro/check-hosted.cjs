const { chromium } = require('/workspace/pr3886/browser/node_modules/playwright');
const fs = require('node:fs');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true,
    proxy: { server: process.env.HTTPS_PROXY }, args: ['--no-sandbox'] });
  try {
    const context = await browser.newContext({ viewport: { width: 1350, height: 850 } });
    const cookies = fs.readFileSync('/workspace/scratch/pending-repro-rc21/playground.cookies','utf8')
      .split('\n').filter(l => l && (!l.startsWith('#') || l.startsWith('#HttpOnly_'))).map(line => {
        const httpOnly = line.startsWith('#HttpOnly_');
        const [domain,,path,secure,expiry,name,value] = line.replace(/^#HttpOnly_/,'').split('\t');
        return {name,value,domain,path,secure:secure==='TRUE',httpOnly,...(+expiry?{expires:+expiry}:{})};
      });
    await context.addCookies(cookies);
    const page = await context.newPage();
    const errors = [], runtimeRequests = [];
    page.on('pageerror', e => errors.push(e.message));
    page.on('request', r => { if(r.url().includes('/pr/mizulu/solid2/')) runtimeRequests.push(r.url()); });
    await page.goto(fs.readFileSync(__dirname+'/url.txt','utf8').trim(), {waitUntil:'domcontentloaded',timeout:30000});
    let frame;
    for(let i=0;i<40;i++) {
      frame = page.frames().find(f => f!==page.mainFrame() && f.url()!=='about:blank');
      if(frame && await frame.locator('#array').count()) {
        await page.waitForTimeout(3000);
        if(await frame.locator('#array').count()) break;
      }
      await page.waitForTimeout(500);
    }
    assert.ok(frame && await frame.locator('#array').count(), 'repro iframe loaded');
    const samples = [];
    const sample = async at => samples.push({at,...await frame.evaluate(() => ({
      array: document.getElementById('array').textContent,
      object: document.getElementById('object').textContent
    }))});
    await sample('initial');
    await frame.getByRole('button',{name:'Run',exact:true}).click();
    await page.waitForTimeout(150); await sample('150ms');
    await page.waitForTimeout(500); await sample('650ms');
    await page.waitForTimeout(500); await sample('1150ms');
    await frame.locator('main').screenshot({path:__dirname+'/mismatch.png'});
    await page.waitForTimeout(600); await sample('finished');
    fs.writeFileSync(__dirname+'/hosted-result.json',JSON.stringify({samples,errors,runtimeRequests},null,2));
    console.log(JSON.stringify({samples,errors},null,2));
    assert.deepEqual(samples.map(s=>[s.array,s.object]),[
      ['0, 0','0, 0'], ['0, 2','0, 2'], ['1, 2','1, 2'], ['1, 2','1, 0'], ['0, 0','0, 0']
    ]);
    assert.deepEqual(errors,[]);
    assert.ok(runtimeRequests.some(x=>x.includes('@solidjs/signals@bcef1041')));
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
