import { test, expect } from 'vitest';
import { writeFileSync } from 'node:fs';
const results: unknown[] = [];
import { action, createOptimisticStore, createRenderEffect, createRoot, createSignal, flush } from 'probe-runtime';
const turn = async () => { await new Promise<void>(r => setTimeout(r, 0)); flush(); };
for (const initial of [[], [0], [0, 0]]) {
  test(`B first, A second, B finishes: initial ${JSON.stringify(initial)}`, async () => {
    const [items, guess] = createOptimisticStore(initial);
    const [savedB, setSavedB] = createSignal(false);
    const endA = Promise.withResolvers<void>(), endB = Promise.withResolvers<void>();
    let shown: unknown, saved = false;
    const timeline: unknown[] = [];
    const dispose = createRoot(dispose => {
      createRenderEffect(() => ({ length: items.length, keys: Object.keys(items),
        a: items[0] ?? 'undefined', b: items[1] ?? 'undefined' }), value => { shown = value; });
      createRenderEffect(savedB, value => { saved = value; });
      return dispose;
    });
    const note = (phase: string) => timeline.push({ phase, shown, savedB: saved });
    let a: Promise<unknown> | undefined, b: Promise<unknown> | undefined;
    try {
      flush(); note('initial');
      b = action(function* () {
        guess(draft => { draft[1] = 2; });
        setSavedB(true);
        yield endB.promise;
      })();
      flush(); note('B live');
      a = action(function* () {
        guess(draft => { draft[0] = 1; });
        yield endA.promise;
      })();
      flush(); note('A and B live');
      endB.resolve(); await b; await turn(); note('B finished, A live');
      endA.resolve(); await a; await turn(); note('both finished');
      expect(shown).toEqual({length: initial.length, keys: Object.keys(initial), a: initial[0] ?? 'undefined', b: initial[1] ?? 'undefined'});
      results.push({initial, timeline}); writeFileSync(process.env.PROBE_OUTPUT!, JSON.stringify(results, null, 2));
    } finally {
      endA.resolve(); endB.resolve(); await Promise.all([a,b]); dispose(); flush();
    }
  });
}
