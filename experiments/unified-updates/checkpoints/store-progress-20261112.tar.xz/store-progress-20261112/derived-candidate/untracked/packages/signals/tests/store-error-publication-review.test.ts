import { expect, it } from "vitest";
import {
  action,
  createEffect,
  createMemo,
  createOptimistic,
  createOptimisticStore,
  createRoot,
  createSignal,
  flush,
  latest,
  isPending
} from "../src/index.js";
const tick = async () => {
  for (let i = 0; i < 4; i++) {
    await new Promise(r => setTimeout(r, 0));
    flush();
  }
};
const serialize = (v: any) => JSON.stringify(v) ?? String(v);
function setup(
  kind: "store" | "scalar",
  whole: boolean,
  error: unknown,
  observation: "ordinary" | "latest" | "pending" = "ordinary"
) {
  const log: Record<string, string[]> = { selected: [], sibling: [], length: [], late: [] };
  let start!: () => any,
    finish!: () => void,
    setPhase!: (v: number) => void,
    late!: () => void,
    dispose!: () => void;
  createRoot(d => {
    dispose = d;
    const [phase, sp] = createSignal(0);
    setPhase = sp;
    const source = createMemo(() => {
      if (phase() === 1) throw error;
      return phase() === 2 ? 4 : 1;
    });
    let selected: () => any, sibling: () => any, length: () => any, propose: () => void;
    if (kind === "scalar") {
      const [v, sv] = createOptimistic(source);
      selected = v;
      sibling = source;
      length = source;
      propose = () => sv(9);
    } else {
      const [st, set] = createOptimisticStore(
        (d: any[]) => {
          const n = source();
          d.length = 0;
          d.push({ id: 1, v: n }, { id: 2, v: n + 1 });
        },
        [],
        { key: "id" }
      );
      selected = () => st[0]?.v;
      sibling = () => st[1]?.v;
      length = () => st.length;
      propose = () =>
        set(d => {
          if (whole) d[0] = { id: 9, v: 9 };
          else d[0].v = 9;
        });
    }
    const watch = (fn: () => any, key: string) =>
      createEffect(fn, {
        effect: v => {
          log[key].push(serialize(v));
        },
        error: e => {
          log[key].push("ERR " + String(e?.message ?? e));
        }
      });
    const observed =
      observation === "latest"
        ? () => latest(selected)
        : observation === "pending"
          ? () => `${selected()}/${isPending(selected)}`
          : selected;
    watch(observed, "selected");
    watch(sibling, "sibling");
    watch(length, "length");
    late = () => watch(observed, "late");
    let resolve!: () => void;
    start = action(function* () {
      propose();
      yield new Promise<void>(r => (resolve = r));
    });
    finish = () => resolve();
  });
  return { log, start, finish, setPhase, late, dispose };
}
for (const whole of [false, true])
  for (const error of [new Error("bad"), undefined])
    for (const observation of ["ordinary", "latest", "pending"] as const) {
      it(`published selected ${whole ? "object" : "leaf"} error=${String(error)} observation=${observation}`, async () => {
        const h = setup("store", whole, error, observation);
        const control = setup("scalar", whole, error, observation);
        await tick();
        h.start();
        control.start();
        await tick();
        h.setPhase(1);
        control.setPhase(1);
        await tick();
        const active = JSON.parse(JSON.stringify(h.log)),
          scalar = JSON.parse(JSON.stringify(control.log));
        h.late();
        control.late();
        await tick();
        const late = JSON.parse(JSON.stringify(h.log));
        h.finish();
        control.finish();
        await tick();
        const retired = JSON.parse(JSON.stringify(h.log));
        h.setPhase(0);
        control.setPhase(0);
        await tick();
        console.log(
          JSON.stringify({
            whole,
            error: String(error),
            observation,
            active,
            scalar,
            late,
            retired,
            recovered: h.log
          })
        );
        expect(active.selected).toEqual(scalar.selected);
        expect(late.late).toEqual(control.log.late.slice(0, 1));
        expect(retired.selected.at(-1)).toMatch(/^ERR /);
        expect(h.log.selected.at(-1)).toBe(observation === "pending" ? '"1/false"' : "1");
        h.dispose();
        control.dispose();
      });
    }

function heldFixture(kind: "store" | "scalar", whole: boolean) {
  const log: { fast: string[]; slow: string[] } = { fast: [], slow: [] };
  let start!: () => any,
    finish!: () => void,
    answer!: () => void,
    change!: () => void,
    dispose!: () => void;
  createRoot(d => {
    dispose = d;
    const [n, s] = createSignal(1);
    change = () => s(4);
    let selected: () => number, propose: () => void;
    if (kind === "scalar") {
      const [v, sv] = createOptimistic(n);
      selected = v;
      propose = () => sv(9);
    } else {
      const [st, set] = createOptimisticStore(
        (d: any[]) => {
          d.length = 0;
          d.push({ id: 1, v: n() }, { id: 2, v: 2 });
        },
        [],
        { key: "id" }
      );
      selected = () => st[0]?.v;
      propose = () =>
        set(d => {
          if (whole) d[0] = { id: 9, v: 9 };
          else d[0].v = 9;
        });
      createEffect(() => st.length, { effect: () => {} });
    }
    const wait = new Promise<void>(r => (answer = r));
    const slow = createMemo(() => {
      const v = selected();
      return v === 4 ? wait.then(() => v) : v;
    });
    createEffect(selected, {
      effect: v => {
        log.fast.push(String(v));
      },
      error: e => {
        log.fast.push("ERR " + String(e));
      }
    });
    createEffect(slow, {
      effect: v => {
        log.slow.push(String(v));
      },
      error: e => {
        log.slow.push("ERR " + String(e));
      }
    });
    let resolve!: () => void;
    start = action(function* () {
      propose();
      yield new Promise<void>(r => (resolve = r));
    });
    finish = () => resolve();
  });
  return { log, start, finish, answer, change, dispose };
}
for (const whole of [false, true])
  it(`holds published ${whole ? "object" : "leaf"} correction with async downstream like scalar`, async () => {
    const h = heldFixture("store", whole),
      c = heldFixture("scalar", whole);
    await tick();
    h.start();
    c.start();
    await tick();
    h.change();
    c.change();
    await tick();
    const active = serialize(h.log),
      controlActive = serialize(c.log);
    h.finish();
    c.finish();
    await tick();
    const held = serialize(h.log),
      controlHeld = serialize(c.log);
    h.answer();
    c.answer();
    await tick();
    console.log(
      JSON.stringify({
        whole,
        active,
        controlActive,
        held,
        controlHeld,
        done: h.log,
        controlDone: c.log
      })
    );
    expect(active).toBe(controlActive);
    expect(held).toBe(controlHeld);
    expect(h.log).toEqual(c.log);
    expect(h.log.slow.at(-1)).toBe("4");
    h.dispose();
    c.dispose();
  });
