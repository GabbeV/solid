import { expect, it } from "vitest";
import { createEffect, createRoot, flush } from "../src/index.js";
import { computed, context, read, setSignal, signal } from "../src/core/core.js";
import { link } from "../src/core/graph.js";
import { createOptimisticSlot } from "../src/layers/optimistic.js";
import { CONFIG_REDERIVE } from "../src/core/constants.js";
import type { Computed } from "../src/core/types.js";

it("a link to an unconsumed child output can propagate error status", () => {
  const logs: string[] = [];
  let fail!: ReturnType<typeof signal<boolean>>;
  const dispose = createRoot(dispose => {
    fail = signal(false);
    const input = computed(() => { if (read(fail)) throw Error("child"); return 1; });
    const child = createOptimisticSlot(input);
    const stable = {};
    const marker = computed(() => { link(child.output, context as Computed<any>); return 0; });
    marker._config |= CONFIG_REDERIVE;
    const parent = computed(() => { read(marker); return stable; });
    createEffect(() => read(parent), {
      effect: () => void logs.push("reference"),
      error: (e: Error) => void logs.push(`error ${e.message}`)
    } as any);
    flush();
    child.propose(9); flush();
    expect(logs).toEqual(["reference"]);
    return dispose;
  });
  setSignal(fail, true); flush();
  expect(logs).toEqual(["reference"]);
  dispose();
});
