import { it, expect } from "vitest";
import {
  action,
  createEffect,
  createMemo,
  createOptimistic,
  createOptimisticStore,
  createRoot,
  createSignal,
  flush
} from "../src/index.js";
const tick = async () => {
  for (let i = 0; i < 4; i++) {
    await new Promise(r => setTimeout(r, 0));
    flush();
  }
};
for (const withLength of [false, true])
  for (const outcome of ["error", "value"] as const) {
    it(`store ${outcome} length=${withLength}`, async () => {
      const a: string[] = [],
        b: string[] = [],
        len: string[] = [];
      let start!: () => any, finish!: () => void, fail!: () => void, settle!: (v?: any) => void;
      createRoot(() => {
        const [n, s] = createSignal(0);
        fail = () => s(1);
        let next: Promise<any> | undefined;
        const m = createMemo(() =>
          n() === 0
            ? Promise.resolve([{ id: 1 }, { id: 3 }])
            : (next ??= new Promise<any>(
                (res, rej) => (settle = outcome === "error" ? () => rej(new Error("bad")) : res)
              ))
        );
        const [issues, set] = createOptimisticStore(
          (d: any[]) => {
            const v = m();
            d.length = 0;
            d.push(...v.map(x => ({ ...x })));
          },
          [],
          { key: "id" }
        );
        let resolve!: () => void;
        start = action(function* () {
          set(d => {
            d.push({ id: 9 });
          });
          yield new Promise<void>(r => (resolve = r));
        });
        finish = () => resolve();
        const watch = (fn: () => any, out: string[]) =>
          createEffect(fn, {
            effect: v => {
              out.push(String(v));
            },
            error: e => {
              out.push(`ERR ${e?.message}`);
            }
          });
        watch(() => issues[2]?.id, a);
        watch(() => issues[0]?.id, b);
        if (withLength) watch(() => issues.length, len);
      });
      await tick();
      start();
      await tick();
      const added = JSON.stringify({ a, b, len });
      fail();
      await tick();
      settle([{ id: 4 }, { id: 5 }, { id: 6 }, { id: 7 }]);
      await tick();
      const answered = JSON.stringify({ a, b, len });
      finish();
      await tick();
      console.log(
        JSON.stringify({
          withLength,
          outcome,
          added,
          answered,
          done: JSON.stringify({ a, b, len })
        })
      );
      expect(JSON.parse(answered).a).toEqual(["undefined", "9"]);
      expect(a).toEqual(["undefined", "9", outcome === "error" ? "ERR bad" : "6"]);
    });
  }
for (const outcome of ["error", "value"] as const)
  it(`scalar ${outcome}`, async () => {
    const a: string[] = [],
      b: string[] = [];
    let start!: () => any, finish!: () => void, fail!: () => void;
    createRoot(() => {
      const [bad, setBad] = createSignal(false);
      fail = () => setBad(true);
      const m = createMemo(() => {
        if (bad()) {
          if (outcome === "error") throw new Error("bad");
          return 4;
        }
        return 1;
      });
      const [v, sv] = createOptimistic(m);
      let resolve!: () => void;
      start = action(function* () {
        sv(9);
        yield new Promise<void>(r => (resolve = r));
      });
      finish = () => resolve();
      createEffect(v, {
        effect: v => {
          a.push(String(v));
        },
        error: e => {
          a.push(`ERR ${e?.message}`);
        }
      });
      createEffect(m, {
        effect: v => {
          b.push(String(v));
        },
        error: e => {
          b.push(`ERR ${e?.message}`);
        }
      });
    });
    flush();
    start();
    flush();
    fail();
    flush();
    const answered = JSON.stringify({ a, b });
    finish();
    await tick();
    console.log(JSON.stringify({ scalar: outcome, answered, done: JSON.stringify({ a, b }) }));
    expect(JSON.parse(answered).a).toEqual(["1", "9"]);
  });
