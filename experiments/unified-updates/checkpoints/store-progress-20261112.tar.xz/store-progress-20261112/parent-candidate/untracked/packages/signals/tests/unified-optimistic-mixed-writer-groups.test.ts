import { expect, it } from "vitest";
import { action, createMemo, createRenderEffect, createRoot, flush } from "../src/index.js";
import { read, signal } from "../src/core/core.js";
import { txOf } from "../src/core/scheduler.js";
import { positionOf } from "../src/layers/coordination.js";
import { createOptimisticSlot, withOptimisticSlotBatch } from "../src/layers/optimistic.js";

const turn = () => new Promise<void>(resolve => setTimeout(resolve, 0));

it.each(["parent-first", "child-first"])(
  "a setter groups a selected parent with its child input (%s)",
  async order => {
    const answer = Promise.withResolvers<number>();
    const end = Promise.withResolvers<void>();
    const parent = createOptimisticSlot(signal(0));
    const child = createOptimisticSlot(parent.output);
    const shown = { parent: -1, child: -1, async: -1 };
    const dispose = createRoot(dispose => {
      const pending = createMemo(() => (read(parent.output) ? answer.promise : 0));
      createRenderEffect(() => read(parent.output), value => { shown.parent = value; });
      createRenderEffect(() => read(child.output), value => { shown.child = value; });
      createRenderEffect(pending, value => { shown.async = value; });
      return dispose;
    });
    let running: Promise<void> | undefined;
    try {
      flush();
      running = action(function* () {
        withOptimisticSlotBatch(() => {
          if (order === "parent-first") {
            parent.propose(1);
            child.propose(1);
          } else {
            child.propose(1);
            parent.propose(1);
          }
        });
        yield end.promise;
      })();
      flush();
      await turn();
      expect(shown).toEqual({ parent: 0, child: 0, async: 0 });
      answer.resolve(10);
      await turn();
      flush();
      expect(shown).toEqual({ parent: 1, child: 1, async: 10 });
    } finally {
      answer.resolve(10);
      end.resolve();
      if (running) await running;
      dispose();
      flush();
    }
  }
);

it("overlapping setter groups transitively share one publication update", async () => {
  const answer = Promise.withResolvers<number>();
  const end = Promise.withResolvers<void>();
  const a = createOptimisticSlot(signal(0));
  const b = createOptimisticSlot(a.output);
  const c = createOptimisticSlot(signal(0));
  const shown = { a: -1, b: -1, c: -1, async: -1 };
  const dispose = createRoot(dispose => {
    const pending = createMemo(() => (read(a.output) ? answer.promise : 0));
    createRenderEffect(() => read(a.output), value => { shown.a = value; });
    createRenderEffect(() => read(b.output), value => { shown.b = value; });
    createRenderEffect(() => read(c.output), value => { shown.c = value; });
    createRenderEffect(pending, value => { shown.async = value; });
    return dispose;
  });
  let running: Promise<void> | undefined;
  try {
    flush();
    running = action(function* () {
      withOptimisticSlotBatch(() => {
        a.propose(1);
        b.propose(1);
      });
      withOptimisticSlotBatch(() => {
        b.propose(1);
        c.propose(1);
      });
      yield end.promise;
    })();
    flush();
    await turn();
    expect(shown).toEqual({ a: 0, b: 0, c: 0, async: 0 });
    answer.resolve(10);
    await turn();
    flush();
    expect(shown).toEqual({ a: 1, b: 1, c: 1, async: 10 });
  } finally {
    answer.resolve(10);
    end.resolve();
    if (running) await running;
    dispose();
    flush();
  }
});

it("cross-dependent setter groups collapse their publication cycle", async () => {
  const answer = Promise.withResolvers<number>();
  const end = Promise.withResolvers<void>();
  const d = createOptimisticSlot(signal(0));
  const b = createOptimisticSlot(signal(0));
  const a = createOptimisticSlot(b.output);
  const c = createOptimisticSlot(d.output);
  const slots = { a, b, c, d };
  const shown = { a: -1, b: -1, c: -1, d: -1, async: -1 };
  const dispose = createRoot(dispose => {
    const pending = createMemo(() => (read(a.output) ? answer.promise : 0));
    for (const key of ["a", "b", "c", "d"] as const)
      createRenderEffect(() => read(slots[key].output), value => { shown[key] = value; });
    createRenderEffect(pending, value => { shown.async = value; });
    return dispose;
  });
  let running: Promise<void> | undefined;
  try {
    flush();
    running = action(function* () {
      withOptimisticSlotBatch(() => {
        a.propose(1);
        d.propose(1);
      });
      withOptimisticSlotBatch(() => {
        c.propose(1);
        b.propose(1);
      });
      yield end.promise;
    })();
    flush();
    await turn();
    expect(shown).toEqual({ a: 0, b: 0, c: 0, d: 0, async: 0 });
    answer.resolve(10);
    await turn();
    flush();
    expect(shown).toEqual({ a: 1, b: 1, c: 1, d: 1, async: 10 });
  } finally {
    answer.resolve(10);
    end.resolve();
    if (running) await running;
    dispose();
    flush();
  }
});

it("a dependent setter group takes the already grouped input's depth", async () => {
  const end = Promise.withResolvers<void>();
  const levels: Record<string, number> = {};
  const seed = createOptimisticSlot(signal(0), undefined, () => (levels.seed = positionOf(txOf(seed.output))));
  const b = createOptimisticSlot(seed.output, undefined, () => (levels.b = positionOf(txOf(b.output))));
  const c = createOptimisticSlot(signal(0), undefined, () => (levels.c = positionOf(txOf(c.output))));
  const a = createOptimisticSlot(b.output, undefined, () => (levels.a = positionOf(txOf(a.output))));
  const d = createOptimisticSlot(signal(0), undefined, () => (levels.d = positionOf(txOf(d.output))));
  let running: Promise<void> | undefined;
  try {
    running = action(function* () {
      seed.propose(1);
      withOptimisticSlotBatch(() => {
        a.propose(1);
        d.propose(1);
      });
      withOptimisticSlotBatch(() => {
        b.propose(1);
        c.propose(1);
      });
      yield end.promise;
    })();
    flush();
    expect(levels).toEqual({ seed: 1, b: 2, c: 2, a: 3, d: 3 });
  } finally {
    end.resolve();
    if (running) await running;
    flush();
  }
});
