import { it, expect } from '/workspace/layered-solid/node_modules/vitest/dist/index.js';
import { createOptimisticStore, affects, flush, isPending, snapshot } from './packages/signals/src/index.ts';
it('requested marked values and whole snapshots retain their verdict', () => {
 const [s] = createOptimisticStore(() => ({a:1,b:2}), {a:0,b:0});
 const [s2] = createOptimisticStore(() => s, {a:0,b:0});
 flush();
 affects(s, 'a');
 expect(isPending(() => s.a)).toBe(true);
 expect(isPending(() => s2.a)).toBe(true);
 expect(isPending(() => s2.b)).toBe(false);
 expect(isPending(() => Object.getOwnPropertyDescriptor(s2,'a')?.value)).toBe(true);
 expect(isPending(() => snapshot(s2))).toBe(true);
 expect(isPending(() => ({...s2}))).toBe(true);
});
