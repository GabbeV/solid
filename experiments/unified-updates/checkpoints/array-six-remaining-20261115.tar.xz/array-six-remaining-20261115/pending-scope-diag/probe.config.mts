import config from './config.mts';
export default async args => {const r=await config(args); return {...r,root:'/workspace/scratch/pending-scope-diag',test:{...r.test,dir:'.',include:['whole-probe.test.ts']}}};
