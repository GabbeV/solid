Capture and source isolation comparison, 2026-11-16
Experiment 94a48bf42 vs next 221b5f99f using prior next.config.mts.

Five control probes pass in both: marks alone do not suspend new tracked row
capture (plain and derived store); a genuinely unresolved derived store does
suspend a new tracked capture before its isPending callback; keyed returned-row
replacement and draft mutation on a derived store do not mutate the incoming
person store. Derived row proxy differs from person. Controls retained as
packages/signals/tests/unified-affects-capture-isolation.test.ts.

Adding isPending(() => person.name)===false assertions to the two mark-only
controls yields two failures in BOTH implementations: actual true when person
is present before affects(list). This violates the user's source-local ruling,
but is not a data-mutation leak. Exploratory failing probes preserved here,
not included as new unexplained main-suite failures.

To reproduce probes: copy mark-isolation-probes.test.ts into packages/signals/tests,
run Vitest from packages/signals; optionally pass the next.config.mts under
/workspace/scratch/affects-model-20261115. No runtime fix attempted.
