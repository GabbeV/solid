const esbuild = require('/workspace/layered-solid/node_modules/esbuild');
const path = require('node:path');
(async () => {
for (const [name, root] of Object.entries({upstream: __dirname+'/upstream', experiment:'/workspace/layered-solid', wrappers:'/workspace/next-store-wrapper-scope'})) {
  const file = path.join(__dirname, name+'.cjs');
  esbuild.buildSync({entryPoints:[root+'/packages/signals/src/index.ts'],outfile:file,bundle:true,platform:'node',format:'cjs',define:{__DEV__:'true',__OBSERVE__:'true',__TEST__:'false'}});
  const {action,affects,createRoot,createStore,createRenderEffect,isPending,flush}=require(file);
  let seen=[];const app=createRoot(dispose=>{
    const [person]=createStore({name:'Alice'}), [list,set]=createStore({people:[person]});const row=list.people[0];
    createRenderEffect(()=>[isPending(()=>person.name),isPending(()=>row.name),isPending(()=>list.people[0].name)],v=>{seen.push(v)});
    return {person, row, list, set, dispose};
  });flush();const wait=Promise.withResolvers();const task=action(function*(){affects(app.list);yield wait.promise})();flush();const marked=seen.at(-1);wait.resolve();await task;flush();app.set(d=>{d.people[0].name='Bob'});flush();console.log(JSON.stringify({name,same:app.row===app.person,marked,after:[app.person.name,app.row.name,app.list.people[0].name]}));app.dispose();flush();
}
})();
