import json, collections, pathlib, re
root=pathlib.Path('/workspace/layered-solid'); out=pathlib.Path('/workspace/scratch/store-integration-inventory')
sources={'cold':'/workspace/scratch/unified-opt-results/cold-full.json','solid':'/workspace/scratch/correctness-review/final/solid-full.json','web':'/workspace/scratch/correctness-review/final/web-full.json'}
# Verified body/helper chains for assertion failures, beyond literal stub errors.
until_helpers={
'create-deferred-3710.test.ts':'D9 parameterized action yields until(() => read()) at source line 483; rejection leaves seen undefined.',
'held-truth-lane-only.test.ts':'Signal-only buildSteal helper yields until(() => stream().version >= 1) at source line 93; six assertions depend on that stolen carrier existing.',
'optimistic-live-echo-3898.test.ts':'Signal parameterization yields until(() => rows().some(...), { timeout: 60 }) at source line 172; rejection name assertions expose Error instead of TimeoutError/confirmed.',
'until-entanglement.test.ts':'Signal action bodies directly yield until stream predicates at source lines 62,118,184,188,251; stub aborts action, changing saving/frame assertions.',
'until-memo-confirmation-3943.test.ts':'Direct/memo confirmation action bodies yield until predicates at lines 33,88,111,114,138,140,169,260; post-echo assertions depend on those waiters.',
'until.test.ts':'Direct until API tests and actions yielding until; wrapped throw/name assertions and frame failures occur after deferred stub is invoked.',
'visibility-oracle.test.ts':'Held-truth state setup in visibility-oracle.states.ts yields until; runner later probes six non-authoritative reader channels over the absent hold.',
'fold-3164.test.ts':'Signal path yields until(() => session().status === "authenticated") at source line 166; stub aborts optimistic signingIn action before initial frame assertion.'}
allrows=[]; files=[]; summary={}
for run,p in sources.items():
 d=json.load(open(p)); counts=collections.Counter(); failedfiles=0
 for s in d['testResults']:
  rel='packages/'+s['name'].split('/packages/',1)[1]
  failed=[a for a in s['assertionResults'] if a['status']=='failed']
  if not failed: continue
  failedfiles+=1; fc=collections.Counter()
  text=(root/rel).read_text(); lexical={x:bool(re.search(pat,text)) for x,pat in {'until_mention':r'\buntil\s*\(', 'refresh_mention':r'\brefresh\s*\(', 'pending_callback_mention':r'\bisPending\s*\(\s*\(', 'latest_callback_mention':r'\blatest\s*\(\s*\(', 'optimistic_store_mention':r'\bcreateOptimisticStore\s*(?:<[^;]*?>)?\s*\('}.items()}
  for a in failed:
   msg='\n'.join(a.get('failureMessages',[])); first=msg.splitlines()[0] if msg else ''
   if first=='Error: Optimistic stores are not integrated with the shared update engine yet.': category='explicit_optimistic_store_unsupported'; evidence='Exact constructor guard error; this masks subsequent test behavior and does not imply no until dependency.'
   elif first=='Error: until is deferred while the shared update engine is integrated.': category='until_deferred_direct'; evidence='Exact until stub error.'
   else:
    evidence=until_helpers.get(pathlib.Path(rel).name)
    category='until_dependent_assertion' if evidence else 'other_unclassified'
   counts[category]+=1;fc[category]+=1
   allrows.append({'run':run,'file':rel,'fullName':a['fullName'],'title':a['title'],'category':category,'evidence':evidence,'first_error':first,'failureMessages':a.get('failureMessages',[])})
  files.append({'run':run,'file':rel,'failed':len(failed),'passed':sum(a['status']=='passed' for a in s['assertionResults']),'categories':dict(fc),'mixed_failure_classes':len(fc)>1,'source_mentions_only_not_semantic_classification':lexical})
 summary[run]={'input':p,'passed':d['numPassedTests'],'failed':d['numFailedTests'],'skipped':d['numPendingTests'],'actual_failed_files':failedfiles,'categories':dict(counts)}
json.dump({'source_revision':'743bfbd11 (task supplied)','method':'Read-only receipt inventory; exact guard failures classified from errors; all 37 assertion/wrapped failures inspected via actual test bodies or setup helper. Lexical source mentions are file-level navigation aids only. Existing assertions are not semantic rulings. No builds or suite reruns.','runs':summary,'combined_failure_counts':dict(collections.Counter(r['category'] for r in allrows))},open(out/'summary.json','w'),indent=2)
json.dump(files,open(out/'files.json','w'),indent=2)
with open(out/'failures.jsonl','w') as f:
 for r in allrows:f.write(json.dumps(r)+'\n')
json.dump([f for f in files if f['mixed_failure_classes']],open(out/'mixed-files.json','w'),indent=2)
print(json.dumps(summary,indent=2));print('combined',collections.Counter(r['category'] for r in allrows))
