import {test} from 'vitest';
import {writeFileSync} from 'node:fs';
import {action,createOptimisticStore,createStore,createMemo,createRenderEffect,createRoot,flush,deep,latest,untrack} from 'probe-runtime';
function gate(){let resolve!:()=>void;const promise=new Promise<void>(r=>resolve=r);return {resolve,promise};}
async function settle(){for(let i=0;i<8;i++){await Promise.resolve();flush();}}
const cases=[
{name:'existing disjoint properties',initial:{a:0,b:0},a:(d:any)=>{d.a=1},b:(d:any)=>{d.b=2}},
{name:'same property scalar-overlap control',initial:{a:0,b:0},a:(d:any)=>{d.a=1},b:(d:any)=>{d.a=2;d.b=2}},
{name:'add different object keys',initial:{base:0},a:(d:any)=>{d.a=1},b:(d:any)=>{d.b=2}},
{name:'delete different object keys',initial:{a:1,b:2,c:3},a:(d:any)=>{delete d.a},b:(d:any)=>{delete d.b}},
{name:'delete one key edit another existing key',initial:{a:1,b:2},a:(d:any)=>{delete d.a},b:(d:any)=>{d.b=20}},
{name:'delete one key add another key',initial:{a:1,base:0},a:(d:any)=>{delete d.a},b:(d:any)=>{d.b=2}},
{name:'existing fields in different rows',initial:[{id:1,n:0},{id:2,n:0}],a:(d:any)=>{d[0].n=1},b:(d:any)=>{d[1].n=2}},
{name:'push different rows',initial:[{id:0}],a:(d:any)=>{d.push({id:1})},b:(d:any)=>{d.push({id:2})}},
{name:'delete different array slots',initial:[{id:0},{id:1},{id:2}],a:(d:any)=>{delete d[0]},b:(d:any)=>{delete d[1]}},
{name:'push rows in different nested arrays',initial:{a:[],b:[]},a:(d:any)=>{d.a.push(1)},b:(d:any)=>{d.b.push(2)}}];
test('observe structural overlap and ordinary-store setter atomicity without until',async()=>{
const results:any[]=[];
for(const c of (process.env.PROBE_ORDINARY_ONLY ? [] : cases))for(const witness of ['leaves','values','keys','deep'])for(const first of ['A','B']){
const frames:string[]=[],keys:string[]=[],deepFrames:string[]=[],timeline:any[]=[];let s:any,set:any;
const dispose=createRoot(dispose=>{[s,set]=createOptimisticStore(JSON.parse(JSON.stringify(c.initial)));createRenderEffect(()=>witness==='leaves'?JSON.stringify(Array.isArray(s)?[s.length,s[0]?.id,s[0]?.n,s[1]?.id,s[1]?.n,s[2]?.id]:[s.a,s.b,s.base,s.c]):JSON.stringify(s),v=>{frames.push(v)});if(witness==='keys')createRenderEffect(()=>Object.keys(s).join(','),v=>{keys.push(v)});if(witness==='deep')createRenderEffect(()=>JSON.stringify(deep(s)),v=>{deepFrames.push(v)});return dispose;});
const snap=(at:string)=>timeline.push({at,rendered:frames.at(-1),untracked:untrack(()=>JSON.stringify(s)),latest:latest(()=>JSON.stringify(s)),frameCount:frames.length});
flush();snap('initial');const a=gate(),b=gate();const pa=action(function*(){set(c.a);yield a.promise;})();flush();snap('A live');const pb=action(function*(){set(c.b);yield b.promise;})();flush();snap('A+B live');(first==='A'?a:b).resolve();await settle();snap(first+' gate resolved');(first==='A'?b:a).resolve();await Promise.all([pa,pb]);await settle();snap('both resolved');dispose();results.push({kind:'optimistic overlap',name:c.name,witness,first,timeline,frames,keys,deepFrames});}
for(const change of ['single setter','separate setters same tick','separate flushes'])for(const binding of ['combined render','separate renders only']){
let s:any,set:any,m:any;const frames:any[]=[],aFrames:any[]=[],bFrames:any[]=[],timeline:any[]=[];const g=gate();const dispose=createRoot(dispose=>{[s,set]=createStore({a:0,b:0});m=createMemo(()=>{const n=s.a;return n===0?0:g.promise.then(()=>n*10)});createRenderEffect(()=>s.a,v=>{aFrames.push(v)});createRenderEffect(()=>s.b,v=>{bFrames.push(v)});if(binding==='combined render')createRenderEffect(()=>[s.a,s.b,m()],v=>{frames.push(v)});else createRenderEffect(m,v=>{frames.push(v)});return dispose;});
const snap=(at:string)=>timeline.push({at,combined:frames.at(-1),a:aFrames.at(-1),b:bFrames.at(-1),untracked:untrack(()=>[s.a,s.b]),latest:latest(()=>[s.a,s.b])});flush();snap('initial');if(change==='single setter')set((d:any)=>{d.a=1;d.b=1});else{set((d:any)=>{d.a=1});if(change==='separate flushes'){flush();snap('a flush');}set((d:any)=>{d.b=1});}snap('before flush');flush();snap('async pending');g.resolve();await settle();snap('async landed');dispose();results.push({kind:'ordinary store atomicity',name:change,binding,timeline,frames,aFrames,bFrames});}
writeFileSync(process.env.PROBE_OUTPUT || '/workspace/scratch/store-integration-inventory/structural/next-results.json',JSON.stringify(results,null,2));});
