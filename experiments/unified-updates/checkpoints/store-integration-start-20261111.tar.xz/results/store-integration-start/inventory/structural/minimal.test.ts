import {test,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {action,createOptimisticStore,createOptimistic,createMemo,createRenderEffect,createRoot,createSignal,deep,flush} from 'probe-runtime';
const result:any[]=[];
function gate(){let resolve!:()=>void;const promise=new Promise<void>(r=>resolve=r);return {resolve,promise};}
async function tick(){await new Promise<void>(r=>setTimeout(r,0));flush();}
for(const withDeep of [false,true])test.skipIf(!!process.env.PROBE_SCALAR_ONLY)(`existing disjoint fields ${withDeep?'with deep render':'without deep render'}`,async()=>{
 const frames:number[][]=[],deepFrames:any[]=[],timeline:any[]=[];let set:any;let doneA=false,doneB=false;
 const dispose=createRoot(dispose=>{const [s,setS]=createOptimisticStore({a:0,b:0});set=setS;createRenderEffect(()=>[s.a,s.b],v=>{frames.push(v)});if(withDeep)createRenderEffect(()=>deep(s),v=>{deepFrames.push(v)});return dispose;});
 const note=(at:string)=>timeline.push({at,rendered:frames.at(-1),doneA,doneB});
 flush();note('initial');const ga=gate(),gb=gate();
 const pa=action(function*(){set((d:any)=>{d.a=1});yield ga.promise;})();pa.then(()=>{doneA=true});flush();note('A live');
 const pb=action(function*(){set((d:any)=>{d.b=2});yield gb.promise;})();pb.then(()=>{doneB=true});flush();note('A+B live');
 ga.resolve();await tick();note('A gate resolved plus real tick');
 gb.resolve();await tick();await Promise.all([pa,pb]);note('B gate resolved plus real tick');dispose();
 expect(timeline.map(x=>x.rendered)).toEqual([[0,0],[1,0],[1,2],withDeep?[1,2]:[0,2],[0,0]]);result.push({kind:'store',withDeep,timeline,frames,deepFrames});writeFileSync(process.env.PROBE_OUTPUT!,JSON.stringify(result,null,2));
});
test('scalar equivalent: two independent optimistic outputs plus combined memo render',async()=>{
 const frames:number[][]=[],combinedFrames:number[][]=[],timeline:any[]=[];let guessA:any,guessB:any;let doneA=false,doneB=false;
 const dispose=createRoot(dispose=>{const [sa]=createSignal(0),[sb]=createSignal(0);const [a,ga]=createOptimistic(sa),[b,gb]=createOptimistic(sb);guessA=ga;guessB=gb;createRenderEffect(()=>[a(),b()],v=>{frames.push(v)});const combined=createMemo(()=>[a(),b()]);createRenderEffect(combined,v=>{combinedFrames.push(v)});return dispose;});
 const note=(at:string)=>timeline.push({at,rendered:frames.at(-1),combined:combinedFrames.at(-1),doneA,doneB});
 flush();note('initial');const ga=gate(),gb=gate();
 const pa=action(function*(){guessA(1);yield ga.promise;})();pa.then(()=>{doneA=true});flush();note('A live');
 const pb=action(function*(){guessB(2);yield gb.promise;})();pb.then(()=>{doneB=true});flush();note('A+B live');
 ga.resolve();await tick();note('A gate resolved plus real tick');gb.resolve();await tick();await Promise.all([pa,pb]);note('B gate resolved plus real tick');dispose();
 expect(timeline.map(x=>x.rendered)).toEqual([[0,0],[1,0],[1,2],[0,2],[0,0]]);expect(combinedFrames).toEqual(frames);result.push({kind:'scalar',timeline,frames,combinedFrames});writeFileSync(process.env.PROBE_OUTPUT!,JSON.stringify(result,null,2));
});
