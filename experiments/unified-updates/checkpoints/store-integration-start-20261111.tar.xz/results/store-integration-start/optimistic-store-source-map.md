# Optimistic-store integration: read-only source map

Baseline inspected: layered-solid 743bfbd11d8c007bfe56c7beb0cf7caceeab7830; unmodified next 4fe75321d61f9e4f1e1c63edc2087d099a36e9e1. No tests, builds, package manager operations, or code edits performed. This notes file is the only write.

## Exact historical scope

INTEGRATION-120.md explicitly authorizes independent input/output lifetime separation, including sync/async errors, arbitrary-depth inactive boundary transparency and no functional scalar rebase. A guessing action still waits on its own input's pending flight, including without readers. It removes selectGuess/bindScope incoming lifetime joins, retains same-output scope merging, and cuts observation tracing at retained overridden input links. INTEGRATION-182.md says every known remaining failure is deferred optimistic-store or until coverage; 1,953 signals /23 Solid /115 web failures were deferred then. These are not evidence of supported stores.

## Current legacy implementation is preserved, not migrated

store/optimistic.ts differs from next ONLY by import LEGACY_LANES and constructor guard (diff inspected). Thus every legacy rebase/stands/ask/park rule is still present and requires deliberate disposition. Constructor at 901 throws with the shared engine.

- notifyOptimisticWrites 121: draft difference produces value guesses, separate presence guesses, length guess, container arrangement LaneView, deep witness guess. writerBacking 103 recursively composes chained views; optimisticDraft 116 sets pending staging aside.
- arrangement/rowSame 231/238 and reconcileDraft 301 are data matching helpers; avoid equating these with lifetime policies. pairRows 547 adopts incoming raw rows into existing guessed targets.
- GlobalQueue._slotTake around 349, _laneRebase around 398, fold 476, foldedRead 503, laneSet 530, rebaseChained 716 depend on legacy node lanes/transactions and split display versus deriving worlds.
- installOptHooks 563: ask/stands/park explicitly merges an independent newly asked question with guessing lifetimes. This conflicts with stage120 if copied as shared-engine behavior. It also treats refresh versus new question differently.
- _overlaid index/sweep 688+, nodesOf/laneNodeOf 764+, optimisticHas/OwnDescriptor/View 793/805/824 are reusable concepts but all currently inspect CONFIG_OVERRIDE/_lane/pendingGuessOf.

## Store integration points

store/target.ts StoreTarget n/h/k/dk = value/presence/container/deep nodes; v/pb = committed/pending backing. StoreFamily map/live/node/status controls identity and projection firewall. Do not repurpose input n/h/k as writable computed outputs: store staging, release, _host/_key, bornStaged, folds and raw publication assume slot signals.

store/store.ts:
- LaneView 267 and asBacking/containerEquals 288/295 combine arrangements with backing ownership today.
- getNode 390, getHasNode 434, getContainerNode 451 materialize truth signals; bornStaged 361 gives late slots both frames.
- slotKept/releaseSlot 310-359 retain unpublished truth and legacy overrides; selected output lifetime must independently retain the truth input where necessary.
- notifyWrites 1164 routes optimistic setters to guesses but derived writes to truth setSignal and normal projection staging. Add explicit selected output read mapping rather than routing derived writes to selected output.
- nodeValue 1780; get trap 2135+; has 2290+; ownKeys/enumerationSource 2015; descriptors 2327+; snapshot backing 2812: all need consistent selection. A leaf-only patch misses direct structural/untracked reads.
- pullFamily 1860 is before leaf selection; it can throw or suspend on producer even when a leaf override should mask it. Requires boundary-aware producer status handling, not unconditional skip. Ordinary projections must retain their firewall behavior.

store/projection.ts wakeFamily 156 adds producer pending source to every slot; errorFamily 191 and settleFamily 208 notify indirect readers. forEachFamilyNode 236 enumerates truth slots. createProjectionInternal 380 owns producer (fam.node), raw adoption and refresh. Input readiness must reach input side of each cut without propagating around its output selector. Family refresh remains one producer, unlike independent scalar producers.

## Shared implementation reuse

layers/optimistic.ts createBoundary 278 and layerAccessors 377 currently private. Extract a narrow internal adapter accepting an existing input node (rather than createOptimistic(() => read(slot)) copies); reuse automatic proposal map, bindScope, pendingScope, retirement and cleanup. createLayerBoundary coordination.ts 1275 already takes an existing producer. A per-slot record owns selected output/propose operation; inputs remain store-owned truth slots. Use existing readOverride/read/stageLayer/context retry and observation outputs. No separate guess scheduler or store holding registry.

Input pending/status complication: plain truth slot signals are not computed producer flights. Merely passing slot to existing scalar adapter loses family pending lifetime, because pendingScope checks layer._input status. Need a deliberate source-status relation (coordination Layer has _statusInput; pendingInput recognizes it) or selector input computation which reads producer plus truth slot. Former needs lifetime contract inspection; latter naturally gets proper pending/error but could over-subscribe each key to all producer changes and must avoid general observedness forwarding. Do not casually decide this in implementation.

## Proposed first implementation boundary

Internal, explicitly partial slice: static non-chained, plain data records with existing primitive-valued keys; per-key output boundaries, composing writer drafts, overlapping/disjoint action tests, no structural edits. This proves routing, lifetime and publication before extending presence and arrangement. Keep public unsupported guard until unsupported paths are honestly gated or integrated. Then add presence/deletion, deep witness, arrays/length/holes as one coherent update, derived/async family status, identity/reconciliation and layered/chained reads. A store-wide snapshot optimistic pair is insufficient: it entangles disjoint key actions and loses property subscriptions. No performance changes now.

## Established next behavior and semantic decision points

1. next _laneRebase (398): keyed older landings transplant truth objects by key, preserve guess order, append unseen truth rows except removed keys; unkeyed stays as written. This is stateful edit rebasing distinct from scalar functional rebase. Whether to retain it under separated input/output is unruled.
2. next fold/foldedRead (476/503): ordinary deriving consumers and latest may read truth below visible guess; render effects and lane passes retain guess. This is exactly a split-world rule to reject/review against coherent propagation, not silently reproduce.
3. next ask/park joins independent new-question flush to guessing action; shared stage120 rejects this causal join. Need distinguish deliberate changed expectation from defects, and retain tests as provenance.
4. Structural container is one output; two disjoint deletes/adds share it in next, while key lifetimes are independently scoped. Need decide semantic overlap granularity of key-set/arrangement output. Reusing scalar lifetime semantics mechanically may merge actions that only change disjoint keys.
5. Matching truth can confirm legacy guesses before action completion; scalar selectGuess retains override until action lifetime retires (equal values may be observationally silent). Early confirmation can affect subsequent guesses/lifetimes even if no immediate value change. Need an explicit ruling if store tests pin this.

## Minimal useful acceptance cases (not executed)

- Same property guesses in two actions share final lifetime; different existing properties revert independently, draft composes previous unflushed guess, ordinary consequences pending asynchronously do not define own override lifetime.
- Independent source input advances during guess (sync and async), output retains guess; retirement correction and a multi-level async dependent publish coherently. Add hidden input error and recovery.
- Four nested inactive optimistic store boundaries plus mixed ordinary memo/projection chain behaves like transparent scalar cuts, including late readers and disposal of readers.
- Once structural stage is attempted: delete/presence/undefined/ownKeys/snapshot agree; array push/splice has coherent index,length, holes, and iteration, with async consequences held together.
- Keyed landing with changed objects/order during active removal; pin row proxy identity and all ordinary/latest consumers before choosing preserve-versus-rebase expectations.
