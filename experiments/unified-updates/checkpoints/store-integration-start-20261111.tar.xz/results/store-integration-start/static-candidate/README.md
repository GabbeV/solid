# Frozen static slot trial

Worktree: /workspace/scratch/unified-store-slots
Base: 743bfbd11d8c007bfe56c7beb0cf7caceeab7830
Frozen on primary instruction; main worktree unchanged. No builds, full suites, install, package-manager, or performance commands.

`complete.patch` includes all tracked changes AND both new source/test files. `complete-source.tar.gz` contains the six complete affected files for independent recovery. status.txt and base.txt record provenance.

## Implemented scope

Public createOptimisticStore static flat plain record overload. Existing own enumerable/writable/configurable data properties only. Object.prototype or null prototype. Primitive, function and nonwrappable raw objects (including Promise) preserved by value. Per-property store input slots stay store-owned. Output companions use createLayerBoundary and existing scalar proposal/scope/retirement/publication machinery. No legacy lane enabling; no store-wide optimistic boundary.

Validated isolated drafts compose previous unflushed/active proposals. Shape and descriptors validate before ANY property proposals. Setter callback replacement records can be used only with identical supported shape. Existing writeHook and dev setter guards retained.

Direct tracked/untracked reads select ordinary output reads; enumeration/snapshot backing composes selected outputs under untrack. Direct own-property descriptors select the requested output. Deep explicitly reads selected leaves (lifetime behavior provisional pending user ruling); normal n/h/k/dk truth slots remain intact. Static `in`/key membership stays unchanged because structural writes are rejected. Same key re-guesses merge actions by existing scalar machinery; independent properties in separate flushed turns correct independently.

Output companions allocated ownerless, independent of both creator and first-reader ownership. Confirmed unmodified-next control: dispose creator before reading; create reader; guess during action; dispose first reader; direct read retains guess; action end corrects; late reader observes correction.

Unsupported: derived store callbacks, arrays, nested/wrappable children, store chaining, shallow option, adding/deleting/reordering keys, descriptor changes, changing prototype. Constructor or setter throws explicit interim unsupported error. User mutations of raw opaque leaf objects are not intercepted (ordinary raw-value contract). No claim of complete stores, hydration, affects integration validation, or performance acceptance.

## Verification

Final frozen candidate:
- targeted-source.log: 20/20 source tests (6 new static cases + existing unified-optimistic-api and cancellation).
- existing-flat-controls.log: 3/3 existing flat #2899 controls (first-settling disjoint actions, same-key overlap, ambient independent write); 2 structural/nested tests excluded by name.
- git diff --check passed.
- next-owner.test.ts one control passed on unmodified next before implementation ownership choice. It is in the parent notes folder.

Earlier exploratory run of full optimistic-store-layer-scope.test.ts: 3 pass, 2 fail (nested and deletion explicitly outside slice); deletion action also emits unsupported rejection. No old test expectations changed.

## Unresolved, no semantic fix attempted

1. Deep witness action overlap is being ruled on by user/primary. Current explicit selected-leaf reads do NOT intentionally preserve next's old dk action joining. Do not integrate as accepted deep semantics yet.
2. Enumeration context tradeoff: composing view under untrack preserves subscription granularity but can still discover value contexts. Making enumeration backing shape-only would avoid that discovery, but Object.keys and Object.getOwnPropertyDescriptors use identical ownKeys->descriptor trap sequences, so returning unchanged enumeration descriptor values would make descriptor collections stale. Current frozen candidate preserves selected descriptor values. No shape-only hook was added and no mandatory requirement was invented.
3. Same-tick A/B/C probe: A guesses a=2 then flush; B guesses a=3 and C guesses b=4 before next flush; resolve A and C with B open => both scalar/store keep b=4. EXPECTED INDEPENDENCE UNESTABLISHED; ordinary same-flush batching is the leading hypothesis. This is not a confirmed inherited defect. Standalone paired control saved in parent folder; no scheduler change or expectation rewrite made.

## Rules read

There is no file named RULES-STORE in either checkout. The current rules source is packages/signals/docs/rules-mining/core-store.md:
- R13: `in` tracks presence, not value; undefined-write doesn't retrigger; delete/add do; no getter invocation.
- R14: Object.keys/for-in subscribe to key-set membership, distinct from property nodes.
- R51: descriptors agree with reads after flush.
R13 does not by itself establish a ban on calculation-context discovery by an untracked value read. Existing subscription-only enumeration test passes. Further contract review should distinguish subscriptions, calculation context and descriptor value correctness.

## Additional acceptance check after freeze

See ../writer-publication/README.md. The frozen candidate has a CONFIRMED writer-publication coherence gap: one setter changing both a and b can publish b=1 while a and its async dependent retain0. Ordinary control and both next pins hold the setter together. Source remains unchanged; this acceptance failure supersedes any interpretation of the 20 passing targeted cases as sufficient coverage of the static slice. Candidate is not ready to integrate as coherent supported static stores.
