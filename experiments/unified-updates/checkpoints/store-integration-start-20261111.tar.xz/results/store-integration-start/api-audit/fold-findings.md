# Observable fold/rebase audit

Pinned sources: unmodified next `4fe75321d`; newer next `bcef1041c` in `/workspace/scratch/solid-pr4717-review`. No runtime/source edits. Probe: `fold.test.ts`, config `fold.config.mjs`, complete timestamped event receipts `fold-next4fe.log` and `fold-nextbcef.log`. Probes use controlled Promise gates, no until. Six observational cases execute per revision; trivial sanity assertions are not a semantic conformance suite.

Core program:
```ts
const [input, setInput] = createSignal([{id:'a'}, {id:'b'}]);
const [view, setView] = createOptimisticStore(() => input(), [], {key:'id'});
const ids = () => view.map(r => r.id).join(',');
const memo = createMemo(ids);
createRenderEffect(ids, publishDirect);
createRenderEffect(memo, publishMemo);
createRenderEffect(() => latest(ids), publishLatest);
const gate = Promise.withResolvers<void>();
const done = action(function* () {
  setView(d => { d.splice(0,1); d.push({id:'g'}); });
  yield gate.promise;
})();
flush();
setInput([{id:'a'}, {id:'b'}, {id:'c'}]);
flush(); // gate remains closed
// Mount fresh mainline memo + render, then release gate.
```

Keyed observable timeline, IDENTICAL on both revisions:

| Phase | direct render | existing memo render | latest render |
|---|---|---|---|
| initial | a,b | a,b | a,b |
| guess | b,g | b,g | b,g |
| truth arrives, gate closed | b,g | b,g | a,b,c |
| gate releases | a,b,c | a,b,c | a,b,c |

Fresh keyed memo mounted after truth COMPUTES a,b,c and latest(freshMemo) returns it. Its ordinary render callback DOES NOT execute until gate releases. Existing keyed memo's calculation in this probe still computes b,g during the retained lane pass. No ordinary publication disagreement was demonstrated; the fresh truth is held consistently. Latest publication genuinely differs because it explicitly selects the held truth. b's proxy identity survives.

Source evidence: next `src/store/optimistic.ts:468 fold` retains keyed arrangement guess and sets lane.folded; `:502 foldedRead` explicitly excludes lane passes/render passes/author derive, serves truth to outside deriving passes and joins the hold. Design `docs/RULES-DERIVED.md` D-34 describes graph correction vs screen retention. Existing `tests/held-truth-lane-only.test.ts:374` explicitly asserts fresh memo computes truth but `published=[]` until release; `tests/optimistic-keyed-fold.test.ts:1` explains original torn-list/remount motivation. These distinguish computation receipts from publication.

A genuinely NEW question already in flight before the guess is a DIFFERENT case: use promise-valued input, set its next promise, flush, then remove a/add g; resolve new answer a,b,c. On both revisions visible output becomes b,g,c BEFORE gate release: removed a stays removed, g stays added, foreign c appends, b retains identity. Release reveals a,b,c. `optimistic.ts:206` sets view.g=null for a new pending question (explicitly excludes refresh); `:397 _laneRebase` composes keyed rows. A quiet refresh already in flight before guess instead folds: display remains b,g, latest gives a,b,c.

Unkeyed (`key:null`) is positional residue, not the keyed rule. New-question answer shows a,b,<empty-id> on 4fe and a,b on bcef; b identity is lost, release yields a,b,c. For synchronous truth, 4fe fresh ordinary memo actually publishes a,b,c while existing direct render remains b,g; bcef holds that fresh memo until release. This newer difference prevents treating the 4fe unkeyed result as a settled semantic requirement.

Receipts: both runs `6 passed`, under one second. Command from respective packages/signals directory:
`AUDIT_SOURCE=<checkout> node /workspace/layered-solid/node_modules/vitest/vitest.mjs run --config /workspace/scratch/store-integration-apis/fold.config.mjs --reporter=verbose`

No new semantic question is proven by keyed foldedRead: ordinary consumers have consistent publication with different held calculations. If asking the user about unkeyed behavior, show the revision-dependent executable example rather than claiming a universal contradiction.
