export default {
  resolve: { alias: { 'audit-signals': (process.env.AUDIT_SOURCE || '/workspace/layered-next-4fe75321') + '/packages/signals/src/index.ts' } },
  define: { __DEV__: 'true', __OBSERVE__: 'true', __TEST__: 'true' },
  test: { include: ['/workspace/scratch/store-integration-apis/fold.test.ts'], globals: true, pool: 'threads', maxWorkers: 1 }
};
