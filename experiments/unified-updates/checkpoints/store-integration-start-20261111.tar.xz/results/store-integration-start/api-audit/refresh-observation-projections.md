# Read-only bounded audit: refresh / isPending / latest / projections

Subject: /workspace/layered-solid HEAD 743bfbd11d8c007bfe56c7beb0cf7caceeab7830.
Baseline: /workspace/layered-next-4fe75321, unmodified next. No source/test changes; no installs/builds/full suites. AGENTS.md read. Scope excludes performance/size.

## Public paths and supported ordinary behavior

- `src/store/index.ts:103 createStore` selects plain store vs `createStoreDerived`; `src/store/projection.ts:380 createProjectionInternal` creates a family + eager derive computed, disables auto-disposal, and assigns `node._fam`. `createProjection` (:442) and derived createStore (:461) share the same mechanism. Public APIs are exported, not stubs. This source supersedes historical summaries claiming projections are deferred.
- `src/store/store.ts:2115` proxy `$REFRESH` returns `target._fam?.node`; `src/layers/refresh.ts:32 refresh` finds that producer, calls `refreshInput` then `markRefresh`, installs a microtask waiter, and returns the ORIGINAL store identity for non-function targets (:103). It waits on source status, detects invalidation before delivery, handles equal/deferred paths, rejects source errors, and respects caller action vs foreign action publication. Plain non-derived stores have no family node and therefore are invalid refresh targets; plain signal accessors are separately valid no-op targets. Wrapper callbacks and property expressions are not refreshable.
- `src/layers/boundary.ts:9 refreshInput` crosses exactly one registered optimistic boundary when `_inputStatus` is set; `_refreshInput` can materialize an immediate producer. No upstream dependency traversal exists here. For today's ordinary projections no boundary is registered on the producer, so refresh re-asks the projection producer itself.
- Store reads call core `read` (aliased `readNode`, store.ts:60), not a detached observation implementation. `pullFamily` (:1860) updates/gates the producer before a leaf/shape read. Settled ordinary reads use untrack around producer to preserve the property firewall; explicit observation windows DO read its observation output (:1910), even when no leaf existed, so a later flight is visible. Pending/error reads go through `readNode`; staged errors avoid direct producer links from observation callers (:1903), preserving the observation cut.
- `src/layers/pending.ts:281 isPending` and `latest.ts:198 latest` use a direct `$REFRESH` producer when passed an accessor; callback forms use `withReadWindow`. Public type expects a callback/accessor, so property probes are `isPending(() => store.key)` / `latest(() => store.key)`, not a bare store argument. `pending.ts:236 probe` first observes source-owned pending output then drives callback control flow in the current calculation's context; it rethrows ContextRetry. `window.ts:54 dispatch` restores outer observation dispatch and prevents propagation into nested computations' own ordinary reads.
- `latest.ts:175 latestOutput` and `pending.ts:196 pendingOutput` maintain source-owned companions; `observation.ts:204 createSourceObservation` calls `createLayerBoundary(source, select, false, true)` (does not own producer, lazy output). `latest` fallback reads through ordinary source when inactive; store keys therefore continue ordinary dependency and publication behavior rather than acquiring an independent pending lifecycle.
- `projection.ts:156 wakeFamily`, :202 settleFamily, :218 familyStatus adapt producer status to subscribed leaf/presence/container/deep nodes. `runProjectionComputed` (:247) shares core handleAsync, validity per run, keyed reconcile, async iterable commits and status handling. It explicitly propagates ContextRetry unchanged (:355); this is essential for coherent cross-boundary abort/retry and must survive optimistic-store integration. Draft validity is per run/owner, not flight duration.

## Comparison to unmodified next

- Projection source is substantially retained. `diff -u` shows only CONFIG_LOADING representation updates plus explicit ContextRetry rethrow in its main pass. Ordinary projection behavior was not removed wholesale.
- Next's `src/core/verdict.ts:338 latest` and :384 isPending wrap callback reads with global verdict dispatch and mark the caller as verdict reader; unified source now uses selected source-owned outputs with read windows. Do not infer semantic exceptions from old caller-level machinery.
- Next `src/signals.ts:923 refresh` marks its target directly and uses an authoritative/FRESH_READ watch. Unified uses immediate-boundary input resolution and shared computed waiter. Existing scalar refresh tests (`tests/unified-refresh.test.ts:39`, :388) encode immediate-input/one-boundary behavior; store port must retain this ruling rather than recursively refresh dependencies.
- Design rules at docs/rules-mining/projections.md explicitly cover firewall (PJ-R12), live chaining (R17-22), invisible initial seed (R23), latest-run wins (R26), quiet refresh vs affects+refresh (R28-29), memo-parity errors/retries (R34-35), per-run draft lifetime (R37). These are evidence/design context; passing selected tests does not authorize excluding the rest of upstream.

## Explicit unsupported branch and implementation hooks

- `src/core/constants.ts:3 LEGACY_LANES = false`; `src/store/optimistic.ts:901 createOptimisticStore` always throws `Optimistic stores are not integrated with the shared update engine yet.` This affects both plain and derived optimistic stores. This is implementation incompleteness, NOT user-approved exclusion. No analogous ordinary projection/refresh/isPending/latest guard exists.
- Legacy `store/hooks.ts OptHooks` remains installed by `store/optimistic.ts:563`. It covers draft/writes/view/has/descriptor/sweep/arrangement/reconcile/pair/ask/park/stands; comments and implementation use legacy lanes. `pullFamily` has `stands` exception for guesses, `wakeFamily` calls `ask`, and view/descriptor/presence paths consult optHooks. These are the retained store integration seams; enabling constructor alone does not wire them to shared layers.
- New implementation needs public store `$REFRESH` to identify the immediate input producer correctly, not a guessed leaf or recursive upstream dependency. Existing scalar registry is `layers/boundary.ts boundaries` and `coordination.ts:1275 createLayerBoundary`; boundary carries `_input`, `_output`, `_inputStatus`, optional `_refreshInput`. Need deliberate mapping for family producer vs selected property outputs.
- Property, presence, container/shape and deep observation must all select through shared ordinary reads; preserve family status forwarding for ordinary reads while stopping observation callers at their selected outputs. Preserve source-owned pending outputs and current-context callback control flow. Retain own input hold until answer even absent downstream readers; do not add general observedness forwarding to compensate for the store firewall. Existing `coordination.ts:107 observed` intentionally cuts overridden input edges.
- `runProjectionComputed` already offers `wrapCommit` and `aroundDraftWrite` hooks (:251-252), and family `opt`, map/live/key metadata are retained. These permit adapting authoritative derive commits separately from user optimistic setter writes without a second async replay rule.

## Focused verification receipts

Command in layered-solid/packages/signals:
`node /workspace/layered-solid/node_modules/vitest/vitest.mjs run tests/store/createProjection.async.test.ts tests/strict-read-pending-store.test.ts tests/derived-store-ispending-boundary-4269.test.ts tests/latest-store-held-manual-write.test.ts -t 'refresh\(\) forces a new async run|await refresh\(store\)|store under a boundary reports pending|latest of one input' --maxWorkers=1`
Result: 4 files passed; 5 selected tests passed, 48 filtered tests skipped; 1.64s. Filtered skips are this audit's bounded selection, not exemptions.

Selected cases:
- `tests/store/createProjection.async.test.ts:519` refresh forces new async derive runs.
- `tests/strict-read-pending-store.test.ts:263` await refresh returns same store, makes next fetch, emits no strict-read diagnostic (also validates thenable probe path).
- `tests/derived-store-ispending-boundary-4269.test.ts:79` callback property pending under revealed boundary yields `1 pending` then `2 -`.
- `tests/latest-store-held-manual-write.test.ts:13` two parameter cases: latest(input) inside ordinary derived store cannot release unrelated manual existing/new-key write held by an action.

Same three upstream tests run on unmodified next with same executable/filter (omit latest-store-held-manual-write file): 3 files passed, 3 selected tests passed, 48 filtered skipped, 1.41s.

## Semantic questions

No new semantic question is established by this bounded audit. Immediate-input refresh, coherent callback context, ordinary async replay, own-input retention, and lack of general observedness forwarding already have user rulings. Family-vs-property boundary representation is an implementation decision to validate against those rulings. If accepted upstream tests fail during integration, classify individually; do not assume all verdict/pending/store failures are excluded. Broader ordinary async projection/error/iterator suites remain unverified by this receipt, not unsupported.
