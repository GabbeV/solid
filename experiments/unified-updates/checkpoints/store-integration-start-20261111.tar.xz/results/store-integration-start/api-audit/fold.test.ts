import { it, expect } from '/workspace/layered-solid/node_modules/vitest/dist/index.js';
import { action, createMemo, createOptimisticStore, createRenderEffect, createRoot, createSignal, flush, latest, refresh } from 'audit-signals';
const turn = async () => { await new Promise(r => setTimeout(r, 0)); flush(); };
for (const key of ['id', null]) {
  it(`current truth beneath remove/add key=${key}`, async () => {
    const events: any[] = [];
    let view: any, setView: any, setInput: any, memo: any, dispose: any;
    const ids = () => view.map((r: any) => r.id).join(',');
    createRoot(d => {
      dispose = d;
      const [input, set] = createSignal([{id:'a'}, {id:'b'}]); setInput = set;
      [view, setView] = createOptimisticStore(() => input(), [], { key });
      memo = createMemo(() => { const value = ids(); events.push(['calculation', value]); return value; });
      createRenderEffect(ids, v => void events.push(['direct-render', v]));
      createRenderEffect(memo, v => void events.push(['memo-render', v]));
      createRenderEffect(() => latest(ids), v => void events.push(['latest-render', v]));
    });
    flush(); await turn();
    const retained = view[1];
    const gate = Promise.withResolvers<void>();
    const run = action(function* () { setView((d:any) => { d.splice(0,1); d.push({id:'g'}); }); yield gate.promise; })();
    const snap = (stage:string) => { flush(); events.push([stage, {direct:ids(), memo:memo(), latest:latest(ids), bSame:view.find((r:any)=>r.id==='b')===retained}]); };
    flush(); await turn(); snap('guess');
    setInput([{id:'a'}, {id:'b'}, {id:'c'}]); flush(); await turn(); snap('truth');
    const freshDispose = createRoot(d => { const fresh = createMemo(() => {const v=ids();events.push(['fresh-calculation',v]); return v;});createRenderEffect(fresh,v=>void events.push(['fresh-render',v])); events.push(['fresh-latest', latest(fresh)]); return d; }); flush();
    events.push(['release-start']); gate.resolve(); await run; await turn(); snap('released');
    console.log(JSON.stringify({case:`current-${key}`, events})); freshDispose(); dispose();
    expect(events.length).toBeGreaterThan(0);
  });
  it(`refresh answer beneath guess key=${key}`, async () => {
    const events:any[]=[]; let view:any,setView:any,dispose:any; let answer=Promise.withResolvers<any>();
    const ids=()=>view.map((r:any)=>r.id).join(',');
    createRoot(d=>{dispose=d; [view,setView]=createOptimisticStore(()=>answer.promise, [], {key}); createRenderEffect(ids,v=>void events.push(['render',v]));});
    answer.resolve([{id:'a'},{id:'b'}]); await turn();
    const retained=view[1];
    answer=Promise.withResolvers<any>(); const refreshed=refresh(view); flush(); await turn();
    const gate=Promise.withResolvers<void>();
    const run=action(function*(){setView((d:any)=>{d.splice(0,1);d.push({id:'g'});});yield gate.promise;})(); flush(); await turn();
    events.push(['guess',ids()]);
    answer.resolve([{id:'a'},{id:'b'},{id:'c'}]); await turn(); await turn();
    events.push(['older-answer',{direct:ids(),latest:latest(ids),bSame:view.find((r:any)=>r.id==='b')===retained}]);
    gate.resolve(); await run; await refreshed; await turn(); events.push(['released',ids()]);
    console.log(JSON.stringify({case:`older-${key}`,events})); dispose(); expect(events.length).toBeGreaterThan(0);
  });
}

for (const key of ['id', null]) it(`new question before guess key=${key}`,async()=>{
 const events:any[]=[];let view:any,setView:any,setInput:any,dispose:any;const first=Promise.withResolvers<any>();const second=Promise.withResolvers<any>();
 const ids=()=>view.map((r:any)=>r.id).join(',');
 createRoot(d=>{dispose=d;const [input,set]=createSignal(first.promise);setInput=set;[view,setView]=createOptimisticStore(()=>input(),[],{key});createRenderEffect(ids,v=>void events.push(['render',v]));});
 first.resolve([{id:'a'},{id:'b'}]);await turn();const retained=view[1];
 setInput(second.promise);flush();await turn();
 const gate=Promise.withResolvers<void>();const run=action(function*(){setView((d:any)=>{d.splice(0,1);d.push({id:'g'});});yield gate.promise;})();flush();await turn();events.push(['guess',ids()]);
 second.resolve([{id:'a'},{id:'b'},{id:'c'}]);await turn();await turn();events.push(['answer',{direct:ids(),latest:latest(ids),bSame:view.find((r:any)=>r.id==='b')===retained}]);
 gate.resolve();await run;await turn();events.push(['released',ids()]);console.log(JSON.stringify({case:`question-${key}`,events}));dispose();expect(events.length).toBeGreaterThan(0);
});
