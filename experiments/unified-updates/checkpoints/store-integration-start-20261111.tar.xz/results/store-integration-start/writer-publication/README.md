# Single-setter writer-publication acceptance check

Read-only executable check; frozen candidate source patch unchanged.

Candidate: /workspace/scratch/unified-store-slots, frozen trial based on 743bfbd11.
Next controls: 4fe75321d61f9e4f1e1c63edc2087d099a36e9e1 and bcef1041cb50bf648da5641693b5ebdea1fc5dc2.

One setter writes a=1 AND b=1. A memo reads only a and suspends on its deferred answer. Three separate scheduled render effects publish a, b, and asyncA independently; there is no combined observer or deep read. The action remains open on a separate gate, which remains unresolved while asyncA is resolved.

Expected while answer unresolved and action gate open: all attached effects retain {a:0,b:0,asyncA:0}.
After async answer resolves with action still open: optimistic outputs publish {a:1,b:1,asyncA:10}; ordinary store retains {0,0,0} until action ends. Optimistic store reverts all on action completion.

Results:
- candidate.test.ts: optimistic test FAILS at initial pending phase: {a:0,b:1,asyncA:0}. Callback log confirms b publishes 1 while a remains0. Ordinary control PASSES. 1 pass /1 fail.
- next4fe.test.ts: both optimistic and ordinary controls PASS. 2 pass.
- nextbcef.test.ts: both optimistic and ordinary controls PASS. 2 pass.

This establishes missing writer-publication grouping in the candidate. Independently proposing each selected slot does not group one setter's publication when only one slot's consequences suspend. Do not weaken coherence expectations or classify the split as intentional.

Files (*.test.ts) import their checkout's actual source; *.log preserve exact commands' output. Each source test run used its checkout's existing vite.config.ts and existing vitest binary, with --dir pointing here. No builds, installs, broader probes or code fixes.
