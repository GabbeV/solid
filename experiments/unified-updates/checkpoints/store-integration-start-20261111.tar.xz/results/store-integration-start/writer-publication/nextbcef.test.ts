import { expect, it } from 'vitest';
import { action, createMemo, createOptimisticStore, createRenderEffect, createRoot, createStore, flush } from '/workspace/scratch/solid-pr4717-review/packages/signals/src/index.ts';
const turn = () => new Promise(r => setTimeout(r, 0));
for (const kind of ['optimistic', 'ordinary'] as const) it(kind + ' single setter publishes both properties coherently', async () => {
  const gate = Promise.withResolvers<void>(), answer = Promise.withResolvers<number>();
  let set!: (fn: (draft: {a: number, b: number}) => void) => void;
  const shown = { a: -1, b: -1, asyncA: -1 };
  const callbacks: [string, number][] = [];
  const dispose = createRoot(dispose => {
    const [s, write] = kind === 'optimistic' ? createOptimisticStore({a: 0, b: 0}) : createStore({a: 0, b: 0});
    set = write;
    const asyncA = createMemo(() => s.a ? answer.promise : 0);
    createRenderEffect(() => s.a, value => {shown.a = value; callbacks.push(['a', value]);});
    createRenderEffect(() => s.b, value => {shown.b = value; callbacks.push(['b', value]);});
    createRenderEffect(asyncA, value => {shown.asyncA = value; callbacks.push(['asyncA', value]);});
    return dispose;
  });
  let running: Promise<unknown> | undefined;
  try {
    flush();
    running = action(function* () {set(d => {d.a = 1; d.b = 1}); yield gate.promise;})();
    flush(); await turn(); flush();
    console.log(JSON.stringify({kind, phase: 'answer unresolved, independent action gate open', shown, callbacks}));
    expect(shown).toEqual({a: 0, b: 0, asyncA: 0});
    answer.resolve(10); await turn(); flush();
    console.log(JSON.stringify({kind, phase: 'answer ready, independent action gate still open', shown, callbacks}));
    if (kind === 'optimistic') expect(shown).toEqual({a: 1, b: 1, asyncA: 10});
    else expect(shown).toEqual({a: 0, b: 0, asyncA: 0});
    gate.resolve(); await running; await turn(); flush();
    console.log(JSON.stringify({kind, phase: 'action complete', shown, callbacks}));
    expect(shown).toEqual(kind === 'optimistic' ? {a: 0, b: 0, asyncA: 0} : {a: 1, b: 1, asyncA: 10});
  } finally {answer.resolve(10); gate.resolve(); if (running) await running; await turn(); dispose(); flush();}
});
