import { mergeConfig } from "vitest/config";
import config from "./vite.config.mjs";
export default mergeConfig(config, { resolve:{alias:{"@solidjs/signals":"/workspace/scratch/error-publication-trace/dist/dev.js"}},test:{server:{deps:{inline:["solid-js","@solidjs/signals"]}}}});
