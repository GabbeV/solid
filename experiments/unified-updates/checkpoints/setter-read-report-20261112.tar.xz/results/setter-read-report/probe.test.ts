import {test,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {action,createOptimisticStore,createRenderEffect,createRoot,createSignal,flush} from 'probe-runtime';
const results:unknown[]=[];
const turn=async()=>{await new Promise(r=>setTimeout(r,0));flush()};
for(const mode of ['read a, write b','literal b','read a, write a']) {
 test(mode,async()=>{
  const [o,set]=createOptimisticStore({a:0,b:0});
  const [saved,setSaved]=createSignal(false);
  const gateA=Promise.withResolvers<void>(),gateB=Promise.withResolvers<void>();
  let shown:unknown,committed=false,read:unknown;
  const dispose=createRoot(d=>{createRenderEffect(()=>[o.a,o.b],v=>{shown=v});createRenderEffect(saved,v=>{committed=v});return d});
  const timeline:unknown[]=[];
  const note=(phase:string)=>timeline.push({phase,shown,committed});
  let a,b;
  try{
   flush();note('initial');
   a=action(function*(){set(d=>{d.a=1});setSaved(true);yield gateA.promise})();
   flush();note('A live');
   b=action(function*(){set(d=>{
    if(mode==='literal b')d.b=2;
    else {read=d.a;if(mode==='read a, write b')d.b=d.a+1;else d.a=d.a+1;}
   });yield gateB.promise})();
   flush();note('both live');
   gateA.resolve();await a;await turn();note('A finished, B live');
   gateB.resolve();await b;await turn();note('both finished');
   expect(shown).toEqual([0,0]);results.push({mode,read,timeline});
   writeFileSync(process.env.PROBE_OUTPUT!,JSON.stringify(results,null,2));
  }finally{gateA.resolve();gateB.resolve();await Promise.all([a,b]);dispose();flush()}
 });
}
