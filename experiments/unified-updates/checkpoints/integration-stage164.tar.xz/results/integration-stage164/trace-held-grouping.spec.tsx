/** @jsxImportSource @solidjs/web */
import { test } from "vitest";
import { createMemo, createSignal, flush, latest, isPending, Loading, Show } from "solid-js";
import { render } from "../src/index.js";
const turn = async () => { await new Promise(r => setTimeout(r, 0)); flush(); };
for (const pending of [false, true]) test(`grouping pending=${pending}`, async () => {
  const div = document.createElement('div');
  const stop = Promise.withResolvers<number>();
  const requests: { name: string, value: number, resolve: (v:number)=>void }[] = [];
  const ask = (name:string, value:number) => new Promise<number>(resolve => requests.push({name,value,resolve}));
  let inspect!: () => unknown;
  let mount!: () => void;
  let setId!: (v:number)=>void;
  const dispose = render(() => {
    const [id,set] = createSignal(1); setId = set;
    const [visible,setVisible] = createSignal(false); mount = () => setVisible(true);
    const preview = createMemo(() => ask('preview', 1 + latest(id) + id()));
    const result = createMemo(() => ask('result', 100 + preview()));
    const hold = createMemo(() => id() === 1 ? 1 : stop.promise);
    inspect = () => [id(),preview(),result(),isPending(result)];
    return <><b>{id()}</b><Loading fallback="loading">{pending
      ? <span>{`${hold()} / ${isPending(result)} / ${result()}`}</span>
      : <span>{`${hold()} / ${result()}`}</span> }</Loading><Show when={visible()}><em>{result()}</em></Show></>;
  }, div);
  let answered = 0;
  const land = async () => { for(let i=0;i<8;i++){const end=requests.length; while(answered<end){const r=requests[answered++];r.resolve(r.value);}await turn();} };
  const states: string[] = [];
  try {
    flush(); await land(); states.push(div.textContent!);
    setId(2); flush(); states.push(div.textContent!);
    await land(); states.push(div.textContent!); process.stdout.write(JSON.stringify({pending, committed:inspect()}) + "\n");
    mount(); flush(); states.push(div.textContent!);
    stop.resolve(1); await land(); states.push(div.textContent!);
    process.stdout.write(JSON.stringify({pending,states,asks: requests.map(r=>`${r.name}:${r.value}`)}) + "\n");
  } finally {stop.resolve(1); dispose();flush();}
});
