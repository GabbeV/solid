import { it } from "vitest";
import {writeFileSync} from "node:fs";
import {createSignal, createMemo, createRoot, createRenderEffect, flush, latest} from "../src/index.js";
it("trace", () => {
 const trace: any[] = []; (globalThis as any).__latestTrace = trace;
 const [s,set] = createSignal(0);
 const dispose = createRoot(dispose => {
  const m = createMemo(() => { trace.push(["START"]); const l=latest(s);trace.push(["LATEST", l]);const v=s();trace.push(["PASS",l,v]);return `${l}/${v}`; });
  createRenderEffect(m, v=>{trace.push(["SCREEN",v])});
  return dispose;
 });
 flush(); trace.push(["WRITE"]);set(1);flush();dispose();delete (globalThis as any).__latestTrace;
 writeFileSync("/workspace/layered-solid/experiments/unified-updates/results/integration-stage149/order.json",JSON.stringify(trace,null,2));
});
