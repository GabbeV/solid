import {it,expect} from "vitest";
import {writeFileSync} from "node:fs";
import {createMemo,createRoot,createSignal,createRenderEffect,latest,flush} from "../src/index.js";
it("latest feedback requests", async () => {
 const asks: {v:number, d:PromiseWithResolvers<number>}[]=[];
 const screen:number[]=[];const frames:any[]=[];
 const [s,set]=createSignal(1);
 const dispose=createRoot(dispose=>{
  const m=createMemo(()=>{
    const value=10*latest(s)+s();
    if(value===11)return value;
    const d=Promise.withResolvers<number>();asks.push({v:value,d});return d.promise;
  });
  createRenderEffect(m,v=>{screen.push(v)});
  return dispose;
 });
 const take=()=>frames.push({source:s(),asks:asks.map(a=>a.v),screen:[...screen]});
 flush();take();set(2);flush();take();
 for(let i=0;i<asks.length;i++){asks[i].d.resolve(asks[i].v);await new Promise(r=>setTimeout(r,0));flush();take();if(i>8)throw Error("too many");}
 dispose();writeFileSync("/workspace/layered-solid/experiments/unified-updates/results/integration-stage149/feedback.json",JSON.stringify(frames,null,2));
 expect(screen.at(-1)).toBe(22);
});
