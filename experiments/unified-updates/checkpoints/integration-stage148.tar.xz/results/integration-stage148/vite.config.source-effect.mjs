import { mergeConfig } from "vitest/config";
import config from "./vite.config.mjs";
export default mergeConfig(config, {
  define: { __DEV__: "true", __OBSERVE__: "true", __TEST__: "false" },
  resolve: { alias: { "@solidjs/signals": "/workspace/layered-solid/packages/signals/src/index.ts" } },
  test: { server: { deps: { inline: ["solid-js", "@solidjs/signals"] } } }
});
