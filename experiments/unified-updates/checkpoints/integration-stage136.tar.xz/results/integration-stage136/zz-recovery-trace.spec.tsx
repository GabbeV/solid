/** @jsxImportSource @solidjs/web */
import { expect, test } from "vitest";
import { action, createMemo, createSignal, Errored, latest, Show } from "solid-js";
import { render } from "@solidjs/web";

const tick = () => new Promise<void>(resolve => setTimeout(resolve, 0));

for (const fail of [false, true]) {
for (const depth of [0, 1, 2]) {
  for (const asyncAnswer of [false, true]) {
    test.each([false, true])(
      `latest publishes errors and recovery through ${depth} memos (async=${asyncAnswer}, error=${fail}, removal=%s)`,
      async removeBranch => {
        const end = Promise.withResolvers<void>();
        const answer = Promise.withResolvers<string>();
        const recovery = Promise.withResolvers<string>();
        const container = document.createElement("div");
        const frames: string[]=[];
        globalThis.__errorTrace = x => process.stdout.write(JSON.stringify({depth,fail,removeBranch,...x})+"\n");
        let start!: () => Promise<unknown>;
        let setVersion!: (value: number) => void;
        function App() {
          const [version, set] = createSignal(0);
          setVersion = set;
          const data = createMemo(() => {
            switch (version()) {
              case 1:
                if (asyncAnswer) return answer.promise;
                if (fail) throw new Error("failed");
                return "changed";
              case 2:
                if (fail) throw new Error("failed again");
                return "changed again";
              case 3: return recovery.promise;
              default: return "ready";
            }
          });
          let ahead = () => latest(data);
          for (let i = 0; i < depth; i++) ahead = createMemo(ahead);
          start = action(function* () {
            set(1);
            yield end.promise;
          });
          return <>
            <p>{version()}</p>
            <Errored fallback={error => (error() as Error).message}>
              <Show when={!removeBranch || version() !== 1}><span>{ahead()}</span></Show>
            </Errored>
            <hr />
            <Errored fallback={error => (error() as Error).message}>
              <span>{data()}</span>
            </Errored>
          </>;
        }
        const dispose = render(() => <App />, container);
        let running: Promise<unknown> | undefined;
        try {
          await tick();
          frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
          running = start();
          await tick();
          if (asyncAnswer) {
            frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
            if (fail) answer.reject(new Error("failed"));
            else answer.resolve("changed");
            await tick();
          }
          frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
          setVersion(2);
          await tick();
          frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
          setVersion(3);
          await tick();
          frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
          recovery.resolve("recovered");
          await tick();
          frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
          end.resolve();
          await running;
          await tick();
          frames.push(container.textContent!); process.stdout.write(JSON.stringify({phase:frames.length,screen:container.textContent})+"\n");
        process.stdout.write(JSON.stringify({depth,asyncAnswer,fail,removeBranch,frames})+"\n");
        } finally {
          end.resolve();
          answer.resolve("ready");
          recovery.resolve("recovered");
          await running;
          dispose();
        }
      }
    );
  }
}

}
