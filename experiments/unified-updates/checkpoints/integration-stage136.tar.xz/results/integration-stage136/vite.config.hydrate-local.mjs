import { mergeConfig } from "vitest/config";
import config from "./vite.config.hydrate.mjs";
export default mergeConfig(config, { test: { setupFiles: ["./test/local-jest-dom.ts"] } });
