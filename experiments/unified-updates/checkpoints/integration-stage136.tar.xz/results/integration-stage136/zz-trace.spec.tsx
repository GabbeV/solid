/**
 * @jsxImportSource @solidjs/web
 * @vitest-environment jsdom
 */
import { expect, test } from "vitest";
import { action, createMemo, createSignal, Errored, latest, Show } from "solid-js";
import { render } from "@solidjs/web";
const turn = () => new Promise<void>(r => setTimeout(r, 0));

test.each([[false,false], [false,true], [true,false], [true,true]])("held latest error timeline (branch removal=%s, error=%s)", async (removeBranch, fail) => {
  globalThis.__errorTrace = x => process.stdout.write(JSON.stringify({removeBranch,fail,...x})+"\n");
  const end = Promise.withResolvers<void>();
  const recovery = Promise.withResolvers<string>();
  const container = document.createElement("div");
  const frames: string[] = [];
  let start!: () => Promise<unknown>, recover!: () => void;
  function App() {
    const [version, setVersion] = createSignal(0);
    const data = createMemo(() => {
      if (version() === 1) {
        if (fail) throw new Error("failed");
        return "changed";
      }
      if (version() === 2) return recovery.promise;
      return "ready";
    });
    start = action(function* () {
      setVersion(1);
      yield end.promise;
    });
    recover = () => setVersion(2);
    return <>
      <p>{version()}</p>
      <Errored fallback={error => error().message}>
        <Show when={!removeBranch || version() !== 1}><span>{latest(data)}</span></Show>
      </Errored>
    </>;
  }
  const dispose = render(() => <App />, container);
  let running: Promise<unknown> | undefined;
  try {
    await turn();
    frames.push(container.textContent!); process.stdout.write(JSON.stringify({removeBranch,fail,phase:frames.length,screen:container.textContent})+"\n");
    running = start();
    await turn();
    frames.push(container.textContent!); process.stdout.write(JSON.stringify({removeBranch,fail,phase:frames.length,screen:container.textContent})+"\n");
    recover();
    await turn();
    frames.push(container.textContent!); process.stdout.write(JSON.stringify({removeBranch,fail,phase:frames.length,screen:container.textContent})+"\n");
    recovery.resolve("recovered");
    await turn();
    frames.push(container.textContent!); process.stdout.write(JSON.stringify({removeBranch,fail,phase:frames.length,screen:container.textContent})+"\n");
    end.resolve();
    await running;
    await turn();
    frames.push(container.textContent!); process.stdout.write(JSON.stringify({removeBranch,fail,phase:frames.length,screen:container.textContent})+"\n");
    expect(frames).toEqual(["0ready", fail ? "0failed" : "0changed", fail ? "0failed" : "0changed", "0recovered", "2recovered"]);
    expect(frames[0]).toBe("0ready");
    expect(frames.at(-1)).toBe("2recovered");
  } finally {
    end.resolve();
    recovery.resolve("recovered");
    await running;
    dispose();
  }
});
