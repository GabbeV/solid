## Summary

While an action holds an update, `latest(data)` can display a successful proposal immediately but keep the old content when the same computation throws. Proposing removal of an enclosing `Show`, or adding identity memos, changes whether the error fallback appears. Repeated errors and recovery also disagree with their successful-value counterparts.

Preserve the selected lane when reading an errored lane memo and when converting that error into an `Errored` fallback. The fallback's error signal and recovery use that publication context too; the original error source remains the reset target. This reuses existing state and adds no node fields.

This follows D-41's value/error publication symmetry and the intent of #3886 / #4106. **Five existing intermediate assertions intentionally change:** errors from ahead computations now display where their successful values would. Their recovery assertions remain intact; ordinary readers still wait for the held update.

## How did you test this change?

Based on `next@45648f78`.

- Added 24 JSX timelines covering values/errors, sync/async answers, zero to two identity memos, retained/removing branches, a second error, pending recovery, and an ordinary reader alongside the ahead reader. Added reset, same-value recovery, fallback identity and cleanup coverage.
- Signals suite: **6,759 passed, 2 skipped**.
- Client web suite: **1,779 passed, 1 skipped**, combining the full run with a rerun of artifact-manifest checks after supplying missing generated declarations.
- Targeted error/latest/boundary hydration tests: **176 passed**.
- Signals dev/prod/observe builds, declaration generation, production purity checks, formatting, diff checks and generated rules index pass.

Tests used the native JSX compiler. Local web config supplies the installed jest-dom setup explicitly; dependencies use the checkout's required seroval 1.7.0. Existing unchanged web artifacts were supplied from the local baseline checkout. The complete SSR suite was not run.

### Size — caps unchanged

Measured with the repository's Rolldown harness against next (the preceding `4fe75321` has identical runtime sources):

| Scenario | Minified change | Brotli change |
| --- | ---: | ---: |
| Ordinary core / store / until+refresh / simple render | 0 B | 0 B |
| isPending/latest | +32 B | +5 B |
| Hydrating app, no stores | +173 B | +71 B |
| CSR app with boundaries | +177 B | +79 B |

The last two scenarios exceed their existing Brotli caps by **34 B and 57 B** respectively, with real minified growth. This draft leaves those gates failing for maintainer review; it does not raise caps or claim performance improvements.

