import { mergeConfig } from "vitest/config";
import config from "./vite.config.ts";
export default (env: any) => mergeConfig(config(env), {
  resolve: { alias: [{ find: /^(?:\.\.\/)+src\/index\.js$/, replacement: "/workspace/layered-next-4fe75321/packages/signals/dist/dev.js" }] }
});
